# E6 Python stdio independent review

Read-only scoped review of the five stopped files listed in /private/tmp/e6-device-stdio.md. All five hashes match /private/tmp/e6-device-stdio-stopped.json. No own JS producer review, product edits, Electron/native, Python consumer execution, installs or builds.

## Actionable findings

1. **P2 — verifier rejects every successful real connect trace.** `tests/desktop/device-ui-stdio-run.mjs:342` counts all providerTrace rows with step=connect and requires exactly1. Actual `createFakeDeviceProvider` in `apps/desktop/src/main/device-broker/fake-provider.ts:601–603` appends a not-sent row before invoke and a sent row after success; its connect override uses that guarded exchange. Thus one successful connect yields2 rows and the oracle will reject an otherwise successful native run. The unit fixture at device-ui-stdio-test.mjs:45 supplies only one unqualified connect row, masking this. Fix by requiring the one sent connect dispatch and its matching not-sent row/operationId, rejecting extra connect operations, and add a realistic paired trace positive regression. Confirmed with /private/tmp/e6-stdio-review-probe.mjs: replacing only that fixture trace with the actual paired shape causes `2 !== 1`.

2. **P2 — serialized process polling can defeat the outer deadline and defer survivor cleanup indefinitely in practice.** `device-ui-stdio-run.mjs:519–548` appends a processTable call to `pending` every50ms regardless of whether the previous poll has completed. processTable has a5second per-call timeout. Slow/hung ps can therefore accumulate up to about2400 queued calls during the120second watchdog. After killing Electron, finally clears the interval but awaits the entire pending chain before writing logs/checking/killing survivors. With repeated5second timeouts this can postpone cleanup for hours, despite the claimed bounded watchdog. Use one in-flight poll (skip overlapping ticks) with bounded final observation and ensure owned-child cleanup remains reachable if monitoring fails. Add a non-native injected slow/rejecting monitor regression; no need to launch Electron to verify the scheduling fix.

## Path/authority/source assessment

Actual Python `Plugin` SDK is copied from E and imported by the consumer through PYTHONPATH; production spawnPluginProcess wraps actual OS stdio, with composition channelOwner supplied by the real runtime. Both consumer IDs are synthetic development namespaces; neither declares a provider or claims builtin identity. Own generated settings resource uses only enabled; mutations route through actual composition/router/persistence worker. Direct host bridge open/visibility is transparently a fixture driver, not generic renderer/gesture evidence. No legacy migration gate is opted in and none is claimed by this producer.

Owner/direction/request-ID matching is enforced for every response and each request family, including initialize/shutdown. Actual settings revisions/receipts and watched event ACKs are checked. UI data hashes, stable row keys/versions, transfer correlation and stale revisions are checked. Main records OS parented Python PIDs; normal original-owner exits and zero worker/bridge counters are required. The denied consumer has no device/write permission; unchanged provider trace is checked across its phase. The controlled cancellation path uses a real fake-provider read barrier and Python SDK cancel frame, not substitute endpoint replies.

Bounded additional observation: cancellation oracle only requires reachedAt to be finite, not between request and cancellation timestamps. A temporary probe with an impossible negative reachedAt still passes the UNIT fixture. The current main producer does actually await its barrier; this is a proof-strengthening gap, not evidence of a runtime cancellation defect. Tighten temporal correlation when touching that oracle.

Inspected final artifact identity qCTPbG:329 source entries, no product sources outside E after excluding node_modules dependencies, and no node_modules/@kobrixa fallback in the recorded artifact. Build uses E tsconfig aliases and hashes sources/artifacts/copied Python SDK/config/interpreter; run-built rechecks them and an empty profile. Builder does not independently reject future foreign source resolution, so continue inspecting identity on rebuild. No current source-alias defect demonstrated.

## Validation actually run

- `node --test tests/desktop/device-ui-stdio-test.mjs` — **32 PASS, 0 fail, 0 skip**. Log /private/tmp/e6-stdio-review-oracle.log. These are oracle fixtures, not native acceptance.
- `node /private/tmp/e6-stdio-review-probe.mjs` — PASS: confirms real paired connect trace is rejected and records cancellation timestamp observation above. Probe only imports the inert verifier and extracts the existing UNIT fixture; no native launches.
- Read-only SHA-256 verification of all five stopped files and final artifact source-resolution inspection.

Recommendation: fix the connect-count oracle before interpreting the controller native run; fix monitor scheduling before accepting watchdog/cleanup guarantees. This review does not establish native execution, installed source-free behavior, hardware, renderer migration attachment, request timeout acceptance or full E6 completion. Those limits are correctly disclosed in the producer handoff.
