# E6 stdio fix3 — stopped

Fresh artifact: /private/tmp/kobrixa-device-stdio-76kdQI. Build-only; controller native rerun pending.

Full unchanged ANqvoz/producer.json now passes the corrected verifier, not just the first assertion. Two incorrect oracle assumptions were demonstrated and fixed together:
- registry.ts:29–37 defines development keys as dev: plus exactly 16 lowercase hex digits, not development:. Oracle now enforces the exact pattern.
- manager.ts initializes development generation to 0 (line965); oracle now requires a nonnegative safe integer, allowing initial zero while rejecting negative, fractional, string and unsafe values.

All remaining assertions passed unchanged: original owner/direction/request correlation; paired provider connect; actual device reads/modes; permission refusal; settings CAS/reset/watch/unwatch and durable receipts; dataset revisions/hashes; cancellation temporal correlation; exits/cleanup. No product or producer behavior changes.

Native3 process.json verified: exit0, signal null, timedOut false, outputOverflow false, survivors [], monitorErrors []. Original raw producer/process/native log/identity untouched, hashes in /private/tmp/e6-stdio-fix3-stopped.json. Offline re-verification result: /private/tmp/e6-stdio-fix3-saved-verification.json. Five in-memory mutations of that real receipt still reject: missing RPC, foreign owner, negative generation, extra connect trace, impossible cancellation. Mutations never written over evidence. No new receipt.json created in consumed ANqvoz.

Exactly changed this wave:
- tests/desktop/device-ui-stdio-run.mjs
- tests/desktop/device-ui-stdio-test.mjs
Remaining three WF files unchanged. No product edits, native/Docker execution, installs, commits or shared builds.

Validation from E:
```
node --test tests/desktop/device-ui-stdio-test.mjs
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/eslint --config /private/tmp/e1-final-eslint.config.mjs tests/desktop/device-ui-stdio-{run.mjs,test.mjs}
node tests/desktop/device-ui-stdio-run.mjs --build-only /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 /Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa
```
RED: 55 pass/1 fail with contract-correct positive fixture before oracle fix (/private/tmp/e6-stdio-fix3-red.log). GREEN: 56 pass/0 fail (/private/tmp/e6-stdio-fix3-green.log), including existing lifecycle/monitor tests and new malformed-key/invalid-generation rejection tests. Changed JS lint PASS. Fresh build PASS (/private/tmp/e6-stdio-fix3-build.log); every recorded source/artifact hash rechecked. No TS files changed; no unnecessary broad checks.

Controller rerun (not executed):
```
node tests/desktop/device-ui-stdio-run.mjs --run-built /private/tmp/kobrixa-device-stdio-76kdQI /Users/kingsley/Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/electron/dist/Electron.app/Contents/MacOS/Electron
```

This is offline verification of the controller's successful native process run using a corrected oracle, not a claim of fresh native acceptance. No installed/source-free/hardware/Stage3 completion claim. Installed planning deferred.
