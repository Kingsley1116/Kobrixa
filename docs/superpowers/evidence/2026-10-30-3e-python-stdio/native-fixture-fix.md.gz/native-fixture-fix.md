# E6 stdio fix2 — stopped

Fresh artifact: /private/tmp/kobrixa-device-stdio-ANqvoz. Native NOT RUN. Controller may execute native3.

Native2 H7NRVW failed in denied command with TimeoutError waiting for UI ready; owner completed its full run. Host ui-bridge.ts initialized/ready both return without UI RPC for !catalog.declaresUi(owner) (lines1055/1148). Python _plugin.py invokes @ready only via ui/ready (_ui_ready); command/execute independently dispatches registered handlers. Thus initialize -> command/execute with no UI ready is legitimate for this command-only denied consumer. No initialized notification is required.

Fix: denied branch executes permission checks without the UI-ready wait. UI owner retains its bounded ready wait. Main obtains denied PID from completed command's done log (owner still uses ready), then independently checks the actual OS PID/parent as before. No product or permission validation changes.

Exactly changed this wave:
- tests/desktop/fixtures/device-ui-public/consumer.py
- tests/desktop/device-ui-stdio-main.ts
- tests/desktop/device-ui-stdio-test.mjs

run.mjs and kobrixa-plugin.json unchanged. Full five-file hashes: /private/tmp/e6-stdio-fix2-stopped.json.

Targeted regression uses actual consumer handlers and Python SDK registration with deterministic client doubles, never native acceptance. It proves denied completes without ready and owner still waits. RED TimeoutError: /private/tmp/e6-stdio-fix2-red.log. GREEN full scoped oracle suite: 47 PASS, 0 fail/skip (/private/tmp/e6-stdio-fix2-green.log). Scoped TS and changed TS/JS lint PASS. Build with D deps and Python3.12 PASS (/private/tmp/e6-stdio-fix2-build.log). Fresh source/artifact hashes rechecked.

Commands run from E:
```
node --test --test-name-pattern='command-only denied' tests/desktop/device-ui-stdio-test.mjs
node --test tests/desktop/device-ui-stdio-test.mjs
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/tsc -p /private/tmp/e6-device-stdio-tsconfig.json
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/eslint --config /private/tmp/e1-final-eslint.config.mjs tests/desktop/device-ui-stdio-{main.ts,test.mjs}
node tests/desktop/device-ui-stdio-run.mjs --build-only /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 /Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa
```

H7NRVW failure preserved without modification; process.json independently confirms no survivors. Producer/process/log/identity hashes retained in stopped receipt. qCTPbG also untouched. No Electron/Docker/commit/install/shared build. No native-pass claim.

Installed planning remains deferred. Read-only inspection identified useful existing helpers plus two adaptation needs: verifyLeaf currently omits declared settings from its exact indexed-file set; public device builder currently rebundles/instruments feature entry, so installed mode must instead consume the production buildBuiltinPayloads leaf byte-for-byte and use the actual assembler. No implementation or public harness edits made.
