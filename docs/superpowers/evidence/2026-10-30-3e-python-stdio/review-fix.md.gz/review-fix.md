# E6 Python stdio fix 1 — stopped handoff

Only four authorized producer files changed this wave: device-ui-stdio-run.mjs, device-ui-stdio-main.ts, device-ui-stdio-test.mjs and fixtures/device-ui-public/consumer.py, all under tests/desktop. The fifth WF file, fixtures/device-ui-public/kobrixa-plugin.json, is unchanged. No product, Maxwell producer, dependency, native, or Git mutations.

## Closures

- P2 paired connect oracle: now requires exactly two connect trace rows, not-sent then sent, with the same nonempty operationId and ordered finite times. This matches fake-provider.ts:601–603. Missing/extra/reordered/foreign operation rows fail. The positive fixture uses the real paired shape.
- P2 monitoring: one bounded in-flight poll; ticks while pending are skipped, never queued. Stop clears the interval and waits at most one observation deadline (5500ms). Final observation has its own 5500ms bound. Failure records an error and attempts cleanup of previously observed owned PIDs; successful observation cleans only currently surviving descendants. Kill failures other than ESRCH are retained. Unit tests inject slow, hung and rejected polling and exercise the actual final cleanup helper. No Electron launched.
- Cancellation: original owner/request/direction correlation plus request <= barrier reached <= cancel <= cancelled response timestamps, nonnegative request time and request/cancel/response sequence ordering. Main's wait predicates also require the original owner. Foreign owner, negative/before-request/after-cancel barrier and response-before-cancel receipts fail.
- Native1 diagnosis: qCTPbG failed during owner command because the consumer expected DEVICE_UNAVAILABLE for stale input-mode revision. The actual legitimate response is PLUGIN_E_STALE_RESOURCE. broker.ts:2266 calls stale() for revision mismatch; registry.ts:17–25 defines that error. getSession likewise calls stale for an unknown session. Both fixture expectations and independent oracle now require STALE_RESOURCE. Frozen recovery contract also retains the existing stale-resource family; no product validation/schema changed.

## Validation

Run from E unless absolute temporary script:

```
node --test tests/desktop/device-ui-stdio-test.mjs
/Library/Frameworks/Python.framework/Versions/3.12/bin/python3 -c "import py_compile; py_compile.compile('tests/desktop/fixtures/device-ui-public/consumer.py',cfile='/private/tmp/e6-stdio-fix1-consumer.pyc',doraise=True)"
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/tsc -p /private/tmp/e6-device-stdio-tsconfig.json
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/eslint --config /private/tmp/e1-final-eslint.config.mjs tests/desktop/device-ui-stdio-{main.ts,run.mjs,test.mjs}
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/prettier --check tests/desktop/device-ui-stdio-{main.ts,run.mjs,test.mjs} tests/desktop/fixtures/device-ui-public/kobrixa-plugin.json
node /private/tmp/e6-device-schema-check.mjs
node /private/tmp/e6-device-schema-check-bundle.mjs
node tests/desktop/device-ui-stdio-run.mjs --build-only /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 /Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa
```

RED recorded before implementation in /private/tmp/e6-stdio-fix1-red.log: corrected positive receipt rejected; monitor regressions fail because helper absent. Final GREEN /private/tmp/e6-stdio-fix1-green.log: 46 PASS, 0 fail/skip. All listed compile/types/lint/format/schema checks PASS. Build-only PASS (/private/tmp/e6-stdio-fix1-build.log).

Fresh unconsumed artifact: /private/tmp/kobrixa-device-stdio-H7NRVW. Python3.12 actual interpreter recorded in identity. Every recorded artifact/source hash rechecked; all non-node_modules recorded sources are inside E. Failed qCTPbG preserved: all its original artifact hashes still match, and producer failure/identity hashes are recorded separately. Nothing was rerun against it.

Controller-only next command (NOT executed):
```
node tests/desktop/device-ui-stdio-run.mjs --run-built /private/tmp/kobrixa-device-stdio-H7NRVW /Users/kingsley/Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/electron/dist/Electron.app/Contents/MacOS/Electron
```

Native acceptance remains NOT RUN for this fresh artifact. Unit receipts and build success are not native success. No hardware, installed/source-free, renderer migration, full E6/Stage3, or uncontrolled request-timeout acceptance claim. Cleanup is best effort if the OS cannot enumerate/kill processes, and any recorded monitor error prevents successful receipt.

## Stopped hashes

Full artifact hash map and five WF source hashes: /private/tmp/e6-stdio-fix1-stopped.json.

Identity SHA256: `64ba214846e060dfe7cf94b618ef8d3054805ebe86999ef29417ffa25b5f483e`

- `tests/desktop/device-ui-stdio-run.mjs`: `e2a0d1a4df60a4b4b3b118974792e68f3193f718a5f2d3fc3f973d73344b2897`
- `tests/desktop/device-ui-stdio-main.ts`: `ddfdd12b200920315cd32c16156e64208dd5ecf06f26ae279a9b9dd768eebc59`
- `tests/desktop/device-ui-stdio-test.mjs`: `5d24667761bfbe05a04e7914078b437d78abfaee594a8df7854dc0d76ec74efa`
- `tests/desktop/fixtures/device-ui-public/consumer.py`: `f0888daeb86458d7624fd09632e34445f1707a2e8919b20e423034c15ab49dfa`
- `tests/desktop/fixtures/device-ui-public/kobrixa-plugin.json`: `9caa7684571e7b253d9fde3e2d06b616cbee1098b884dc3aac72c6c57a32fa8d`
