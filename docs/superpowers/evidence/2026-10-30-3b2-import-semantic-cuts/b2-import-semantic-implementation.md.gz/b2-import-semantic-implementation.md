# RF5 eight semantic cuts — stopped implementation

Seven-file write set and exact SHA-256 hashes below. Pressure role/renderer changes are already committed separately; preserved. No product/pressure-core/raw-capture changes, staging, commit, native, build, or install by this agent.

## Integrated behavior

Explicit selectors: `semantic-eight`, or individually `before-plan`, `after-plan`, `before-attempt`, `after-attempt`, `before-skip`, `after-skip`, `before-barrier`, `after-barrier`. Existing `publication-six` and its six individual publication selectors remain supported unchanged.

Each selected semantic trial has a fresh profile: real producer pause, external supervisor SIGKILL, three fresh host reopens, public SDK read/CAS delete, extra reopen. Original load remains 50 actual 8 MiB sources (400 MiB), with actual synthetic mapping to equally sized targets. Ordinary cuts expect 50 targets, then49 after deletion; trusted-host skip expects49, then48. Skip journal evidence is recorded before admission, without a fabricated ticket. This is trusted-host skip, not UI-confirmation proof.

Forwarders observe actual plan/admit/record/publication methods; current admitted owner is captured from coordinator load. Historical tickets remain immutable for reconciliation. Barrier evidence comes from actual composition writer lifecycle and actual durable auxiliary readback; there is no artificial second restore. Actual external process sequence and bounded transport hash/offset evidence reuse existing producer machinery. Test fixtures do not constitute native evidence.

Harness now explicitly dispatches only the eight named semantic slices to assertSemanticPhase, preserving the six-cut oracle, pressure branch, and full-foundation partial-report rejection. New direct regression passes each of eight valid phase receipts through verifyRunReceipt, rejects missing writer evidence, and rejects the same receipt at verifyFoundationReports.

Aggregate output is `partial-import-semantic-trials`, `rf5Complete:false`. Full18 matrix, raw/consumption, pre-raw fresh-window capture and stale settings nonce remain OPEN. No overall RF5 or foundation PASS claim.

## Scoped verification

From E, using D installed tools and existing temporary source aliases:

```sh
node --experimental-transform-types --import /private/tmp/b2-semantic-test-alias.mjs --test tests/desktop/import-boundaries.test.mjs
# 24 PASS
node --test --test-name-pattern='slice' tests/desktop/plugin-persistence-import.test.mjs
# 45 PASS
node --experimental-transform-types --import /private/tmp/b2-semantic-test-alias.mjs --test --test-name-pattern='pressure builtin roles|T7fix' tests/desktop/plugin-persistence-interop.test.mjs
# 22 PASS
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/tsc -p /private/tmp/b2-semantic-tsconfig.json
# PASS
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/eslint --config /private/tmp/e1-final-eslint.config.mjs tests/desktop/import-boundaries.ts tests/desktop/import-boundaries.test.mjs tests/desktop/plugin-persistence-import.ts tests/desktop/plugin-persistence-import.test.mjs tests/desktop/plugin-persistence-main.ts tests/desktop/plugin-persistence-run.mjs tests/desktop/plugin-persistence-harness.mjs
# PASS
node --check tests/desktop/plugin-persistence-run.mjs
node --check tests/desktop/plugin-persistence-harness.mjs
git diff --check
# PASS
```

Logs: /private/tmp/b2-semantic-{tests,six-regression,supervisor,types,lint}.log. 91 scoped tests total, no broad suite.

## Controller native command (not executed)

Use the same native-capable isolated environment and dependency/source resolution as existing publication/pressure runs, with current valid stopped-owner handoff receipt and fresh absolute output. No consumed profile reuse:

```sh
PERSISTENCE_HANDOFFS=/absolute/current-handoffs.json \
PERSISTENCE_EVIDENCE=/absolute/fresh-semantic-eight.json \
node --experimental-transform-types tests/desktop/plugin-persistence-run.mjs \
  --case=import-restart --import-trial=semantic-eight
```

On current E/D split, also use `--import /private/tmp/b2-semantic-test-alias.mjs` as existing source-resolution setup requires; Linux controller should use its existing image dependencies/resolution, not a copied macOS path. To probe one cut first, replace `semantic-eight` with any individual selector above and choose a new output path. Full selector implies eight separate five-host trials (40 host processes). Preflight remains mandatory and refuses missing/invalid handoff prerequisites. This command runs the existing producer build/native path only under controller ownership.

## Stopped hashes

```json
{
  "head": "43adff45c32d56a92e39478ba179d13ab3b4fda1",
  "files": {
    "tests/desktop/import-boundaries.ts": "c48e3178d59bdc5dea948cb810db4c93228989c3fe914f561c2be3ee993b9d66",
    "tests/desktop/import-boundaries.test.mjs": "9af3d9d79e4515f26c0df9941b1f76e35f2fed79895ee839570773dbb369ad57",
    "tests/desktop/plugin-persistence-import.ts": "c1af9b5e64c060ca5d17bafb2ac65bb47c105744cca8c316984573c6fd53d286",
    "tests/desktop/plugin-persistence-import.test.mjs": "1c4d3c30f10e28a9a03618fffe25a917b37c793fee3fd92b194782d1af32ae0b",
    "tests/desktop/plugin-persistence-main.ts": "595e6ba0990bc20a80542640f1ac0a0dae05ab15aea17688362be41fb2c48c0b",
    "tests/desktop/plugin-persistence-run.mjs": "0e2621226a223deff9f25b80ecc5ba44786b2edc21206cf6c10f803d2d47ef55",
    "tests/desktop/plugin-persistence-harness.mjs": "5c00ba1ed5387bf2194c8f5d57ac698cc6389a2c1baee68b14e9c92c162ef288"
  }
}
```
