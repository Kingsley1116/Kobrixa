import assert from 'node:assert/strict';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {transform} from '/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/esbuild/lib/main.js';
const E='/Users/kingsley/.codex/worktrees/plugin-3e/Kobrixa',candidate='16f2ccc';
const commit=execFileSync('git',['rev-parse',candidate],{cwd:E,encoding:'utf8'}).trim();
for(const name of ['plugin-persistence-import','import-boundaries']){
 let source=execFileSync('git',['show',candidate+':tests/desktop/'+name+'.ts'],{cwd:E,encoding:'utf8'});
 source=source.replace('"./plugin-persistence-import.ts"','"./semantic-plugin-persistence-import.mjs"');
 await writeFile('/private/tmp/semantic-'+name+'.mjs',(await transform(source,{loader:'ts',format:'esm',target:'node22'})).code);
}
const {SEMANTIC_IMPORT_BOUNDARIES,assertSemanticSequence}=await import('/private/tmp/semantic-import-boundaries.mjs');
const root='/private/tmp/kobrixa-b2-semantic-native-16f2ccc';
const dirs=await readdir(root),one=p=>{const v=dirs.filter(x=>x.startsWith(p));assert.equal(v.length,1);return root+'/'+v[0];};
const folder=one('kobrixa-persistence-'),controller=one('kobrixa-import-controller-');
const phases=['kill','reopen1','reopen2','reopen3','deleted'],trials=[];
for(const trial of SEMANTIC_IMPORT_BOUNDARIES){
 const reports=[];
 for(const phase of phases){
  const report=JSON.parse(await readFile(`${folder}/import-${trial}-${phase}.receipt.json`));
  assert.equal(report.commit,commit);
  if(phase!=='kill')assert.deepEqual(report.cleanup,{workers:0,listeners:0,errors:[],children:0});
  reports.push(report);
 }
 await assertSemanticSequence(reports);trials.push({trial,reports});
}
const hash=b=>createHash('sha256').update(b).digest('hex');
const rendererBytes=await readFile(controller+'/renderer-build/renderer-artifact.json'),renderer=JSON.parse(rendererBytes);
let artifactFiles=0;
for(const [name,expected] of Object.entries(renderer.sha256)){
 assert.equal(hash(await readFile(renderer.root.replace('/evidence',root)+'/'+name)),expected);artifactFiles++;
}
const build=folder+'/build',main=await readFile(build+'/main.cjs');
assert.equal(hash(main),trials[0].reports[0].bundleSha256);
const indices=await Promise.all(['acceptance-builtin-import','acceptance-builtin-recording','acceptance-builtin-settings'].map(n=>readFile(build+'/plugins/'+n+'/resource-index.json')));
const artifact=hash(Buffer.concat([main,await readFile(build+'/worker.cjs'),Buffer.from(hash(rendererBytes)),Buffer.from('null'),...indices]));
for(const trial of trials)for(const r of trial.reports)assert.equal(r.artifactSha256,artifact);
let originalBytes=0;
for(const file of trials[0].reports[0].evidence.importSlice.originals){const bytes=await readFile(`${folder}/synthetic/${file.name}`);assert.equal(hash(bytes),file.sha256);originalBytes+=bytes.length;}
assert.equal(originalBytes,419430400);
console.log(JSON.stringify({candidate:commit,status:'eight-semantic-trials-scoped-pass',folder,controller,trials:trials.map(t=>({trial:t.trial,pids:t.reports.map(r=>r.pid)})),originalBytes,artifactFiles,artifact,fullRF5:false},null,2));
