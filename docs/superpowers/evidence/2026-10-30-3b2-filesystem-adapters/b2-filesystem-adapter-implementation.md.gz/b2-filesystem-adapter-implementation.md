# B2 priority2 filesystem/engine slice — stopped

Only two authorized test files changed:
- apps/desktop/src/main/plugins/persistence/filesystem.test.ts
- apps/desktop/src/main/plugins/persistence/atomic-store.test.ts

No product changes, framework, main files, native execution, build, install or Git operation.

## Scope and result

12 new focused cases PASS:

- Filesystem3: actual opened descriptor with repeated positive3-byte writes and exact readback, then zero-progress rejection with no appended bytes; explicit unsupported directory-sync policy versus supported-adapter ENOTSUP; same policy versus EIO. Descriptor closure is checked with stale-handle rejection.
- AtomicStore9: short positive writes; zero progress; ENOSPC,EDQUOT,EACCES,EROFS after a real3-byte prefix; supported directory-sync ENOTSUP/EIO at object-directory sync before head publication; explicit unsupported directory-sync policy successful replacement.

Each engine case seeds a real old record with the existing setup/stage helpers. It retains exact ticket/old receipt, raw old/head bytes+hash, adapter calls/outcome/error, pre-cleanup quota, abort result assertions, resulting receipt/head, post-cleanup quota, and fresh-epoch readback. Failures prove no replacement of head.json and byte-identical old head, retain reservation charge until abort, then release reservations. Success proves the exact full new record and receipt. Every case disposes the original store, reopens the same filesystem under a new host/process epoch, rejects the old handle, verifies exact metadata/payload SHA and head bytes, and checks one durable record, exact committed bytes, zero reserved bytes and two available write slots. Both stores dispose successfully.

Important contract distinction: NodePersistenceFs chooses directory-sync capability explicitly. `directorySyncSupported:false` reports file-sync-only and skips the unsupported call. A supported adapter throwing ENOTSUP or EIO propagates failure without silently downgrading durability. This slice tests both paths rather than inventing an ENOTSUP fallback. EIO is not mislabeled successful/file-sync-only.

## Retained raw evidence

[/private/tmp/b2-filesystem-adapter-evidence-index.json](/private/tmp/b2-filesystem-adapter-evidence-index.json) lists12 actual adapter-evidence.json files with SHA256. Their original temporary roots and filesystem bytes remain on disk; tests deliberately retain them on success and assertion failure. Nine engine receipts have complete:true and successful cleanup observations. Three adapter receipts carry operation traces; their PASS status is supplied by the scoped test run, not a fabricated native receipt.

Representative retained roots:
- short replacement: /private/var/folders/mx/g0rnwxh14t93mtqb06px7x400000gn/T/atomic-InuVnW
- zero progress: /private/var/folders/mx/g0rnwxh14t93mtqb06px7x400000gn/T/atomic-dhXmef
- ENOSPC: /private/var/folders/mx/g0rnwxh14t93mtqb06px7x400000gn/T/atomic-5OpDJi
- EIO directory sync: /private/var/folders/mx/g0rnwxh14t93mtqb06px7x400000gn/T/atomic-xdjDI2
- explicit file-only policy: /private/var/folders/mx/g0rnwxh14t93mtqb06px7x400000gn/T/atomic-490kdj

No assertion failure occurred in the focused run. Injection results are retained as expected test evidence, not reported as actual disk exhaustion.

## Exact checks

From E, installed D executables, E source aliases:

```
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/vitest run --config /private/tmp/b2-fs-adapter-vitest.config.mjs -t 'B2 adapter evidence'
```

12PASS,81existing tests not selected/skipped,2files. No claim of93PASS or a full suite. Log: /private/tmp/b2-fs-adapter-tests.log.

```
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/tsc -p /private/tmp/b2-fs-adapter-tsconfig.json
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/eslint -c /private/tmp/e1-final-eslint.config.mjs apps/desktop/src/main/plugins/persistence/filesystem.test.ts apps/desktop/src/main/plugins/persistence/atomic-store.test.ts
```

Both PASS; noEmit. Existing helpers were reused; setup only gains a returned root and optional explicit directory-sync policy for the new tests. Existing default behavior is preserved.

## Stopped SHA256

- filesystem.test.ts: 41da8809d77c15941c3a97ef400735fc37d198d9930a76fa8bcb2b47bd551047
- atomic-store.test.ts: 155c0bf74a54d08a85bb35d1ed4ec81893ca22717306d727e1a93756a5ccfada

This is N07/N11 filesystem/engine subproof on the current macOS execution host. It is NOT full public-wire §723 closure, actual disk exhaustion/quota exhaustion/permission revocation, Windows evidence, process-kill/power-loss proof or B2/Stage3 closure. Writes stopped.
