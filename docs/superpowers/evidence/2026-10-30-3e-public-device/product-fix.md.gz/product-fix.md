# E6 feature form-sync fix — stopped handoff

All three authorized product files are stopped. No generic host sync change, E6 harness edit during this fix, native execution, new native artifact, commit, install or shared build.

Native2 evidence: pENBL4 producer ui.form273 carried identical values with revision2→3, immediately preceding candidate command274 for the original row. Feature unconditionally cleared rows/incremented discovery on every form notification, so the synchronized row action invalidated itself. The same defect affected mode selection.

## Change

`uiEvent(ui.form)` still advances formRevision and stores the newest accepted form, rejecting old/equal revisions as before. It now compares scalar dependencies before invalidating published data:
- transport or Wi-Fi address change advances discovery, clears candidates and removes their accepted dataset revision;
- input-port change clears modes, modeIdentity and their accepted dataset revision;
- identical values preserve candidate/mode rows, identities, revisions, phase and dirty state;
- transport preferences retain the existing immediate serialized CAS behavior;
- late mode-query adoption additionally requires its original port still to be selected.

Transport/address select a future connection and do not change the current session's mode metadata; port selection does not change discovered connection candidates. Actual session/source/authority and dataset/key/version checks are unchanged. Replay after connect/mode write remains rejected.

## Permanent regressions and exact validation

Public transport fixture now uses the real UiStateRegistry for initial form binding and syncForm, then sends the resulting ui.form envelope before command/invoke over its existing real node:worker_threads MessageChannel. SDK/device router/broker remain actual. Other UI/data/settings handlers remain fixtures; these are not Electron/generic-renderer end-to-end claims.

9 new cases: unchanged sync→candidate connect; unchanged sync→mode set; changed transport/address rejection of the old candidate; changed port→back rejection of an old mode; four controller dependency-delta cases including unchanged values and old-revision rejection.

- RED: `D/node_modules/.bin/vitest run --config /private/tmp/e4-vitest.config.mjs -t 'E6:'` — **6 failed, 3 passed, 40 filtered**. Both connect and mode-set calls were absent, reproducing the native symptom. `/private/tmp/e6-feature-form-red.log`.
- GREEN: `D/node_modules/.bin/vitest run --config /private/tmp/e4-vitest.config.mjs` — **49 PASS, 3 files** (original40 + new9). `/private/tmp/e6-feature-form-green.log`.
- `D/node_modules/.bin/tsc -p /private/tmp/e4-tsconfig.json` — PASS; `/private/tmp/e6-feature-form-types.log`.
- `D/node_modules/.bin/eslint --config /private/tmp/e1-final-eslint.config.mjs` on exact3 files — PASS; `/private/tmp/e6-feature-form-lint.log`.
- Prettier on exact3 files, scoped git diff --check — PASS.

D = `/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa`; all product source aliases point to E. No broad desktop suites rerun. Product fix awaits controller review/native confirmation. A separate later harness fix will have its own report and hashes.

## Exact stopped write set / SHA-256

- `plugins/device-ev3/src/controller.ts` — `cdf0eebf15244287fe9832de57fd2bdde40c1ab4d8c3def41e9833650cc06117`
- `apps/desktop/src/builtin-features/device-ev3/controller.test.ts` — `a3c3bb8b438340a60ab9e7d6e6947577b464822a34c965cbf2e86d9de524cefa`
- `apps/desktop/src/builtin-features/device-ev3/public-transport.test.ts` — `5af0303a12a68136914a2ccd2037c029cbc5c214601d2270e8d177fd0248acd6`

Machine-readable receipt: `/private/tmp/e6-feature-form-fix-stopped.json`.
