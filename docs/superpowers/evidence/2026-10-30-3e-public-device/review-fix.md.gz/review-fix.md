# E6 JS harness review fixes — stopped

Both P2 findings in e6-public-review.md addressed within exactly the four harness files below. Product form-sync fix is separately stopped/reported in `/private/tmp/e6-feature-form-fix.md` (49 PASS), now controller-committed 3ed573b. No product edits in this harness wave.

Capture: production pluginUiWindow establishes the synchronous three-key freeze before either SettingsStore.set. Actual SettingsStore/bootstrap tests preserve canonical and whitespace-padded original bytes, permit unrelated settings writes, and detect any legacy write. Native fixture seeds the padded original address; observation-only storage audit requires unchanged original capture and no later three-key writes.

Action proof: each of five commands requires its own expected native target identity, node, pointerdown/up, exact host interaction invocationId and binding, and ordered successful operation RPC. Row actions additionally match selected key/version/dataset/revision to an actually published page and selected target label. Refresh read must occur after its invocation and before the next action. No generic host synchronization bypass. This is a structural evidence oracle, not cryptographic protection against a malicious producer.

Validation (no Electron): RED 23 PASS / 8 FAIL; GREEN 31 PASS / 0 FAIL. New negatives reject unrelated/reused clicks, wrong node/row, operation before invocation, and legacy writes after seed; two actual bootstrap cases cover raw bytes. Scoped TypeScript, ESLint, Prettier and build-only PASS. No broad suite rerun.

Commands from E:
```
KOBRIXA_E6_DEPS=/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa node --test tests/desktop/device-ui-public-test.mjs
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/tsc -p /private/tmp/e6-tsconfig.json
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/eslint --config /private/tmp/e1-final-eslint.config.mjs tests/desktop/device-ui-public-{run.mjs,main.ts,renderer.tsx,test.mjs}
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/prettier --check tests/desktop/device-ui-public-{run.mjs,main.ts,renderer.tsx,test.mjs}
KOBRIXA_E6_DEPS=/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa node tests/desktop/device-ui-public-run.mjs --build-only
```
Logs: `/private/tmp/e6-harness-review-{red,green,types,lint,format,build}.log`.

## Fresh controller-only native command
```
KOBRIXA_E6_DEPS=/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa node tests/desktop/device-ui-public-run.mjs --run-built /private/tmp/kobrixa-device-public-01SG24
```
Fresh profile; never rerun consumed GLjOG6/pENBL4. No native execution or successful native acceptance claimed. Existing source-free/cross-language/hardware limitations remain. Build emits ordinary chunk-size and classic fixture-script warnings, not failures. Default dependencies remain checkout root; D is an explicit override.

## Exact changed files and stopped SHA-256
- `tests/desktop/device-ui-public-run.mjs` — `75fd27cf888db786c5236b11c324a962f7d1fc4680110b7b60a40623ce1c7951`
- `tests/desktop/device-ui-public-main.ts` — `46f9a31ff0736d7e973af090aa7440f1c9e2c3cc26d6fbef512498e69a79379f`
- `tests/desktop/device-ui-public-renderer.tsx` — `6ccd5d2d15838fd5194a59590876c47d6882b3afcb2c1e73de9492f127ba4df8`
- `tests/desktop/device-ui-public-test.mjs` — `43cab9be3bc6e7625e0b1a22f565414f4a0dd6ad586b100d79ae8aff828bcddc`

Artifact identity SHA-256: `a7ea74af232d53865e73dc736d02c34e9b792843d9cc6e9c7e49909807b19ac3`. Machine receipt: `/private/tmp/e6-harness-review-fix-stopped.json`. All four files stopped. No native/install/shared build/commit.
