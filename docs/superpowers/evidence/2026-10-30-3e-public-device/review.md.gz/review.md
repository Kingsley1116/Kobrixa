# E6 JS public producer — independent read-only review

Verdict: **two validated P2 findings in the producer/evidence**, no demonstrated product validation defect. Review bounded to `tests/desktop/device-ui-public-{run.mjs,main.ts,renderer.tsx,test.mjs}` and the updated handoff. Supporting production retirement/settings-freeze/authoritative-reader seams were inspected read-only. No own Python stdio producer review, no product writes, no Electron launch.

## P2 — Freeze before bootstrap settings writes

Location: `tests/desktop/device-ui-public-renderer.tsx:45–47`.

The fixture seeds original localStorage, then calls `settingsStore.set("rightPanel", "plugins")` and `settingsStore.set("locale", "en")` before `pluginUiWindow()` constructs the production migration adapter. SettingsStore.set invokes save; until freezeDevicePreferences has run, save writes all three legacy connection keys. A probe using the actual E SettingsStore and the current exact seed recorded writes to `kobrixa.lastWifiAddress`, `kobrixa.connectionMode`, and `kobrixa.rememberWifiAddress` before the owner/freeze call. The current canonical seed happens to retain the same bytes, concealing the prohibited early writer. A whitespace-bearing remembered address or otherwise normalized legacy value can change before capture, so this ordering cannot substantiate original-byte capture or the freeze-before-startup contract.

Recommendation: construct the per-window production migration owner (or invoke its existing synchronous freeze through the approved adapter) before any SettingsStore.set; perform layout/locale setup afterward. Add a fixture regression that rejects any legacy-key write between original seeding and capture, including a noncanonical-but-supported original byte representation. Do not relax product validators or fabricate a capture. This is a harness ordering fix within the four-file ownership, not a product change.

Evidence: `/private/tmp/e6-public-freeze-probe.log`; temporary probe uses the actual SettingsStore implementation, not a replica.

## P2 — Correlate the exact trusted action, not any recent click

Location: `tests/desktop/device-ui-public-run.mjs:155–163`.

The oracle checks only whether some trusted pointerdown occurred within two seconds before each command. It ignores the recorded node/id/text and driver target, permits the same event to satisfy all five commands, and does not tie candidate/mode action row identity to the triggering input. Thus an unrelated native click followed by unintended automatic device commands is accepted as explicit discovery/connect/refresh/mode input. The native driver does issue separate sendInputEvent calls today, but the independent acceptance oracle fails to enforce that evidence.

Reproduction: copied only the existing UNIT fixture definition to /private/tmp, replaced its entire native-event list with one trusted pointerdown on node `unrelated` / id `not-a-device-action`, and passed the unchanged exported verifier. It returned success with `nativeSteps: 5`. Existing23oracle tests remain green because they remove trust globally, not exact-action correlation.

Recommendation: require distinct, ordered input events matching the expected actual node/driver target for each command and correlate their binding/row key/version/dataset revision where applicable. Reject reuse and unrelated-node events; associate each command's resulting operation with that invocation/phase rather than just presence anywhere in the trace. Add negative cases for one click reused across commands, wrong node, wrong row, and operation before its corresponding invocation. This does not require a custom host endpoint or weakening the real trusted action path.

Evidence: `/private/tmp/e6-public-oracle-probe.log`; result is intentionally synthetic rejection-test evidence, not a native receipt.

## Checks without new findings

- Navigation correction uses the actual createWindowRetirementHandler, capturing/retiring original scope before authority.invalidate. Its next scope is host-created, device authority stays invalid until did-navigate, and registerPersistenceWindow170's trusted sender/frame/document listeners remain active. No product guard was edited or bypassed. The generic settings mount now receives the actual settings.open binding rather than a stale URL scope.
- Producer uses composeDesktopMain, production launcher/MessageChannel, original preload, real UI/persistence IPC registration and shipped worker. Wrappers observe calls/results rather than replace handlers. Synthetic fake-provider metadata adaptation is declared as fixture behavior; it is not physical EV3 proof.
- Production `plugins/device-ev3/src/main.ts` is bundled with its actual controller/SDK imports; PID logging is additive. Build resolver rejects foreign workspace source and @kobrixa node_modules fallback; validated original manifest/resources/index replace the static provider source once.
- Original six file fields plus three captured localStorage values are asserted as nine migrated values and the driver waits on the actual authoritative host, which reads the worker and checks migration readiness. Settings update/reset traverse the actual binding and CAS service. This is not a restart/reopen durability test; the handoff correctly leaves that unclaimed. Migration readiness checkpoints are host observations, not independently replayed persistence publication evidence.
- Build-only mode does not emit native PASS. Native wrapper requires exit0, no watchdog timeout, valid artifact hashes and successful oracle. The handoff explicitly retains the first native failure, marks fresh pENBL4 native pending, and excludes hardware/source-free/full Stage3 closeout. A future successful run should still not close the two findings above without correction.

## Verification performed

- `node --test tests/desktop/device-ui-public-test.mjs`: **23 PASS**, no Electron; `/private/tmp/e6-public-review-unit.log`.
- `node /private/tmp/e6-public-oracle-probe.mjs`: reproduced acceptance of one unrelated trusted input for five commands.
- `node /private/tmp/e6-public-freeze-probe.cjs`: reproduced all three pre-freeze legacy writes using E SettingsStore. The temporary probe was bundled only under /private/tmp using installed D esbuild; no shared output.
- Stopped four source hashes match /private/tmp/e6-device-public-stopped.json. pENBL4 identity hash and every recorded artifact hash match; production entry recorded. Details: `/private/tmp/e6-public-review-hashes.json`.

No native acceptance verdict. No files outside /private/tmp written. Both findings are bounded to the JS harness/oracle; no change requested to production validation.
