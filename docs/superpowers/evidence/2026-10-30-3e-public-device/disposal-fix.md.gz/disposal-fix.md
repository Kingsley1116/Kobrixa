# E6 native3 disposal-contract fix — stopped

Harness-only correction. Native3 completed migration/open/reopen/discover/connect/read/modes/settings CAS/reset, then the driver incorrectly waited for devices/unsubscribe. SDK disposal uses events/unsubscribe (packages/plugin-sdk-js/src/index.ts unwatch). No product changes; renderer unchanged this wave.

Driver now snapshots active device subscription IDs before hide and waits for successful removed:true replies for every distinct ID after that boundary. Oracle reconstructs the same set from original devices/subscribe replies, subtracts prior successful removals, and requires exactly one successful removal per active ID inside the hiding→hidden sequence/time boundary. Existing original reply, owner, sequence and trusted action correlations remain. Unrelated failed stale shutdown disposals are not accepted as hide evidence and do not invalidate successful hide disposal.

Batch audit: evaluated every verifier assertion against the saved native3 trace using a diagnostic-only nonthrowing assertion collector (/private/tmp/e6-audit-trace.mjs, e6-native3-verifier-audit-final.log). For diagnosis only, hiding boundaries were derived from the actual last Close driver input and response616; absent tail checkpoints were placeholders to permit remaining assertions to run. This did NOT change producer.json or create a receipt. All completed-phase checks pass, including raw migration capture, five exact trusted action correlations, row identities, operation phases and settings CAS/reset. Actual device identities at hide are catalog/session/telemetry/authority/connectionRecovery; successful disposal pairs605–616. Settings watch is also disposed (611), separately. Failed unrelated shutdown removals621/623 are outside hide. Remaining failures are the original incomplete stage/failure and unexecuted disable/re-enable/cleanup tail, which require controller native execution. No other completed-phase structural mismatch found.

Validation: 37 Node tests PASS (31 existing +6 disposal negatives). Fixture now uses actual devices/subscribe→events/unsubscribe shape with five distinct IDs, removed:true replies and a later unrelated stale shutdown error. Negatives cover obsolete method, wrong ID, reused ID, removed:false, missing original reply, and reply outside hide. Scoped tsc and ESLint PASS; edited files formatted; fresh build-only PASS. No native, install, shared build or commit.

Commands from E:
```
KOBRIXA_E6_DEPS=/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa node --test tests/desktop/device-ui-public-test.mjs
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/tsc -p /private/tmp/e6-tsconfig.json
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/eslint --config /private/tmp/e1-final-eslint.config.mjs tests/desktop/device-ui-public-{run.mjs,main.ts,renderer.tsx,test.mjs}
KOBRIXA_E6_DEPS=/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa node tests/desktop/device-ui-public-run.mjs --build-only
```
Logs /private/tmp/e6-disposal-{tests,types,lint,format,build}.log.

Fresh controller-only launch (new unconsumed profile):
```
KOBRIXA_E6_DEPS=/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa node tests/desktop/device-ui-public-run.mjs --run-built /private/tmp/kobrixa-device-public-YEbaPE
```

Changed files this wave: run.mjs, main.ts, test.mjs in tests/desktop/device-ui-public-*; renderer.tsx preserved. All four now stopped:
- `tests/desktop/device-ui-public-run.mjs` — `b2fbc8a9e0a7b15f8069014c72be4bc5372bd05d4856ac5777dc203c0616103c`
- `tests/desktop/device-ui-public-main.ts` — `00c763c72f1518598d018aea8554214c606d69c8c01bfe5f1e7bcba9344d9106`
- `tests/desktop/device-ui-public-renderer.tsx` — `6ccd5d2d15838fd5194a59590876c47d6882b3afcb2c1e73de9492f127ba4df8`
- `tests/desktop/device-ui-public-test.mjs` — `badeef46e76d64500d646da427e2376691db03b9884b71e987a7f5f2d1b92a78`

Artifact identity SHA-256: `1dea5c5e37bc390d0cb671c1e6488b5a0e195290b8157910199dd051ca93db9f`. Receipt: `/private/tmp/e6-disposal-fix-stopped.json`. No native acceptance claimed; source-free/cross-language/hardware limits unchanged.
