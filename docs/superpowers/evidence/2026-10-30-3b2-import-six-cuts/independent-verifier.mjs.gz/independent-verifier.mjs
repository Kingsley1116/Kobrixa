import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {transform} from '/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/esbuild/lib/main.js';
const E='/Users/kingsley/.codex/worktrees/plugin-3e/Kobrixa';
const source=execFileSync('git',['show','6f2496c:tests/desktop/plugin-persistence-import.ts'],{cwd:E,encoding:'utf8'});
await writeFile('/private/tmp/b2-import-six-6f2496c-oracle.mjs',(await transform(source,{loader:'ts',format:'esm',target:'node22'})).code);
const {assertImportTrials,IMPORT_PUBLICATION_TRIALS}=await import('/private/tmp/b2-import-six-6f2496c-oracle.mjs');
const root='/private/tmp/kobrixa-b2-import-six-6f2496c';
const folder=root+'/kobrixa-persistence-CIUKSV';
const phases=['kill','reopen1','reopen2','reopen3','deleted'];
const trials=[];
for(const trial of IMPORT_PUBLICATION_TRIALS){
 const reports=[];
 for(const phase of phases){
  const report=JSON.parse(await readFile(`${folder}/import-${trial}-${phase}.receipt.json`));
  assert.equal(report.commit,'6f2496cce3d393c85809266c97bafefb1dbcae53');
  if(phase!=='kill'){assert.deepEqual(report.cleanup,{workers:0,listeners:0,errors:[],children:0});}
  reports.push(report);
 }
 trials.push({trial,reports});
}
assertImportTrials(trials,'publication-six');
const hash=b=>createHash('sha256').update(b).digest('hex');
const rendererFile=root+'/kobrixa-import-controller-7FfHTz/renderer-build/renderer-artifact.json';
const rendererBytes=await readFile(rendererFile), renderer=JSON.parse(rendererBytes);
let artifactFiles=0;
for(const [name,expected] of Object.entries(renderer.sha256)){
 assert.equal(hash(await readFile(renderer.root.replace('/evidence',root)+'/'+name)),expected);artifactFiles++;
}
const build=folder+'/build';
const main=await readFile(build+'/main.cjs');
assert.equal(hash(main),trials[0].reports[0].bundleSha256);
const indices=await Promise.all(['acceptance-builtin-import','acceptance-builtin-recording','acceptance-builtin-settings'].map(n=>readFile(build+'/plugins/'+n+'/resource-index.json')));
const artifact=hash(Buffer.concat([main,await readFile(build+'/worker.cjs'),Buffer.from(hash(rendererBytes)),Buffer.from('null'),...indices]));
for(const trial of trials)for(const r of trial.reports)assert.equal(r.artifactSha256,artifact);

const originals=trials[0].reports[0].evidence.importSlice.originals;
let originalBytes=0;
for(const file of originals){
 const bytes=await readFile(`${folder}/synthetic/${file.name}`);
 assert.equal(createHash('sha256').update(bytes).digest('hex'),file.sha256);
 originalBytes+=bytes.length;
}
assert.equal(originalBytes,419430400);
console.log(JSON.stringify({candidate:'6f2496c',status:'six-trials-scoped-pass',trials:trials.map(t=>({trial:t.trial,pids:t.reports.map(r=>r.pid)})),originalBytes,artifactFiles,artifact,fullRF5:false},null,2));
