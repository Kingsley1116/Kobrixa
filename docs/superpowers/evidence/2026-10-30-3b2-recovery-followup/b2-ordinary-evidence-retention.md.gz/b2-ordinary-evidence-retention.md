# Ordinary unresolved evidence retention — stopped

Implemented only the controller-approved retention correction. Ordinary first-create with missing head/no previous still returns unavailable (`recovery-blocked`). No automatic recovery, replay, default, new quarantine mechanism, spec change, or public API change. Already-erased evidence remains unavailable and is not fabricated.

The scanner records unresolved record locations during head validation. Its stale-host staging cleanup now skips tickets for those locations, preserving original intent/sealed and associated staging bytes. Known-safe stale staging for other targets in the same namespace still follows existing cleanup. Import journal classification/quarantine introduced in1979204 is unchanged; its regression tests still pass.

Actual-filesystem regression uses the real AtomicStore/NodePersistenceFs publication hook to snapshot an untagged 8 MiB first-create before the head rename. A second safe sealed write is also produced through the real engine. Three fresh-host-epoch initializations remain blocked; filenames, byte lengths and SHA-256 of all unresolved staging/record files stay identical. The independent safe staging directory is removed; no ordinary payload is quarantined or published. Explicitly removing the original intent in the test still leaves recovery unavailable and does not recreate it.

RED: focused new test failed because intent/sealed entries disappeared (`/private/tmp/b2-ordinary-retention-red.log`).
GREEN: **99 PASS** in recovery-scan/atomic-store/filesystem, including existing import recovery and quarantine-interruption tests (`/private/tmp/b2-ordinary-retention-green.log`).

Commands, from E:
- `node /Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/vitest/vitest.mjs run --config /private/tmp/b2-prepublish-vitest.config.mjs` — 99 PASS. RED used `-t 'unresolved ordinary'`.
- `node /Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/typescript/bin/tsc -p /private/tmp/b2-ordinary-retention-tsconfig.json` — PASS; scoped to these two files and dependencies.
- `node /Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/eslint/bin/eslint.js --config /private/tmp/e1-final-eslint.config.mjs apps/desktop/src/main/plugins/persistence/recovery-scan.ts apps/desktop/src/main/plugins/persistence/recovery-scan.test.ts` — PASS.
- `git diff --check` — PASS. No wholesale formatting.

Exact write set / SHA-256:
- `apps/desktop/src/main/plugins/persistence/recovery-scan.ts` — `48186655a05101b4db4983a69a574352f16bcc4add31a6fbd659cb9f9c6fc4cd`
- `apps/desktop/src/main/plugins/persistence/recovery-scan.test.ts` — `60e30d6a76b469d809ceecab655d5aabecbfcd3181c93be9b2b98b1cdc56b73f`

Observed HEAD: `6f2496cce3d393c85809266c97bafefb1dbcae53`. Machine receipt: `/private/tmp/b2-ordinary-evidence-retention-stopped.json`.
No other repository writes; all concurrent controller/Arch changes preserved. No native, build, install or commit. Writes/checks stopped. Semantic18 matrix remains OPEN.
