import base from '/private/tmp/e1-vitest.config.mjs';
export default {...base,test:{...base.test,include:['apps/desktop/src/main/plugins/persistence/{recovery-scan,atomic-store,filesystem}.test.ts'],maxWorkers:1,cache:false}};
