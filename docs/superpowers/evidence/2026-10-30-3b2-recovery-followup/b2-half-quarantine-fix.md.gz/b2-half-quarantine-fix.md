# Half-quarantine recovery correction — stopped handoff

Base HEAD `8183187e482eb6a2dbfd85e164fffcdd8cf7de01`. Only the two authorized recovery scanner files changed. Other dirty semantic-boundary/import/main/run work was preserved. No native/Docker/build/install/commit, RSS change or spec change.

## Correction

A headless record with a remaining temporary head is now examined even when its objects directory is empty. The existing single-candidate restriction and exact durable pending import journal/attempt/target/metadata/tag checks remain required. For the half-moved state, the exact attempt-named quarantine payload must exist and match both byte length and streamed SHA-256 (buffers <=256KiB). Only then is the original temporary head moved to the unoccupied attempt-named quarantine head destination, with both directories synced.

No payload is published, replayed, deleted or moved back. Existing quarantine destinations are never blindly replaced. Multiple candidates, an occupied head destination, a foreign/corrupt quarantined payload, or a foreign journal association fail closed. Ordinary unavailable/evidence-retention behavior remains intact; no broad multiple-candidate recovery was added.

## RED / GREEN

Actual filesystem regression reproduces the complete sequence: original prepublish snapshot → interrupted first payload quarantine move → restart/fresh admission → second prepublish snapshot → restart. Before the correction it failed at the second AtomicStore.initialize with `recovery-blocked`.

After the correction it verifies:
- two distinct8MiB payloads retained, hash-verified and charged as exactly16MiB temporary bytes;
- both original temporary heads removed from the record directory via safe moves, with matching retained quarantine heads;
- no published head, committed bytes or visible record, and no replay;
- both prior tickets rejected as stale, original ticket/plan values unchanged, exact current/planned import reconciliation remains not-committed;
- repeated scans remain stable;
- foreign payload, occupied head destination, extra candidate and foreign journal association preserve relevant record/staging/quarantine evidence and keep startup blocked.

Commands from E, using installed D tools and existing E-source aliases:

1. RED:
   `node /Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/vitest/vitest.mjs run --config /private/tmp/b2-prepublish-vitest.config.mjs -t 'two consecutive prepublish crashes'`
   Expected1FAIL at second initialization. `/private/tmp/b2-half-quarantine-red.log`.
2. GREEN:
   `node /Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/vitest/vitest.mjs run --config /private/tmp/b2-prepublish-vitest.config.mjs`
   **104PASS / 3files**: recovery-scan, atomic-store, filesystem. `/private/tmp/b2-half-quarantine-green.log`.
3. `D/node_modules/.bin/tsc -p /private/tmp/b2-half-quarantine-tsconfig.json` — PASS, noEmit, only authorized product/test roots.
4. `D/node_modules/.bin/eslint --config /private/tmp/e1-final-eslint.config.mjs apps/desktop/src/main/plugins/persistence/recovery-scan.ts apps/desktop/src/main/plugins/persistence/recovery-scan.test.ts` — PASS.
5. Scoped `git diff --check` — PASS.

D = `/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa`.

Existing six-native evidence remains the controller's frozen6f run. These unit/filesystem results do not relabel it as testing this correction. Real process/power-loss validation of the new correction remains unrun.

## Exact stopped files / SHA-256

- `apps/desktop/src/main/plugins/persistence/recovery-scan.ts` — `f0f2800bd1aa3139d990a1b67e97d93d5214a33d45c19bf1214b572fa1a7fe06`
- `apps/desktop/src/main/plugins/persistence/recovery-scan.test.ts` — `38d885631f21958d4b05567d6984ca122211ae2e2b0da9d256ec2aa715feb50c`

Both files stopped. No further writes planned.
