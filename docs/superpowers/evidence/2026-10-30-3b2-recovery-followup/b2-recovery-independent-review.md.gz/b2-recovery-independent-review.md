# B2 recovery scanner — independent read-only review

Reviewed frozen commits `1979204` + `a8c0ddb` against `f0a8d07`: recovery-scan.ts and its tests, with direct namespace/AtomicStore call-path and B2 contract checks only. No tests, native execution, builds, installation or product edits. Compared scanner files at current HEAD with the frozen tip: no further delta at review time.

Frozen Git blobs:
- recovery-scan.ts: `76320650a94c10eb289785cf37ae8ca91872b3d6`
- recovery-scan.test.ts: `ec0b5a70d0de74b70462c9692e4c388036d1ca85`

## One actionable finding

**P2 — Finish interrupted quarantine before admitting another publication attempt.**

Location: `apps/desktop/src/main/plugins/persistence/recovery-scan.ts:82` (objects-nonempty gate), together with candidate count at line32 and the two moves at lines57–60.

Concrete sequence:
1. Exact pending import candidate A is validated. Its object is moved to `quarantine/A.prepublish.bin`, then the process stops before moving `head.A.tmp`.
2. On restart the record objects directory is empty. The line82 gate skips `quarantinePendingImportCandidate`, so `head.A.tmp` remains indefinitely. The scan succeeds and normal old-epoch staging cleanup runs. Existing interruption test covers this state but stops after `reconcileImport(A) === not-committed`.
3. The fresh host admits attempt B for the same planned record/revision. `admitImport` creates a new ticket and journal association; it has no live A entry to abort. `AtomicStore.publish` removes/replaces only `head.B.tmp`, not A's orphan.
4. If B also stops at the legitimate before-publish boundary, the next startup has one valid B object but **two** temporary heads. The new helper rejects `candidates.length !== 1`; scan reports corrupt and initialization becomes recovery-blocked. The durable journal still proves the exact B candidate, and A's bytes remain safely quarantined, but the scanner's own unfinished move prevents its advertised retry recovery.

This is a source-supported recovery/liveness defect, not an unauthorized publication or data-erasure finding. I did not execute the reproduction. It is distinct from the documented eventual temporary-quota exhaustion: two8MiB candidates fit within the32MiB budget.

Smallest correction: resume the verified two-move quarantine when only the original temporary head plus matching quarantined payload remain, before allowing a fresh import attempt. Require the same exact pending journal/attempt/target/metadata/tag and payload hash; never blindly accept or overwrite an existing quarantine destination, and do not generally relax the multiple-candidate guard.

Regression: extend the actual-filesystem interruption-after-`.prepublish.bin` case through reopen → fresh admission → second pre-head process-loss snapshot → reopen. Require both payloads retained/charged, no published head/replay, exact pending attempt reconciliation, and no stale temporary head blocking recovery. The existing interruption cases at recovery-scan.test.ts:172–191 stop before this second attempt and therefore do not cover it.

## Other requested checks

No additional actionable issue found in this bounded pass:
- Exact authority/hash checks: importDocumentSchema ties the pending publication ticket to its immutable planned attempt; scanner checks journal target/source, incomplete/pending state, null receipt, exact commit ID/filename, target, metadata, tag, mapped bytes/hash, and verifies both journal and candidate payloads before moving anything. Fresh adoption still requires the current host owner; old tickets are not renewed/replayed by scanning.
- Interrupted quarantine retains payload bytes without promoting a head. The issue above is finishing the old metadata move, not missing payload retention.
- Ordinary unresolved first-create remains unavailable. The new unresolved-directory set preserves its intent/seal/evidence while independently safe old staging can be cleaned. Malformed/unknown evidence remains fail-closed; missing intent is not synthesized.
- Original files and quarantined evidence are not automatically deleted. Quarantine payload remains temporary-quota charged. Existing ordinary-unavailable and hash/foreign-attempt/terminal-journal negatives support these boundaries; they do not establish broad crash recovery or full RF5 completion.

Reviewed owner handoff `/private/tmp/b2-prepublish-recovery-fix.md` and design contract sections on pending import retry/evidence and non-destructive quarantine. Its reported98 direct tests/copy probes are prior-owner evidence, not independently rerun here. Report complete; read-only work stopped.
