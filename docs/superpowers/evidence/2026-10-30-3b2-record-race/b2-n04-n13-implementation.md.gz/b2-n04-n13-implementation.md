# N04/N13 slice1 — STOPPED, tested

Only changed file: `apps/desktop/src/main/plugins/persistence/worker.test.ts`.
SHA256: `0c2035aa9ed49e235b50124c427c85f80d514f95c2d6080244260e03c8edd273`.
Diff:101 additions/1 deletion. No product, raw/common, pressure, slice2/3, git, install or native Electron changes.

## Actual sequence

One bounded joint N04/N13 test reuses negativeHost, actual RpcPeer routes/host/worker/Node filesystem and its retained diagnostic path. Existing receipt-writing code is factored into retainNegativeEvidence and reused unchanged by prior16 cases; actual bundle SHA remains included.

Two records are created through public storage begin/chunk/seal/commit, retaining real original receipts. A limit1 list captures the original two-row snapshot; reads pin both revisions. An initial old-read prefix is read before mutation. One replacement is admitted and sealed; while its commit is withheld, actual concurrent beginWrite and delete requests on that target both return STORAGE_CONFLICT/write-in-progress with zero extra reserve. Joint before/after tree/quota/pins/core remain equal.

The replacement commits once; repeated commit returns identical receipt/record. Old-revision replacement and delete separately return revision-mismatch with their own before/after joint snapshots. The other original record is deleted through public CAS; repeated delete returns the same receipt. Original page2 still contains the deleted original revision, with no duplicate/skip; fresh list contains only the new winning record.

Pinned prefix+suffix reconstruct exact original binary bytes across replacement. The deleted record's pin still reads exact original bytes. A new read returns replacement bytes. Three observed backend pins are retained in joint evidence, then explicitly closed; public read rejects the closed handle. Cleanup has one committed record, zero reservations/pinned/temporary bytes and empty core recovery.

Fresh worker/hostEpoch on the same profile verifies exact winning metadata/revision/SHA and publicly read bytes, no resurrection of deleted ID, stale old read/list/write handles, matching quota, no observed pins or recovery errors. Actual wire carries all replies/outcomes and byte chunks, not expected synthetic summaries.

## Verification (each scoped/full/type/lint command run once)

Working directory E: `/Users/kingsley/.codex/worktrees/plugin-3e/Kobrixa`.
D prefix: `/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin`.

- Focused **1 PASS /59 filtered**: `B2_NEGATIVE_EVIDENCE_DIR=/private/tmp/b2-n04-n13-evidence D/vitest run --config /private/tmp/b2-negative-worker-vitest.config.mjs -t 'B2-N04-N13'`. Log `/private/tmp/b2-n04-n13-focused.log`.
- Full file **60 PASS**: `D/vitest run --config /private/tmp/b2-negative-worker-vitest.config.mjs`. Log `/private/tmp/b2-n04-n13-all.log` (43.04s).
- Types exit0: `D/tsc -p /private/tmp/b2-negative-worker-tsconfig.json`; log `/private/tmp/b2-n04-n13-types.log`.
- Lint exit0: `D/eslint --config /private/tmp/e1-final-eslint.config.mjs apps/desktop/src/main/plugins/persistence/worker.test.ts`; log `/private/tmp/b2-n04-n13-lint.log`.
- Scoped git diff --check clean.

Receipt/source/transcript/bundle hashes independently rechecked: `/private/tmp/b2-n04-n13-receipt-check.json`. Retained receipt:
`/private/tmp/b2-n04-n13-evidence/N04-N13-record-race-d8f67dc5-04e4-4b57-8c66-123d7f17784b.jsonl.receipt.json`.
47 actual correlated wire replies and9 joint snapshot phases.
Worker bundle SHA: `b05fdb484f6f87476479bdbc8b991f70a49d982a68dc16c2878c08aecb35f815`.
Transcript SHA: `977c691dabadf489fa072118ee4df9c0bc7a847cd2afcb0d274208aa87ba89cd`.
Candidate field remains null for this working-source run; controller immutable run must bind its own candidate.

## Limits

This proves concurrency against an already admitted sealed replacement, not nondeterministic simultaneous first admission or interrupted publication. Paging is challenged by actual replacement/deletion; elapsed read/list expiry and same-host generation rotation are not added. Fresh-host old-handle invalidation is covered. No child kill/native/Electron/hardware/full-matrix claim. Existing test lock stub and observed-handle ledger (not full private registry census) remain explicit. Temporary test worker compilation only, no shared build. All writes stopped.
