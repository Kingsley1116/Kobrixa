//#region \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
//#endregion
let node_crypto = require("node:crypto");
let node_perf_hooks = require("node:perf_hooks");
let node_worker_threads = require("node:worker_threads");
let node_async_hooks = require("node:async_hooks");
let node_path = require("node:path");
node_path = __toESM(node_path, 1);
let node_fs = require("node:fs");
let node_fs_promises = require("node:fs/promises");
//#region apps/desktop/src/main/plugins/persistence/engine-port.ts
var ownerKey = (owner) => JSON.stringify([
	owner.sourceKey,
	owner.pluginId,
	owner.generation,
	owner.hostEpoch,
	owner.processEpoch
]);
var PublicationGate = class {
	memory;
	words;
	constructor(deadline, memory, byteOffset = 0, initialize = memory === void 0) {
		this.memory = memory ?? new SharedArrayBuffer(16);
		this.words = new BigInt64Array(this.memory, byteOffset, 2);
		if (initialize) {
			Atomics.store(this.words, 0, 0n);
			Atomics.store(this.words, 1, BigInt(Math.floor(deadline)));
		}
	}
	get deadline() {
		return Number(Atomics.load(this.words, 1));
	}
	get dispatched() {
		return Atomics.load(this.words, 0) === 1n;
	}
	shorten(deadline, now = node_perf_hooks.performance.now()) {
		if (deadline <= now) Atomics.compareExchange(this.words, 0, 0n, 2n);
		const value = BigInt(Math.floor(deadline));
		let old = Atomics.load(this.words, 1);
		while (value < old) {
			const seen = Atomics.compareExchange(this.words, 1, old, value);
			if (seen === old) break;
			old = seen;
		}
	}
	dispatch(now) {
		if (now >= this.deadline) return false;
		if (Atomics.compareExchange(this.words, 0, 0n, 1n) !== 0n) return false;
		return true;
	}
};
/** Durable metadata correlation only; this identifier grants no publication/read authority. */
function checkpointRecoveryId(checkpoint) {
	const digest = (0, node_crypto.createHash)("sha256").update("checkpoint-recovery:" + checkpoint).digest("hex");
	return `${digest.slice(0, 8)}-${digest.slice(8, 12)}-4${digest.slice(13, 16)}-8${digest.slice(17, 20)}-${digest.slice(20, 32)}`;
}
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/util.js
function getEnumValues(entries) {
	const numericValues = Object.values(entries).filter((v) => typeof v === "number");
	return Object.entries(entries).filter(([k, _]) => numericValues.indexOf(+k) === -1).map(([_, v]) => v);
}
function joinValues(array, separator = "|") {
	return array.map((val) => stringifyPrimitive(val)).join(separator);
}
function jsonStringifyReplacer(_, value) {
	if (typeof value === "bigint") return value.toString();
	return value;
}
var Cached = class {
	constructor(getter) {
		this._getter = getter;
		this._value = void 0;
	}
	get value() {
		const getter = this._getter;
		if (getter !== void 0) {
			this._value = getter();
			this._getter = void 0;
		}
		return this._value;
	}
};
function cached(getter) {
	return new Cached(getter);
}
function nullish(input) {
	return input === null || input === void 0;
}
function cleanRegex(source) {
	const start = source.startsWith("^") ? 1 : 0;
	const end = source.endsWith("$") ? source.length - 1 : source.length;
	return source.slice(start, end);
}
function floatSafeRemainder(val, step) {
	const ratio = val / step;
	const roundedRatio = Math.round(ratio);
	const tolerance = 4 * Number.EPSILON * Math.max(Math.abs(ratio), 1);
	if (Math.abs(ratio - roundedRatio) < tolerance) return 0;
	return ratio - roundedRatio;
}
function assignProp(target, prop, value) {
	Object.defineProperty(target, prop, {
		value,
		writable: true,
		enumerable: true,
		configurable: true
	});
}
/**
* Whichever object a def's `shape` currently answers from: the one the caller passed until the first read, the frozen copy after it.
*
* Its keys and descriptors read without invoking anything, which is what lets a discriminated union check its discriminator, and the cycle walk read a shape, without resolving a getter that references the schema being constructed. A def that answers `shape` from an accessor of its own has none.
*/
function rawShape(def) {
	const desc = Object.getOwnPropertyDescriptor(def, "shape");
	return desc?.get ? desc.get.raw : desc?.value;
}
function sourceShape(schema) {
	return rawShape(schema._zod.def) ?? schema._zod.def.shape;
}
function deferProp(target, key, getter) {
	Object.defineProperty(target, key, {
		get() {
			const value = getter();
			assignProp(this, key, value);
			return value;
		},
		enumerable: true,
		configurable: true
	});
}
function putProp(target, key, value) {
	if (key in target) assignProp(target, key, value);
	else target[key] = value;
}
/**
* Copies `keys` of `source`'s shape onto `target`, each value passed through `wrap`.
*
* A key the source has resolved is copied through now, so the derived shape states it outright and nothing has to resolve it to learn what it holds. A key the source still defers stays deferred, and reads back through the source's own `shape`, so it resolves once and both shapes get that one schema.
*/
function mirrorShape(target, source, keys, wrap) {
	const raw = sourceShape(source);
	for (const key of keys) {
		const desc = Object.getOwnPropertyDescriptor(raw, key);
		if (!desc.enumerable) continue;
		if (desc.get) deferProp(target, key, () => {
			const value = source._zod.def.shape[key];
			return wrap ? wrap(value, key) : value;
		});
		else putProp(target, key, wrap ? wrap(desc.value, key) : desc.value);
	}
}
function mirrorProps(target, source) {
	for (const key of Reflect.ownKeys(source)) {
		const desc = Object.getOwnPropertyDescriptor(source, key);
		if (!desc.enumerable) continue;
		if (desc.get) deferProp(target, key, () => source[key]);
		else putProp(target, key, desc.value);
	}
}
function mergeDefs(...defs) {
	const mergedDescriptors = {};
	for (const def of defs) {
		const descriptors = Object.getOwnPropertyDescriptors(def);
		Object.assign(mergedDescriptors, descriptors);
	}
	return Object.defineProperties({}, mergedDescriptors);
}
function esc(str) {
	return JSON.stringify(str);
}
function slugify(input) {
	return input.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
var captureStackTrace = "captureStackTrace" in Error ? Error.captureStackTrace : (..._args) => {};
function isObject(data) {
	return typeof data === "object" && data !== null && !Array.isArray(data);
}
var allowsEval = /* @__PURE__*/ cached(() => {
	if (globalConfig.jitless) return false;
	if (typeof navigator !== "undefined" && navigator?.userAgent?.includes("Cloudflare")) return false;
	try {
		new Function("");
		return true;
	} catch (_) {
		return false;
	}
});
function isPlainObject(o) {
	if (isObject(o) === false) return false;
	const ctor = o.constructor;
	if (ctor === void 0) return true;
	if (typeof ctor !== "function") return true;
	const prot = ctor.prototype;
	if (isObject(prot) === false) return false;
	if (Object.prototype.hasOwnProperty.call(prot, "isPrototypeOf") === false) return false;
	return true;
}
function shallowClone(o) {
	if (isPlainObject(o)) return { ...o };
	if (Array.isArray(o)) return [...o];
	if (o instanceof Map) return new Map(o);
	if (o instanceof Set) return new Set(o);
	return o;
}
var propertyKeyTypes = /* @__PURE__*/ new Set([
	"string",
	"number",
	"symbol"
]);
function escapeRegex(str) {
	return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function clone(inst, def, params) {
	const cl = new inst._zod.constr(def ?? inst._zod.def);
	if (!def || params?.parent) cl._zod.parent = inst;
	return cl;
}
function normalizeParams(_params) {
	const params = _params;
	if (!params) return {};
	if (typeof params === "string") return { error: () => params };
	if (params?.message !== void 0) {
		if (params?.error !== void 0) throw new Error("Cannot specify both `message` and `error` params");
		params.error = params.message;
	}
	delete params.message;
	if (typeof params.error === "string") return {
		...params,
		error: () => params.error
	};
	return params;
}
function stringifyPrimitive(value) {
	if (typeof value === "bigint") return value.toString() + "n";
	if (typeof value === "string") return `"${value}"`;
	return `${value}`;
}
function optionalKeys(shape) {
	return Object.keys(shape).filter((k) => {
		return shape[k]._zod.optin !== void 0 && shape[k]._zod.optout === "optional";
	});
}
var NUMBER_FORMAT_RANGES = /*@__PURE__*/ (() => ({
	safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
	int32: [-2147483648, 2147483647],
	uint32: [0, 4294967295],
	float32: [-34028234663852886e22, 34028234663852886e22],
	float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}))();
var BIGINT_FORMAT_RANGES = {
	int64: [/* @__PURE__*/ BigInt("-9223372036854775808"), /* @__PURE__*/ BigInt("9223372036854775807")],
	uint64: [/* @__PURE__*/ BigInt(0), /* @__PURE__*/ BigInt("18446744073709551615")]
};
function pick(schema, mask) {
	const currDef = schema._zod.def;
	const checks = currDef.checks;
	if (checks && checks.length > 0) throw new Error(".pick() cannot be used on object schemas containing refinements");
	const newShape = {};
	mirrorShape(newShape, schema, maskedKeys(schema, mask));
	return clone(schema, mergeDefs(currDef, {
		shape: newShape,
		checks: []
	}));
}
function maskedKeys(schema, mask) {
	const raw = sourceShape(schema);
	const keys = [];
	for (const key of Reflect.ownKeys(mask)) {
		if (!Object.getOwnPropertyDescriptor(raw, key)?.enumerable) throw new Error(`Unrecognized key: "${String(key)}"`);
		if (mask[key]) keys.push(key);
	}
	return keys;
}
function omit(schema, mask) {
	const currDef = schema._zod.def;
	const checks = currDef.checks;
	if (checks && checks.length > 0) throw new Error(".omit() cannot be used on object schemas containing refinements");
	const omitted = new Set(maskedKeys(schema, mask));
	const newShape = {};
	mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)).filter((key) => !omitted.has(key)));
	return clone(schema, mergeDefs(currDef, {
		shape: newShape,
		checks: []
	}));
}
function extend(schema, shape) {
	if (!isPlainObject(shape)) throw new Error("Invalid input to extend: expected a plain object");
	const checks = schema._zod.def.checks;
	if (checks && checks.length > 0) {
		const existingShape = sourceShape(schema);
		for (const key of Reflect.ownKeys(shape)) if (Object.getOwnPropertyDescriptor(existingShape, key) !== void 0) throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
	}
	return clone(schema, mergeDefs(schema._zod.def, { shape: extended(schema, shape) }));
}
function extended(schema, shape) {
	const newShape = {};
	mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)));
	mirrorProps(newShape, shape);
	return newShape;
}
function safeExtend(schema, shape) {
	if (!isPlainObject(shape)) throw new Error("Invalid input to safeExtend: expected a plain object");
	return clone(schema, mergeDefs(schema._zod.def, { shape: extended(schema, shape) }));
}
function merge(a, b) {
	if (!b?._zod?.def) throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
	if (a._zod.def.checks?.length) throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
	const newShape = {};
	mirrorShape(newShape, a, Reflect.ownKeys(sourceShape(a)));
	mirrorShape(newShape, b, Reflect.ownKeys(sourceShape(b)));
	return clone(a, mergeDefs(a._zod.def, {
		shape: newShape,
		get catchall() {
			return b._zod.def.catchall;
		},
		checks: b._zod.def.checks ?? []
	}));
}
function partial(Class, schema, mask, name = "partial") {
	const checks = schema._zod.def.checks;
	if (checks && checks.length > 0) throw new Error(`.${name}() cannot be used on object schemas containing refinements`);
	const selected = mask ? new Set(maskedKeys(schema, mask)) : void 0;
	const newShape = {};
	mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)), Class && ((value, key) => selected && !selected.has(key) ? value : new Class({
		type: "optional",
		innerType: value
	})));
	return clone(schema, mergeDefs(schema._zod.def, {
		shape: newShape,
		checks: []
	}));
}
function required(Class, schema, mask) {
	const selected = mask ? new Set(maskedKeys(schema, mask)) : void 0;
	const newShape = {};
	mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)), (value, key) => selected && !selected.has(key) ? value : new Class({
		type: "nonoptional",
		innerType: value
	}));
	return clone(schema, mergeDefs(schema._zod.def, { shape: newShape }));
}
function aborted(x, startIndex = 0) {
	if (x.aborted === true) return true;
	for (let i = startIndex; i < x.issues.length; i++) if (x.issues[i]?.continue !== true) return true;
	return false;
}
function explicitlyAborted(x, startIndex = 0) {
	if (x.aborted === true) return true;
	for (let i = startIndex; i < x.issues.length; i++) if (x.issues[i]?.continue === false) return true;
	return false;
}
function prefixIssues(path, issues) {
	return issues.map((iss) => {
		var _a;
		(_a = iss).path ?? (_a.path = []);
		iss.path.unshift(path);
		return iss;
	});
}
function unwrapMessage(message) {
	return typeof message === "string" ? message : message?.message;
}
function attachSchema(issues, start, inst) {
	var _a;
	for (let i = start; i < issues.length; i++) (_a = issues[i]).schema ?? (_a.schema = inst);
}
function finalizeIssue(iss, ctx, config) {
	var _a;
	const traits = iss.inst?._zod?.traits;
	if (traits?.has("$ZodType")) {
		if (traits.has("$ZodCheck")) (_a = iss).schema ?? (_a.schema = iss.inst);
		else iss.schema = iss.inst;
	}
	const schemaError = iss.schema !== iss.inst ? iss.schema?._zod.def?.error : void 0;
	const message = iss.message ? iss.message : unwrapMessage(iss.inst?._zod.def?.error?.(iss)) ?? unwrapMessage(schemaError?.(iss)) ?? unwrapMessage(ctx?.error?.(iss)) ?? unwrapMessage(config.customError?.(iss)) ?? unwrapMessage(config.localeError?.(iss)) ?? "Invalid input";
	const full = {};
	for (const k of Object.keys(iss)) {
		if (k === "inst" || k === "schema" || k === "continue" || k === "input" || k === "__proto__") continue;
		full[k] = iss[k];
	}
	full.path ?? (full.path = []);
	full.message = message;
	if (ctx?.reportInput) full.input = iss.input;
	return full;
}
var highSurrogate = /[\uD800-\uDBFF]/;
function codePointLength(str) {
	const units = str.length;
	if (!highSurrogate.test(str)) return units;
	let count = units;
	for (let i = 0; i < units - 1; i++) if ((str.charCodeAt(i) & 64512) === 55296 && (str.charCodeAt(i + 1) & 64512) === 56320) {
		count--;
		i++;
	}
	return count;
}
function getLengthableOrigin(input) {
	if (Array.isArray(input)) return "array";
	if (typeof input === "string") return "string";
	return "unknown";
}
function parsedType(data) {
	const t = typeof data;
	switch (t) {
		case "number": return Number.isNaN(data) ? "nan" : "number";
		case "object": {
			if (data === null) return "null";
			if (Array.isArray(data)) return "array";
			const obj = data;
			if (obj && Object.getPrototypeOf(obj) !== Object.prototype && "constructor" in obj && obj.constructor) return obj.constructor.name;
		}
	}
	return t;
}
function issue(...args) {
	const [iss, input, inst] = args;
	if (typeof iss === "string") return {
		message: iss,
		code: "custom",
		input,
		inst
	};
	return { ...iss };
}
/**
* Installs a trait's members on its prototype. Each value builds that member for the instance on first read; the built value shadows the accessor as an own property, so a detached `const { parse } = schema` keeps working.
*
* Call this from a `proto` initializer, which runs once per prototype — never per instance.
*/
function members(proto, table) {
	for (const key in table) {
		const desc = Object.getOwnPropertyDescriptor(table, key);
		if (desc.get) Object.defineProperty(proto, key, {
			...desc,
			enumerable: false
		});
		else defineBound(proto, key, desc.value);
	}
}
/** Shadows a prototype member with an own value, so a getter that builds from the instance runs once. */
function own(inst, key, value, enumerable = true) {
	Object.defineProperty(inst, key, {
		configurable: true,
		writable: true,
		enumerable,
		value
	});
	return value;
}
/** Like {@link own}, for a member that was never an own data property and has to stay out of `Object.keys`. */
function hide(inst, key, value) {
	return own(inst, key, value, false);
}
/** Adds members a table derives from the instance: each builds on first read and shadows as own data, and assignment shadows the same way, as when these were own properties. */
function derived(computes, table) {
	for (const key in computes) {
		const compute = computes[key];
		Object.defineProperty(table, key, {
			configurable: true,
			enumerable: true,
			get() {
				return own(this, key, compute(this));
			},
			set(value) {
				own(this, key, value);
			}
		});
	}
	return table;
}
function defineBound(proto, key, fn) {
	Object.defineProperty(proto, key, {
		configurable: true,
		get() {
			return this == null ? fn : own(this, key, fn.bind(this));
		},
		set(value) {
			own(this, key, value);
		}
	});
}
/** Returns the prototype to install on, or `undefined` if this group is already installed on it. */
function claim(inst, sentinel) {
	const proto = Object.getPrototypeOf(inst);
	return sentinel in proto ? void 0 : proto;
}
var installing;
var broke = false;
var breaker = {
	configurable: true,
	get() {
		broke = true;
	}
};
/**
* Installs a lazily-derived internal on the `_zod` prototype of `inst`'s
* constructor, computed from the internals object itself and cached there on
* first read. One accessor per constructor rather than one per instance.
*/
function defineLazyInternal(inst, key, compute) {
	const proto = Object.getPrototypeOf(inst._zod);
	if (key in proto && installing !== inst._zod) {
		installing = void 0;
		return;
	}
	installing = inst._zod;
	Object.defineProperty(proto, key, {
		configurable: true,
		get() {
			Object.defineProperty(this, key, breaker);
			const outer = broke;
			broke = false;
			try {
				const value = compute(this);
				if (broke) delete this[key];
				else Object.defineProperty(this, key, {
					configurable: true,
					writable: true,
					value
				});
				broke = broke || outer;
				return value;
			} catch (err) {
				delete this[key];
				broke = broke || outer;
				throw err;
			}
		},
		set(value) {
			Object.defineProperty(this, key, {
				configurable: true,
				writable: true,
				value
			});
		}
	});
}
/**
* Installs `key` on `inst`'s prototype, computed by `make` on first read and cached there as an own
* data property. One accessor per constructor rather than one per instance, because an own accessor
* puts every instance after the first into v8 dictionary mode. The key doubles as the sentinel.
*/
function installLazyProp(inst, key, make, enumerable) {
	const proto = claim(inst, key);
	if (!proto) return;
	Object.defineProperty(proto, key, {
		configurable: true,
		get() {
			const desc = {
				configurable: true,
				writable: true,
				enumerable,
				value: void 0
			};
			Object.defineProperty(this, key, desc);
			desc.value = make(this);
			Object.defineProperty(this, key, desc);
			return desc.value;
		},
		set(value) {
			Object.defineProperty(this, key, {
				configurable: true,
				writable: true,
				enumerable,
				value
			});
		}
	});
}
/** Marks the thunk `_catch` synthesises for a constant catch value. `Function.length` cannot tell that thunk from a user callback — rest and defaulted parameters both report arity 0 — and a user callback reads `ctx.error`, whose issues only finalize correctly against the caller's per-parse error map. Provenance can say what arity cannot. A plain string key rather than `Symbol.for`, whose call at module scope no bundler can prove pure — the same shape that anchored `urlCanParse` into every build. */
var CONSTANT_CATCH = "~constantCatch";
/** Wraps a constant catch value in a thunk tagged with {@link CONSTANT_CATCH}. */
function constantCatch(value) {
	const fn = () => value;
	fn[CONSTANT_CATCH] = true;
	return fn;
}
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/core.js
var _a$1;
var _zodDesc = {
	value: void 0,
	enumerable: false
};
var _E = "captureStackTrace" in Error ? Error : null;
function newError(Definition) {
	const E = _E;
	if (E) {
		const saved = E.stackTraceLimit;
		if (typeof saved === "number") {
			try {
				E.stackTraceLimit = 0;
			} catch {
				_E = null;
				return new Definition();
			}
			try {
				return new Definition();
			} finally {
				E.stackTraceLimit = saved;
			}
		}
	}
	return new Definition();
}
function $constructor(name, initializer, proto, params) {
	const zodProto = {};
	function Internals(def) {
		this.def = def;
		this.constr = _;
		this.traits = /* @__PURE__ */ new Set();
	}
	Internals.prototype = zodProto;
	const protoMembers = proto;
	const initialized = protoMembers && /* @__PURE__ */ new WeakSet();
	function init(inst, def) {
		if (!inst._zod) {
			_zodDesc.value = new Internals(def);
			try {
				Object.defineProperty(inst, "_zod", _zodDesc);
			} finally {
				_zodDesc.value = void 0;
			}
		} else if (inst._zod.traits.has(name)) return;
		inst._zod.traits.add(name);
		initializer(inst, def);
		if (initialized) {
			const own = Object.getPrototypeOf(inst);
			const ctorProto = inst._zod.constr.prototype;
			let up = own;
			while (up && up !== ctorProto) up = Object.getPrototypeOf(up);
			const target = up ?? own;
			if (!initialized.has(target)) {
				initialized.add(target);
				members(target, protoMembers);
			}
		}
		const proto = _.prototype;
		for (const k in proto) {
			if (!Object.prototype.hasOwnProperty.call(proto, k)) continue;
			if (!(k in inst)) inst[k] = proto[k].bind(inst);
		}
	}
	const Parent = params?.Parent ?? Object;
	class Definition extends Parent {}
	Object.defineProperty(Definition, "name", { value: name });
	function _(def) {
		const inst = params?.Parent ? newError(Definition) : this;
		init(inst, def);
		const deferred = inst._zod.deferred;
		if (deferred) {
			for (const fn of deferred) fn();
			inst._zod.deferred = void 0;
		}
		const pp = globalThis.__zod_globalConfig?.postProcessor;
		if (pp) pp(inst);
		return inst;
	}
	Object.defineProperty(_, "init", { value: init });
	Object.defineProperty(_, Symbol.hasInstance, { value: (inst) => {
		if (params?.Parent && inst instanceof params.Parent) return true;
		return inst?._zod?.traits?.has(name);
	} });
	Object.defineProperty(_, "name", { value: name });
	return _;
}
var $ZodAsyncError = class extends Error {
	constructor() {
		super(`Encountered Promise during synchronous parse. Use .parseAsync() instead.`);
	}
};
var $ZodEncodeError = class extends Error {
	constructor(name) {
		super(`Encountered unidirectional transform during encode: ${name}`);
		this.name = "ZodEncodeError";
	}
};
(_a$1 = globalThis).__zod_globalConfig ?? (_a$1.__zod_globalConfig = {});
var globalConfig = globalThis.__zod_globalConfig;
function config(newConfig) {
	if (newConfig) Object.assign(globalConfig, newConfig);
	return globalConfig;
}
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/errors.js
function _getMessage() {
	const internals = this._zod;
	internals.message ?? (internals.message = JSON.stringify(internals.def, jsonStringifyReplacer, 2));
	return internals.message;
}
function _setMessage(value) {
	this._zod.message = value;
}
var _messageDesc = {
	get: _getMessage,
	set: _setMessage,
	enumerable: true,
	configurable: true
};
var _issuesDesc = {
	value: void 0,
	enumerable: false
};
var _installedToString = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
var initializer$1 = (inst, def) => {
	inst.name = "$ZodError";
	_issuesDesc.value = def;
	Object.defineProperty(inst, "issues", _issuesDesc);
	_issuesDesc.value = void 0;
	Object.defineProperty(inst, "message", _messageDesc);
	const proto = Object.getPrototypeOf(inst);
	if (!_installedToString.has(proto)) {
		_installedToString.add(proto);
		Object.defineProperty(proto, "toString", {
			configurable: true,
			enumerable: false,
			get() {
				const value = () => this.message;
				Object.defineProperty(this, "toString", {
					value,
					configurable: true,
					writable: true
				});
				return value;
			},
			set(value) {
				Object.defineProperty(this, "toString", {
					value,
					configurable: true,
					writable: true
				});
			}
		});
	}
};
var $ZodError = $constructor("$ZodError", initializer$1);
$constructor("$ZodError", initializer$1, void 0, { Parent: Error });
/** Get-or-create `obj[key]` as an own data property. A path segment naming an inherited member
* ("toString", "constructor") would otherwise read through to the prototype, and assigning
* "__proto__" would hit the setter instead of creating a key. */
function node(obj, key, make) {
	if (!Object.prototype.hasOwnProperty.call(obj, key)) {
		if (key === "__proto__") Object.defineProperty(obj, key, {
			value: make(),
			writable: true,
			enumerable: true,
			configurable: true
		});
		else obj[key] = make();
	}
	return obj[key];
}
function flattenError(error, mapper = (issue) => issue.message) {
	const fieldErrors = {};
	const formErrors = [];
	for (const sub of error.issues) if (sub.path.length > 0) node(fieldErrors, sub.path[0], () => []).push(mapper(sub));
	else formErrors.push(mapper(sub));
	return {
		formErrors,
		fieldErrors
	};
}
function formatError(error, mapper = (issue) => issue.message) {
	const fieldErrors = { _errors: [] };
	const processError = (error, path = []) => {
		for (const issue of error.issues) if (issue.code === "invalid_union" && issue.errors.length) issue.errors.map((issues) => processError({ issues }, [...path, ...issue.path]));
		else if (issue.code === "invalid_key") processError({ issues: issue.issues }, [...path, ...issue.path]);
		else if (issue.code === "invalid_element") processError({ issues: issue.issues }, [...path, ...issue.path]);
		else {
			const fullpath = [...path, ...issue.path];
			if (fullpath.length === 0) fieldErrors._errors.push(mapper(issue));
			else {
				let curr = fieldErrors;
				let i = 0;
				while (i < fullpath.length) {
					const el = fullpath[i];
					const terminal = i === fullpath.length - 1;
					if (el === "_errors") {
						if (terminal) curr._errors.push(mapper(issue));
						i++;
						continue;
					}
					if (!Object.prototype.hasOwnProperty.call(curr, el)) Object.defineProperty(curr, el, {
						value: { _errors: [] },
						enumerable: true,
						writable: true,
						configurable: true
					});
					const node = curr[el];
					if (terminal) node._errors.push(mapper(issue));
					curr = node;
					i++;
				}
			}
		}
	};
	processError(error);
	return fieldErrors;
}
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/parse.js
function finalizeParams(callee, params) {
	return {
		callee: params?.callee ?? callee,
		Err: params?.Err
	};
}
var _parse = (_Err) => {
	const fn = (schema, value, _ctx, _params) => {
		const ctx = _ctx ? {
			..._ctx,
			async: false
		} : { async: false };
		const result = schema._zod.run({
			value,
			issues: []
		}, ctx);
		if (result instanceof Promise) throw new $ZodAsyncError();
		if (result.issues.length) {
			const e = new ((_params?.Err) ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
			captureStackTrace(e, _params?.callee ?? fn);
			throw e;
		}
		return result.value;
	};
	return fn;
};
var _parseAsync = (_Err) => {
	const fn = async (schema, value, _ctx, params) => {
		const ctx = _ctx ? {
			..._ctx,
			async: true
		} : { async: true };
		let result = schema._zod.run({
			value,
			issues: []
		}, ctx);
		if (result instanceof Promise) result = await result;
		if (result.issues.length) {
			const e = new ((params?.Err) ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
			captureStackTrace(e, params?.callee ?? fn);
			throw e;
		}
		return result.value;
	};
	return fn;
};
var _safeParse = (_Err) => (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		async: false
	} : { async: false };
	const result = schema._zod.run({
		value,
		issues: []
	}, ctx);
	if (result instanceof Promise) throw new $ZodAsyncError();
	return result.issues.length ? failure$2(_Err, result.issues, ctx) : {
		success: true,
		data: result.value
	};
};
function failure$2(Err, issues, ctx) {
	let error;
	return {
		success: false,
		get error() {
			if (!error) {
				error = new Err(issues.map((iss) => finalizeIssue(iss, ctx, config())));
				issues = void 0;
				ctx = void 0;
			}
			return error;
		},
		set error(e) {
			error = e;
			issues = void 0;
			ctx = void 0;
		}
	};
}
var _safeParseAsync = (_Err) => async (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		async: true
	} : { async: true };
	let result = schema._zod.run({
		value,
		issues: []
	}, ctx);
	if (result instanceof Promise) result = await result;
	return result.issues.length ? failure$2(_Err, result.issues, ctx) : {
		success: true,
		data: result.value
	};
};
var COMPILE_INVALID = /* @__PURE__ */ Symbol.for("zod.compile.invalid");
var COMPILE_FALLBACK = /* @__PURE__ */ Symbol.for("zod.compile.fallback");
var validate = ((schema, value, _ctx) => {
	const validator = schema._zod.bag.validator;
	if (validator !== void 0) {
		if (validator(value) !== COMPILE_INVALID) return true;
		if (validator.definite === true && _ctx === void 0) return false;
	}
	return validateFallback(schema, value, _ctx);
});
function validateFallback(schema, value, _ctx) {
	const ctx = _ctx ? {
		..._ctx,
		async: false,
		abortEarly: true
	} : {
		async: false,
		abortEarly: true
	};
	const fallbackRun = schema._zod.bag.fallbackRun;
	let result;
	if (fallbackRun) {
		ctx[COMPILE_FALLBACK] = true;
		result = fallbackRun({
			value,
			issues: []
		}, ctx);
	} else result = schema._zod.run({
		value,
		issues: []
	}, ctx);
	if (result instanceof Promise) throw new $ZodAsyncError();
	return result.issues.length === 0;
}
var validateAsync$1 = async (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		async: true,
		abortEarly: true
	} : {
		async: true,
		abortEarly: true
	};
	let result = schema._zod.run({
		value,
		issues: []
	}, ctx);
	if (result instanceof Promise) result = await result;
	return result.issues.length === 0;
};
var _encode = (_Err) => {
	const parse = _parse(_Err);
	const fn = (schema, value, _ctx, _params) => {
		const ctx = _ctx ? {
			..._ctx,
			direction: "backward"
		} : { direction: "backward" };
		return parse(schema, value, ctx, finalizeParams(fn, _params));
	};
	return fn;
};
var _decode = (_Err) => {
	const parse = _parse(_Err);
	const fn = (schema, value, _ctx, _params) => {
		return parse(schema, value, _ctx, finalizeParams(fn, _params));
	};
	return fn;
};
var _encodeAsync = (_Err) => {
	const parseAsync = _parseAsync(_Err);
	const fn = async (schema, value, _ctx, _params) => {
		const ctx = _ctx ? {
			..._ctx,
			direction: "backward"
		} : { direction: "backward" };
		return await parseAsync(schema, value, ctx, finalizeParams(fn, _params));
	};
	return fn;
};
var _decodeAsync = (_Err) => {
	const parseAsync = _parseAsync(_Err);
	const fn = async (schema, value, _ctx, _params) => {
		return await parseAsync(schema, value, _ctx, finalizeParams(fn, _params));
	};
	return fn;
};
var _safeEncode = (_Err) => (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		direction: "backward"
	} : { direction: "backward" };
	return _safeParse(_Err)(schema, value, ctx);
};
var _safeDecode = (_Err) => (schema, value, _ctx) => {
	return _safeParse(_Err)(schema, value, _ctx);
};
var _safeEncodeAsync = (_Err) => async (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		direction: "backward"
	} : { direction: "backward" };
	return _safeParseAsync(_Err)(schema, value, ctx);
};
var _safeDecodeAsync = (_Err) => async (schema, value, _ctx) => {
	return _safeParseAsync(_Err)(schema, value, _ctx);
};
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/regexes.js
/**
* @deprecated CUID v1 is deprecated by its authors due to information leakage
* (timestamps embedded in the id). Use {@link cuid2} instead.
* See https://github.com/paralleldrive/cuid.
*/
var cuid = /^[cC][0-9a-z]{6,}$/;
var cuid2 = /^[0-9a-z]+$/;
var ulid = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/;
var xid = /^[0-9a-vA-V]{20}$/;
var ksuid = /^[A-Za-z0-9]{27}$/;
var nanoid = /^[a-zA-Z0-9_-]{21}$/;
function nanoidOfLength(length) {
	return new RegExp(`^[a-zA-Z0-9_-]{${length}}$`);
}
/** ISO 8601-1 duration regex. Does not support the 8601-2 extensions like negative durations or fractional/negative components. */
var duration = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/;
/** A regex for any UUID-like identifier: 8-4-4-4-12 hex pattern */
var guid = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/;
/** Returns a regex for validating an RFC 9562/4122 UUID.
*
* @param version Optionally specify a version 1-8. If no version is specified, all versions are supported. */
var uuid$2 = (version) => {
	if (!version) return /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/;
	return new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${version}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`);
};
/** Practical email validation */
var email = /^(?:[A-Za-z0-9_'+\-]+\.)*[A-Za-z0-9_'+\-]*[A-Za-z0-9_+-]@(?:[A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/;
var _emoji$1 = `^(?=[\\s\\S]*[\\p{Extended_Pictographic}\\p{Regional_Indicator}\\u20E3])[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$`;
function emoji() {
	return new RegExp(_emoji$1, "u");
}
var ipv4 = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/;
var cidrv4 = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/;
var cidrv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64 = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/;
var base64url = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2,3})?$/;
var httpProtocol = /^https?$/;
var e164 = /^\+[1-9]\d{6,14}$/;
var dateSource = `(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))`;
/** Anchors a pattern source. The interpolation lives here rather than at the call site because
* esbuild will not drop a `@__PURE__` call whose own argument interpolates a variable, but it
* will drop `anchor(dateSource)`. Keeping it inline pinned `date` into every bundle. */
function anchor(source) {
	return new RegExp(`^${source}$`);
}
var date = /*@__PURE__*/ anchor(dateSource);
function timeSource(args) {
	const hhmm = `(?:[01]\\d|2[0-3]):[0-5]\\d`;
	return typeof args.precision === "number" ? args.precision === -1 ? `${hhmm}` : args.precision === 0 ? `${hhmm}:[0-5]\\d` : `${hhmm}:[0-5]\\d\\.\\d{${args.precision}}` : args.seconds ? `${hhmm}:[0-5]\\d(?:\\.\\d+)?` : `${hhmm}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function time(args) {
	return new RegExp(`^${timeSource(args)}$`);
}
function datetime(args) {
	const opts = ["Z"];
	if (args.offset) opts.push(`([+-](?:[01]\\d|2[0-3]):[0-5]\\d)`);
	const qualified = `${timeSource({
		precision: args.precision,
		seconds: true
	})}(?:${opts.join("|")})`;
	const timeRegex = args.local ? `${qualified}|${timeSource({ precision: args.precision })}` : qualified;
	return new RegExp(`^${dateSource}T(?:${timeRegex})$`);
}
var anyString = /^[\s\S]{0,}$/;
var integer$1 = /^-?\d+$/;
var number$1 = /^-?\d+(?:\.\d+)?$/;
var boolean$1 = /^(?:true|false)$/i;
var _null$2 = /^null$/i;
var lowercase = /^[^A-Z]*$/;
var uppercase = /^[^a-z]*$/;
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/checks.js
var $ZodCheck = /*@__PURE__*/ $constructor("$ZodCheck", (inst, def) => {
	var _a;
	inst._zod ?? (inst._zod = {});
	inst._zod.def = def;
	(_a = inst._zod).onattach ?? (_a.onattach = []);
});
/** Default `when` for length-based checks: run only on non-nullish values with a `length`. */
var _whenHasLength = (payload) => {
	const val = payload.value;
	return !nullish(val) && val.length !== void 0;
};
var numericOriginMap = {
	number: "number",
	bigint: "bigint",
	object: "date"
};
var $ZodCheckLessThan = /*@__PURE__*/ $constructor("$ZodCheckLessThan", (inst, def) => {
	$ZodCheck.init(inst, def);
	const origin = numericOriginMap[typeof def.value];
	inst._zod.check = (payload) => {
		if (def.inclusive ? payload.value <= def.value : payload.value < def.value) return;
		payload.issues.push({
			origin: numericOriginMap[typeof payload.value] ?? origin,
			code: "too_big",
			maximum: typeof def.value === "object" ? def.value.getTime() : def.value,
			input: payload.value,
			inclusive: def.inclusive,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckGreaterThan = /*@__PURE__*/ $constructor("$ZodCheckGreaterThan", (inst, def) => {
	$ZodCheck.init(inst, def);
	const origin = numericOriginMap[typeof def.value];
	inst._zod.check = (payload) => {
		if (def.inclusive ? payload.value >= def.value : payload.value > def.value) return;
		payload.issues.push({
			origin: numericOriginMap[typeof payload.value] ?? origin,
			code: "too_small",
			minimum: typeof def.value === "object" ? def.value.getTime() : def.value,
			input: payload.value,
			inclusive: def.inclusive,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckMultipleOf = /*@__PURE__*/ $constructor("$ZodCheckMultipleOf", (inst, def) => {
	$ZodCheck.init(inst, def);
	inst._zod.check = (payload) => {
		if (typeof payload.value !== typeof def.value) throw new Error("Cannot mix number and bigint in multiple_of check.");
		if (typeof payload.value === "bigint" ? def.value !== BigInt(0) && payload.value % def.value === BigInt(0) : floatSafeRemainder(payload.value, def.value) === 0) return;
		payload.issues.push({
			origin: typeof payload.value,
			code: "not_multiple_of",
			divisor: def.value,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckNumberFormat = /*@__PURE__*/ $constructor("$ZodCheckNumberFormat", (inst, def) => {
	$ZodCheck.init(inst, def);
	def.format = def.format || "float64";
	const isInt = def.format?.includes("int");
	const origin = isInt ? "int" : "number";
	const [minimum, maximum] = NUMBER_FORMAT_RANGES[def.format];
	inst._zod.check = (payload) => {
		const input = payload.value;
		if (isInt) {
			if (!Number.isInteger(input)) {
				payload.issues.push({
					expected: origin,
					format: def.format,
					code: "invalid_type",
					continue: false,
					input,
					inst
				});
				return;
			}
			if (!Number.isSafeInteger(input)) {
				if (input > 0) payload.issues.push({
					input,
					code: "too_big",
					maximum: Number.MAX_SAFE_INTEGER,
					note: "Integers must be within the safe integer range.",
					inst,
					origin,
					inclusive: true,
					continue: !def.abort
				});
				else payload.issues.push({
					input,
					code: "too_small",
					minimum: Number.MIN_SAFE_INTEGER,
					note: "Integers must be within the safe integer range.",
					inst,
					origin,
					inclusive: true,
					continue: !def.abort
				});
				return;
			}
		}
		if (input < minimum) payload.issues.push({
			origin: "number",
			input,
			code: "too_small",
			minimum,
			inclusive: true,
			inst,
			continue: !def.abort
		});
		if (input > maximum) payload.issues.push({
			origin: "number",
			input,
			code: "too_big",
			maximum,
			inclusive: true,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckMaxLength = /*@__PURE__*/ $constructor("$ZodCheckMaxLength", (inst, def) => {
	var _a;
	$ZodCheck.init(inst, def);
	(_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
	inst._zod.check = (payload) => {
		const input = payload.value;
		const units = input.length;
		if ((typeof input === "string" && units > def.maximum ? codePointLength(input) : units) <= def.maximum) return;
		const origin = getLengthableOrigin(input);
		payload.issues.push({
			origin,
			code: "too_big",
			maximum: def.maximum,
			inclusive: true,
			input,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckMinLength = /*@__PURE__*/ $constructor("$ZodCheckMinLength", (inst, def) => {
	var _a;
	$ZodCheck.init(inst, def);
	(_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
	inst._zod.check = (payload) => {
		const input = payload.value;
		const units = input.length;
		if ((typeof input === "string" && units >= def.minimum && units < def.minimum * 2 ? codePointLength(input) : units) >= def.minimum) return;
		const origin = getLengthableOrigin(input);
		payload.issues.push({
			origin,
			code: "too_small",
			minimum: def.minimum,
			inclusive: true,
			input,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckLengthEquals = /*@__PURE__*/ $constructor("$ZodCheckLengthEquals", (inst, def) => {
	var _a;
	$ZodCheck.init(inst, def);
	(_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
	inst._zod.check = (payload) => {
		const input = payload.value;
		const units = input.length;
		const length = typeof input === "string" && units >= def.length && units <= def.length * 2 ? codePointLength(input) : units;
		if (length === def.length) return;
		const origin = getLengthableOrigin(input);
		const tooBig = length > def.length;
		payload.issues.push({
			origin,
			...tooBig ? {
				code: "too_big",
				maximum: def.length
			} : {
				code: "too_small",
				minimum: def.length
			},
			inclusive: true,
			exact: true,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckStringFormat = /*@__PURE__*/ $constructor("$ZodCheckStringFormat", (inst, def) => {
	var _a, _b;
	$ZodCheck.init(inst, def);
	if (def.pattern) (_a = inst._zod).check ?? (_a.check = (payload) => {
		def.pattern.lastIndex = 0;
		if (def.pattern.test(payload.value)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: def.format,
			input: payload.value,
			...def.pattern ? { pattern: def.pattern.toString() } : {},
			inst,
			continue: !def.abort
		});
	});
	else (_b = inst._zod).check ?? (_b.check = () => {});
});
var $ZodCheckRegex = /*@__PURE__*/ $constructor("$ZodCheckRegex", (inst, def) => {
	$ZodCheckStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		def.pattern.lastIndex = 0;
		if (def.pattern.test(payload.value)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "regex",
			input: payload.value,
			pattern: def.pattern.toString(),
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckLowerCase = /*@__PURE__*/ $constructor("$ZodCheckLowerCase", (inst, def) => {
	def.pattern ?? (def.pattern = lowercase);
	$ZodCheckStringFormat.init(inst, def);
});
var $ZodCheckUpperCase = /*@__PURE__*/ $constructor("$ZodCheckUpperCase", (inst, def) => {
	def.pattern ?? (def.pattern = uppercase);
	$ZodCheckStringFormat.init(inst, def);
});
var $ZodCheckIncludes = /*@__PURE__*/ $constructor("$ZodCheckIncludes", (inst, def) => {
	$ZodCheck.init(inst, def);
	const escapedRegex = escapeRegex(def.includes);
	def.pattern = new RegExp(typeof def.position === "number" ? `^.{${def.position},}${escapedRegex}` : escapedRegex);
	inst._zod.check = (payload) => {
		if (payload.value.includes(def.includes, def.position)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "includes",
			includes: def.includes,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckStartsWith = /*@__PURE__*/ $constructor("$ZodCheckStartsWith", (inst, def) => {
	$ZodCheck.init(inst, def);
	const pattern = new RegExp(`^${escapeRegex(def.prefix)}.*`);
	def.pattern ?? (def.pattern = pattern);
	inst._zod.check = (payload) => {
		if (payload.value.startsWith(def.prefix)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "starts_with",
			prefix: def.prefix,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckEndsWith = /*@__PURE__*/ $constructor("$ZodCheckEndsWith", (inst, def) => {
	$ZodCheck.init(inst, def);
	const pattern = new RegExp(`.*${escapeRegex(def.suffix)}$`);
	def.pattern ?? (def.pattern = pattern);
	inst._zod.check = (payload) => {
		if (payload.value.endsWith(def.suffix)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "ends_with",
			suffix: def.suffix,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
function handleCheckPropertyResult(result, payload, property) {
	if (result.issues.length) payload.issues.push(...prefixIssues(property, result.issues));
}
var $ZodCheckProperties = /*@__PURE__*/ $constructor("$ZodCheckProperties", (inst, def) => {
	$ZodCheck.init(inst, def);
	hide(inst, Symbol.iterator, function* () {
		yield inst;
	});
	let entries;
	inst._zod.check = (payload) => {
		if (payload.value == null) {
			payload.issues.push({
				expected: "object",
				code: "invalid_type",
				input: payload.value,
				inst
			});
			return;
		}
		entries ?? (entries = Reflect.ownKeys(def.shape).map((key) => [key, def.shape[key]]));
		const input = payload.value;
		let proms;
		for (const [key, schema] of entries) {
			const result = schema._zod.run({
				value: input[key],
				issues: []
			}, {});
			if (result instanceof Promise) {
				proms ?? (proms = []);
				proms.push(result.then((result) => handleCheckPropertyResult(result, payload, key)));
			} else handleCheckPropertyResult(result, payload, key);
		}
		if (proms) return Promise.all(proms).then(() => void 0);
	};
});
var $ZodCheckOverwrite = /*@__PURE__*/ $constructor("$ZodCheckOverwrite", (inst, def) => {
	$ZodCheck.init(inst, def);
	inst._zod.check = (payload) => {
		payload.value = def.tx(payload.value);
	};
});
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/doc.js
var Doc = class {
	constructor(args = [], closed = {}) {
		this.content = [];
		this.indent = 0;
		this.args = args;
		this.closed = closed;
	}
	indented(fn) {
		this.indent += 1;
		try {
			fn(this);
		} finally {
			this.indent -= 1;
		}
	}
	write(arg) {
		if (typeof arg === "function") {
			arg(this, { execution: "sync" });
			arg(this, { execution: "async" });
			return;
		}
		const lines = arg.split("\n").filter((x) => x);
		const minIndent = Math.min(...lines.map((x) => x.length - x.trimStart().length));
		const dedented = lines.map((x) => x.slice(minIndent)).map((x) => " ".repeat(this.indent * 2) + x);
		for (const line of dedented) this.content.push(line);
	}
	compile() {
		const F = Function;
		const content = this?.content ?? [``];
		return new F(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {\n${content.join("\n")}\n};`)(...Object.values(this.closed));
	}
};
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/versions.js
var version$1 = {
	major: 4,
	minor: 6,
	patch: 5
};
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/schemas.js
var $ZodType = /*@__PURE__*/ $constructor("$ZodType", (inst, def) => {
	var _a;
	inst ?? (inst = {});
	inst._zod.def = def;
	inst._zod.bag = inst._zod.bag || {};
	inst._zod.version = version$1;
	const defChecks = inst._zod.def.checks;
	const checks = inst._zod.traits.has("$ZodCheck") ? [inst, ...defChecks ?? []] : defChecks?.length ? [...defChecks] : [];
	for (const ch of checks) for (const fn of ch._zod.onattach) fn(inst);
	if (checks.length === 0) {
		(_a = inst._zod).deferred ?? (_a.deferred = []);
		inst._zod.deferred?.push(() => {
			inst._zod.run = inst._zod.parse;
		});
	} else {
		const runChecks = (payload, checks, ctx) => {
			if (payload.memo) return payload;
			let isAborted = aborted(payload);
			let asyncResult;
			for (const ch of checks) {
				if (ch._zod.def.when) {
					if (explicitlyAborted(payload)) continue;
					if (!ch._zod.def.when(payload)) continue;
				} else if (isAborted) continue;
				const currLen = payload.issues.length;
				const _ = ch._zod.check(payload);
				if (_ instanceof Promise && ctx?.async === false) throw new $ZodAsyncError();
				if (asyncResult || _ instanceof Promise) asyncResult = (asyncResult ?? Promise.resolve()).then(async () => {
					await _;
					if (payload.issues.length === currLen) return;
					attachSchema(payload.issues, currLen, inst);
					if (!isAborted) isAborted = aborted(payload, currLen);
				});
				else {
					if (payload.issues.length === currLen) continue;
					attachSchema(payload.issues, currLen, inst);
					if (!isAborted) isAborted = aborted(payload, currLen);
				}
			}
			if (asyncResult) return asyncResult.then(() => {
				return payload;
			});
			return payload;
		};
		const handleCanaryResult = (canary, payload, ctx) => {
			if (aborted(canary)) {
				canary.aborted = true;
				return canary;
			}
			const checkResult = runChecks(payload, checks, ctx);
			if (checkResult instanceof Promise) {
				if (ctx.async === false) throw new $ZodAsyncError();
				return checkResult.then((checkResult) => inst._zod.parse(checkResult, ctx));
			}
			return inst._zod.parse(checkResult, ctx);
		};
		inst._zod.run = (payload, ctx) => {
			if (ctx.skipChecks) return inst._zod.parse(payload, ctx);
			if (ctx.direction === "backward") {
				const canary = inst._zod.parse({
					value: payload.value,
					issues: []
				}, {
					...ctx,
					skipChecks: true
				});
				if (canary instanceof Promise) return canary.then((canary) => {
					return handleCanaryResult(canary, payload, ctx);
				});
				return handleCanaryResult(canary, payload, ctx);
			}
			const result = inst._zod.parse(payload, ctx);
			if (result instanceof Promise) {
				if (ctx.async === false) throw new $ZodAsyncError();
				return result.then((result) => runChecks(result, checks, ctx));
			}
			return runChecks(result, checks, ctx);
		};
	}
}, {
	get "~standard"() {
		return hide(this, "~standard", standardProps(this));
	},
	set "~standard"(value) {
		own(this, "~standard", value);
	}
});
/** The Standard Schema surface for `inst`. Shared so wrappers can extend it without forcing it. */
var toStandardResult = (r, ctx) => r.issues.length ? { issues: r.issues.map((iss) => finalizeIssue(iss, ctx, config())) } : { value: r.value };
async function validateAsync(inst, value) {
	const ctx = { async: true };
	return toStandardResult(await inst._zod.run({
		value,
		issues: []
	}, ctx), ctx);
}
function standardProps(inst) {
	return {
		validate: (value) => {
			const ctx = { async: false };
			try {
				const r = inst._zod.run({
					value,
					issues: []
				}, ctx);
				if (!(r instanceof Promise)) return toStandardResult(r, ctx);
			} catch (_) {}
			return validateAsync(inst, value);
		},
		vendor: "zod",
		version: 1
	};
}
var $ZodString = /*@__PURE__*/ $constructor("$ZodString", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.pattern = def.pattern ?? anyString;
	inst._zod.parse = (payload, _) => {
		if (def.coerce) try {
			payload.value = String(payload.value);
		} catch (_) {}
		if (typeof payload.value === "string") return payload;
		payload.issues.push({
			expected: "string",
			code: "invalid_type",
			input: payload.value,
			inst
		});
		return payload;
	};
});
var $ZodStringFormat = /*@__PURE__*/ $constructor("$ZodStringFormat", (inst, def) => {
	$ZodCheckStringFormat.init(inst, def);
	$ZodString.init(inst, def);
});
var $ZodGUID = /*@__PURE__*/ $constructor("$ZodGUID", (inst, def) => {
	def.pattern ?? (def.pattern = guid);
	$ZodStringFormat.init(inst, def);
});
var $ZodUUID = /*@__PURE__*/ $constructor("$ZodUUID", (inst, def) => {
	if (def.version) {
		const v = {
			v1: 1,
			v2: 2,
			v3: 3,
			v4: 4,
			v5: 5,
			v6: 6,
			v7: 7,
			v8: 8
		}[def.version];
		if (v === void 0) throw new Error(`Invalid UUID version: "${def.version}"`);
		def.pattern ?? (def.pattern = uuid$2(v));
	} else def.pattern ?? (def.pattern = uuid$2());
	$ZodStringFormat.init(inst, def);
});
var $ZodEmail = /*@__PURE__*/ $constructor("$ZodEmail", (inst, def) => {
	def.pattern ?? (def.pattern = email);
	$ZodStringFormat.init(inst, def);
});
function canParseURL(input) {
	try {
		if (typeof URL !== "undefined" && typeof URL.canParse === "function") return URL.canParse(input);
		new URL(input);
		return true;
	} catch {
		return false;
	}
}
function validateURL(trimmed, def) {
	if (!("normalize" in def) && !("hostname" in def) && !("protocol" in def)) return canParseURL(trimmed) || 2;
	return parseURLObject(trimmed, def);
}
/** Parses a URL while preserving the non-normalizing HTTP guard. */
function parseURLObject(trimmed, def) {
	if (!def.normalize && def.protocol?.source === httpProtocol.source && !/^https?:\/\//i.test(trimmed)) return 1;
	try {
		if (typeof URL !== "undefined") {
			const URLStatic = URL;
			if (typeof URLStatic.parse === "function") return URLStatic.parse(trimmed) ?? 2;
		}
		return new URL(trimmed);
	} catch {
		return 2;
	}
}
var asciiTabOrNewline = /[\t\n\r]/g;
/** The URL parser deletes every ASCII tab, LF and CR from its input before it parses, so `new URL("https://exa\nmple.com")` reports on `example.com`. Applying the same deletion to the returned value closes the half of that divergence which can move the host; the parser's other rewrite, stripping C0 controls at the edges, cannot. */
function stripTabAndNewline(value) {
	return value.replace(asciiTabOrNewline, "");
}
function urlHostnameOk(url, hostname) {
	hostname.lastIndex = 0;
	return hostname.test(url.hostname);
}
function urlProtocolOk(url, protocol) {
	protocol.lastIndex = 0;
	return protocol.test(url.protocol.endsWith(":") ? url.protocol.slice(0, -1) : url.protocol);
}
var $ZodURL = /*@__PURE__*/ $constructor("$ZodURL", (inst, def) => {
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		try {
			const trimmed = payload.value.trim();
			const url = validateURL(trimmed, def);
			if (url === 1) {
				payload.issues.push({
					code: "invalid_format",
					format: "url",
					note: "Invalid URL format",
					input: payload.value,
					inst,
					continue: !def.abort
				});
				return;
			}
			if (url === 2) {
				payload.issues.push({
					code: "invalid_format",
					format: "url",
					input: payload.value,
					inst,
					continue: !def.abort
				});
				return;
			}
			if (url === true) {
				payload.value = stripTabAndNewline(trimmed);
				return;
			}
			if (def.hostname && !urlHostnameOk(url, def.hostname)) payload.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid hostname",
				pattern: def.hostname.source,
				input: payload.value,
				inst,
				continue: !def.abort
			});
			if (def.protocol && !urlProtocolOk(url, def.protocol)) payload.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid protocol",
				pattern: def.protocol.source,
				input: payload.value,
				inst,
				continue: !def.abort
			});
			payload.value = def.normalize ? url.href : stripTabAndNewline(trimmed);
			return;
		} catch (_) {
			payload.issues.push({
				code: "invalid_format",
				format: "url",
				input: payload.value,
				inst,
				continue: !def.abort
			});
		}
	};
});
var $ZodEmoji = /*@__PURE__*/ $constructor("$ZodEmoji", (inst, def) => {
	def.pattern ?? (def.pattern = emoji());
	$ZodStringFormat.init(inst, def);
});
var $ZodNanoID = /*@__PURE__*/ $constructor("$ZodNanoID", (inst, def) => {
	if (def.length !== void 0 && (!Number.isInteger(def.length) || def.length < 1)) throw new Error(`Invalid nanoid length: ${def.length}`);
	def.pattern ?? (def.pattern = def.length === void 0 ? nanoid : nanoidOfLength(def.length));
	$ZodStringFormat.init(inst, def);
});
/**
* @deprecated CUID v1 is deprecated by its authors due to information leakage
* (timestamps embedded in the id). Use {@link $ZodCUID2} instead.
* See https://github.com/paralleldrive/cuid.
*/
var $ZodCUID = /*@__PURE__*/ $constructor("$ZodCUID", (inst, def) => {
	def.pattern ?? (def.pattern = cuid);
	$ZodStringFormat.init(inst, def);
});
var $ZodCUID2 = /*@__PURE__*/ $constructor("$ZodCUID2", (inst, def) => {
	def.pattern ?? (def.pattern = cuid2);
	$ZodStringFormat.init(inst, def);
});
var $ZodULID = /*@__PURE__*/ $constructor("$ZodULID", (inst, def) => {
	def.pattern ?? (def.pattern = ulid);
	$ZodStringFormat.init(inst, def);
});
var $ZodXID = /*@__PURE__*/ $constructor("$ZodXID", (inst, def) => {
	def.pattern ?? (def.pattern = xid);
	$ZodStringFormat.init(inst, def);
});
var $ZodKSUID = /*@__PURE__*/ $constructor("$ZodKSUID", (inst, def) => {
	def.pattern ?? (def.pattern = ksuid);
	$ZodStringFormat.init(inst, def);
});
var $ZodISODateTime = /*@__PURE__*/ $constructor("$ZodISODateTime", (inst, def) => {
	def.pattern ?? (def.pattern = datetime(def));
	$ZodStringFormat.init(inst, def);
});
var $ZodISODate = /*@__PURE__*/ $constructor("$ZodISODate", (inst, def) => {
	def.pattern ?? (def.pattern = date);
	$ZodStringFormat.init(inst, def);
});
var $ZodISOTime = /*@__PURE__*/ $constructor("$ZodISOTime", (inst, def) => {
	def.pattern ?? (def.pattern = time(def));
	$ZodStringFormat.init(inst, def);
});
var $ZodISODuration = /*@__PURE__*/ $constructor("$ZodISODuration", (inst, def) => {
	def.pattern ?? (def.pattern = duration);
	$ZodStringFormat.init(inst, def);
});
var $ZodIPv4 = /*@__PURE__*/ $constructor("$ZodIPv4", (inst, def) => {
	def.pattern ?? (def.pattern = ipv4);
	$ZodStringFormat.init(inst, def);
});
/** An IPv6 address is written with hex digits, colons and dots, and nothing else. The guard is what makes the check below an IPv6 check: `new URL("http://[...]")` parses an authority, not an address, so `@` and `\` re-delimit it and `"::@1\\"` validates against the host `0.0.0.1`. The URL parser also deletes ASCII tab, LF and CR rather than failing, which is how `"::1\n"` validated as `::1`. */
var ipv6Alphabet = /^[0-9a-fA-F:.]+$/;
function isValidIPv6(value) {
	if (!ipv6Alphabet.test(value)) return false;
	return canParseURL(`http://[${value}]`);
}
var $ZodIPv6 = /*@__PURE__*/ $constructor("$ZodIPv6", (inst, def) => {
	def.pattern ?? (def.pattern = ipv6);
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		if (!isValidIPv6(payload.value)) payload.issues.push({
			code: "invalid_format",
			format: "ipv6",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCIDRv4 = /*@__PURE__*/ $constructor("$ZodCIDRv4", (inst, def) => {
	def.pattern ?? (def.pattern = cidrv4);
	$ZodStringFormat.init(inst, def);
});
function isValidCIDRv6(value) {
	const parts = value.split("/");
	if (parts.length !== 2) return false;
	const [address, prefix] = parts;
	if (!prefix) return false;
	const prefixNum = Number(prefix);
	if (`${prefixNum}` !== prefix) return false;
	if (prefixNum < 0 || prefixNum > 128) return false;
	return isValidIPv6(address);
}
var $ZodCIDRv6 = /*@__PURE__*/ $constructor("$ZodCIDRv6", (inst, def) => {
	def.pattern ?? (def.pattern = cidrv6);
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		if (!isValidCIDRv6(payload.value)) payload.issues.push({
			code: "invalid_format",
			format: "cidrv6",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
function isValidBase64(data) {
	if (data === "") return true;
	if (/\s/.test(data)) return false;
	if (data.length % 4 !== 0) return false;
	try {
		atob(data);
		return true;
	} catch {
		return false;
	}
}
var base64Charset = /^[0-9a-zA-Z+/]*={0,2}$/;
var $ZodBase64 = /*@__PURE__*/ $constructor("$ZodBase64", (inst, def) => {
	def.pattern ?? (def.pattern = base64Charset);
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		if (isValidBase64(payload.value)) return;
		payload.issues.push({
			code: "invalid_format",
			format: "base64",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var base64urlCharset = /^[A-Za-z0-9_-]*$/;
function isValidBase64URL(data) {
	if (!base64urlCharset.test(data)) return false;
	const base64 = data.replace(/[-_]/g, (c) => c === "-" ? "+" : "/");
	return isValidBase64(base64.padEnd(Math.ceil(base64.length / 4) * 4, "="));
}
var $ZodBase64URL = /*@__PURE__*/ $constructor("$ZodBase64URL", (inst, def) => {
	def.pattern ?? (def.pattern = base64urlCharset);
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		if (isValidBase64URL(payload.value)) return;
		payload.issues.push({
			code: "invalid_format",
			format: "base64url",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodE164 = /*@__PURE__*/ $constructor("$ZodE164", (inst, def) => {
	def.pattern ?? (def.pattern = e164);
	$ZodStringFormat.init(inst, def);
});
function isValidJWT(token, algorithm = null) {
	try {
		const tokensParts = token.split(".");
		if (tokensParts.length !== 3) return false;
		const [header] = tokensParts;
		if (!header) return false;
		const parsedHeader = JSON.parse(atob(header));
		if ("typ" in parsedHeader && parsedHeader?.typ !== "JWT") return false;
		if (!parsedHeader.alg) return false;
		if (algorithm && (!("alg" in parsedHeader) || parsedHeader.alg !== algorithm)) return false;
		return true;
	} catch {
		return false;
	}
}
var $ZodJWT = /*@__PURE__*/ $constructor("$ZodJWT", (inst, def) => {
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		if (isValidJWT(payload.value, def.alg)) return;
		payload.issues.push({
			code: "invalid_format",
			format: "jwt",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodNumber = /*@__PURE__*/ $constructor("$ZodNumber", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.pattern = number$1;
	inst._zod.parse = (payload, _ctx) => {
		if (def.coerce) try {
			payload.value = Number(payload.value);
		} catch (_) {}
		const input = payload.value;
		if (typeof input === "number" && !Number.isNaN(input) && Number.isFinite(input)) return payload;
		const received = typeof input === "number" ? Number.isNaN(input) ? "NaN" : !Number.isFinite(input) ? String(input) : void 0 : void 0;
		payload.issues.push({
			expected: "number",
			code: "invalid_type",
			input,
			inst,
			...received ? { received } : {}
		});
		return payload;
	};
});
var $ZodNumberFormat = /*@__PURE__*/ $constructor("$ZodNumberFormat", (inst, def) => {
	$ZodCheckNumberFormat.init(inst, def);
	$ZodNumber.init(inst, def);
});
var $ZodBoolean = /*@__PURE__*/ $constructor("$ZodBoolean", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.pattern = boolean$1;
	inst._zod.parse = (payload, _ctx) => {
		if (def.coerce) try {
			payload.value = Boolean(payload.value);
		} catch (_) {}
		const input = payload.value;
		if (typeof input === "boolean") return payload;
		payload.issues.push({
			expected: "boolean",
			code: "invalid_type",
			input,
			inst
		});
		return payload;
	};
});
var $ZodNull = /*@__PURE__*/ $constructor("$ZodNull", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.pattern = _null$2;
	inst._zod.values = /* @__PURE__ */ new Set([null]);
	inst._zod.parse = (payload, _ctx) => {
		const input = payload.value;
		if (input === null) return payload;
		payload.issues.push({
			expected: "null",
			code: "invalid_type",
			input,
			inst
		});
		return payload;
	};
});
var $ZodUnknown = /*@__PURE__*/ $constructor("$ZodUnknown", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.parse = (payload) => payload;
});
var $ZodNever = /*@__PURE__*/ $constructor("$ZodNever", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.parse = (payload, _ctx) => {
		payload.issues.push({
			expected: "never",
			code: "invalid_type",
			input: payload.value,
			inst
		});
		return payload;
	};
});
function handleArrayResult(result, final, index) {
	if (result.issues.length) final.issues.push(...prefixIssues(index, result.issues));
	final.value[index] = result.value;
}
var $ZodArray = /*@__PURE__*/ $constructor("$ZodArray", (inst, def) => {
	$ZodType.init(inst, def);
	const memo = globalConfig.memoizer;
	memo?.attach(inst);
	inst._zod.parse = (payload, ctx) => {
		const input = payload.value;
		if (!Array.isArray(input)) {
			payload.issues.push({
				expected: "array",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		}
		payload.value = memo ? memo.alloc(inst, payload, Array(input.length), ctx) : Array(input.length);
		const proms = [];
		const abortEarly = ctx?.abortEarly;
		for (let i = 0; i < input.length; i++) {
			const item = input[i];
			const result = def.element._zod.run({
				value: item,
				issues: []
			}, ctx);
			if (result instanceof Promise) proms.push(result.then((result) => handleArrayResult(result, payload, i)));
			else {
				handleArrayResult(result, payload, i);
				if (abortEarly && result.issues.length !== 0 && aborted(result)) break;
			}
		}
		if (proms.length) return Promise.all(proms).then(() => payload);
		return payload;
	};
});
function handlePropertyResult(result, final, key, input, optin, optout) {
	const isPresent = key in input;
	const isOptionalOut = optout === "optional";
	if (!isPresent && isOptionalOut && optin === "optional") return;
	if (result.issues.length) {
		if (optin !== void 0 && isOptionalOut && !isPresent) return;
		final.issues.push(...prefixIssues(key, result.issues));
	}
	if (!isPresent && optin === void 0) {
		if (!result.issues.length) final.issues.push({
			code: "invalid_type",
			expected: "nonoptional",
			input: void 0,
			path: [key]
		});
		return;
	}
	if (result.value === void 0) {
		if (isPresent || optin === "defaulted" && !isOptionalOut) final.value[key] = void 0;
	} else final.value[key] = result.value;
}
var NO_SYMBOL_KEYS = [];
function normalizeDef(def) {
	const keys = Object.keys(def.shape);
	const ownSymbols = Object.getOwnPropertySymbols(def.shape);
	const symbolKeys = ownSymbols.length ? ownSymbols : NO_SYMBOL_KEYS;
	const allKeys = symbolKeys.length ? [...keys, ...symbolKeys] : keys;
	for (const k of allKeys) if (!def.shape?.[k]?._zod?.traits?.has("$ZodType")) throw new Error(`Invalid element at key "${String(k)}": expected a Zod schema`);
	const okeys = optionalKeys(def.shape);
	return {
		...def,
		allKeys,
		symbolKeys,
		keySet: new Set(keys),
		numKeys: keys.length,
		optionalKeys: new Set(okeys)
	};
}
function handleCatchall(proms, input, payload, ctx, def, inst, abortEarly) {
	const unrecognized = [];
	const keySet = def.keySet;
	const _catchall = def.catchall._zod;
	const t = _catchall.def.type;
	const optin = _catchall.optin;
	const optout = _catchall.optout;
	let seen = 0;
	for (const key in input) {
		if (abortEarly && payload.issues.length !== seen) {
			if (aborted(payload, seen)) break;
			seen = payload.issues.length;
		}
		if (keySet.has(key)) continue;
		if (key === "__proto__") {
			if (t === "never") unrecognized.push(key);
			continue;
		}
		if (t === "never") {
			unrecognized.push(key);
			continue;
		}
		const r = _catchall.run({
			value: input[key],
			issues: []
		}, ctx);
		if (r instanceof Promise) proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, optin, optout)));
		else handlePropertyResult(r, payload, key, input, optin, optout);
	}
	if (unrecognized.length) payload.issues.push({
		code: "unrecognized_keys",
		keys: unrecognized,
		input,
		inst,
		continue: true
	});
	if (!proms.length) return payload;
	return Promise.all(proms).then(() => {
		return payload;
	});
}
var $ZodObject = /*@__PURE__*/ $constructor("$ZodObject", (inst, def) => {
	$ZodType.init(inst, def);
	const desc = Object.getOwnPropertyDescriptor(def, "shape");
	const sh = desc?.get ? desc.get.raw : def.shape ?? {};
	if (sh) {
		const get = () => {
			const newSh = { ...sh };
			Object.defineProperty(def, "shape", { value: newSh });
			get.raw = newSh;
			return newSh;
		};
		get.raw = sh;
		Object.defineProperty(def, "shape", { get });
	}
	const _normalized = cached(() => normalizeDef(def));
	defineLazyInternal(inst, "propValues", (zod) => {
		const shape = zod.def.shape;
		const propValues = {};
		for (const key in shape) {
			const field = shape[key]._zod;
			if (field.values) {
				if (!Object.prototype.hasOwnProperty.call(propValues, key)) assignProp(propValues, key, /* @__PURE__ */ new Set());
				for (const v of field.values) propValues[key].add(v);
				if (field.optin !== void 0) propValues[key].add(void 0);
			}
		}
		return propValues;
	});
	const isObject$2 = isObject;
	const catchall = def.catchall;
	let value;
	const memo = globalConfig.memoizer;
	memo?.attach(inst);
	inst._zod.parse = (payload, ctx) => {
		value ?? (value = _normalized.value);
		const input = payload.value;
		if (!isObject$2(input)) {
			payload.issues.push({
				expected: "object",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		}
		payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
		const proms = [];
		const shape = value.shape;
		const abortEarly = ctx?.abortEarly;
		let seen = payload.issues.length;
		for (const key of value.allKeys) {
			if (abortEarly && payload.issues.length !== seen) {
				if (aborted(payload, seen)) break;
				seen = payload.issues.length;
			}
			if (key === "__proto__") continue;
			const el = shape[key];
			const optin = el._zod.optin;
			const optout = el._zod.optout;
			const r = el._zod.run({
				value: input[key],
				issues: []
			}, ctx);
			if (r instanceof Promise) proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, optin, optout)));
			else handlePropertyResult(r, payload, key, input, optin, optout);
		}
		if (!catchall) return proms.length ? Promise.all(proms).then(() => payload) : payload;
		return handleCatchall(proms, input, payload, ctx, _normalized.value, inst, abortEarly === true);
	};
});
var $ZodObjectJIT = /*@__PURE__*/ $constructor("$ZodObjectJIT", (inst, def) => {
	$ZodObject.init(inst, def);
	const superParse = inst._zod.parse;
	const _normalized = cached(() => normalizeDef(def));
	const memo = globalConfig.memoizer;
	const generateFastpass = (shape) => {
		const normalized = _normalized.value;
		const syms = normalized.symbolKeys;
		const doc = new Doc(["payload", "ctx"], {
			shape,
			inst,
			memo,
			syms
		});
		const parseStr = (k) => `shape[${k}]._zod.run({ value: input[${k}], issues: [] }, ctx)`;
		const prefixStr = (id, k) => `
          let ${id}_ab = false;
          for (let i = 0; i < ${id}.issues.length; i++) {
            const iss = ${id}.issues[i];
            iss.path = iss.path ? [${k}, ...iss.path] : [${k}];
            payload.issues.push(iss);
            if (iss.continue !== true) ${id}_ab = true;
          }
          if (${id}_ab && ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }`;
		doc.write(`const input = payload.value;`);
		const ids = Object.create(null);
		let counter = 0;
		for (const key of normalized.allKeys) ids[key] = `key_${counter++}`;
		doc.write(memo ? `const newResult = memo.alloc(inst, payload, {}, ctx);` : `const newResult = {};`);
		for (const key of normalized.allKeys) {
			if (key === "__proto__") continue;
			const id = ids[key];
			const k = typeof key === "symbol" ? `syms[${syms.indexOf(key)}]` : esc(key);
			const isPresent = `${k} in input`;
			const schema = shape[key];
			const optin = schema?._zod?.optin;
			const isOptionalIn = optin !== void 0;
			const isOptionalOut = schema?._zod?.optout === "optional";
			doc.write(`const ${id} = ${parseStr(k)};`);
			if (isOptionalIn && isOptionalOut) {
				const assign = optin === "optional" ? `${id}_present` : `${id}.value !== undefined || ${id}_present`;
				doc.write(`
        const ${id}_present = ${isPresent};
        if (!${id}.issues.length || ${id}_present) {
          if (${id}.issues.length) {${prefixStr(id, k)}
          }

          if (${assign}) {
            newResult[${k}] = ${id}.value;
          }
        }

      `);
			} else if (!isOptionalIn) doc.write(`
        const ${id}_present = ${isPresent};
        if (${id}.issues.length) {${prefixStr(id, k)}
        }
        if (!${id}_present && !${id}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${k}]
          });
          if (ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }
        }

        if (${id}_present) {
          newResult[${k}] = ${id}.value;
        }

      `);
			else {
				doc.write(`
        if (${id}.issues.length) {${prefixStr(id, k)}
        }
      `);
				if (optin === "defaulted") doc.write(`newResult[${k}] = ${id}.value;`);
				else doc.write(`
        if (${id}.value !== undefined || ${isPresent}) {
          newResult[${k}] = ${id}.value;
        }
      `);
			}
		}
		doc.write(`payload.value = newResult;`);
		doc.write(`return payload;`);
		return doc.compile();
	};
	let fastpass;
	const isObject$1 = isObject;
	const jit = !globalConfig.jitless;
	const fastEnabled = jit && allowsEval.value;
	const catchall = def.catchall;
	let value;
	inst._zod.parse = (payload, ctx) => {
		value ?? (value = _normalized.value);
		const input = payload.value;
		if (!isObject$1(input)) {
			payload.issues.push({
				expected: "object",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		}
		if (jit && fastEnabled && ctx?.async === false && ctx.jitless !== true) {
			if (!fastpass) fastpass = generateFastpass(def.shape);
			payload = fastpass(payload, ctx);
			if (!catchall) return payload;
			return handleCatchall([], input, payload, ctx, value, inst, ctx?.abortEarly === true);
		}
		return superParse(payload, ctx);
	};
});
function handleUnionResults(results, final, inst, ctx) {
	for (const result of results) if (result.issues.length === 0) {
		final.value = result.value;
		return final;
	}
	const nonaborted = results.filter((r) => !aborted(r));
	if (nonaborted.length === 1) {
		final.value = nonaborted[0].value;
		return nonaborted[0];
	}
	final.issues.push({
		code: "invalid_union",
		input: final.value,
		inst,
		errors: results.map((result) => result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
	});
	return final;
}
var $ZodUnion = /*@__PURE__*/ $constructor("$ZodUnion", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "optin", (zod) => zod.def.options.some((o) => o._zod.optin === "defaulted") ? "defaulted" : zod.def.options.some((o) => o._zod.optin !== void 0) ? "optional" : void 0);
	defineLazyInternal(inst, "optout", (zod) => zod.def.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0);
	defineLazyInternal(inst, "values", (zod) => {
		if (zod.def.options.every((o) => o._zod.values)) return new Set(zod.def.options.flatMap((option) => Array.from(option._zod.values)));
	});
	defineLazyInternal(inst, "pattern", (zod) => {
		if (zod.def.options.every((o) => o._zod.pattern)) {
			const patterns = zod.def.options.map((o) => o._zod.pattern);
			return new RegExp(`^(${patterns.map((p) => cleanRegex(p.source)).join("|")})$`);
		}
	});
	const first = def.options.length === 1 ? def.options[0]._zod.run : null;
	inst._zod.parse = (payload, ctx) => {
		if (first) return first(payload, ctx);
		let async = false;
		const results = [];
		for (const option of def.options) {
			const result = option._zod.run({
				value: payload.value,
				issues: []
			}, ctx);
			if (result instanceof Promise) {
				results.push(result);
				async = true;
			} else {
				if (result.issues.length === 0) return result;
				results.push(result);
			}
		}
		if (!async) return handleUnionResults(results, payload, inst, ctx);
		return Promise.all(results).then((results) => {
			return handleUnionResults(results, payload, inst, ctx);
		});
	};
});
function discriminatorMap(def) {
	const map = /* @__PURE__ */ new Map();
	for (const option of def.options) {
		const values = option._zod.propValues?.[def.discriminator];
		if (!values || values.size === 0) throw new Error(`Invalid discriminated union option at index "${def.options.indexOf(option)}"`);
		for (const value of values) if (map.has(value)) {
			if (value !== void 0) throw new Error(`Duplicate discriminator value "${String(value)}"`);
			map.set(value, null);
		} else map.set(value, option);
	}
	return map;
}
var $ZodDiscriminatedUnion = /*@__PURE__*/ $constructor("$ZodDiscriminatedUnion", (inst, def) => {
	def.inclusive = false;
	$ZodUnion.init(inst, def);
	const _super = inst._zod.parse;
	defineLazyInternal(inst, "propValues", (zod) => {
		const propValues = {};
		let undefinedCount = 0;
		for (const option of zod.def.options) {
			const pv = option._zod.propValues;
			if (!pv || Object.keys(pv).length === 0) throw new Error(`Invalid discriminated union option at index "${zod.def.options.indexOf(option)}"`);
			if (pv[zod.def.discriminator]?.has(void 0)) undefinedCount++;
			for (const [k, v] of Object.entries(pv)) {
				if (!Object.prototype.hasOwnProperty.call(propValues, k)) assignProp(propValues, k, /* @__PURE__ */ new Set());
				for (const val of v) propValues[k].add(val);
			}
		}
		if (!zod.def.unionFallback && undefinedCount > 1) propValues[zod.def.discriminator]?.delete(void 0);
		return propValues;
	});
	def.options.forEach((option, i) => {
		const propShape = rawShape(option._zod.def);
		if (propShape && !Object.prototype.hasOwnProperty.call(propShape, def.discriminator)) throw new Error(`Invalid discriminated union option at index "${i}"`);
	});
	const disc = cached(() => discriminatorMap(def));
	inst._zod.parse = (payload, ctx) => {
		const input = payload.value;
		if (!isObject(input)) {
			payload.issues.push({
				code: "invalid_type",
				expected: "object",
				input,
				inst
			});
			return payload;
		}
		const value = input?.[def.discriminator];
		const opt = disc.value.get(value);
		if (opt && (value !== void 0 || ctx.direction !== "backward")) return opt._zod.run(payload, ctx);
		if (def.unionFallback || ctx.direction === "backward") return _super(payload, ctx);
		payload.issues.push({
			code: "invalid_union",
			errors: [],
			note: "No matching discriminator",
			discriminator: def.discriminator,
			options: Array.from(disc.value.keys()).filter((value) => disc.value.get(value) !== null),
			input,
			path: [def.discriminator],
			inst
		});
		return payload;
	};
});
var $ZodIntersection = /*@__PURE__*/ $constructor("$ZodIntersection", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.parse = (payload, ctx) => {
		const input = payload.value;
		const left = def.left._zod.run({
			value: input,
			issues: []
		}, ctx);
		const right = def.right._zod.run({
			value: input,
			issues: []
		}, ctx);
		if (left instanceof Promise || right instanceof Promise) return Promise.all([left, right]).then(([left, right]) => {
			return handleIntersectionResults(payload, left, right);
		});
		return handleIntersectionResults(payload, left, right);
	};
});
function mergeValues(a, b) {
	if (a === b) return {
		valid: true,
		data: a
	};
	if (a instanceof Date && b instanceof Date && +a === +b) return {
		valid: true,
		data: a
	};
	if (isPlainObject(a) && isPlainObject(b)) {
		const bKeys = Object.keys(b);
		const sharedKeys = Object.keys(a).filter((key) => bKeys.indexOf(key) !== -1);
		const newObj = {
			...a,
			...b
		};
		if (Object.prototype.hasOwnProperty.call(newObj, "__proto__")) delete newObj.__proto__;
		for (const key of sharedKeys) {
			if (key === "__proto__") continue;
			const sharedValue = mergeValues(a[key], b[key]);
			if (!sharedValue.valid) return {
				valid: false,
				mergeErrorPath: [key, ...sharedValue.mergeErrorPath]
			};
			newObj[key] = sharedValue.data;
		}
		return {
			valid: true,
			data: newObj
		};
	}
	if (Array.isArray(a) && Array.isArray(b)) {
		if (a.length !== b.length) return {
			valid: false,
			mergeErrorPath: []
		};
		const newArray = [];
		for (let index = 0; index < a.length; index++) {
			const itemA = a[index];
			const itemB = b[index];
			const sharedValue = mergeValues(itemA, itemB);
			if (!sharedValue.valid) return {
				valid: false,
				mergeErrorPath: [index, ...sharedValue.mergeErrorPath]
			};
			newArray.push(sharedValue.data);
		}
		return {
			valid: true,
			data: newArray
		};
	}
	return {
		valid: false,
		mergeErrorPath: []
	};
}
function handleIntersectionResults(result, left, right) {
	const unrecKeys = /* @__PURE__ */ new Map();
	let unrecIssue;
	const keyIssues = /* @__PURE__ */ new Map();
	const collect = (iss, side) => {
		let keys;
		if (iss.code === "unrecognized_keys" && !iss.path?.length) {
			unrecIssue ?? (unrecIssue = iss);
			keys = iss.keys;
		} else if (iss.code === "invalid_key" && iss.origin === "record" && iss.path?.length === 1) {
			const k = String(iss.path[0]);
			if (!keyIssues.has(k)) keyIssues.set(k, iss);
			keys = [k];
		} else return false;
		for (const k of keys) {
			if (!unrecKeys.has(k)) unrecKeys.set(k, {});
			unrecKeys.get(k)[side] = true;
		}
		return true;
	};
	for (const iss of left.issues) if (!collect(iss, "l")) result.issues.push(iss);
	for (const iss of right.issues) if (!collect(iss, "r")) result.issues.push(iss);
	const bothKeys = [...unrecKeys].filter(([, f]) => f.l && f.r).map(([k]) => k);
	if (bothKeys.length) {
		const aggregated = unrecIssue ? bothKeys.filter((k) => unrecIssue.keys.includes(k)) : [];
		if (aggregated.length) result.issues.push({
			...unrecIssue,
			keys: aggregated
		});
		for (const k of bothKeys) if (!aggregated.includes(k) && keyIssues.has(k)) result.issues.push(keyIssues.get(k));
	}
	const merged = mergeValues(left.value, right.value);
	if (!merged.valid) {
		if (aborted(result)) return result;
		throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(merged.mergeErrorPath)}`);
	}
	result.value = merged.data;
	return result;
}
var $ZodTuple = /*@__PURE__*/ $constructor("$ZodTuple", (inst, def) => {
	$ZodType.init(inst, def);
	const items = def.items;
	const memo = globalConfig.memoizer;
	memo?.attach(inst);
	inst._zod.parse = (payload, ctx) => {
		const input = payload.value;
		if (!Array.isArray(input)) {
			payload.issues.push({
				input,
				inst,
				expected: "tuple",
				code: "invalid_type"
			});
			return payload;
		}
		payload.value = memo ? memo.alloc(inst, payload, [], ctx) : [];
		const proms = [];
		const optinStart = getTupleOptStart(items, "optin");
		const optoutStart = getTupleOptStart(items, "optout");
		if (!def.rest) {
			if (input.length < optinStart) {
				payload.issues.push({
					code: "too_small",
					minimum: optinStart,
					inclusive: true,
					input,
					inst,
					origin: "array"
				});
				return payload;
			}
			if (input.length > items.length) payload.issues.push({
				code: "too_big",
				maximum: items.length,
				inclusive: true,
				input,
				inst,
				origin: "array"
			});
		}
		const itemResults = new Array(items.length);
		const abortEarly = def.rest ? ctx?.abortEarly : void 0;
		let itemAborted = false;
		for (let i = 0; i < items.length; i++) {
			const r = items[i]._zod.run({
				value: input[i],
				issues: []
			}, ctx);
			if (r instanceof Promise) proms.push(r.then((rr) => {
				itemResults[i] = rr;
			}));
			else {
				itemResults[i] = r;
				if (abortEarly && !itemAborted && r.issues.length) itemAborted = aborted(r);
			}
		}
		if (def.rest && !itemAborted) {
			let i = items.length - 1;
			const rest = input.slice(items.length);
			let seen = payload.issues.length;
			for (const el of rest) {
				if (abortEarly && payload.issues.length !== seen) {
					if (aborted(payload, seen)) break;
					seen = payload.issues.length;
				}
				i++;
				const result = def.rest._zod.run({
					value: el,
					issues: []
				}, ctx);
				if (result instanceof Promise) proms.push(result.then((r) => handleTupleResult(r, payload, i)));
				else handleTupleResult(result, payload, i);
			}
		}
		if (proms.length) return Promise.all(proms).then(() => handleTupleResults(itemResults, payload, items, input, optoutStart));
		return handleTupleResults(itemResults, payload, items, input, optoutStart);
	};
});
function getTupleOptStart(items, key) {
	for (let i = items.length - 1; i >= 0; i--) if (!(key === "optin" ? items[i]._zod.optin !== void 0 : items[i]._zod.optout === "optional")) return i + 1;
	return 0;
}
function handleTupleResult(result, final, index) {
	if (result.issues.length) final.issues.push(...prefixIssues(index, result.issues));
	final.value[index] = result.value;
}
function handleTupleResults(itemResults, final, items, input, optoutStart) {
	for (let i = 0; i < items.length; i++) {
		const r = itemResults[i];
		const isPresent = i < input.length;
		if (!isPresent && i >= optoutStart && items[i]._zod.optin === "optional") {
			final.value.length = i;
			break;
		}
		if (r.issues.length) {
			if (!isPresent && i >= optoutStart) {
				final.value.length = i;
				break;
			}
			final.issues.push(...prefixIssues(i, r.issues));
		}
		final.value[i] = r.value;
	}
	for (let i = final.value.length - 1; i >= input.length; i--) if (items[i]._zod.optout === "optional" && final.value[i] === void 0) final.value.length = i;
	else break;
	return final;
}
var $ZodRecord = /*@__PURE__*/ $constructor("$ZodRecord", (inst, def) => {
	$ZodType.init(inst, def);
	const memo = globalConfig.memoizer;
	memo?.attach(inst);
	inst._zod.parse = (payload, ctx) => {
		const input = payload.value;
		if (!isPlainObject(input)) {
			payload.issues.push({
				expected: "record",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		}
		const proms = [];
		const values = def.keyType._zod.values;
		if (values && !def.partial) {
			payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
			const recordKeys = /* @__PURE__ */ new Set();
			for (const key of values) if (typeof key === "string" || typeof key === "number" || typeof key === "symbol") {
				recordKeys.add(typeof key === "number" ? key.toString() : key);
				if (key === "__proto__") continue;
				const keyResult = def.keyType._zod.run({
					value: key,
					issues: []
				}, ctx);
				if (keyResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
				if (keyResult.issues.length) {
					payload.issues.push({
						code: "invalid_key",
						origin: "record",
						issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
						input: key,
						path: [key],
						inst
					});
					continue;
				}
				const outKey = keyResult.value;
				if (outKey === "__proto__") continue;
				const result = def.valueType._zod.run({
					value: input[key],
					issues: []
				}, ctx);
				if (result instanceof Promise) proms.push(result.then((result) => {
					if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
					payload.value[outKey] = result.value;
				}));
				else {
					if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
					payload.value[outKey] = result.value;
				}
			}
			let unrecognized;
			for (const key in input) if (!recordKeys.has(key)) {
				if (def.mode === "loose") {
					if (key === "__proto__") continue;
					payload.value[key] = input[key];
				} else {
					unrecognized = unrecognized ?? [];
					unrecognized.push(key);
				}
			}
			if (unrecognized && unrecognized.length > 0) payload.issues.push({
				code: "unrecognized_keys",
				input,
				inst,
				keys: unrecognized,
				continue: true
			});
		} else {
			payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
			let unrecognized;
			for (const key of Reflect.ownKeys(input)) {
				if (key === "__proto__") continue;
				if (!Object.prototype.propertyIsEnumerable.call(input, key)) continue;
				let keyResult = def.keyType._zod.run({
					value: key,
					issues: []
				}, ctx);
				if (keyResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
				if (typeof key === "string" && number$1.test(key) && keyResult.issues.length) {
					const retryResult = def.keyType._zod.run({
						value: Number(key),
						issues: []
					}, ctx);
					if (retryResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
					if (retryResult.issues.length === 0) keyResult = retryResult;
				}
				if (keyResult.issues.length) {
					if (def.mode === "loose") payload.value[key] = input[key];
					else if (values) {
						unrecognized = unrecognized ?? [];
						unrecognized.push(key);
					} else payload.issues.push({
						code: "invalid_key",
						origin: "record",
						issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
						input: key,
						path: [key],
						inst
					});
					continue;
				}
				const outKey = keyResult.value;
				if (outKey === "__proto__") continue;
				const result = def.valueType._zod.run({
					value: input[key],
					issues: []
				}, ctx);
				if (result instanceof Promise) proms.push(result.then((result) => {
					if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
					payload.value[outKey] = result.value;
				}));
				else {
					if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
					payload.value[outKey] = result.value;
				}
			}
			if (unrecognized && unrecognized.length > 0) payload.issues.push({
				code: "unrecognized_keys",
				input,
				inst,
				keys: unrecognized,
				continue: true
			});
		}
		if (proms.length) return Promise.all(proms).then(() => payload);
		return payload;
	};
});
var $ZodEnum = /*@__PURE__*/ $constructor("$ZodEnum", (inst, def) => {
	$ZodType.init(inst, def);
	const values = getEnumValues(def.entries);
	const valuesSet = new Set(values);
	inst._zod.values = valuesSet;
	defineLazyInternal(inst, "pattern", (zod) => {
		const patternValues = getEnumValues(zod.def.entries).filter((k) => propertyKeyTypes.has(typeof k));
		return new RegExp(patternValues.length ? `^(${patternValues.map((o) => escapeRegex(o.toString())).join("|")})$` : "^[^\\s\\S]$");
	});
	inst._zod.parse = (payload, _ctx) => {
		const input = payload.value;
		if (valuesSet.has(input)) return payload;
		payload.issues.push({
			code: "invalid_value",
			values,
			input,
			inst
		});
		return payload;
	};
});
var $ZodLiteral = /*@__PURE__*/ $constructor("$ZodLiteral", (inst, def) => {
	$ZodType.init(inst, def);
	const values = new Set(def.values);
	inst._zod.values = values;
	defineLazyInternal(inst, "pattern", (zod) => {
		const vals = zod.def.values;
		return new RegExp(vals.length ? `^(${vals.map((o) => typeof o === "string" ? escapeRegex(o) : o ? escapeRegex(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$");
	});
	inst._zod.parse = (payload, _ctx) => {
		const input = payload.value;
		if (values.has(input)) return payload;
		payload.issues.push({
			code: "invalid_value",
			values: def.values,
			input,
			inst
		});
		return payload;
	};
});
var $ZodTransform = /*@__PURE__*/ $constructor("$ZodTransform", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.optin = "optional";
	globalConfig.memoizer?.guard(inst);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") throw new $ZodEncodeError(inst.constructor.name);
		const _out = def.transform(payload.value, payload);
		if (ctx.async) return (_out instanceof Promise ? _out : Promise.resolve(_out)).then((output) => {
			payload.value = output;
			return payload;
		});
		if (_out instanceof Promise) throw new $ZodAsyncError();
		payload.value = _out;
		return payload;
	};
});
function handleOptionalResult(payload, result) {
	payload.value = result.issues.length ? void 0 : result.value;
	return payload;
}
var $ZodOptional = /*@__PURE__*/ $constructor("$ZodOptional", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
	inst._zod.optout = "optional";
	defineLazyInternal(inst, "values", (zod) => {
		const values = zod.def.innerType._zod.values;
		return values ? /* @__PURE__ */ new Set([...values, void 0]) : void 0;
	});
	defineLazyInternal(inst, "pattern", (zod) => {
		const pattern = zod.def.innerType._zod.pattern;
		return pattern ? new RegExp(`^(${cleanRegex(pattern.source)})?$`) : void 0;
	});
	inst._zod.parse = (payload, ctx) => {
		if (payload.value === void 0) {
			if (def.innerType._zod.optin !== "defaulted") return payload;
			const result = def.innerType._zod.run({
				value: payload.value,
				issues: []
			}, ctx);
			if (result instanceof Promise) return result.then((result) => handleOptionalResult(payload, result));
			return handleOptionalResult(payload, result);
		}
		return def.innerType._zod.run(payload, ctx);
	};
});
var $ZodExactOptional = /*@__PURE__*/ $constructor("$ZodExactOptional", (inst, def) => {
	$ZodOptional.init(inst, def);
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	defineLazyInternal(inst, "pattern", (zod) => zod.def.innerType._zod.pattern);
	inst._zod.parse = (payload, ctx) => {
		return def.innerType._zod.run(payload, ctx);
	};
});
var $ZodNullable = /*@__PURE__*/ $constructor("$ZodNullable", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin);
	defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
	defineLazyInternal(inst, "pattern", (zod) => {
		const pattern = zod.def.innerType._zod.pattern;
		return pattern ? new RegExp(`^(${cleanRegex(pattern.source)}|null)$`) : void 0;
	});
	defineLazyInternal(inst, "values", (zod) => {
		return zod.def.innerType._zod.values ? /* @__PURE__ */ new Set([...zod.def.innerType._zod.values, null]) : void 0;
	});
	inst._zod.parse = (payload, ctx) => {
		if (payload.value === null) return payload;
		return def.innerType._zod.run(payload, ctx);
	};
});
var $ZodDefault = /*@__PURE__*/ $constructor("$ZodDefault", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.optin = "defaulted";
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
		if (payload.value === void 0) {
			payload.value = def.defaultValue;
			/**
			* $ZodDefault returns the default value immediately in forward direction.
			* It doesn't pass the default value into the validator ("prefault"). There's no reason to pass the default value through validation. The validity of the default is enforced by TypeScript statically. Otherwise, it's the responsibility of the user to ensure the default is valid. In the case of pipes with divergent in/out types, you can specify the default on the `in` schema of your ZodPipe to set a "prefault" for the pipe.   */
			return payload;
		}
		const result = def.innerType._zod.run(payload, ctx);
		if (result instanceof Promise) return result.then((result) => handleDefaultResult(result, def));
		return handleDefaultResult(result, def);
	};
});
function handleDefaultResult(payload, def) {
	if (payload.value === void 0) payload.value = def.defaultValue;
	return payload;
}
var $ZodPrefault = /*@__PURE__*/ $constructor("$ZodPrefault", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.optin = "defaulted";
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
		if (payload.value === void 0) payload.value = def.defaultValue;
		return def.innerType._zod.run(payload, ctx);
	};
});
var $ZodNonOptional = /*@__PURE__*/ $constructor("$ZodNonOptional", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "values", (zod) => {
		const v = zod.def.innerType._zod.values;
		return v ? new Set([...v].filter((x) => x !== void 0)) : void 0;
	});
	inst._zod.parse = (payload, ctx) => {
		const result = def.innerType._zod.run(payload, ctx);
		if (result instanceof Promise) return result.then((result) => handleNonOptionalResult(result, inst));
		return handleNonOptionalResult(result, inst);
	};
});
function handleNonOptionalResult(payload, inst) {
	if (!payload.issues.length && payload.value === void 0) payload.issues.push({
		code: "invalid_type",
		expected: "nonoptional",
		input: payload.value,
		inst
	});
	return payload;
}
function handleCatchResult(payload, result, def, ctx) {
	if (!result.issues.length) {
		payload.value = result.value;
		if (result.memo) payload.memo = true;
		return payload;
	}
	payload.value = def.catchValue({
		...result,
		value: payload.value,
		error: { issues: result.issues.map((iss) => finalizeIssue(iss, ctx, config())) },
		input: payload.value
	});
	return payload;
}
var $ZodCatch = /*@__PURE__*/ $constructor("$ZodCatch", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
	defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
		const result = def.innerType._zod.run({
			value: payload.value,
			issues: []
		}, ctx);
		if (result instanceof Promise) return result.then((result) => handleCatchResult(payload, result, def, ctx));
		return handleCatchResult(payload, result, def, ctx);
	};
});
var $ZodPipe = /*@__PURE__*/ $constructor("$ZodPipe", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "values", (zod) => zod.def.in._zod.values);
	defineLazyInternal(inst, "optin", (zod) => zod.def.in._zod.optin);
	defineLazyInternal(inst, "optout", (zod) => zod.def.out._zod.optout);
	defineLazyInternal(inst, "propValues", (zod) => zod.def.in._zod.propValues);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") {
			const right = def.out._zod.run(payload, ctx);
			if (right instanceof Promise) return right.then((right) => handlePipeResult(right, def.in, ctx));
			return handlePipeResult(right, def.in, ctx);
		}
		const left = def.in._zod.run(payload, ctx);
		if (left instanceof Promise) return left.then((left) => handlePipeResult(left, def.out, ctx));
		return handlePipeResult(left, def.out, ctx);
	};
});
function handlePipeResult(left, next, ctx) {
	if (left.issues.some((iss) => iss.code !== "unrecognized_keys")) {
		left.aborted = true;
		return left;
	}
	return next._zod.run({
		value: left.value,
		issues: left.issues
	}, ctx);
}
var $ZodReadonly = /*@__PURE__*/ $constructor("$ZodReadonly", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "propValues", (zod) => zod.def.innerType._zod.propValues);
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	defineLazyInternal(inst, "optin", (zod) => zod.def.innerType?._zod?.optin);
	defineLazyInternal(inst, "optout", (zod) => zod.def.innerType?._zod?.optout);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
		const result = def.innerType._zod.run(payload, ctx);
		if (result instanceof Promise) return result.then(handleReadonlyResult);
		return handleReadonlyResult(result);
	};
});
function handleReadonlyResult(payload) {
	if (!payload.memo) payload.value = Object.freeze(payload.value);
	return payload;
}
var $ZodCustom = /*@__PURE__*/ $constructor("$ZodCustom", (inst, def) => {
	$ZodCheck.init(inst, def);
	$ZodType.init(inst, def);
	inst._zod.parse = (payload, _) => {
		return payload;
	};
	inst._zod.check = (payload) => {
		const input = payload.value;
		const r = def.fn(input);
		if (r instanceof Promise) return r.then((r) => handleRefineResult(r, payload, input, inst));
		handleRefineResult(r, payload, input, inst);
	};
});
function handleRefineResult(result, payload, input, inst) {
	if (!result) {
		const _iss = {
			code: "custom",
			input,
			inst,
			path: [...inst._zod.def.path ?? []],
			continue: !inst._zod.def.abort
		};
		if (inst._zod.def.params) _iss.params = inst._zod.def.params;
		payload.issues.push(issue(_iss));
	}
}
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/memoizer.js
var $ZodCyclicError = class extends Error {
	constructor() {
		super(`Cannot parse a reference cycle that closes through a transform`);
		this.name = "ZodCyclicError";
	}
};
/** Keyed off the context object every schema in one parse call already shares. */
var STATE = "~memo";
var NO_ISSUES = [];
function isRef(value) {
	return value !== null && typeof value === "object";
}
function cloneIssues(issues) {
	return issues.map((iss) => iss.path ? {
		...iss,
		path: iss.path.slice()
	} : { ...iss });
}
var recursive = /*@__PURE__*/ new WeakMap();
/** What the walk established, in order of certainty: ordered so the strongest answer among children wins. */
var NONE = 0;
var ASSUMED = 1;
var PROVEN = 2;
/** Whether this schema's subtree contains a cycle, so one parse can re-enter it. */
function isRecursive(inst, stack, resolve) {
	const cached = recursive.get(inst);
	if (cached !== void 0) return cached ? PROVEN : NONE;
	if (stack.has(inst)) return PROVEN;
	stack.add(inst);
	let result = NONE;
	const check = (child) => {
		if (result !== PROVEN && child?._zod) {
			const answer = isRecursive(child, stack, resolve);
			if (answer > result) result = answer;
		}
	};
	const shape = (sh, spread) => {
		let answer = NONE;
		for (const key of Reflect.ownKeys(sh)) {
			const desc = Object.getOwnPropertyDescriptor(sh, key);
			if (spread && !desc.enumerable) continue;
			const child = desc.get ? ASSUMED : desc.value?._zod ? isRecursive(desc.value, stack, resolve) : NONE;
			if (child > answer) answer = child;
		}
		return answer;
	};
	const merge = (answer) => {
		if (answer > result) result = answer;
	};
	const def = inst._zod.def;
	switch (def.type) {
		case "object": {
			const raw = rawShape(def);
			merge(raw ? shape(raw, true) : ASSUMED);
			check(def.catchall);
			break;
		}
		case "array":
			check(def.element);
			break;
		case "tuple":
			for (const el of def.items) check(el);
			check(def.rest);
			break;
		case "record":
		case "map":
			check(def.keyType);
			check(def.valueType);
			break;
		case "set":
			check(def.valueType);
			break;
		case "union":
			for (const el of def.options) check(el);
			break;
		case "intersection":
			check(def.left);
			check(def.right);
			break;
		case "optional":
		case "nullable":
		case "default":
		case "prefault":
		case "catch":
		case "readonly":
		case "nonoptional":
		case "promise":
		case "success":
			check(def.innerType);
			break;
		case "pipe":
			check(def.in);
			check(def.out);
			break;
		case "function":
			check(def.input);
			check(def.output);
			break;
		case "lazy": {
			const inner = def._cachedInner ?? (resolve ? inst._zod.innerType : void 0);
			merge(inner ? isRecursive(inner, stack, false) : ASSUMED);
			break;
		}
		case "template_literal":
		case "string":
		case "number":
		case "int":
		case "boolean":
		case "bigint":
		case "symbol":
		case "undefined":
		case "null":
		case "void":
		case "never":
		case "any":
		case "unknown":
		case "date":
		case "nan":
		case "enum":
		case "literal":
		case "file":
		case "transform":
		case "custom": break;
		default: for (const key in def) {
			const desc = Object.getOwnPropertyDescriptor(def, key);
			if (!desc || desc.get) continue;
			const value = desc.value;
			if (!value || typeof value !== "object") continue;
			if (value._zod) check(value);
			else if (Array.isArray(value)) for (const el of value) check(el);
		}
	}
	stack.delete(inst);
	return settle(inst, result);
}
/** An assumed answer must not outlive the resolution that settles it, so only a certain one is cached. */
function settle(inst, answer) {
	if (answer !== ASSUMED) recursive.set(inst, answer === PROVEN);
	return answer;
}
function bucketFor(state, inst) {
	let bucket = state.buckets.get(inst);
	if (!bucket) {
		bucket = /* @__PURE__ */ new WeakMap();
		state.buckets.set(inst, bucket);
	}
	return bucket;
}
var handoff;
var open$1 = [];
var memo = {
	alloc(_inst, payload, empty) {
		const bucket = handoff;
		if (!bucket) return empty;
		handoff = void 0;
		const entry = {
			value: empty,
			issues: null
		};
		bucket.set(payload.value, entry);
		open$1.push(entry);
		return empty;
	},
	guard(inst) {
		var _a;
		(_a = inst._zod).deferred ?? (_a.deferred = []);
		inst._zod.deferred.push(() => {
			const base = inst._zod.parse;
			const wrapped = (payload, ctx) => {
				if (ctx.direction !== "backward" && isBackEdge(ctx, payload.value)) throw new $ZodCyclicError();
				return base(payload, ctx);
			};
			inst._zod.parse = wrapped;
			if (inst._zod.run === base) inst._zod.run = wrapped;
		});
	},
	attach(inst) {
		var _a;
		let isRecursiveInst;
		let rechecked = false;
		let lastCtx;
		let lastBucket;
		(_a = inst._zod).deferred ?? (_a.deferred = []);
		inst._zod.deferred.push(() => {
			const base = inst._zod.parse;
			const wrapped = (payload, ctx) => {
				if (isRecursiveInst === void 0) {
					const walked = isRecursive(inst, /* @__PURE__ */ new Set(), false);
					if (walked === NONE) {
						inst._zod.parse = base;
						if (inst._zod.run === wrapped) inst._zod.run = base;
						return base(payload, ctx);
					}
					if (walked === PROVEN || rechecked) isRecursiveInst = true;
					else rechecked = true;
				}
				const input = payload.value;
				if (!isRef(input)) return base(payload, ctx);
				let state = ctx[STATE];
				if (!state) {
					state = {
						buckets: /* @__PURE__ */ new WeakMap(),
						backEdges: void 0
					};
					ctx[STATE] = state;
				}
				let bucket;
				if (lastCtx === ctx) bucket = lastBucket;
				else {
					bucket = bucketFor(state, inst);
					lastCtx = ctx;
					lastBucket = bucket;
				}
				const hit = bucket.get(input);
				if (hit) {
					payload.value = hit.value;
					if (hit.issues) {
						if (hit.issues.length) payload.issues.push(...cloneIssues(hit.issues));
					} else {
						payload.memo = true;
						state.backEdges ?? (state.backEdges = /* @__PURE__ */ new WeakSet());
						state.backEdges.add(hit.value);
					}
					return payload;
				}
				handoff = bucket;
				const depth = open$1.length;
				const result = base(payload, ctx);
				handoff = void 0;
				const entry = open$1.length > depth ? open$1.pop() : void 0;
				if (result instanceof Promise) return result.then((r) => {
					if (entry) entry.issues = r.issues.length ? cloneIssues(r.issues) : NO_ISSUES;
					return r;
				});
				if (entry) entry.issues = result.issues.length ? cloneIssues(result.issues) : NO_ISSUES;
				return result;
			};
			inst._zod.parse = wrapped;
			if (inst._zod.run === base) inst._zod.run = wrapped;
		});
	}
};
/** The memoizer that gives containers cycle support. `zod` installs it by default; `zod/mini` opts in with `config({ memoizer: memoizer() })`. */
function memoizer() {
	return memo;
}
/** Whether this value is a node a back-edge resolved to before it finished. */
function isBackEdge(ctx, value) {
	const backEdges = ctx[STATE]?.backEdges;
	return backEdges !== void 0 && isRef(value) && backEdges.has(value);
}
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/locales/en.js
var error = () => {
	const Sizable = {
		string: {
			unit: "characters",
			verb: "to have"
		},
		file: {
			unit: "bytes",
			verb: "to have"
		},
		array: {
			unit: "items",
			verb: "to have"
		},
		set: {
			unit: "items",
			verb: "to have"
		},
		map: {
			unit: "entries",
			verb: "to have"
		}
	};
	function getSizing(origin) {
		return Sizable[origin] ?? null;
	}
	const FormatDictionary = {
		regex: "input",
		email: "email address",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datetime",
		date: "ISO date",
		time: "ISO time",
		duration: "ISO duration",
		ipv4: "IPv4 address",
		ipv6: "IPv6 address",
		mac: "MAC address",
		cidrv4: "IPv4 range",
		cidrv6: "IPv6 range",
		base64: "base64-encoded string",
		base64url: "base64url-encoded string",
		json_string: "JSON string",
		e164: "E.164 number",
		currency_code: "currency code",
		credit_card: "credit card number",
		iban: "IBAN",
		jwt: "JWT",
		template_literal: "input"
	};
	const TypeDictionary = { nan: "NaN" };
	function getTypeName(type, input) {
		if (type === "number" && typeof input === "number" && !Number.isFinite(input)) return String(input);
		return TypeDictionary[type] ?? type;
	}
	return (issue) => {
		switch (issue.code) {
			case "invalid_type": return `Invalid input: expected ${getTypeName(issue.expected)}, received ${getTypeName(parsedType(issue.input), issue.input)}`;
			case "invalid_value":
				if (issue.values.length === 1) return `Invalid input: expected ${stringifyPrimitive(issue.values[0])}`;
				return `Invalid option: expected one of ${joinValues(issue.values, "|")}`;
			case "too_big": {
				const adj = issue.exact ? "exactly " : issue.inclusive ? "<=" : "<";
				const sizing = getSizing(issue.origin);
				if (sizing) return `Too big: expected ${issue.origin ?? "value"} to have ${adj}${issue.maximum.toString()} ${sizing.unit ?? "elements"}`;
				return `Too big: expected ${issue.origin ?? "value"} to be ${adj}${issue.maximum.toString()}`;
			}
			case "too_small": {
				const adj = issue.exact ? "exactly " : issue.inclusive ? ">=" : ">";
				const sizing = getSizing(issue.origin);
				if (sizing) return `Too small: expected ${issue.origin} to have ${adj}${issue.minimum.toString()} ${sizing.unit}`;
				return `Too small: expected ${issue.origin} to be ${adj}${issue.minimum.toString()}`;
			}
			case "invalid_format": {
				const _issue = issue;
				if (_issue.format === "starts_with") return `Invalid string: must start with "${_issue.prefix}"`;
				if (_issue.format === "ends_with") return `Invalid string: must end with "${_issue.suffix}"`;
				if (_issue.format === "includes") return `Invalid string: must include "${_issue.includes}"`;
				if (_issue.format === "regex") return `Invalid string: must match pattern ${_issue.pattern}`;
				return `Invalid ${FormatDictionary[_issue.format] ?? issue.format}`;
			}
			case "not_multiple_of": return `Invalid number: must be a multiple of ${issue.divisor}`;
			case "unrecognized_keys": return `Unrecognized key${issue.keys.length > 1 ? "s" : ""}: ${joinValues(issue.keys, ", ")}`;
			case "invalid_key": return `Invalid key in ${issue.origin}`;
			case "invalid_union":
				if (issue.options && Array.isArray(issue.options) && issue.options.length > 0) return `Invalid discriminator value. Expected ${issue.options.map((o) => `'${o}'`).join(" | ")}`;
				if (issue.inclusive === false) return "Invalid input: more than one option matched";
				return "Invalid input";
			case "invalid_element": return `Invalid value in ${issue.origin}`;
			default: return `Invalid input`;
		}
	};
};
function en_default() {
	return { localeError: error() };
}
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/registries.js
var _a;
var $ZodRegistry = class {
	constructor() {
		this._map = /* @__PURE__ */ new WeakMap();
		this._idmap = /* @__PURE__ */ new Map();
	}
	add(schema, ..._meta) {
		const meta = _meta[0];
		this._map.set(schema, meta);
		if (meta && typeof meta === "object" && "id" in meta) this._idmap.set(meta.id, schema);
		return this;
	}
	clear() {
		this._map = /* @__PURE__ */ new WeakMap();
		this._idmap = /* @__PURE__ */ new Map();
		return this;
	}
	remove(schema) {
		const meta = this._map.get(schema);
		if (meta && typeof meta === "object" && "id" in meta) this._idmap.delete(meta.id);
		this._map.delete(schema);
		return this;
	}
	get(schema) {
		const p = schema._zod.parent;
		if (p) {
			const pm = { ...this.get(p) ?? {} };
			delete pm.id;
			const f = {
				...pm,
				...this._map.get(schema)
			};
			return Object.keys(f).length ? f : void 0;
		}
		return this._map.get(schema);
	}
	has(schema) {
		return this._map.has(schema);
	}
};
function registry() {
	return new $ZodRegistry();
}
(_a = globalThis).__zod_globalRegistry ?? (_a.__zod_globalRegistry = registry());
var globalRegistry = globalThis.__zod_globalRegistry;
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/api.js
function snapshotChecks(def) {
	if (def.checks) def.checks = [...def.checks];
	return def;
}
// @__NO_SIDE_EFFECTS__
function _string(Class, params) {
	return new Class(snapshotChecks({
		type: "string",
		...normalizeParams(params)
	}));
}
// @__NO_SIDE_EFFECTS__
function _email(Class, params) {
	return new Class({
		type: "string",
		format: "email",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _guid(Class, params) {
	return new Class({
		type: "string",
		format: "guid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uuid(Class, params) {
	return new Class({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uuidv4(Class, params) {
	return new Class({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: false,
		version: "v4",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uuidv6(Class, params) {
	return new Class({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: false,
		version: "v6",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uuidv7(Class, params) {
	return new Class({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: false,
		version: "v7",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _url(Class, params) {
	return new Class({
		type: "string",
		format: "url",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _emoji(Class, params) {
	return new Class({
		type: "string",
		format: "emoji",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _nanoid(Class, params) {
	return new Class({
		type: "string",
		format: "nanoid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
/**
* @deprecated CUID v1 is deprecated by its authors due to information leakage
* (timestamps embedded in the id). Use {@link _cuid2} instead.
* See https://github.com/paralleldrive/cuid.
*/
// @__NO_SIDE_EFFECTS__
function _cuid(Class, params) {
	return new Class({
		type: "string",
		format: "cuid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _cuid2(Class, params) {
	return new Class({
		type: "string",
		format: "cuid2",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _ulid(Class, params) {
	return new Class({
		type: "string",
		format: "ulid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _xid(Class, params) {
	return new Class({
		type: "string",
		format: "xid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _ksuid(Class, params) {
	return new Class({
		type: "string",
		format: "ksuid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _ipv4(Class, params) {
	return new Class({
		type: "string",
		format: "ipv4",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _ipv6(Class, params) {
	return new Class({
		type: "string",
		format: "ipv6",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _cidrv4(Class, params) {
	return new Class({
		type: "string",
		format: "cidrv4",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _cidrv6(Class, params) {
	return new Class({
		type: "string",
		format: "cidrv6",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _base64(Class, params) {
	return new Class({
		type: "string",
		format: "base64",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _base64url(Class, params) {
	return new Class({
		type: "string",
		format: "base64url",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _e164(Class, params) {
	return new Class({
		type: "string",
		format: "e164",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _jwt(Class, params) {
	return new Class({
		type: "string",
		format: "jwt",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _isoDateTime(Class, params) {
	return new Class({
		type: "string",
		format: "datetime",
		check: "string_format",
		offset: false,
		local: false,
		precision: null,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _isoDate(Class, params) {
	return new Class({
		type: "string",
		format: "date",
		check: "string_format",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _isoTime(Class, params) {
	return new Class({
		type: "string",
		format: "time",
		check: "string_format",
		precision: null,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _isoDuration(Class, params) {
	return new Class({
		type: "string",
		format: "duration",
		check: "string_format",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _number(Class, params) {
	return new Class(snapshotChecks({
		type: "number",
		checks: [],
		...normalizeParams(params)
	}));
}
// @__NO_SIDE_EFFECTS__
function _int(Class, params) {
	return new Class({
		type: "number",
		check: "number_format",
		abort: false,
		format: "safeint",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _boolean(Class, params) {
	return new Class({
		type: "boolean",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _null$1(Class, params) {
	return new Class({
		type: "null",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _unknown(Class) {
	return new Class({ type: "unknown" });
}
// @__NO_SIDE_EFFECTS__
function _never(Class, params) {
	return new Class({
		type: "never",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _lt(value, params) {
	return new $ZodCheckLessThan({
		check: "less_than",
		...normalizeParams(params),
		value,
		inclusive: false
	});
}
// @__NO_SIDE_EFFECTS__
function _lte(value, params) {
	return new $ZodCheckLessThan({
		check: "less_than",
		...normalizeParams(params),
		value,
		inclusive: true
	});
}
// @__NO_SIDE_EFFECTS__
function _gt(value, params) {
	return new $ZodCheckGreaterThan({
		check: "greater_than",
		...normalizeParams(params),
		value,
		inclusive: false
	});
}
// @__NO_SIDE_EFFECTS__
function _gte(value, params) {
	return new $ZodCheckGreaterThan({
		check: "greater_than",
		...normalizeParams(params),
		value,
		inclusive: true
	});
}
// @__NO_SIDE_EFFECTS__
function _multipleOf(value, params) {
	return new $ZodCheckMultipleOf({
		check: "multiple_of",
		...normalizeParams(params),
		value
	});
}
// @__NO_SIDE_EFFECTS__
function _maxLength(maximum, params) {
	return new $ZodCheckMaxLength({
		check: "max_length",
		...normalizeParams(params),
		maximum
	});
}
// @__NO_SIDE_EFFECTS__
function _minLength(minimum, params) {
	return new $ZodCheckMinLength({
		check: "min_length",
		...normalizeParams(params),
		minimum
	});
}
// @__NO_SIDE_EFFECTS__
function _length(length, params) {
	return new $ZodCheckLengthEquals({
		check: "length_equals",
		...normalizeParams(params),
		length
	});
}
// @__NO_SIDE_EFFECTS__
function _regex(pattern, params) {
	return new $ZodCheckRegex({
		check: "string_format",
		format: "regex",
		...normalizeParams(params),
		pattern
	});
}
// @__NO_SIDE_EFFECTS__
function _lowercase(params) {
	return new $ZodCheckLowerCase({
		check: "string_format",
		format: "lowercase",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uppercase(params) {
	return new $ZodCheckUpperCase({
		check: "string_format",
		format: "uppercase",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _includes(includes, params) {
	return new $ZodCheckIncludes({
		check: "string_format",
		format: "includes",
		...normalizeParams(params),
		includes
	});
}
// @__NO_SIDE_EFFECTS__
function _startsWith(prefix, params) {
	return new $ZodCheckStartsWith({
		check: "string_format",
		format: "starts_with",
		...normalizeParams(params),
		prefix
	});
}
// @__NO_SIDE_EFFECTS__
function _endsWith(suffix, params) {
	return new $ZodCheckEndsWith({
		check: "string_format",
		format: "ends_with",
		...normalizeParams(params),
		suffix
	});
}
// @__NO_SIDE_EFFECTS__
function _properties(shape, params) {
	return new $ZodCheckProperties({
		check: "properties",
		shape,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _overwrite(tx) {
	return new $ZodCheckOverwrite({
		check: "overwrite",
		tx
	});
}
// @__NO_SIDE_EFFECTS__
function _normalize(form) {
	return /* @__PURE__ */ _overwrite((input) => input.normalize(form));
}
// @__NO_SIDE_EFFECTS__
function _trim() {
	return /* @__PURE__ */ _overwrite((input) => input.trim());
}
// @__NO_SIDE_EFFECTS__
function _toLowerCase() {
	return /* @__PURE__ */ _overwrite((input) => input.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function _toUpperCase() {
	return /* @__PURE__ */ _overwrite((input) => input.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function _slugify() {
	return /* @__PURE__ */ _overwrite((input) => slugify(input));
}
// @__NO_SIDE_EFFECTS__
function _array(Class, element, params) {
	return new Class({
		type: "array",
		element,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _refine(Class, fn, _params) {
	return new Class({
		type: "custom",
		check: "custom",
		fn,
		...normalizeParams(_params)
	});
}
// @__NO_SIDE_EFFECTS__
function _superRefine(fn, params) {
	const ch = /* @__PURE__ */ _check((payload) => {
		payload.addIssue = (issue$2) => {
			if (typeof issue$2 === "string") payload.issues.push(issue(issue$2, payload.value, ch._zod.def));
			else {
				const _issue = issue$2;
				if (_issue.fatal) _issue.continue = false;
				_issue.code ?? (_issue.code = "custom");
				if (!("input" in _issue)) _issue.input = payload.value;
				_issue.inst ?? (_issue.inst = ch);
				_issue.continue ?? (_issue.continue = !ch._zod.def.abort);
				payload.issues.push(issue(_issue));
			}
		};
		return fn(payload.value, payload);
	}, params);
	return ch;
}
// @__NO_SIDE_EFFECTS__
function _check(fn, params) {
	const ch = new $ZodCheck({
		check: "custom",
		...normalizeParams(params)
	});
	ch._zod.check = fn;
	return ch;
}
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/to-json-schema.js
function assignProps(target, ...sources) {
	for (const source of sources) for (const key of Reflect.ownKeys(source)) if (Object.prototype.propertyIsEnumerable.call(source, key)) assignProp(target, key, source[key]);
	return target;
}
function initializeContext(params) {
	let target = params?.target ?? "draft-2020-12";
	if (target === "draft-4") target = "draft-04";
	if (target === "draft-7") target = "draft-07";
	return {
		processors: params.processors ?? {},
		metadataRegistry: params?.metadata ?? globalRegistry,
		target,
		unrepresentable: params?.unrepresentable ?? "throw",
		override: params?.override ?? (() => {}),
		io: params?.io ?? "output",
		counter: 0,
		seen: /* @__PURE__ */ new Map(),
		sharedDefsExtractedFor: void 0,
		sharedEmitDoneFor: void 0,
		cycles: params?.cycles ?? "ref",
		reused: params?.reused ?? "inline",
		intersections: [],
		deferred: [],
		external: params?.external ?? void 0
	};
}
/**
* Applies the `unrepresentable` setting at a site that has no JSON Schema equivalent. Throws
* `message` unless the setting (or the handler's return value) says otherwise. Returns `true` if a
* custom JSON Schema was written into `json`, in which case the caller must not write its own.
*/
function handleUnrepresentable(schema, ctx, json, params, message) {
	const result = typeof ctx.unrepresentable === "function" ? ctx.unrepresentable({
		zodSchema: schema,
		path: params.path,
		message
	}) : ctx.unrepresentable;
	if (result === "any") return false;
	if (result === void 0 || result === "throw") throw new Error(message);
	Object.assign(json, result);
	return true;
}
function processSchema(schema, ctx, _params = {
	path: [],
	schemaPath: []
}) {
	var _a;
	const def = schema._zod.def;
	const seen = ctx.seen.get(schema);
	if (seen) {
		seen.count++;
		if (_params.schemaPath.includes(schema)) seen.cycle = _params.path;
		return seen.schema;
	}
	const result = {
		schema: {},
		count: 1,
		cycle: void 0,
		path: _params.path
	};
	ctx.seen.set(schema, result);
	ctx.sharedDefsExtractedFor = void 0;
	ctx.sharedEmitDoneFor = void 0;
	const overrideSchema = schema._zod.toJSONSchema?.();
	if (overrideSchema) result.schema = overrideSchema;
	else {
		const params = {
			..._params,
			schemaPath: [..._params.schemaPath, schema],
			path: _params.path
		};
		if (schema._zod.processJSONSchema) schema._zod.processJSONSchema(ctx, result.schema, params);
		else {
			const _json = result.schema;
			const processor = ctx.processors[def.type];
			if (!processor) throw new Error(`[toJSONSchema]: Non-representable type encountered: ${def.type}`);
			processor(schema, ctx, _json, params);
		}
		const parent = schema._zod.parent;
		if (parent) {
			if (!result.ref) result.ref = parent;
			processSchema(parent, ctx, params);
			ctx.seen.get(parent).isParent = true;
		}
	}
	const meta = ctx.metadataRegistry.get(schema);
	if (meta) assignProps(result.schema, meta);
	if (ctx.io === "input" && isTransforming(schema)) {
		delete result.schema.examples;
		delete result.schema.default;
	}
	if (ctx.io === "input" && "_prefault" in result.schema) (_a = result.schema).default ?? (_a.default = result.schema._prefault);
	delete result.schema._prefault;
	return ctx.seen.get(schema).schema;
}
function encodeJSONPointerSegment(segment) {
	return segment.replace(/~/g, "~0").replace(/\//g, "~1");
}
function extractDefs(ctx, schema) {
	const root = ctx.seen.get(schema);
	if (!root) throw new Error("Unprocessed schema. This is a bug in Zod.");
	if (ctx.external && ctx.sharedDefsExtractedFor === ctx.external) return;
	const idToSchema = /* @__PURE__ */ new Map();
	for (const entry of ctx.seen.entries()) {
		const id = ctx.metadataRegistry.get(entry[0])?.id;
		if (id) {
			const existing = idToSchema.get(id);
			if (existing && existing !== entry[0]) throw new Error(`Duplicate schema id "${id}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
			idToSchema.set(id, entry[0]);
		}
	}
	const makeURI = (entry) => {
		const defsSegment = ctx.target === "draft-2020-12" ? "$defs" : "definitions";
		if (ctx.external) {
			const externalId = ctx.external.registry.get(entry[0])?.id;
			const uriGenerator = ctx.external.uri ?? ((id) => id);
			if (externalId) return { ref: uriGenerator(externalId) };
			const id = entry[1].defId ?? entry[1].schema.id ?? `schema${ctx.counter++}`;
			entry[1].defId = id;
			return {
				defId: id,
				ref: `${uriGenerator("__shared")}#/${defsSegment}/${encodeJSONPointerSegment(id)}`
			};
		}
		const uriPrefix = `#`;
		const defUriPrefix = `${uriPrefix}/${defsSegment}/`;
		if (entry[1] === root && !entry[1].schema.id) return { ref: uriPrefix };
		const defId = entry[1].schema.id ?? `__schema${ctx.counter++}`;
		return {
			defId,
			ref: defUriPrefix + encodeJSONPointerSegment(defId)
		};
	};
	const extractToDef = (entry) => {
		if (entry[1].schema.$ref) return;
		const seen = entry[1];
		const { ref, defId } = makeURI(entry);
		seen.def = { ...seen.schema };
		if (defId) seen.defId = defId;
		const schema = seen.schema;
		for (const key in schema) delete schema[key];
		schema.$ref = ref;
	};
	if (ctx.cycles === "throw") for (const entry of ctx.seen.entries()) {
		const seen = entry[1];
		if (seen.cycle) throw new Error(`Cycle detected: #/${seen.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
	}
	for (const entry of ctx.seen.entries()) {
		const seen = entry[1];
		if (schema === entry[0]) {
			extractToDef(entry);
			continue;
		}
		if (ctx.external) {
			const ext = ctx.external.registry.get(entry[0])?.id;
			if (schema !== entry[0] && ext) {
				extractToDef(entry);
				continue;
			}
		}
		if (ctx.metadataRegistry.get(entry[0])?.id) {
			extractToDef(entry);
			continue;
		}
		if (seen.cycle) {
			extractToDef(entry);
			continue;
		}
		if (seen.count > 1) {
			if (ctx.reused === "ref") extractToDef(entry);
		}
	}
	if (ctx.external) ctx.sharedDefsExtractedFor = ctx.external;
}
/** Rewrites `anyOf: [{type: "a"}, {type: "b"}]` to `type: ["a", "b"]`, which every JSON Schema draft treats as equivalent and most consumers render far better for the nullable case. Only branches that are a bare type assertion qualify — anything carrying a constraint, `$ref`, `const` or metadata is left alone. Runs after `flattenRef`, so a branch an override decorated or `$defs` extraction turned into a `$ref` is no longer bare and correctly stays in `anyOf`. `oneOf` is excluded: `integer` and `number` overlap, so "exactly one" and "at least one" are not the same there. OpenAPI 3.0 is excluded: its `type` must be a single string. */
function compactTypeUnion(schema) {
	const options = schema.anyOf;
	if (!Array.isArray(options) || options.length === 0 || schema.type !== void 0) return;
	const types = [];
	for (const option of options) {
		if (!option || typeof option !== "object") return;
		compactTypeUnion(option);
		const keys = Object.keys(option);
		if (keys.length !== 1 || keys[0] !== "type") return;
		const type = option.type;
		for (const member of Array.isArray(type) ? type : [type]) {
			if (typeof member !== "string") return;
			if (!types.includes(member)) types.push(member);
		}
	}
	delete schema.anyOf;
	schema.type = types.length === 1 ? types[0] : types;
}
/** Keywords `foldIntersection` knows how to combine. Anything else — `$ref`, `patternProperties`,
* an annotation like `description` — makes a member unfoldable, so a constraint this does not
* understand leaves the `allOf` alone instead of being silently dropped or misattributed. */
var FOLDABLE_KEYS = /* @__PURE__ */ new Set([
	"type",
	"properties",
	"required",
	"additionalProperties"
]);
var UNION_KEYS = ["oneOf", "anyOf"];
/** A member's constraint on a key it does not declare itself. A `catchall` states one; `false`, an absent `additionalProperties`, and the empty schema a loose object emits state nothing. */
function undeclaredConstraint(member) {
	const extra = member.additionalProperties;
	if (extra === void 0 || extra === false || typeof extra !== "object" || extra === null) return null;
	return Object.keys(extra).length ? extra : null;
}
/** Combines object members into the single object they describe together, or returns `null` if any of them carries a keyword outside {@link FOLDABLE_KEYS}. */
function foldObjects(members) {
	const objects = [];
	for (const member of members) {
		if (typeof member !== "object" || member.type !== "object") return null;
		for (const key in member) if (!FOLDABLE_KEYS.has(key)) return null;
		objects.push(member);
	}
	const properties = {};
	const required = /* @__PURE__ */ new Set();
	for (const object of objects) {
		for (const key in object.properties) {
			if (Object.prototype.hasOwnProperty.call(properties, key)) continue;
			const parts = [];
			for (const other of objects) {
				const part = other.properties?.[key] ?? undeclaredConstraint(other);
				if (part === null || part === void 0) continue;
				if (!parts.some((seen) => JSON.stringify(seen) === JSON.stringify(part))) parts.push(part);
			}
			assignProp(properties, key, parts.length === 1 ? parts[0] : foldObjects(parts) ?? { allOf: parts });
		}
		for (const key of object.required ?? []) required.add(key);
	}
	const folded = {
		type: "object",
		properties
	};
	if (required.size) folded.required = [...required];
	if (objects.every((object) => object.additionalProperties === false)) folded.additionalProperties = false;
	else {
		const constraints = [];
		for (const object of objects) {
			const constraint = undeclaredConstraint(object);
			if (constraint && !constraints.some((seen) => JSON.stringify(seen) === JSON.stringify(constraint))) constraints.push(constraint);
		}
		if (constraints.length === 1) folded.additionalProperties = constraints[0];
		else if (constraints.length > 1) folded.additionalProperties = { allOf: constraints };
	}
	return folded;
}
/** `additionalProperties` in an `allOf` member sees only that member's own `properties`, so two
* closed object members reject each other's keys and the schema validates nothing. Zod's parser
* pools the key sets instead — `handleIntersectionResults` reports a key as unrecognized only when
* *every* side rejects it — so the emitted schema has to pool them too, and folding the members
* into one object is the encoding that says so on every target.
*
* This runs from `finalize`, after `extractDefs`, which is what keeps it clear of the `$ref`
* machinery: a member extracted into `$defs` is already a `$ref` by now and declines to fold, so it
* keeps its reference and its own closedness rather than being inlined as a stale copy. */
function foldIntersection(json) {
	const allOf = json.allOf;
	if (!Array.isArray(allOf) || allOf.length < 2) return;
	for (const key of FOLDABLE_KEYS) if (key in json) return;
	const unions = allOf.filter((m) => UNION_KEYS.some((k) => Array.isArray(m[k])));
	let folded = null;
	if (!unions.length) folded = foldObjects(allOf);
	else {
		const union = unions[0];
		const keyword = UNION_KEYS.find((k) => Array.isArray(union[k]));
		if (Object.keys(union).length !== 1) return;
		const rest = allOf.filter((m) => m !== union);
		const branches = union[keyword].map((branch) => foldObjects([...rest, branch]));
		if (branches.some((b) => !b)) return;
		folded = { [keyword]: branches };
	}
	if (!folded) return;
	delete json.allOf;
	assignProps(json, folded);
}
function finalize(ctx, schema) {
	const root = ctx.seen.get(schema);
	if (!root) throw new Error("Unprocessed schema. This is a bug in Zod.");
	const flattenRef = (zodSchema) => {
		const seen = ctx.seen.get(zodSchema);
		if (seen.ref === null) return;
		const schema = seen.def ?? seen.schema;
		const _cached = { ...schema };
		const ref = seen.ref;
		seen.ref = null;
		if (ref) {
			flattenRef(ref);
			const refSeen = ctx.seen.get(ref);
			const refSchema = refSeen.schema;
			if (refSchema.$ref && (ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0")) {
				schema.allOf = schema.allOf ?? [];
				schema.allOf.push(refSchema);
			} else assignProps(schema, refSchema);
			assignProps(schema, _cached);
			if (zodSchema._zod.parent === ref) for (const key in schema) {
				if (key === "$ref" || key === "allOf") continue;
				if (!(key in _cached)) delete schema[key];
			}
			if (refSchema.$ref && refSeen.def) for (const key in schema) {
				if (key === "$ref" || key === "allOf") continue;
				if (key in refSeen.def && JSON.stringify(schema[key]) === JSON.stringify(refSeen.def[key])) delete schema[key];
			}
		}
		const parent = zodSchema._zod.parent;
		if (parent && parent !== ref) {
			flattenRef(parent);
			const parentSeen = ctx.seen.get(parent);
			if (parentSeen?.schema.$ref) {
				schema.$ref = parentSeen.schema.$ref;
				if (parentSeen.def) for (const key in schema) {
					if (key === "$ref" || key === "allOf") continue;
					if (key in parentSeen.def && JSON.stringify(schema[key]) === JSON.stringify(parentSeen.def[key])) delete schema[key];
				}
			}
		}
		ctx.override({
			zodSchema,
			jsonSchema: schema,
			path: seen.path ?? []
		});
	};
	if (!ctx.external || ctx.sharedEmitDoneFor !== ctx.external) {
		for (const entry of [...ctx.seen.entries()].reverse()) flattenRef(entry[0]);
		if (ctx.target !== "openapi-3.0") for (const entry of ctx.seen.entries()) compactTypeUnion(entry[1].def ?? entry[1].schema);
		for (const rewrite of ctx.deferred) rewrite();
		if (ctx.intersections.length) {
			const carriers = /* @__PURE__ */ new Map();
			for (const seen of ctx.seen.values()) for (const json of [seen.schema, seen.def]) {
				const allOf = json?.allOf;
				if (!Array.isArray(allOf)) continue;
				const existing = carriers.get(allOf);
				if (existing) existing.push(json);
				else carriers.set(allOf, [json]);
			}
			for (const allOf of ctx.intersections) for (const json of carriers.get(allOf) ?? []) foldIntersection(json);
		}
	}
	const result = {};
	if (ctx.target === "draft-2020-12") result.$schema = "https://json-schema.org/draft/2020-12/schema";
	else if (ctx.target === "draft-07") result.$schema = "http://json-schema.org/draft-07/schema#";
	else if (ctx.target === "draft-04") result.$schema = "http://json-schema.org/draft-04/schema#";
	else if (ctx.target === "openapi-3.0") {}
	if (ctx.external?.uri) {
		const id = ctx.external.registry.get(schema)?.id;
		if (!id) throw new Error("Schema is missing an `id` property");
		result.$id = ctx.external.uri(id);
	}
	assignProps(result, root.defId ? root.schema : root.def ?? root.schema);
	const rootMetaId = ctx.metadataRegistry.get(schema)?.id;
	if (rootMetaId !== void 0 && result.id === rootMetaId) delete result.id;
	const defs = ctx.external?.defs ?? {};
	if (!ctx.external || ctx.sharedEmitDoneFor !== ctx.external) for (const entry of ctx.seen.entries()) {
		const seen = entry[1];
		if (seen.def && seen.defId) {
			if (seen.def.id === seen.defId) delete seen.def.id;
			assignProp(defs, seen.defId, seen.def);
		}
	}
	if (ctx.external) ctx.sharedEmitDoneFor = ctx.external;
	if (ctx.external) {} else if (Object.keys(defs).length > 0) {
		if (ctx.target === "draft-2020-12") result.$defs = defs;
		else result.definitions = defs;
	}
	try {
		const finalized = JSON.parse(JSON.stringify(result));
		Object.defineProperty(finalized, "~standard", {
			value: {
				...schema["~standard"],
				jsonSchema: {
					input: createStandardJSONSchemaMethod(schema, "input", ctx.processors),
					output: createStandardJSONSchemaMethod(schema, "output", ctx.processors)
				}
			},
			enumerable: false,
			writable: false
		});
		return finalized;
	} catch (_err) {
		throw new Error("Error converting schema to JSON.");
	}
}
function isTransforming(_schema, _ctx) {
	const ctx = _ctx ?? { seen: /* @__PURE__ */ new Set() };
	if (ctx.seen.has(_schema)) return false;
	ctx.seen.add(_schema);
	const def = _schema._zod.def;
	if (def.type === "transform") return true;
	if (def.type === "array") return isTransforming(def.element, ctx);
	if (def.type === "set") return isTransforming(def.valueType, ctx);
	if (def.type === "lazy") return isTransforming(def.getter(), ctx);
	if (def.type === "promise" || def.type === "optional" || def.type === "nonoptional" || def.type === "nullable" || def.type === "readonly" || def.type === "default" || def.type === "prefault" || def.type === "catch") return isTransforming(def.innerType, ctx);
	if (def.type === "intersection") return isTransforming(def.left, ctx) || isTransforming(def.right, ctx);
	if (def.type === "record" || def.type === "map") return isTransforming(def.keyType, ctx) || isTransforming(def.valueType, ctx);
	if (def.type === "pipe") {
		if (_schema._zod.traits.has("$ZodCodec")) return true;
		return isTransforming(def.in, ctx) || isTransforming(def.out, ctx);
	}
	if (def.type === "object") {
		for (const key in def.shape) if (isTransforming(def.shape[key], ctx)) return true;
		return false;
	}
	if (def.type === "union") {
		for (const option of def.options) if (isTransforming(option, ctx)) return true;
		return false;
	}
	if (def.type === "tuple") {
		for (const item of def.items) if (isTransforming(item, ctx)) return true;
		if (def.rest && isTransforming(def.rest, ctx)) return true;
		return false;
	}
	return false;
}
/**
* Creates a toJSONSchema method for a schema instance.
* This encapsulates the logic of initializing context, processing, extracting defs, and finalizing.
*/
var createToJSONSchemaMethod = (schema, processors = {}) => (params) => {
	const ctx = initializeContext({
		...params,
		processors
	});
	processSchema(schema, ctx);
	extractDefs(ctx, schema);
	return finalize(ctx, schema);
};
var createStandardJSONSchemaMethod = (schema, io, processors = {}) => (params) => {
	const { libraryOptions, target } = params ?? {};
	const ctx = initializeContext({
		...libraryOptions ?? {},
		target,
		io,
		processors
	});
	processSchema(schema, ctx);
	extractDefs(ctx, schema);
	return finalize(ctx, schema);
};
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/core/json-schema-processors.js
var narrowMin = (agg, key, value) => {
	if (agg[key] === void 0 || value > agg[key]) agg[key] = value;
};
var narrowMax = (agg, key, value) => {
	if (agg[key] === void 0 || value < agg[key]) agg[key] = value;
};
var narrowBoth = (agg, value) => {
	narrowMin(agg, "minimum", value);
	narrowMax(agg, "maximum", value);
};
var addDivisor = (agg, value) => {
	agg.multipleOf ?? (agg.multipleOf = []);
	if (!agg.multipleOf.includes(value)) agg.multipleOf.push(value);
};
var addPattern = (agg, pattern) => {
	agg.patterns ?? (agg.patterns = /* @__PURE__ */ new Set());
	agg.patterns.add(pattern);
};
var intersectMime = (agg, mime) => {
	agg.mime = agg.mime ? agg.mime.filter((m) => mime.includes(m)) : [...mime];
};
var setFormat = (agg, format) => {
	agg.format = format;
	if (format.includes("int")) agg.isInt = true;
};
var minContributor = (agg, def) => narrowMin(agg, "minimum", def.minimum);
var maxContributor = (agg, def) => narrowMax(agg, "maximum", def.maximum);
var formatContributor = (ranges) => (agg, def) => {
	setFormat(agg, def.format);
	const [minimum, maximum] = ranges[def.format];
	narrowMin(agg, "minimum", minimum);
	narrowMax(agg, "maximum", maximum);
};
var contributors = {
	greater_than: (agg, def) => narrowMin(agg, def.inclusive ? "minimum" : "exclusiveMinimum", def.value),
	less_than: (agg, def) => narrowMax(agg, def.inclusive ? "maximum" : "exclusiveMaximum", def.value),
	multiple_of: (agg, def) => addDivisor(agg, def.value),
	number_format: formatContributor(NUMBER_FORMAT_RANGES),
	bigint_format: formatContributor(BIGINT_FORMAT_RANGES),
	min_length: minContributor,
	max_length: maxContributor,
	length_equals: (agg, def) => narrowBoth(agg, def.length),
	min_size: minContributor,
	max_size: maxContributor,
	size_equals: (agg, def) => narrowBoth(agg, def.size),
	string_format: (agg, def) => {
		setFormat(agg, def.format);
		if (def.pattern) addPattern(agg, def.pattern);
		if (def.format === "base64" || def.format === "base64url") agg.contentEncoding = def.format;
		if (def.local || def.precision === -1) agg.laxFormat = true;
	},
	mime_type: (agg, def) => intersectMime(agg, def.mime)
};
function aggregateChecks(schema) {
	const agg = {};
	const def = schema._zod.def;
	const list = schema._zod.traits.has("$ZodCheck") ? [schema, ...def.checks ?? []] : def.checks ?? [];
	for (const ch of list) contributors[ch._zod.def.check]?.(agg, ch._zod.def);
	const bag = schema._zod.bag;
	if (bag.minimum !== void 0) narrowMin(agg, "minimum", bag.minimum);
	if (bag.exclusiveMinimum !== void 0) narrowMin(agg, "exclusiveMinimum", bag.exclusiveMinimum);
	if (bag.maximum !== void 0) narrowMax(agg, "maximum", bag.maximum);
	if (bag.exclusiveMaximum !== void 0) narrowMax(agg, "exclusiveMaximum", bag.exclusiveMaximum);
	if (bag.multipleOf !== void 0) addDivisor(agg, bag.multipleOf);
	if (bag.format !== void 0) {
		agg.format ?? (agg.format = bag.format);
		if (bag.format.includes("int")) agg.isInt = true;
	}
	if (bag.mime) intersectMime(agg, bag.mime);
	for (const pattern of bag.patterns ?? []) addPattern(agg, pattern);
	return agg;
}
var formatMap = {
	guid: "uuid",
	url: "uri",
	datetime: "date-time",
	json_string: "json-string",
	regex: ""
};
var exactPatterns = /* @__PURE__ */ new Map([[base64Charset, base64], [base64urlCharset, base64url]]);
var exactPattern = (p) => exactPatterns.get(p) ?? p;
var stringProcessor = (schema, ctx, _json, _params) => {
	const json = _json;
	json.type = "string";
	const { minimum, maximum, format, patterns, contentEncoding, laxFormat } = aggregateChecks(schema);
	if (typeof minimum === "number") json.minLength = minimum;
	if (typeof maximum === "number") json.maxLength = maximum;
	if (format) {
		json.format = formatMap[format] ?? format;
		if (json.format === "") delete json.format;
		if (format === "time" || laxFormat) delete json.format;
	}
	if (contentEncoding) json.contentEncoding = contentEncoding;
	if (patterns && patterns.size > 0) {
		const patternList = [...patterns].map(exactPattern);
		if (patternList.length === 1) json.pattern = patternList[0].source;
		else if (patternList.length > 1) json.allOf = [...patternList.map((regex) => ({
			...ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0" ? { type: "string" } : {},
			pattern: regex.source
		}))];
	}
};
var numberProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const { minimum, maximum, multipleOf, exclusiveMaximum, exclusiveMinimum, isInt } = aggregateChecks(schema);
	json.type = isInt ? "integer" : "number";
	const exMin = typeof exclusiveMinimum === "number" && exclusiveMinimum >= (minimum ?? Number.NEGATIVE_INFINITY);
	const exMax = typeof exclusiveMaximum === "number" && exclusiveMaximum <= (maximum ?? Number.POSITIVE_INFINITY);
	const legacy = ctx.target === "draft-04" || ctx.target === "openapi-3.0";
	if (exMin) {
		if (legacy) {
			json.minimum = exclusiveMinimum;
			json.exclusiveMinimum = true;
		} else json.exclusiveMinimum = exclusiveMinimum;
	} else if (typeof minimum === "number") json.minimum = minimum;
	if (exMax) {
		if (legacy) {
			json.maximum = exclusiveMaximum;
			json.exclusiveMaximum = true;
		} else json.exclusiveMaximum = exclusiveMaximum;
	} else if (typeof maximum === "number") json.maximum = maximum;
	if (multipleOf) {
		const divisors = /* @__PURE__ */ new Set();
		for (const divisor of multipleOf) if (Number.isFinite(divisor) && divisor !== 0) divisors.add(Math.abs(divisor));
		else handleUnrepresentable(schema, ctx, json, params, `A multipleOf divisor of ${divisor} cannot be represented in JSON Schema`);
		const [first, ...rest] = divisors;
		if (first !== void 0) json.multipleOf = first;
		if (rest.length) json.allOf = [...json.allOf ?? [], ...rest.map((m) => ({ multipleOf: m }))];
	}
};
var booleanProcessor = (_schema, _ctx, json, _params) => {
	json.type = "boolean";
};
var nullProcessor = (_schema, ctx, json, _params) => {
	if (ctx.target === "openapi-3.0") {
		json.type = "string";
		json.nullable = true;
		json.enum = [null];
	} else json.type = "null";
};
var neverProcessor = (_schema, _ctx, json, _params) => {
	json.not = {};
};
var enumProcessor = (schema, _ctx, json, _params) => {
	const def = schema._zod.def;
	const values = getEnumValues(def.entries);
	if (values.length === 0) {
		json.not = {};
		return;
	}
	if (values.every((v) => typeof v === "number")) json.type = "number";
	if (values.every((v) => typeof v === "string")) json.type = "string";
	json.enum = values;
};
var literalProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	if (def.values.length === 0) {
		json.not = {};
		return;
	}
	const vals = [];
	for (const val of def.values) if (val === void 0) {
		if (handleUnrepresentable(schema, ctx, json, params, "Literal `undefined` cannot be represented in JSON Schema")) return;
	} else if (typeof val === "bigint") {
		if (handleUnrepresentable(schema, ctx, json, params, "BigInt literals cannot be represented in JSON Schema")) return;
		vals.push(Number(val));
	} else vals.push(val);
	if (vals.length === 0) {} else if (vals.length === 1) {
		const val = vals[0];
		json.type = val === null ? "null" : typeof val;
		if (ctx.target === "draft-04" || ctx.target === "openapi-3.0") json.enum = [val];
		else json.const = val;
	} else {
		if (vals.every((v) => typeof v === "number")) json.type = "number";
		if (vals.every((v) => typeof v === "string")) json.type = "string";
		if (vals.every((v) => typeof v === "boolean")) json.type = "boolean";
		if (vals.every((v) => v === null)) json.type = "null";
		json.enum = vals;
	}
};
var customProcessor = (schema, ctx, json, params) => {
	handleUnrepresentable(schema, ctx, json, params, "Custom types cannot be represented in JSON Schema");
};
var transformProcessor = (schema, ctx, json, params) => {
	handleUnrepresentable(schema, ctx, json, params, "Transforms cannot be represented in JSON Schema");
};
var arrayProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const def = schema._zod.def;
	const { minimum, maximum } = aggregateChecks(schema);
	if (typeof minimum === "number") json.minItems = minimum;
	if (typeof maximum === "number") json.maxItems = maximum;
	json.type = "array";
	json.items = processSchema(def.element, ctx, {
		...params,
		path: [...params.path, "items"]
	});
};
function inputOptin(schema) {
	const def = schema._zod.def;
	if (def.type === "pipe" && def.in._zod.traits.has("$ZodTransform")) return inputOptin(def.out);
	if (def.type === "catch") return inputOptin(def.innerType);
	return schema._zod.optin;
}
var objectProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const def = schema._zod.def;
	const shape = def.shape;
	if (Object.getOwnPropertySymbols(shape).length && handleUnrepresentable(schema, ctx, json, params, "Symbol keys cannot be represented in JSON Schema")) return;
	json.type = "object";
	json.properties = {};
	for (const key in shape) assignProp(json.properties, key, processSchema(shape[key], ctx, {
		...params,
		path: [
			...params.path,
			"properties",
			key
		]
	}));
	const requiredKeys = [];
	for (const key of Object.keys(shape)) {
		const field = def.shape[key];
		if (ctx.io === "input" ? inputOptin(field) === void 0 : field._zod.optout === void 0) requiredKeys.push(key);
	}
	if (requiredKeys.length > 0) json.required = requiredKeys;
	if (def.catchall?._zod.def.type === "never") json.additionalProperties = false;
	else if (!def.catchall) {
		if (ctx.io === "output") json.additionalProperties = false;
	} else if (def.catchall) json.additionalProperties = processSchema(def.catchall, ctx, {
		...params,
		path: [...params.path, "additionalProperties"]
	});
};
var unionProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	const isExclusive = def.inclusive === false;
	const options = def.options.map((x, i) => processSchema(x, ctx, {
		...params,
		path: [
			...params.path,
			isExclusive ? "oneOf" : "anyOf",
			i
		]
	}));
	if (isExclusive) json.oneOf = options;
	else json.anyOf = options;
};
var intersectionProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	const a = processSchema(def.left, ctx, {
		...params,
		path: [
			...params.path,
			"allOf",
			0
		]
	});
	const b = processSchema(def.right, ctx, {
		...params,
		path: [
			...params.path,
			"allOf",
			1
		]
	});
	const isSimpleIntersection = (val) => "allOf" in val && Object.keys(val).length === 1;
	const allOf = [...isSimpleIntersection(a) ? a.allOf : [a], ...isSimpleIntersection(b) ? b.allOf : [b]];
	json.allOf = allOf;
	ctx.intersections.push(allOf);
};
var tupleProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const def = schema._zod.def;
	json.type = "array";
	const prefixPath = ctx.target === "draft-2020-12" ? "prefixItems" : "items";
	const restPath = ctx.target === "draft-2020-12" ? "items" : ctx.target === "openapi-3.0" ? "items" : "additionalItems";
	const prefixItems = def.items.map((x, i) => processSchema(x, ctx, {
		...params,
		path: [
			...params.path,
			prefixPath,
			i
		]
	}));
	const rest = def.rest ? processSchema(def.rest, ctx, {
		...params,
		path: [
			...params.path,
			restPath,
			...ctx.target === "openapi-3.0" ? [def.items.length] : []
		]
	}) : null;
	let minItems = def.items.length;
	while (minItems > 0) {
		const item = def.items[minItems - 1];
		if (!(ctx.io === "input" ? inputOptin(item) !== void 0 : item._zod.optout === "optional")) break;
		minItems--;
	}
	const maxItems = def.items.length;
	const isClosed = !def.rest;
	if (ctx.target === "draft-2020-12") {
		json.prefixItems = prefixItems;
		if (isClosed) json.items = false;
		else if (rest) json.items = rest;
		if (minItems > 0) json.minItems = minItems;
		if (isClosed) json.maxItems = maxItems;
	} else if (ctx.target === "openapi-3.0") {
		json.items = { anyOf: prefixItems };
		if (rest) json.items.anyOf.push(rest);
		if (minItems > 0) json.minItems = minItems;
		if (isClosed) json.maxItems = maxItems;
	} else {
		json.items = prefixItems;
		if (isClosed) json.additionalItems = false;
		else if (rest) json.additionalItems = rest;
		if (minItems > 0) json.minItems = minItems;
		if (isClosed) json.maxItems = maxItems;
	}
	const { minimum, maximum } = aggregateChecks(schema);
	if (typeof minimum === "number") json.minItems = minimum;
	if (typeof maximum === "number") json.maxItems = maximum;
};
/** JSON object keys are always strings, so a numeric record key schema is re-expressed over the
* numeric-string form the record parser matches. Deferred to `finalize`, after the flatten: a key
* behind a wrapper only carries its own `type` before then, and a union key only has its branches.
*
* A numeric bound cannot apply to a property name, so `minimum` and its siblings are dropped rather
* than carried over: keeping them beside `type: "string"` reproduces the match-nothing schema this
* exists to fix. A key that carries one therefore emits wider than the record parses — `z.record(z.number().min(5), V)`
* accepts `"3"` — which is the deliberate trade, since throwing on it would reject an ordinary schema
* outright. */
function stringifyKeyNames(bySchema, json, visited) {
	if (json.$ref) {
		if (visited.has(json)) return json;
		visited.add(json);
		const def = bySchema.get(json)?.def;
		if (!def) return json;
		const inlined = stringifyKeyNames(bySchema, def, visited);
		return inlined === def ? json : inlined;
	}
	for (const keyword of ["anyOf", "oneOf"]) {
		const branches = json[keyword];
		if (!Array.isArray(branches)) continue;
		const mapped = branches.map((branch) => stringifyKeyNames(bySchema, branch, visited));
		if (mapped.some((branch, i) => branch !== branches[i])) json = {
			...json,
			[keyword]: mapped
		};
	}
	const types = Array.isArray(json.type) ? json.type : [json.type];
	const numericType = !types.includes("string") && types.some((t) => t === "number" || t === "integer");
	const values = json.enum ?? (json.const !== void 0 ? [json.const] : void 0);
	if (!numericType && !values?.some((v) => typeof v === "number")) return json;
	const { minimum, maximum, exclusiveMinimum, exclusiveMaximum, multipleOf, format, id, ...rest } = json;
	if (rest.enum) rest.enum = rest.enum.map((v) => typeof v === "number" ? String(v) : v);
	else if (typeof rest.const === "number") rest.const = String(rest.const);
	if (!numericType) return rest;
	rest.type = "string";
	if (!values) rest.pattern = (types.includes("number") ? number$1 : integer$1).source;
	return rest;
}
/** Every record of one conversion, so the carriers are found in a single pass rather than once per record. */
var pendingRecords = /* @__PURE__ */ new WeakMap();
function rewriteKeyNames(ctx) {
	const bySchema = /* @__PURE__ */ new Map();
	for (const entry of ctx.seen.values()) if (entry.def && !bySchema.has(entry.schema)) bySchema.set(entry.schema, entry);
	const rewrites = /* @__PURE__ */ new Map();
	for (const record of pendingRecords.get(ctx) ?? []) {
		const seen = ctx.seen.get(record);
		const names = (seen?.def ?? seen?.schema)?.propertyNames;
		if (!names || names === true || rewrites.has(names)) continue;
		const rewritten = stringifyKeyNames(bySchema, names, /* @__PURE__ */ new Set());
		if (rewritten !== names) rewrites.set(names, rewritten);
	}
	if (!rewrites.size) return;
	for (const entry of ctx.seen.values()) for (const carrier of [entry.schema, entry.def]) {
		const rewritten = carrier && rewrites.get(carrier.propertyNames);
		if (rewritten) carrier.propertyNames = rewritten;
	}
}
var recordProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const def = schema._zod.def;
	json.type = "object";
	const keyType = def.keyType;
	const patterns = aggregateChecks(keyType).patterns;
	if (def.mode === "loose" && patterns && patterns.size > 0) {
		const valueSchema = processSchema(def.valueType, ctx, {
			...params,
			path: [
				...params.path,
				"patternProperties",
				"*"
			]
		});
		json.patternProperties = {};
		for (const pattern of patterns) assignProp(json.patternProperties, exactPattern(pattern).source, valueSchema);
	} else {
		if (ctx.target === "draft-07" || ctx.target === "draft-2020-12") {
			json.propertyNames = processSchema(def.keyType, ctx, {
				...params,
				path: [...params.path, "propertyNames"]
			});
			let pending = pendingRecords.get(ctx);
			if (!pending) {
				pending = [];
				pendingRecords.set(ctx, pending);
				ctx.deferred.push(() => rewriteKeyNames(ctx));
			}
			pending.push(schema);
		}
		json.additionalProperties = processSchema(def.valueType, ctx, {
			...params,
			path: [...params.path, "additionalProperties"]
		});
	}
	const keyValues = keyType._zod.values;
	const omittableOnInput = ctx.io === "input" && inputOptin(def.valueType) !== void 0;
	if (keyValues && !def.partial && !omittableOnInput) {
		const validKeyValues = [...keyValues].filter((v) => typeof v === "string" || typeof v === "number");
		if (validKeyValues.length > 0) json.required = validKeyValues.map(String);
	}
};
var nullableProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	const inner = processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	if (ctx.target === "openapi-3.0") {
		seen.ref = def.innerType;
		json.nullable = true;
	} else json.anyOf = [inner, { type: "null" }];
};
var nonoptionalProcessor = (schema, ctx, _json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
};
/** Round-trips a default value through JSON so the emitted schema is guaranteed to be valid JSON.
* A BigInt has no reliable encoding, so it goes through `unrepresentable` like any other
* unrepresentable value. Returns a sentinel when the caller must not write a default of its own. */
var UNREPRESENTABLE_DEFAULT = Symbol();
function serializeDefaultValue(value, schema, ctx, json, params) {
	let unrepresentable = false;
	const serialized = JSON.stringify(value, (_, val) => {
		if (typeof val !== "bigint") return val;
		unrepresentable = true;
		return null;
	});
	if (!unrepresentable) return JSON.parse(serialized);
	handleUnrepresentable(schema, ctx, json, params, "BigInt defaults cannot be represented in JSON Schema");
	return UNREPRESENTABLE_DEFAULT;
}
var defaultProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	const value = serializeDefaultValue(def.defaultValue, schema, ctx, json, params);
	if (value !== UNREPRESENTABLE_DEFAULT) json.default = value;
};
var prefaultProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	if (ctx.io !== "input") return;
	const value = serializeDefaultValue(def.defaultValue, schema, ctx, json, params);
	if (value !== UNREPRESENTABLE_DEFAULT) json._prefault = value;
};
var catchProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	let catchValue;
	try {
		catchValue = def.catchValue(void 0);
	} catch {
		handleUnrepresentable(schema, ctx, json, params, "Dynamic catch values are not supported in JSON Schema");
		return;
	}
	json.default = catchValue;
};
var pipeProcessor = (schema, ctx, _json, params) => {
	const def = schema._zod.def;
	const inIsTransform = def.in._zod.traits.has("$ZodTransform");
	const innerType = ctx.io === "input" ? inIsTransform ? def.out : def.in : def.out;
	processSchema(innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = innerType;
};
var readonlyProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	json.readOnly = true;
};
var optionalProcessor = (schema, ctx, _json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
};
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/classic/errors.js
var _installedErrorProtos = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function _lazyMethod(proto, key, make) {
	Object.defineProperty(proto, key, {
		configurable: true,
		enumerable: false,
		get() {
			const value = make(this);
			Object.defineProperty(this, key, {
				value,
				configurable: true,
				writable: true
			});
			return value;
		},
		set(value) {
			Object.defineProperty(this, key, {
				value,
				configurable: true,
				writable: true
			});
		}
	});
}
var initializer = (inst, issues) => {
	$ZodError.init(inst, issues);
	inst.name = "ZodError";
	const proto = Object.getPrototypeOf(inst);
	if (_installedErrorProtos.has(proto)) return;
	_installedErrorProtos.add(proto);
	_lazyMethod(proto, "format", (self) => (mapper) => formatError(self, mapper));
	_lazyMethod(proto, "flatten", (self) => (mapper) => flattenError(self, mapper));
	_lazyMethod(proto, "addIssue", (self) => (issue) => {
		self.issues.push(issue);
		self.message = JSON.stringify(self.issues, jsonStringifyReplacer, 2);
	});
	_lazyMethod(proto, "addIssues", (self) => (issues) => {
		self.issues.push(...issues);
		self.message = JSON.stringify(self.issues, jsonStringifyReplacer, 2);
	});
	Object.defineProperty(proto, "isEmpty", {
		configurable: true,
		enumerable: false,
		get() {
			return this.issues.length === 0;
		}
	});
};
var ZodRealError = /*@__PURE__*/ $constructor("ZodError", initializer, void 0, { Parent: Error });
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/classic/parse.js
var parse = /* @__PURE__ */ _parse(ZodRealError);
var parseAsync = /* @__PURE__ */ _parseAsync(ZodRealError);
var safeParse = /* @__PURE__ */ _safeParse(ZodRealError);
var safeParseAsync = /* @__PURE__ */ _safeParseAsync(ZodRealError);
var encode = /* @__PURE__ */ _encode(ZodRealError);
var decode$2 = /* @__PURE__ */ _decode(ZodRealError);
var encodeAsync = /* @__PURE__ */ _encodeAsync(ZodRealError);
var decodeAsync = /* @__PURE__ */ _decodeAsync(ZodRealError);
var safeEncode = /* @__PURE__ */ _safeEncode(ZodRealError);
var safeDecode = /* @__PURE__ */ _safeDecode(ZodRealError);
var safeEncodeAsync = /* @__PURE__ */ _safeEncodeAsync(ZodRealError);
var safeDecodeAsync = /* @__PURE__ */ _safeDecodeAsync(ZodRealError);
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/zod/v4/classic/schemas.js
function _ensureDefaultLocale() {
	if (!globalConfig.localeError) config(en_default());
}
function _ensureDefaultMemoizer() {
	if (!globalConfig.memoizer) config({ memoizer: memoizer() });
}
var ZodType = /*@__PURE__*/ $constructor("ZodType", (inst, def) => {
	_ensureDefaultLocale();
	$ZodType.init(inst, def);
	inst.def = def;
	inst.type = def.type;
	return inst;
}, {
	check(...chks) {
		const def = this.def;
		return this.clone(mergeDefs(def, { checks: [...def.checks ?? [], ...chks.map((ch) => typeof ch === "function" ? { _zod: {
			check: ch,
			def: { check: "custom" },
			onattach: []
		} } : ch)] }), { parent: true });
	},
	with(...chks) {
		return this.check(...chks);
	},
	clone(def, params) {
		return clone(this, def, params);
	},
	brand() {
		return this;
	},
	register(reg, meta) {
		reg.add(this, meta);
		return this;
	},
	refine(check, params) {
		return this.check(refine(check, params));
	},
	superRefine(refinement, params) {
		return this.check(superRefine(refinement, params));
	},
	overwrite(fn) {
		return this.check(/* @__PURE__ */ _overwrite(fn));
	},
	optional() {
		return optional(this);
	},
	exactOptional() {
		return exactOptional(this);
	},
	nullable() {
		return nullable(this);
	},
	nullish() {
		return optional(nullable(this));
	},
	nonoptional(params) {
		return nonoptional(this, params);
	},
	array() {
		return array(this);
	},
	or(arg) {
		return union([this, arg]);
	},
	and(arg) {
		return intersection(this, arg);
	},
	transform(tx) {
		return pipe(this, transform(tx));
	},
	default(d) {
		return _default(this, d);
	},
	prefault(d) {
		return prefault(this, d);
	},
	catch(params) {
		return _catch(this, params);
	},
	pipe(target) {
		return pipe(this, target);
	},
	readonly() {
		return readonly(this);
	},
	describe(description) {
		const cl = this.clone();
		globalRegistry.add(cl, { description });
		return cl;
	},
	meta(...args) {
		if (args.length === 0) return globalRegistry.get(this);
		const cl = this.clone();
		globalRegistry.add(cl, args[0]);
		return cl;
	},
	isOptional() {
		return this.safeParse(void 0).success;
	},
	isNullable() {
		return this.safeParse(null).success;
	},
	apply(fn, ...args) {
		return args.length === 0 ? fn(this) : fn(this, ...args);
	},
	get "~standard"() {
		return hide(this, "~standard", {
			...standardProps(this),
			jsonSchema: {
				input: createStandardJSONSchemaMethod(this, "input"),
				output: createStandardJSONSchemaMethod(this, "output")
			}
		});
	},
	set "~standard"(value) {
		own(this, "~standard", value);
	},
	parse: function _parse(data, params) {
		return parse(this, data, params, { callee: _parse });
	},
	parseAsync: async function _parseAsync(data, params) {
		return await parseAsync(this, data, params, { callee: _parseAsync });
	},
	safeParse(data, params) {
		return safeParse(this, data, params);
	},
	async safeParseAsync(data, params) {
		return safeParseAsync(this, data, params);
	},
	get spa() {
		return this?.safeParseAsync;
	},
	set spa(value) {
		own(this, "spa", value);
	},
	validate(data, params) {
		return validate(this, data, params);
	},
	validateAsync(data, params) {
		return validateAsync$1(this, data, params);
	},
	encode: function _encode(data, params) {
		return encode(this, data, params, { callee: _encode });
	},
	decode: function _decode(data, params) {
		return decode$2(this, data, params, { callee: _decode });
	},
	encodeAsync: async function _encodeAsync(data, params) {
		return await encodeAsync(this, data, params, { callee: _encodeAsync });
	},
	decodeAsync: async function _decodeAsync(data, params) {
		return await decodeAsync(this, data, params, { callee: _decodeAsync });
	},
	safeEncode(data, params) {
		return safeEncode(this, data, params);
	},
	safeDecode(data, params) {
		return safeDecode(this, data, params);
	},
	async safeEncodeAsync(data, params) {
		return safeEncodeAsync(this, data, params);
	},
	async safeDecodeAsync(data, params) {
		return safeDecodeAsync(this, data, params);
	},
	toJSONSchema(params) {
		return createToJSONSchemaMethod(this, {})(params);
	},
	get description() {
		return globalRegistry.get(this)?.description;
	},
	get _def() {
		return this._zod.def;
	}
});
/** @internal */
var _ZodString = /*@__PURE__*/ $constructor("_ZodString", (inst, def) => {
	$ZodString.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => stringProcessor(inst, ctx, json, params);
}, /*@__PURE__*/ derived({
	format: (inst) => aggregateChecks(inst).format ?? null,
	minLength: (inst) => aggregateChecks(inst).minimum ?? null,
	maxLength: (inst) => aggregateChecks(inst).maximum ?? null
}, {
	regex(...args) {
		return this.check(/* @__PURE__ */ _regex(...args));
	},
	includes(...args) {
		return this.check(/* @__PURE__ */ _includes(...args));
	},
	startsWith(...args) {
		return this.check(/* @__PURE__ */ _startsWith(...args));
	},
	endsWith(...args) {
		return this.check(/* @__PURE__ */ _endsWith(...args));
	},
	min(...args) {
		return this.check(/* @__PURE__ */ _minLength(...args));
	},
	max(...args) {
		return this.check(/* @__PURE__ */ _maxLength(...args));
	},
	length(...args) {
		return this.check(/* @__PURE__ */ _length(...args));
	},
	nonempty(...args) {
		return this.check(/* @__PURE__ */ _minLength(1, ...args));
	},
	lowercase(params) {
		return this.check(/* @__PURE__ */ _lowercase(params));
	},
	uppercase(params) {
		return this.check(/* @__PURE__ */ _uppercase(params));
	},
	trim() {
		return this.check(/* @__PURE__ */ _trim());
	},
	normalize(...args) {
		return this.check(/* @__PURE__ */ _normalize(...args));
	},
	toLowerCase() {
		return this.check(/* @__PURE__ */ _toLowerCase());
	},
	toUpperCase() {
		return this.check(/* @__PURE__ */ _toUpperCase());
	},
	slugify() {
		return this.check(/* @__PURE__ */ _slugify());
	}
}));
var ZodString = /*@__PURE__*/ $constructor("ZodString", (inst, def) => {
	$ZodString.init(inst, def);
	_ZodString.init(inst, def);
}, {
	email(params) {
		return this.check(/* @__PURE__ */ _email(ZodEmail, params));
	},
	url(params) {
		return this.check(/* @__PURE__ */ _url(ZodURL, params));
	},
	jwt(params) {
		return this.check(/* @__PURE__ */ _jwt(ZodJWT, params));
	},
	emoji(params) {
		return this.check(/* @__PURE__ */ _emoji(ZodEmoji, params));
	},
	guid(params) {
		return this.check(/* @__PURE__ */ _guid(ZodGUID, params));
	},
	uuid(params) {
		return this.check(/* @__PURE__ */ _uuid(ZodUUID, params));
	},
	uuidv4(params) {
		return this.check(/* @__PURE__ */ _uuidv4(ZodUUID, params));
	},
	uuidv6(params) {
		return this.check(/* @__PURE__ */ _uuidv6(ZodUUID, params));
	},
	uuidv7(params) {
		return this.check(/* @__PURE__ */ _uuidv7(ZodUUID, params));
	},
	nanoid(params) {
		return this.check(/* @__PURE__ */ _nanoid(ZodNanoID, params));
	},
	cuid(params) {
		return this.check(/* @__PURE__ */ _cuid(ZodCUID, params));
	},
	cuid2(params) {
		return this.check(/* @__PURE__ */ _cuid2(ZodCUID2, params));
	},
	ulid(params) {
		return this.check(/* @__PURE__ */ _ulid(ZodULID, params));
	},
	base64(params) {
		return this.check(/* @__PURE__ */ _base64(ZodBase64, params));
	},
	base64url(params) {
		return this.check(/* @__PURE__ */ _base64url(ZodBase64URL, params));
	},
	xid(params) {
		return this.check(/* @__PURE__ */ _xid(ZodXID, params));
	},
	ksuid(params) {
		return this.check(/* @__PURE__ */ _ksuid(ZodKSUID, params));
	},
	ipv4(params) {
		return this.check(/* @__PURE__ */ _ipv4(ZodIPv4, params));
	},
	ipv6(params) {
		return this.check(/* @__PURE__ */ _ipv6(ZodIPv6, params));
	},
	cidrv4(params) {
		return this.check(/* @__PURE__ */ _cidrv4(ZodCIDRv4, params));
	},
	cidrv6(params) {
		return this.check(/* @__PURE__ */ _cidrv6(ZodCIDRv6, params));
	},
	e164(params) {
		return this.check(/* @__PURE__ */ _e164(ZodE164, params));
	},
	datetime(params) {
		return this.check(/* @__PURE__ */ _isoDateTime(ZodISODateTime, params));
	},
	date(params) {
		return this.check(/* @__PURE__ */ _isoDate(ZodISODate, params));
	},
	time(params) {
		return this.check(/* @__PURE__ */ _isoTime(ZodISOTime, params));
	},
	duration(params) {
		return this.check(/* @__PURE__ */ _isoDuration(ZodISODuration, params));
	}
});
function string(params) {
	return /* @__PURE__ */ _string(ZodString, params);
}
var ZodStringFormat = /*@__PURE__*/ $constructor("ZodStringFormat", (inst, def) => {
	$ZodStringFormat.init(inst, def);
	_ZodString.init(inst, def);
});
var ZodISODateTime = /*@__PURE__*/ $constructor("ZodISODateTime", (inst, def) => {
	$ZodISODateTime.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodISODate = /*@__PURE__*/ $constructor("ZodISODate", (inst, def) => {
	$ZodISODate.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodISOTime = /*@__PURE__*/ $constructor("ZodISOTime", (inst, def) => {
	$ZodISOTime.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodISODuration = /*@__PURE__*/ $constructor("ZodISODuration", (inst, def) => {
	$ZodISODuration.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodEmail = /*@__PURE__*/ $constructor("ZodEmail", (inst, def) => {
	$ZodEmail.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodGUID = /*@__PURE__*/ $constructor("ZodGUID", (inst, def) => {
	$ZodGUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodUUID = /*@__PURE__*/ $constructor("ZodUUID", (inst, def) => {
	$ZodUUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodURL = /*@__PURE__*/ $constructor("ZodURL", (inst, def) => {
	$ZodURL.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodEmoji = /*@__PURE__*/ $constructor("ZodEmoji", (inst, def) => {
	$ZodEmoji.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodNanoID = /*@__PURE__*/ $constructor("ZodNanoID", (inst, def) => {
	$ZodNanoID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
/**
* @deprecated CUID v1 is deprecated by its authors due to information leakage
* (timestamps embedded in the id). Use {@link ZodCUID2} instead.
* See https://github.com/paralleldrive/cuid.
*/
var ZodCUID = /*@__PURE__*/ $constructor("ZodCUID", (inst, def) => {
	$ZodCUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodCUID2 = /*@__PURE__*/ $constructor("ZodCUID2", (inst, def) => {
	$ZodCUID2.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodULID = /*@__PURE__*/ $constructor("ZodULID", (inst, def) => {
	$ZodULID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodXID = /*@__PURE__*/ $constructor("ZodXID", (inst, def) => {
	$ZodXID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodKSUID = /*@__PURE__*/ $constructor("ZodKSUID", (inst, def) => {
	$ZodKSUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodIPv4 = /*@__PURE__*/ $constructor("ZodIPv4", (inst, def) => {
	$ZodIPv4.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodIPv6 = /*@__PURE__*/ $constructor("ZodIPv6", (inst, def) => {
	$ZodIPv6.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodCIDRv4 = /*@__PURE__*/ $constructor("ZodCIDRv4", (inst, def) => {
	$ZodCIDRv4.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodCIDRv6 = /*@__PURE__*/ $constructor("ZodCIDRv6", (inst, def) => {
	$ZodCIDRv6.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodBase64 = /*@__PURE__*/ $constructor("ZodBase64", (inst, def) => {
	$ZodBase64.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodBase64URL = /*@__PURE__*/ $constructor("ZodBase64URL", (inst, def) => {
	$ZodBase64URL.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodE164 = /*@__PURE__*/ $constructor("ZodE164", (inst, def) => {
	$ZodE164.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodJWT = /*@__PURE__*/ $constructor("ZodJWT", (inst, def) => {
	$ZodJWT.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodNumber = /*@__PURE__*/ $constructor("ZodNumber", (inst, def) => {
	$ZodNumber.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => numberProcessor(inst, ctx, json, params);
	inst.isFinite = true;
}, /*@__PURE__*/ derived({
	minValue: (inst) => {
		const { minimum, exclusiveMinimum } = aggregateChecks(inst);
		return Math.max(minimum ?? Number.NEGATIVE_INFINITY, exclusiveMinimum ?? Number.NEGATIVE_INFINITY);
	},
	maxValue: (inst) => {
		const { maximum, exclusiveMaximum } = aggregateChecks(inst);
		return Math.min(maximum ?? Number.POSITIVE_INFINITY, exclusiveMaximum ?? Number.POSITIVE_INFINITY);
	},
	isInt: (inst) => {
		const { isInt, multipleOf } = aggregateChecks(inst);
		return !!isInt || !!multipleOf?.some(Number.isSafeInteger);
	},
	format: (inst) => aggregateChecks(inst).format ?? null
}, {
	gt(value, params) {
		return this.check(/* @__PURE__ */ _gt(value, params));
	},
	gte(value, params) {
		return this.check(/* @__PURE__ */ _gte(value, params));
	},
	min(value, params) {
		return this.check(/* @__PURE__ */ _gte(value, params));
	},
	lt(value, params) {
		return this.check(/* @__PURE__ */ _lt(value, params));
	},
	lte(value, params) {
		return this.check(/* @__PURE__ */ _lte(value, params));
	},
	max(value, params) {
		return this.check(/* @__PURE__ */ _lte(value, params));
	},
	int(params) {
		return this.check(int(params));
	},
	safe(params) {
		return this.check(int(params));
	},
	positive(params) {
		return this.check(/* @__PURE__ */ _gt(0, params));
	},
	nonnegative(params) {
		return this.check(/* @__PURE__ */ _gte(0, params));
	},
	negative(params) {
		return this.check(/* @__PURE__ */ _lt(0, params));
	},
	nonpositive(params) {
		return this.check(/* @__PURE__ */ _lte(0, params));
	},
	multipleOf(value, params) {
		return this.check(/* @__PURE__ */ _multipleOf(value, params));
	},
	step(value, params) {
		return this.check(/* @__PURE__ */ _multipleOf(value, params));
	},
	finite() {
		return this;
	}
}));
function number(params) {
	return /* @__PURE__ */ _number(ZodNumber, params);
}
var ZodNumberFormat = /*@__PURE__*/ $constructor("ZodNumberFormat", (inst, def) => {
	$ZodNumberFormat.init(inst, def);
	ZodNumber.init(inst, def);
});
function int(params) {
	return /* @__PURE__ */ _int(ZodNumberFormat, params);
}
var ZodBoolean = /*@__PURE__*/ $constructor("ZodBoolean", (inst, def) => {
	$ZodBoolean.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => booleanProcessor(inst, ctx, json, params);
});
function boolean(params) {
	return /* @__PURE__ */ _boolean(ZodBoolean, params);
}
var ZodNull = /*@__PURE__*/ $constructor("ZodNull", (inst, def) => {
	$ZodNull.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => nullProcessor(inst, ctx, json, params);
});
function _null(params) {
	return /* @__PURE__ */ _null$1(ZodNull, params);
}
var ZodUnknown = /*@__PURE__*/ $constructor("ZodUnknown", (inst, def) => {
	$ZodUnknown.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => void 0;
});
function unknown() {
	return /* @__PURE__ */ _unknown(ZodUnknown);
}
var ZodNever = /*@__PURE__*/ $constructor("ZodNever", (inst, def) => {
	$ZodNever.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => neverProcessor(inst, ctx, json, params);
});
function never(params) {
	return /* @__PURE__ */ _never(ZodNever, params);
}
var ZodArray = /*@__PURE__*/ $constructor("ZodArray", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodArray.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => arrayProcessor(inst, ctx, json, params);
	inst.element = def.element;
}, {
	min(n, params) {
		return this.check(/* @__PURE__ */ _minLength(n, params));
	},
	nonempty(params) {
		return this.check(/* @__PURE__ */ _minLength(1, params));
	},
	max(n, params) {
		return this.check(/* @__PURE__ */ _maxLength(n, params));
	},
	length(n, params) {
		return this.check(/* @__PURE__ */ _length(n, params));
	},
	unwrap() {
		return this.element;
	}
});
function array(element, params) {
	return /* @__PURE__ */ _array(ZodArray, element, params);
}
var ZodObject = /*@__PURE__*/ $constructor("ZodObject", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodObjectJIT.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => objectProcessor(inst, ctx, json, params);
	installLazyProp(inst, "shape", (self) => self._zod.def.shape, false);
}, {
	keyof() {
		return _enum(Object.keys(this._zod.def.shape));
	},
	catchall(catchall) {
		return this.clone(mergeDefs(this._zod.def, { catchall }));
	},
	passthrough() {
		return this.clone(mergeDefs(this._zod.def, { catchall: unknown() }));
	},
	loose() {
		return this.clone(mergeDefs(this._zod.def, { catchall: unknown() }));
	},
	strict() {
		return this.clone(mergeDefs(this._zod.def, { catchall: never() }));
	},
	strip() {
		return this.clone(mergeDefs(this._zod.def, { catchall: void 0 }));
	},
	extend(incoming) {
		return extend(this, incoming);
	},
	safeExtend(incoming) {
		return safeExtend(this, incoming);
	},
	merge(other) {
		return merge(this, other);
	},
	pick(mask) {
		return pick(this, mask);
	},
	omit(mask) {
		return omit(this, mask);
	},
	partial(...args) {
		return partial(ZodOptional, this, args[0]);
	},
	exactPartial(...args) {
		return partial(ZodExactOptional, this, args[0], "exactPartial");
	},
	required(...args) {
		return required(ZodNonOptional, this, args[0]);
	}
});
function strictObject(shape, params) {
	return new ZodObject({
		type: "object",
		shape,
		catchall: never(),
		...normalizeParams(params)
	});
}
function looseObject(shape, params) {
	return new ZodObject({
		type: "object",
		shape,
		catchall: unknown(),
		...normalizeParams(params)
	});
}
var ZodUnion = /*@__PURE__*/ $constructor("ZodUnion", (inst, def) => {
	$ZodUnion.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => unionProcessor(inst, ctx, json, params);
	inst.options = def.options;
});
function union(options, params) {
	return new ZodUnion({
		type: "union",
		options,
		...normalizeParams(params)
	});
}
var ZodDiscriminatedUnion = /*@__PURE__*/ $constructor("ZodDiscriminatedUnion", (inst, def) => {
	ZodUnion.init(inst, def);
	$ZodDiscriminatedUnion.init(inst, def);
});
function discriminatedUnion(discriminator, options, params) {
	return new ZodDiscriminatedUnion({
		type: "union",
		options,
		discriminator,
		...normalizeParams(params)
	});
}
var ZodIntersection = /*@__PURE__*/ $constructor("ZodIntersection", (inst, def) => {
	$ZodIntersection.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => intersectionProcessor(inst, ctx, json, params);
});
function intersection(left, right) {
	return new ZodIntersection({
		type: "intersection",
		left,
		right
	});
}
var ZodTuple = /*@__PURE__*/ $constructor("ZodTuple", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodTuple.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => tupleProcessor(inst, ctx, json, params);
}, {
	rest(rest) {
		return this.clone({
			...this._zod.def,
			rest
		});
	},
	partial() {
		const def = this._zod.def;
		if (def.checks?.length) throw new Error(".partial() cannot be used on tuple schemas containing refinements");
		return this.clone({
			...def,
			items: def.items.map((item) => new ZodOptional({
				type: "optional",
				innerType: item
			}))
		});
	}
});
function tuple(items, _paramsOrRest, _params) {
	const hasRest = _paramsOrRest instanceof $ZodType;
	return new ZodTuple({
		type: "tuple",
		items,
		rest: hasRest ? _paramsOrRest : null,
		...normalizeParams(hasRest ? _params : _paramsOrRest)
	});
}
var ZodRecord = /*@__PURE__*/ $constructor("ZodRecord", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodRecord.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => recordProcessor(inst, ctx, json, params);
	inst.keyType = def.keyType;
	inst.valueType = def.valueType;
});
function record$1(keyType, valueType, params) {
	if (!valueType || !valueType._zod) return new ZodRecord({
		type: "record",
		keyType: string(),
		valueType: keyType,
		...normalizeParams(valueType)
	});
	return new ZodRecord({
		type: "record",
		keyType,
		valueType,
		...normalizeParams(params)
	});
}
var ZodEnum = /*@__PURE__*/ $constructor("ZodEnum", (inst, def) => {
	$ZodEnum.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => enumProcessor(inst, ctx, json, params);
	inst.enum = def.entries;
	inst.options = [...inst._zod.values];
	const keys = new Set(Object.keys(def.entries));
	inst.extract = (values, params) => {
		const newEntries = {};
		for (const value of values) if (keys.has(value)) newEntries[value] = def.entries[value];
		else throw new Error(`Key ${value} not found in enum`);
		return new ZodEnum({
			...def,
			checks: [],
			...normalizeParams(params),
			entries: newEntries
		});
	};
	inst.exclude = (values, params) => {
		const newEntries = { ...def.entries };
		for (const value of values) if (keys.has(value)) delete newEntries[value];
		else throw new Error(`Key ${value} not found in enum`);
		return new ZodEnum({
			...def,
			checks: [],
			...normalizeParams(params),
			entries: newEntries
		});
	};
});
function _enum(values, params) {
	return new ZodEnum({
		type: "enum",
		entries: Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values,
		...normalizeParams(params)
	});
}
var ZodLiteral = /*@__PURE__*/ $constructor("ZodLiteral", (inst, def) => {
	$ZodLiteral.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => literalProcessor(inst, ctx, json, params);
	inst.values = new Set(def.values);
	Object.defineProperty(inst, "value", { get() {
		if (def.values.length > 1) throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
		return def.values[0];
	} });
});
function literal(value, params) {
	return new ZodLiteral({
		type: "literal",
		values: Array.isArray(value) ? value : [value],
		...normalizeParams(params)
	});
}
var ZodTransform = /*@__PURE__*/ $constructor("ZodTransform", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodTransform.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => transformProcessor(inst, ctx, json, params);
	inst._zod.parse = (payload, _ctx) => {
		if (_ctx.direction === "backward") throw new $ZodEncodeError(inst.constructor.name);
		payload.addIssue = (issue$1) => {
			if (typeof issue$1 === "string") payload.issues.push(issue(issue$1, payload.value, def));
			else {
				const _issue = issue$1;
				if (_issue.fatal) _issue.continue = false;
				_issue.code ?? (_issue.code = "custom");
				if (!("input" in _issue)) _issue.input = payload.value;
				_issue.inst ?? (_issue.inst = inst);
				payload.issues.push(issue(_issue));
			}
		};
		const output = def.transform(payload.value, payload);
		if (output instanceof Promise) return output.then((output) => {
			payload.value = output;
			return payload;
		});
		payload.value = output;
		return payload;
	};
});
function transform(fn) {
	return new ZodTransform({
		type: "transform",
		transform: fn
	});
}
var ZodOptional = /*@__PURE__*/ $constructor("ZodOptional", (inst, def) => {
	$ZodOptional.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function optional(innerType) {
	return new ZodOptional({
		type: "optional",
		innerType
	});
}
var ZodExactOptional = /*@__PURE__*/ $constructor("ZodExactOptional", (inst, def) => {
	$ZodExactOptional.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function exactOptional(innerType) {
	return new ZodExactOptional({
		type: "optional",
		innerType
	});
}
var ZodNullable = /*@__PURE__*/ $constructor("ZodNullable", (inst, def) => {
	$ZodNullable.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => nullableProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function nullable(innerType) {
	return new ZodNullable({
		type: "nullable",
		innerType
	});
}
var ZodDefault = /*@__PURE__*/ $constructor("ZodDefault", (inst, def) => {
	$ZodDefault.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => defaultProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
	inst.removeDefault = inst.unwrap;
});
function _default(innerType, defaultValue) {
	return new ZodDefault({
		type: "default",
		innerType,
		get defaultValue() {
			return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
		}
	});
}
var ZodPrefault = /*@__PURE__*/ $constructor("ZodPrefault", (inst, def) => {
	$ZodPrefault.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => prefaultProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function prefault(innerType, defaultValue) {
	return new ZodPrefault({
		type: "prefault",
		innerType,
		get defaultValue() {
			return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
		}
	});
}
var ZodNonOptional = /*@__PURE__*/ $constructor("ZodNonOptional", (inst, def) => {
	$ZodNonOptional.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => nonoptionalProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function nonoptional(innerType, params) {
	return new ZodNonOptional({
		type: "nonoptional",
		innerType,
		...normalizeParams(params)
	});
}
var ZodCatch = /*@__PURE__*/ $constructor("ZodCatch", (inst, def) => {
	$ZodCatch.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => catchProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
	inst.removeCatch = inst.unwrap;
});
function _catch(innerType, catchValue) {
	return new ZodCatch({
		type: "catch",
		innerType,
		catchValue: typeof catchValue === "function" ? catchValue : constantCatch(catchValue)
	});
}
var ZodPipe = /*@__PURE__*/ $constructor("ZodPipe", (inst, def) => {
	$ZodPipe.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => pipeProcessor(inst, ctx, json, params);
	inst.in = def.in;
	inst.out = def.out;
});
function pipe(in_, out) {
	return new ZodPipe({
		type: "pipe",
		in: in_,
		out
	});
}
var ZodReadonly = /*@__PURE__*/ $constructor("ZodReadonly", (inst, def) => {
	$ZodReadonly.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => readonlyProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function readonly(innerType) {
	return new ZodReadonly({
		type: "readonly",
		innerType
	});
}
var ZodCustom = /*@__PURE__*/ $constructor("ZodCustom", (inst, def) => {
	$ZodCustom.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => customProcessor(inst, ctx, json, params);
});
function refine(fn, _params = {}) {
	return /* @__PURE__ */ _refine(ZodCustom, fn, _params);
}
function superRefine(fn, params) {
	return /* @__PURE__ */ _superRefine(fn, params);
}
var ZodInstanceOf = /*@__PURE__*/ $constructor("ZodInstanceOf", (inst, def) => {
	ZodCustom.init(inst, def);
}, { properties(shape, params) {
	return this.check(/* @__PURE__ */ _properties(shape, params));
} });
function _instanceof(cls, params = {}) {
	const inst = new ZodInstanceOf({
		type: "custom",
		check: "custom",
		fn: (data) => data instanceof cls,
		abort: true,
		...normalizeParams(params)
	});
	inst._zod.bag.Class = cls;
	inst._zod.check = (payload) => {
		if (!(payload.value instanceof cls)) payload.issues.push({
			code: "invalid_type",
			expected: cls.name,
			input: payload.value,
			inst,
			path: [...inst._zod.def.path ?? []]
		});
	};
	return inst;
}
//#endregion
//#region packages/plugin-protocol/src/limits.ts
var PLUGIN_LIMITS$1 = {
	messageBytes: 1048576,
	headerBytes: 1024,
	idLength: 128,
	textLength: 200,
	messageLength: 2e3,
	errorMessageLength: 2e3,
	commandsPerPlugin: 64,
	activationEvents: 64,
	manifestBytes: 65536
};
//#endregion
//#region packages/plugin-protocol/src/common.ts
var SINGLE_LINE$1 = /^[^\u0000-\u001F\u007F]*$/;
var namespacedIdSchema$1 = string().min(3).max(PLUGIN_LIMITS$1.idLength).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*(?:\.[a-z0-9]+(?:-[a-z0-9]+)*)+$/);
string().max(64).regex(/^(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/);
_enum(["en", "zh-TW"]);
_enum([
	"ui.notifications",
	"ui.panels",
	"ui.status",
	"settings.read",
	"settings.write",
	"storage.read",
	"storage.write",
	"storage.export",
	"ui.clipboard",
	"devices.read",
	"devices.connect",
	"devices.control"
]);
var text$5 = string().min(1).max(PLUGIN_LIMITS$1.textLength).regex(SINGLE_LINE$1);
union([text$5, looseObject({
	en: text$5,
	"zh-TW": text$5.optional()
})]);
//#endregion
//#region packages/plugin-protocol/src/device-types.ts
var handleSchema$4 = string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
var counterSchema$1 = number().int().min(0).max(Number.MAX_SAFE_INTEGER);
var boundedIdSchema$1 = string().min(1).max(64).regex(/^[A-Za-z0-9][A-Za-z0-9:._-]*$/);
var wireText$1 = (min, max) => string().min(min).max(2 * max).regex(SINGLE_LINE$1);
var capabilitySchema$1 = _enum([
	"connection.v1",
	"telemetry.v1",
	"inputModes.v1",
	"finiteMotion.v1",
	"recordingReservation.v1"
]);
string().max(64).regex(/^[A-Za-z][A-Za-z0-9]*\.v[1-9][0-9]*$/);
strictObject({
	sourceKey: string().max(160).regex(/^(?:builtin:[a-z0-9.-]+|dev:[0-9a-f]{16})$/),
	pluginId: namespacedIdSchema$1,
	generation: counterSchema$1,
	hostEpoch: handleSchema$4,
	processEpoch: handleSchema$4
});
var addressSchema$1 = string().min(2).max(45).regex(/^[0-9a-f:.]+$/);
strictObject({
	candidateId: handleSchema$4,
	providerId: namespacedIdSchema$1,
	name: wireText$1(1, 200),
	transport: _enum([
		"usb",
		"wifi",
		"mock"
	]),
	address: addressSchema$1.exactOptional(),
	identity: _enum([
		"stable",
		"session-only",
		"ambiguous"
	]),
	expiresInMs: number().int().min(0).max(3e4)
});
strictObject({
	sessionId: handleSchema$4,
	providerId: namespacedIdSchema$1,
	providerGeneration: counterSchema$1,
	revision: counterSchema$1,
	name: wireText$1(1, 200),
	transport: _enum([
		"usb",
		"wifi",
		"mock"
	]),
	capabilities: array(capabilitySchema$1).max(5),
	state: _enum([
		"connected",
		"quarantined",
		"disconnecting",
		"disconnected"
	]),
	foreground: _enum([
		"none",
		"motion",
		"program",
		"file",
		"mode",
		"recovery"
	]),
	recording: boolean(),
	sourceRevision: counterSchema$1
});
var sourceState$1 = _enum([
	"ready",
	"empty",
	"initializing",
	"unknown",
	"error"
]);
var channelDefinitionSchema$1 = strictObject({
	channelId: handleSchema$4,
	kind: _enum([
		"input",
		"output-angle",
		"battery-percent",
		"battery-voltage"
	]),
	portId: boundedIdSchema$1.nullable(),
	typeId: boundedIdSchema$1,
	modeId: boundedIdSchema$1.nullable(),
	component: number().int().min(0).max(7),
	name: wireText$1(1, 80),
	modeName: wireText$1(0, 80),
	unit: wireText$1(0, 32),
	decimals: number().int().min(0).max(9),
	state: sourceState$1
});
var actuatorDefinitionSchema$1 = strictObject({
	actuatorId: handleSchema$4,
	portId: boundedIdSchema$1,
	name: wireText$1(1, 80),
	typeId: boundedIdSchema$1,
	state: sourceState$1
});
strictObject({
	sessionId: handleSchema$4,
	sourceRevision: counterSchema$1,
	channels: array(channelDefinitionSchema$1).max(38),
	actuators: array(actuatorDefinitionSchema$1).max(4)
});
strictObject({
	fromSequence: counterSchema$1,
	toSequence: counterSchema$1,
	reason: literal("overflow")
});
var telemetryFrameSchema$1 = strictObject({
	sequence: counterSchema$1,
	sampledAt: counterSchema$1,
	elapsedMs: number().min(0),
	sourceRevision: counterSchema$1,
	status: _enum([
		"ok",
		"busy",
		"error",
		"gap"
	]),
	values: array(strictObject({
		channelId: handleSchema$4,
		value: number().nullable()
	})).max(38),
	program: _enum([
		"stopped",
		"running",
		"unknown"
	]),
	gap: strictObject({
		fromSequence: counterSchema$1,
		toSequence: counterSchema$1,
		reason: _enum([
			"busy",
			"overflow",
			"read-error"
		])
	}).exactOptional()
});
strictObject({
	sessionId: handleSchema$4,
	revision: counterSchema$1,
	status: _enum([
		"fresh",
		"stale",
		"busy",
		"unavailable"
	]),
	ageMs: number().min(0).nullable(),
	frame: telemetryFrameSchema$1.nullable()
});
strictObject({
	sourceRevision: counterSchema$1,
	portId: boundedIdSchema$1,
	typeId: boundedIdSchema$1,
	currentModeId: boundedIdSchema$1.nullable(),
	modes: array(strictObject({
		modeId: boundedIdSchema$1,
		name: wireText$1(1, 80)
	})).max(8)
});
var motionBase$1 = {
	actuatorId: handleSchema$4,
	power: number().int().min(1).max(100),
	direction: union([literal(1), literal(-1)]),
	brake: boolean()
};
discriminatedUnion("mode", [
	strictObject({
		...motionBase$1,
		mode: literal("jog")
	}),
	strictObject({
		...motionBase$1,
		mode: literal("timed"),
		durationMs: number().int().min(100).max(5e3)
	}),
	strictObject({
		...motionBase$1,
		mode: literal("relative-angle"),
		degrees: number().int().min(1).max(3600)
	})
]);
strictObject({
	reservationId: handleSchema$4,
	sessionId: handleSchema$4,
	revision: counterSchema$1,
	state: _enum([
		"active",
		"ending",
		"ended"
	]),
	channels: array(channelDefinitionSchema$1).min(1).max(4),
	firstSequence: counterSchema$1,
	lastSequence: counterSchema$1,
	reason: _enum([
		"active",
		"released",
		"source-changed",
		"disconnected",
		"suspended",
		"core-disconnect",
		"retired",
		"renderer-lost",
		"limit",
		"overflow"
	])
});
var pluginErrorCodeSchema$1 = _enum([
	"PLUGIN_E_MANIFEST",
	"PLUGIN_E_API_VERSION",
	"PLUGIN_E_RESERVED_ID",
	"PLUGIN_E_DIAGNOSTIC_HELP",
	"PLUGIN_E_STATIC_LANGUAGE",
	"PLUGIN_E_STATIC_LANGUAGE_CONFLICT",
	"PLUGIN_E_STATIC_LANGUAGE_REGISTRATION",
	"PLUGIN_E_DUPLICATE_ID",
	"PLUGIN_E_COMMAND_NAMESPACE",
	"PLUGIN_E_DUPLICATE_COMMAND",
	"PLUGIN_E_ACTIVATION",
	"PLUGIN_E_RUNTIME_NOT_ALLOWED",
	"PLUGIN_E_FRONTEND_REQUIRES_BUILTIN",
	"PLUGIN_E_BACKEND_REQUIRES_BUILTIN",
	"PLUGIN_E_LANGUAGE_SERVICE_REQUIRES_BUILTIN",
	"PLUGIN_E_PROVIDER_CONFLICT",
	"PLUGIN_E_ENTRY",
	"PLUGIN_E_LAUNCH",
	"PLUGIN_E_HANDSHAKE",
	"PLUGIN_E_PROTOCOL",
	"PLUGIN_E_UNRESPONSIVE",
	"PLUGIN_E_CRASHED",
	"PLUGIN_E_CRASH_LOOP",
	"PLUGIN_E_TIMEOUT",
	"PLUGIN_E_CANCELLED",
	"PLUGIN_E_COMMAND_FAILED",
	"PLUGIN_E_UNKNOWN_COMMAND",
	"PLUGIN_E_UNKNOWN_PLUGIN",
	"PLUGIN_E_DISABLED",
	"PLUGIN_E_BUILTIN_REQUIRED",
	"PLUGIN_E_SAFE_MODE",
	"PLUGIN_E_STATE_SAVE",
	"PLUGIN_E_STATE_CORRUPT",
	"PLUGIN_E_SHUTTING_DOWN",
	"PLUGIN_E_SOURCE_TIMEOUT",
	"PLUGIN_E_SOURCE_EXISTS",
	"PLUGIN_E_DEVELOPER_MODE",
	"PLUGIN_E_SESSION_SOURCE",
	"PLUGIN_E_PYTHON_UNUSABLE",
	"PLUGIN_E_PERMISSION_DENIED",
	"PLUGIN_E_STALE_RESOURCE",
	"PLUGIN_E_RESOURCE_LIMIT",
	"PLUGIN_E_DEVICE_PROVIDER_REQUIRES_BUILTIN",
	"PLUGIN_E_DEVICE_UNAVAILABLE",
	"PLUGIN_E_DEVICE_CAPABILITY",
	"PLUGIN_E_DEVICE_BUSY",
	"PLUGIN_E_DEVICE_AUTHORITY",
	"PLUGIN_E_DEVICE_OPERATION",
	"PLUGIN_E_DEVICE_STOP_UNCONFIRMED",
	"PLUGIN_E_UI_RESOURCE",
	"PLUGIN_E_UI_VERSION",
	"PLUGIN_E_SETTINGS_SCHEMA",
	"PLUGIN_E_SETTINGS_CONFLICT",
	"PLUGIN_E_SETTINGS_SAVE",
	"PLUGIN_E_STORAGE_QUOTA",
	"PLUGIN_E_STORAGE_CONFLICT",
	"PLUGIN_E_STORAGE_IO",
	"PLUGIN_E_STORAGE_VERSION"
]);
var reasons$3 = Object.values({
	PLUGIN_E_DEVICE_UNAVAILABLE: [
		"provider-disabled",
		"disconnected",
		"quarantined",
		"ui-scope-unavailable"
	],
	PLUGIN_E_DEVICE_CAPABILITY: ["unsupported-capability"],
	PLUGIN_E_DEVICE_BUSY: [
		"foreground",
		"recording",
		"connecting",
		"source-changing"
	],
	PLUGIN_E_DEVICE_AUTHORITY: [
		"unbound",
		"joining",
		"unsynced",
		"not-holder",
		"viewer",
		"authority-changed",
		"scope-expired"
	],
	PLUGIN_E_DEVICE_OPERATION: [
		"preflight-program-running",
		"preflight-output-unknown",
		"preflight-output-moving",
		"motor-unavailable",
		"source-changed",
		"mode-unavailable",
		"provider-failure",
		"provider-contract",
		"journal-unwritable",
		"journal-corrupt",
		"identity-ambiguous"
	],
	PLUGIN_E_DEVICE_STOP_UNCONFIRMED: [
		"readback-failed",
		"stop-deadline",
		"connection-lost",
		"provider-stalled"
	],
	PLUGIN_E_TIMEOUT: ["deadline"],
	PLUGIN_E_CANCELLED: ["cancelled"],
	PLUGIN_E_DISABLED: ["disabled"],
	PLUGIN_E_SAFE_MODE: ["safe-mode"],
	PLUGIN_E_SHUTTING_DOWN: ["shutting-down"],
	PLUGIN_E_CRASHED: ["process-lost"],
	PLUGIN_E_PROTOCOL: ["protocol"],
	PLUGIN_E_PROVIDER_CONFLICT: ["provider-conflict"]
}).flat();
var deviceErrorDetailSchema$1 = strictObject({
	kind: literal("device"),
	reason: _enum(reasons$3),
	operationId: handleSchema$4.exactOptional(),
	dispatch: _enum([
		"not-sent",
		"sent",
		"unknown"
	]),
	stopConfirmation: _enum([
		"not-required",
		"pending",
		"confirmed",
		"unconfirmed"
	])
});
var permissionErrorDetailSchema$1 = strictObject({
	kind: literal("permission"),
	reason: _enum(["permission", "user-action-required"])
});
union([
	deviceErrorDetailSchema$1,
	permissionErrorDetailSchema$1,
	strictObject({
		kind: literal("resource"),
		reason: _enum([
			"stale",
			"quota",
			"rate",
			"queue"
		]),
		resource: _enum([
			"operation",
			"subscription",
			"candidate",
			"reservation",
			"journal",
			"rpc",
			"ui-binding",
			"storage-write",
			"storage-read",
			"storage-list",
			"storage-export",
			"storage-watch"
		]),
		limit: counterSchema$1.exactOptional()
	})
]);
strictObject({
	code: pluginErrorCodeSchema$1,
	message: wireText$1(1, 2e3),
	detail: deviceErrorDetailSchema$1
});
var resources150$1 = [
	"operation",
	"subscription",
	"candidate",
	"reservation",
	"journal",
	"rpc"
];
var resources160$1 = [...resources150$1, "ui-binding"];
var resources170$1 = [
	...resources160$1,
	"storage-write",
	"storage-read",
	"storage-list",
	"storage-export",
	"storage-watch"
];
function commonFailureSchemaFor$1(batch) {
	const resources = batch === "1.5.0" ? resources150$1 : batch === "1.6.0" ? resources160$1 : resources170$1;
	return union([
		strictObject({
			ok: literal(false),
			error: strictObject({
				code: literal("PLUGIN_E_PERMISSION_DENIED"),
				message: wireText$1(1, 2e3),
				detail: permissionErrorDetailSchema$1
			})
		}),
		strictObject({
			ok: literal(false),
			error: strictObject({
				code: literal("PLUGIN_E_STALE_RESOURCE"),
				message: wireText$1(1, 2e3),
				detail: strictObject({
					kind: literal("resource"),
					reason: literal("stale"),
					resource: _enum(resources),
					limit: counterSchema$1.exactOptional()
				})
			})
		}),
		strictObject({
			ok: literal(false),
			error: strictObject({
				code: literal("PLUGIN_E_RESOURCE_LIMIT"),
				message: wireText$1(1, 2e3),
				detail: strictObject({
					kind: literal("resource"),
					reason: _enum([
						"quota",
						"rate",
						"queue"
					]),
					resource: _enum(resources),
					limit: counterSchema$1.exactOptional()
				})
			})
		})
	]);
}
commonFailureSchemaFor$1("1.6.0");
//#endregion
//#region packages/plugin-protocol/src/persistence-primitives.ts
var persistenceCodeReasons$1 = {
	PLUGIN_E_SETTINGS_SCHEMA: [
		"invalid-resource",
		"invalid-value",
		"duplicate-key",
		"unknown-key",
		"size-limit",
		"schema-changed-without-version",
		"migration-required",
		"downgrade",
		"unsupported-format",
		"corrupt"
	],
	PLUGIN_E_SETTINGS_CONFLICT: ["revision-mismatch"],
	PLUGIN_E_SETTINGS_SAVE: [
		"disk-full",
		"permission",
		"read-only",
		"io",
		"sync-failed",
		"publish-uncertain",
		"import-pending"
	],
	PLUGIN_E_STORAGE_QUOTA: [
		"record-count",
		"source-bytes",
		"host-bytes",
		"temporary-bytes"
	],
	PLUGIN_E_STORAGE_CONFLICT: [
		"revision-mismatch",
		"write-in-progress",
		"offset-mismatch",
		"sealed",
		"incomplete",
		"checksum-mismatch",
		"flush-incomplete",
		"export-not-ready"
	],
	PLUGIN_E_STORAGE_IO: [
		"not-found",
		"disk-full",
		"permission",
		"read-only",
		"io",
		"sync-failed",
		"publish-uncertain",
		"corrupt",
		"import-pending",
		"input-changed",
		"clipboard-unavailable",
		"destination-changed",
		"unsupported-filesystem"
	],
	PLUGIN_E_STORAGE_VERSION: ["unsupported-format", "schema-mismatch"]
};
var jsonBytes$1 = (value) => new TextEncoder().encode(JSON.stringify(value)).byteLength;
var utf8Bytes$1 = (value) => new TextEncoder().encode(value).byteLength;
var safeIntegerSchema$1 = number().int().min(0).max(Number.MAX_SAFE_INTEGER);
var versionSchema$1 = number().int().min(1).max(2147483647);
var handleSchema$3 = string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
var revisionSchema$1 = string().regex(/^r_[0-9a-f]{32}$/);
var sha256Schema$1 = string().regex(/^[0-9a-f]{64}$/);
var keySchema$1 = string().max(64).regex(/^[a-z][A-Za-z0-9]*(?:\.[a-z][A-Za-z0-9]*)*$/).refine((value) => !value.split(".").some((k) => [
	"__proto__",
	"prototype",
	"constructor"
].includes(k)));
var durabilitySchema$1 = _enum(["file-and-directory-sync", "file-sync-only"]);
var receiptSchema$1 = strictObject({
	revision: revisionSchema$1,
	commitId: handleSchema$3,
	durability: durabilitySchema$1
});
var wellFormedText$1 = (text) => !text.includes("\0") && [...text].every((c) => {
	const n = c.codePointAt(0);
	return n < 55296 || n > 57343;
});
function boundedText$1(min, max, bytes, singleLine = false) {
	return string().refine((s) => wellFormedText$1(s) && [...s].length >= min && [...s].length <= max && utf8Bytes$1(s) <= bytes && (!singleLine || !/[\u0000-\u001f\u007f\u2028\u2029]/u.test(s)));
}
var reasons$2 = [...new Set(Object.values(persistenceCodeReasons$1).flat())];
var persistenceDetailSchema$1 = strictObject({
	kind: literal("persistence"),
	reason: _enum(reasons$2),
	phase: _enum([
		"validate",
		"reserve",
		"write",
		"seal",
		"publish",
		"sync",
		"recover"
	]).optional(),
	disposition: _enum([
		"not-committed",
		"committed",
		"unknown"
	]).optional(),
	actualRevision: revisionSchema$1.optional(),
	expectedVersion: versionSchema$1.optional(),
	actualVersion: versionSchema$1.optional(),
	limit: safeIntegerSchema$1.optional(),
	requested: safeIntegerSchema$1.optional(),
	retryable: boolean().optional(),
	payload: _enum([
		"complete-staging",
		"checkpoint-only",
		"none"
	]).optional(),
	expiresAt: safeIntegerSchema$1.optional(),
	commitId: handleSchema$3.optional(),
	keys: array(keySchema$1).max(16).optional()
}).refine((d) => jsonBytes$1(d) <= 2048).transform((d) => ({
	kind: d.kind,
	reason: d.reason,
	...d.phase === void 0 ? {} : { phase: d.phase },
	...d.disposition === void 0 ? {} : { disposition: d.disposition },
	...d.actualRevision === void 0 ? {} : { actualRevision: d.actualRevision },
	...d.expectedVersion === void 0 ? {} : { expectedVersion: d.expectedVersion },
	...d.actualVersion === void 0 ? {} : { actualVersion: d.actualVersion },
	...d.limit === void 0 ? {} : { limit: d.limit },
	...d.requested === void 0 ? {} : { requested: d.requested },
	...d.retryable === void 0 ? {} : { retryable: d.retryable },
	...d.payload === void 0 ? {} : { payload: d.payload },
	...d.expiresAt === void 0 ? {} : { expiresAt: d.expiresAt },
	...d.commitId === void 0 ? {} : { commitId: d.commitId },
	...d.keys === void 0 ? {} : { keys: d.keys }
}));
var permissionDetail$1 = strictObject({
	kind: literal("permission"),
	reason: _enum(["permission", "user-action-required"])
});
var resourceDetail$1 = strictObject({
	kind: literal("resource"),
	reason: _enum([
		"stale",
		"quota",
		"rate",
		"queue"
	]),
	resource: _enum([
		"operation",
		"subscription",
		"candidate",
		"reservation",
		"journal",
		"rpc",
		"ui-binding",
		"storage-write",
		"storage-read",
		"storage-list",
		"storage-export",
		"storage-watch"
	]),
	limit: safeIntegerSchema$1.optional()
}).transform(({ limit, ...detail }) => ({
	...detail,
	...limit === void 0 ? {} : { limit }
}));
var message$1 = boundedText$1(0, 2e3, 8e3);
var lifecycle$1 = [
	"PLUGIN_E_TIMEOUT",
	"PLUGIN_E_CANCELLED",
	"PLUGIN_E_DISABLED",
	"PLUGIN_E_SAFE_MODE",
	"PLUGIN_E_SHUTTING_DOWN"
];
var persistenceErrorSchema$1 = strictObject({
	code: _enum([
		"PLUGIN_E_PERMISSION_DENIED",
		"PLUGIN_E_STALE_RESOURCE",
		"PLUGIN_E_RESOURCE_LIMIT",
		...[
			"PLUGIN_E_SETTINGS_SCHEMA",
			"PLUGIN_E_SETTINGS_SAVE",
			"PLUGIN_E_SETTINGS_CONFLICT",
			"PLUGIN_E_STORAGE_QUOTA",
			"PLUGIN_E_STORAGE_CONFLICT",
			"PLUGIN_E_STORAGE_IO",
			"PLUGIN_E_STORAGE_VERSION"
		],
		...lifecycle$1
	]),
	message: message$1,
	detail: union([
		persistenceDetailSchema$1,
		permissionDetail$1,
		resourceDetail$1
	]).optional()
}).superRefine((e, ctx) => {
	let valid = false;
	const d = e.detail;
	if (e.code in persistenceCodeReasons$1) valid = d === void 0 || d.kind === "persistence" && persistenceCodeReasons$1[e.code].includes(d.reason);
	else if (e.code === "PLUGIN_E_PERMISSION_DENIED") valid = d === void 0 || d.kind === "permission";
	else if (e.code === "PLUGIN_E_STALE_RESOURCE") valid = d === void 0 || d.kind === "resource" && d.reason === "stale";
	else if (e.code === "PLUGIN_E_RESOURCE_LIMIT") valid = d === void 0 || d.kind === "resource" && d.reason !== "stale";
	else valid = d === void 0;
	if (!valid || d !== void 0 && jsonBytes$1(d) > 2048) ctx.addIssue({
		code: "custom",
		message: "Invalid code/detail pair"
	});
}).transform(({ detail, ...error }) => ({
	...error,
	...detail === void 0 ? {} : { detail }
}));
function persistenceResultSchema$1(value) {
	return union([
		strictObject({
			ok: literal(true),
			value
		}),
		commonFailureSchemaFor$1("1.7.0"),
		strictObject({
			ok: literal(false),
			error: persistenceErrorSchema$1
		})
	]);
}
persistenceResultSchema$1(string());
function canonicalBase64Length$1(text, allowEmpty = false) {
	if (text === "" && allowEmpty) return 0;
	if (text.length === 0 || text.length > 349528 || text.length % 4 !== 0 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(text)) throw new Error("invalid-base64");
	const padding = text.endsWith("==") ? 2 : text.endsWith("=") ? 1 : 0;
	const last = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".indexOf(text[text.length - padding - 1]);
	if (padding === 2 && (last & 15) !== 0 || padding === 1 && (last & 3) !== 0) throw new Error("invalid-base64-tail-bits");
	const bytes = text.length / 4 * 3 - padding;
	if (bytes > 262144) throw new Error("size-limit");
	return bytes;
}
var chunkSchema$1 = (allowEmpty = false) => string().refine((text) => {
	try {
		canonicalBase64Length$1(text, allowEmpty);
		return true;
	} catch {
		return false;
	}
});
var PersistenceValidationError = class extends Error {
	reason;
	constructor(reason) {
		super(reason);
		this.reason = reason;
	}
};
//#endregion
//#region packages/plugin-protocol/src/settings.ts
var settingsText$1 = (value) => ({
	en: value.en,
	...value["zh-TW"] === void 0 ? {} : { "zh-TW": value["zh-TW"] }
});
var title$1 = strictObject({
	en: boundedText$1(1, 200, 800, true),
	"zh-TW": boundedText$1(1, 200, 800, true).optional()
}).transform(settingsText$1);
var common$1 = {
	key: keySchema$1,
	label: title$1,
	help: strictObject({
		en: boundedText$1(0, 2e3, 8192),
		"zh-TW": boundedText$1(0, 2e3, 8192).optional()
	}).transform(settingsText$1).optional(),
	resetWhen: strictObject({
		key: keySchema$1,
		equals: boolean()
	}).optional()
};
var scalar$1 = union([
	boolean(),
	number(),
	boundedText$1(0, 4e3, 4096)
]);
var optionValue$1 = union([number().int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER), boundedText$1(0, 4e3, 4096)]);
var settingsFieldSchema$1 = discriminatedUnion("type", [
	strictObject({
		...common$1,
		type: literal("boolean"),
		default: boolean()
	}),
	strictObject({
		...common$1,
		type: literal("number"),
		default: number(),
		minimum: number(),
		maximum: number()
	}),
	strictObject({
		...common$1,
		type: literal("integer"),
		default: number().int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),
		minimum: number().int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),
		maximum: number().int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER)
	}),
	strictObject({
		...common$1,
		type: literal("string"),
		default: boundedText$1(0, 4e3, 4096),
		minLength: number().int().min(0).max(4e3),
		maxLength: number().int().min(0).max(4e3),
		maxBytes: number().int().min(1).max(4096)
	}),
	strictObject({
		...common$1,
		type: literal("enum"),
		default: optionValue$1,
		options: array(strictObject({
			value: optionValue$1,
			label: title$1
		})).min(1).max(32)
	})
]).transform(({ help, resetWhen, ...field }) => ({
	...field,
	...help === void 0 ? {} : { help },
	...resetWhen === void 0 ? {} : { resetWhen }
}));
var valuesSchema$1 = array(strictObject({
	key: keySchema$1,
	value: scalar$1
})).max(128).refine((v) => new Set(v.map((x) => x.key)).size === v.length && jsonBytes$1(v) <= 65536);
var settingsResourceV1Schema$1 = strictObject({
	schemaVersion: versionSchema$1,
	title: title$1,
	fields: array(settingsFieldSchema$1).min(1).max(128)
});
var settingsSnapshotSchema$1 = strictObject({
	schemaVersion: versionSchema$1,
	revision: revisionSchema$1.nullable(),
	values: valuesSchema$1
});
var settingsMutationSchema$1 = strictObject({
	snapshot: settingsSnapshotSchema$1,
	receipt: receiptSchema$1
});
strictObject({
	revision: revisionSchema$1,
	schemaVersion: versionSchema$1,
	changedKeys: array(keySchema$1).max(128),
	cause: _enum([
		"update",
		"reset",
		"migrate",
		"import"
	])
});
var failure$1 = (reason) => {
	throw new PersistenceValidationError(reason);
};
function validateSettingsValues(resource, input, complete) {
	if (jsonBytes$1(input) > 65536) return failure$1("size-limit");
	const parsed = valuesSchema$1.safeParse(input);
	if (!parsed.success) return failure$1("invalid-value");
	const values = parsed.data;
	const fields = new Map(resource.fields.map((f) => [f.key, f]));
	if (complete && values.length !== fields.size) return failure$1("invalid-value");
	for (const { key, value } of values) {
		const f = fields.get(key);
		if (!f) return failure$1("unknown-key");
		switch (f.type) {
			case "boolean":
				if (typeof value !== "boolean") return failure$1("invalid-value");
				break;
			case "number":
			case "integer":
				if (typeof value !== "number" || !Number.isFinite(value) || value < f.minimum || value > f.maximum || f.type === "integer" && !Number.isSafeInteger(value)) return failure$1("invalid-value");
				break;
			case "string":
				if (typeof value !== "string" || !boundedText$1(f.minLength, f.maxLength, f.maxBytes).safeParse(value).success) return failure$1("invalid-value");
				break;
			case "enum": if (!f.options.some((o) => typeof o.value === typeof value && o.value === value)) return failure$1("invalid-value");
		}
	}
	if (complete) {
		const map = new Map(values.map((entry) => [entry.key, entry.value]));
		for (const field of resource.fields) if (field.resetWhen && map.get(field.resetWhen.key) === field.resetWhen.equals && map.get(field.key) !== field.default) return failure$1("invalid-value");
	}
	return values;
}
/** Normalize an otherwise valid complete candidate before the host's single CAS.
* Persisted reads must use validateSettingsValues instead, never repair on read. */
function normalizeSettingsValues(resource, input) {
	const values = validateSettingsValues(resource, input, false);
	if (values.length !== resource.fields.length) return failure$1("invalid-value");
	const map = new Map(values.map((entry) => [entry.key, entry.value]));
	for (const field of resource.fields) if (field.resetWhen && map.get(field.resetWhen.key) === field.resetWhen.equals) map.set(field.key, field.default);
	return validateSettingsValues(resource, values.map(({ key }) => ({
		key,
		value: map.get(key)
	})), true);
}
function settingsValidationText(resource) {
	return JSON.stringify({
		schemaVersion: resource.schemaVersion,
		fields: [...resource.fields].sort((a, b) => a.key < b.key ? -1 : a.key > b.key ? 1 : 0).map((f) => {
			const base = {
				key: f.key,
				type: f.type,
				default: f.default,
				...f.resetWhen ? { resetWhen: {
					key: f.resetWhen.key,
					equals: f.resetWhen.equals
				} } : {}
			};
			if (f.type === "number" || f.type === "integer") return {
				...base,
				minimum: f.minimum,
				maximum: f.maximum
			};
			if (f.type === "string") return {
				...base,
				minLength: f.minLength,
				maxLength: f.maxLength,
				maxBytes: f.maxBytes
			};
			if (f.type === "enum") return {
				...base,
				options: f.options.map((o) => [typeof o.value, o.value]).sort((a, b) => JSON.stringify(a) < JSON.stringify(b) ? -1 : JSON.stringify(a) > JSON.stringify(b) ? 1 : 0)
			};
			return base;
		})
	});
}
var request$4 = (params, value) => ({
	params,
	result: persistenceResultSchema$1(value)
});
request$4(strictObject({ schemaVersion: versionSchema$1 }), settingsSnapshotSchema$1), request$4(strictObject({
	schemaVersion: versionSchema$1,
	expectedRevision: revisionSchema$1.nullable(),
	changes: valuesSchema$1.min(1)
}), settingsMutationSchema$1), request$4(strictObject({
	schemaVersion: versionSchema$1,
	expectedRevision: revisionSchema$1.nullable(),
	keys: array(keySchema$1).min(1).max(128).refine((v) => new Set(v).size === v.length)
}), settingsMutationSchema$1), request$4(strictObject({ schemaVersion: versionSchema$1 }), strictObject({
	subscriptionId: handleSchema$3,
	sequence: literal(0),
	snapshot: settingsSnapshotSchema$1
})), request$4(strictObject({}), strictObject({
	stored: settingsSnapshotSchema$1,
	declaredSchemaVersion: versionSchema$1
})), request$4(strictObject({
	fromSchemaVersion: versionSchema$1,
	schemaVersion: versionSchema$1,
	expectedRevision: revisionSchema$1,
	values: valuesSchema$1
}), settingsMutationSchema$1);
//#endregion
//#region apps/desktop/src/main/plugins/persistence/filesystem.ts
async function writeAll(fs, fd, offset, bytes) {
	let done = 0;
	while (done < bytes.byteLength) {
		const written = await fs.write(fd, offset + done, bytes.subarray(done));
		if (!Number.isSafeInteger(written) || written <= 0 || written > bytes.byteLength - done) throw new Error("io");
		done += written;
	}
}
var NodePersistenceFs = class {
	root;
	profile;
	options;
	durability;
	descriptors = /* @__PURE__ */ new WeakMap();
	constructor(root, profile, options = {}) {
		this.root = root;
		this.profile = profile;
		this.options = options;
		this.durability = options.directorySyncSupported ?? process.platform !== "win32" ? "file-and-directory-sync" : "file-sync-only";
	}
	now() {
		return this.options.now?.() ?? node_perf_hooks.performance.now();
	}
	path(...parts) {
		return createStorePath(this, parts);
	}
	name(p) {
		return storePathName(this, p);
	}
	async check(p, missingLeaf = false) {
		this.profile.assertHeld();
		const name = this.name(p), relative = node_path.default.relative(this.root, name);
		if (relative.startsWith("..") || node_path.default.isAbsolute(relative)) throw new Error("unsafe-path");
		const parts = relative ? relative.split(node_path.default.sep) : [];
		for (let i = 0; i <= parts.length; i++) {
			const current = node_path.default.join(this.root, ...parts.slice(0, i));
			let st;
			try {
				st = await (0, node_fs_promises.lstat)(current);
			} catch (e) {
				if (missingLeaf && i === parts.length && e.code === "ENOENT") return;
				throw e;
			}
			if (st.isSymbolicLink() || !st.isDirectory() && !st.isFile() || st.isFile() && st.nlink !== 1 || i < parts.length && !st.isDirectory() || await (0, node_fs_promises.realpath)(current) !== current) throw new Error("unsafe-path");
		}
	}
	async open(p, mode) {
		await this.check(p, mode === "create-exclusive");
		const name = this.name(p), nofollow = node_fs.constants.O_NOFOLLOW ?? 0;
		this.profile.assertHeld();
		const fd = await (0, node_fs_promises.open)(name, (mode === "read" ? node_fs.constants.O_RDONLY : node_fs.constants.O_WRONLY | node_fs.constants.O_CREAT | node_fs.constants.O_EXCL) | nofollow, 384);
		try {
			const a = await fd.stat(), b = await (0, node_fs_promises.lstat)(name);
			if (!a.isFile() || a.nlink !== 1 || a.dev !== b.dev || a.ino !== b.ino || b.isSymbolicLink()) throw new Error("unsafe-path");
			await this.check(p);
			const token = Object.freeze({});
			this.descriptors.set(token, fd);
			return token;
		} catch (e) {
			await fd.close();
			throw e;
		}
	}
	fd(token) {
		const fd = this.descriptors.get(token);
		if (!fd) throw new Error("stale");
		return fd;
	}
	async read(fd, offset, maxBytes) {
		if (!Number.isSafeInteger(offset) || offset < 0 || !Number.isSafeInteger(maxBytes) || maxBytes < 1 || maxBytes > 262144) throw new Error("invalid-range");
		this.profile.assertHeld();
		const identity = await this.fd(fd).stat();
		if (!identity.isFile() || identity.nlink !== 1) throw new Error("unsafe-path");
		const buffer = Buffer.allocUnsafe(maxBytes);
		const { bytesRead } = await this.fd(fd).read(buffer, 0, maxBytes, offset);
		return buffer.subarray(0, bytesRead);
	}
	async write(fd, offset, bytes) {
		this.profile.assertHeld();
		const identity = await this.fd(fd).stat();
		if (!identity.isFile() || identity.nlink !== 1) throw new Error("unsafe-path");
		this.profile.assertHeld();
		return (await this.fd(fd).write(bytes, 0, bytes.byteLength, offset)).bytesWritten;
	}
	async sync(fd) {
		this.profile.assertHeld();
		await this.fd(fd).sync();
	}
	async close(token) {
		const fd = this.fd(token);
		this.descriptors.delete(token);
		await fd.close();
	}
	async directorySync(name) {
		const fd = await (0, node_fs_promises.open)(name, node_fs.constants.O_RDONLY);
		try {
			this.profile.assertHeld();
			await fd.sync();
		} finally {
			await fd.close();
		}
	}
	async syncDirectory(p) {
		await this.check(p);
		if (this.durability === "file-and-directory-sync") await this.directorySync(this.name(p));
	}
	async atomicReplace(from, to) {
		await this.check(from);
		await this.check(to, true);
		const source = await (0, node_fs_promises.lstat)(this.name(from)), parent = await (0, node_fs_promises.lstat)(node_path.default.dirname(this.name(to)));
		if (source.dev !== parent.dev) throw Object.assign(/* @__PURE__ */ new Error("unsupported-filesystem"), { code: "EXDEV" });
		this.profile.assertHeld();
		await (0, node_fs_promises.rename)(this.name(from), this.name(to));
	}
	async mkdir(p) {
		await this.check(p, true);
		this.profile.assertHeld();
		await (0, node_fs_promises.mkdir)(this.name(p), { mode: 448 }).catch((e) => {
			if (e.code !== "EEXIST") throw e;
		});
		await this.check(p);
		if (!(await (0, node_fs_promises.lstat)(this.name(p))).isDirectory()) throw new Error("unsafe-path");
		if (this.durability === "file-and-directory-sync") await this.directorySync(node_path.default.dirname(this.name(p)));
	}
	async statfs(p) {
		await this.check(p);
		const st = await (0, node_fs_promises.statfs)(this.name(p), { bigint: true });
		return { availableBytes: Number(st.bavail * st.bsize > BigInt(Number.MAX_SAFE_INTEGER) ? BigInt(Number.MAX_SAFE_INTEGER) : st.bavail * st.bsize) };
	}
	async unlink(p) {
		await this.check(p);
		this.profile.assertHeld();
		await (0, node_fs_promises.unlink)(this.name(p));
	}
	async removeEmpty(p) {
		if (!await this.exists(p)) return;
		await this.check(p);
		this.profile.assertHeld();
		await (0, node_fs_promises.rmdir)(this.name(p));
		if (this.durability === "file-and-directory-sync") await this.directorySync(node_path.default.dirname(this.name(p)));
	}
	async fault(point) {
		await this.at(point, async () => {});
	}
	async at(point, work) {
		await this.options.fault?.(point, "before");
		const value = await work();
		await this.options.fault?.(point, "after");
		return value;
	}
	async exists(p) {
		try {
			await this.check(p);
			return true;
		} catch (e) {
			if (e.code === "ENOENT") return false;
			throw e;
		}
	}
	async size(p) {
		await this.check(p);
		return (await (0, node_fs_promises.lstat)(this.name(p))).size;
	}
	async entries(p, maximum) {
		await this.check(p);
		const dir = await (0, node_fs_promises.opendir)(this.name(p)), entries = [];
		for await (const entry of dir) {
			if (entries.length === maximum) throw new Error("scan-limit");
			const name = node_path.default.join(this.name(p), entry.name), st = await (0, node_fs_promises.lstat)(name);
			if (st.isSymbolicLink() || !st.isFile() && !st.isDirectory() || st.isFile() && st.nlink !== 1 || await (0, node_fs_promises.realpath)(name) !== name) throw new Error("unsafe-path");
			entries.push({
				name: entry.name,
				directory: st.isDirectory(),
				bytes: st.size
			});
		}
		return entries;
	}
	async bytes(p, maximum) {
		const fd = await this.open(p, "read");
		try {
			const size = (await this.fd(fd).stat()).size;
			if (size > maximum) throw new Error("size-limit");
			const result = new Uint8Array(size);
			let offset = 0;
			while (offset < size) {
				const b = await this.read(fd, offset, Math.min(262144, size - offset));
				if (!b.length) throw new Error("corrupt");
				result.set(b, offset);
				offset += b.length;
			}
			if ((await this.fd(fd).stat()).size !== size) throw new Error("input-changed");
			return result;
		} finally {
			await this.close(fd);
		}
	}
};
var NativeOutput = class {
	profile;
	quota;
	now;
	fs;
	destinations = /* @__PURE__ */ new Map();
	jobs = /* @__PURE__ */ new Map();
	constructor(profile, quota, now, fs) {
		this.profile = profile;
		this.quota = quota;
		this.now = now;
		this.fs = fs;
	}
	async identity(name) {
		try {
			const s = await (0, node_fs_promises.lstat)(name, { bigint: true });
			if (s.isSymbolicLink() || !s.isFile() && !s.isDirectory() || s.isFile() && s.nlink !== 1n) throw new Error("unsafe-path");
			return `${s.dev}:${s.ino}`;
		} catch (e) {
			if (e.code === "ENOENT") return null;
			throw e;
		}
	}
	async check(d, checkDeadline = true) {
		this.profile.assertHeld();
		if (checkDeadline && this.now() >= d.deadline) throw new Error("stale");
		if (await (0, node_fs_promises.realpath)(d.parent) !== d.parent || await this.identity(d.parent) !== d.parentIdentity || await this.identity(d.name) !== d.leafIdentity) throw new Error("destination-changed");
	}
	async register(input) {
		this.profile.assertHeld();
		if (!node_path.default.isAbsolute(input.nativePath) || this.now() >= input.deadlineMonotonicMs) throw new Error("stale");
		const parent = node_path.default.dirname(input.nativePath);
		if (await (0, node_fs_promises.realpath)(parent) !== parent) throw new Error("unsafe-path");
		const parentIdentity = await this.identity(parent);
		if (!parentIdentity) throw new Error("destination-changed");
		const token = Object.freeze({});
		this.destinations.set(token, {
			action: input.action,
			scope: structuredClone(input.scope),
			name: input.nativePath,
			parent,
			parentIdentity,
			leafIdentity: await this.identity(input.nativePath),
			deadline: input.deadlineMonotonicMs,
			claimed: false
		});
		return token;
	}
	assertSettled() {
		if ([...this.jobs.values()].some((j) => j.outcome.disposition === "unknown")) throw new Error("publish-uncertain");
	}
	async release(token) {
		const d = this.destinations.get(token);
		if (!d) return;
		if ([...this.jobs.values()].some((j) => j.destination === d && j.outcome.disposition === "unknown")) return;
		for (const [id, j] of this.jobs) if (j.destination === d) {
			if (j.outcome.disposition !== "committed") await this.abort(id);
			this.jobs.delete(id);
		}
		this.destinations.delete(token);
	}
	async begin(id, owner, destination, bytes, sha256, deadline) {
		const d = this.destinations.get(destination);
		if (!d || d.scope.hostEpoch !== owner.hostEpoch || d.claimed || this.jobs.has(id) || !Number.isSafeInteger(bytes) || bytes < 0 || bytes > 8388608 || !/^[0-9a-f]{64}$/.test(sha256)) throw new Error("stale");
		d.deadline = Math.min(d.deadline, deadline);
		await this.check(d);
		const disk = await (0, node_fs_promises.statfs)(d.parent, { bigint: true });
		this.quota.reserve(id, owner.sourceKey, {
			bytes: 0,
			create: false,
			metadata: 0,
			lane: "export"
		}, Number(disk.bavail * disk.bsize));
		const temp = node_path.default.join(d.parent, `.kobrixa-${(0, node_crypto.randomUUID)()}.tmp`);
		try {
			this.quota.holdTemporary(owner.sourceKey, temp, bytes);
			const fd = await (0, node_fs_promises.open)(temp, node_fs.constants.O_CREAT | node_fs.constants.O_EXCL | node_fs.constants.O_RDWR | (node_fs.constants.O_NOFOLLOW ?? 0), 384);
			this.jobs.set(id, {
				destination: d,
				owner,
				temp,
				fd,
				size: bytes,
				sha256,
				offset: 0,
				hash: (0, node_crypto.createHash)("sha256"),
				last: null,
				outcome: { disposition: "not-committed" },
				dispatched: false
			});
			d.claimed = true;
		} catch (e) {
			this.quota.releaseTemporary(owner.sourceKey, temp);
			this.quota.release(id);
			throw e;
		}
	}
	job(id) {
		const j = this.jobs.get(id);
		if (!j) throw new Error("stale");
		return j;
	}
	async append(id, offset, bytes) {
		const j = this.job(id);
		await this.check(j.destination);
		if (j.dispatched || bytes.length < 1 || bytes.length > 262144) throw new Error("sealed");
		if (j.last?.offset === offset && Buffer.from(j.last.bytes).equals(Buffer.from(bytes))) return j.offset;
		if (offset !== j.offset || offset + bytes.length > j.size) throw new Error("offset-mismatch");
		let done = 0;
		while (done < bytes.length) {
			this.profile.assertHeld();
			const r = await j.fd.write(bytes, done, bytes.length - done, offset + done);
			if (!r.bytesWritten) throw new Error("io");
			done += r.bytesWritten;
		}
		j.hash.update(bytes);
		j.offset += bytes.length;
		j.last = {
			offset,
			bytes: Uint8Array.from(bytes)
		};
		return j.offset;
	}
	async commit(id) {
		const j = this.job(id);
		if (j.dispatched) return this.reconcile(id);
		if (j.offset !== j.size || j.hash.copy().digest("hex") !== j.sha256) throw new Error("incomplete");
		await j.fd.sync();
		await this.check(j.destination);
		const source = await j.fd.stat(), atPath = await (0, node_fs_promises.lstat)(j.temp);
		if (source.dev !== atPath.dev || source.ino !== atPath.ino) throw new Error("destination-changed");
		await this.fs.fault("before-publish");
		await this.check(j.destination);
		j.dispatched = true;
		j.outcome = { disposition: "unknown" };
		try {
			await (0, node_fs_promises.rename)(j.temp, j.destination.name);
			await this.fs.fault("after-publish");
			if (process.platform !== "win32") {
				const dir = await (0, node_fs_promises.open)(j.destination.parent, node_fs.constants.O_RDONLY);
				try {
					await dir.sync();
				} finally {
					await dir.close();
				}
			}
			j.outcome = {
				disposition: "committed",
				commitId: (0, node_crypto.randomUUID)(),
				durability: process.platform === "win32" ? "file-sync-only" : "file-and-directory-sync"
			};
			await j.fd.close();
			this.quota.releaseTemporary(j.owner.sourceKey, j.temp);
			this.quota.release(id);
			return j.outcome;
		} catch (e) {
			if (["EXDEV", "ENOTSUP"].includes(e.code ?? "")) {
				j.dispatched = false;
				j.outcome = { disposition: "not-committed" };
				throw new Error("unsupported-filesystem");
			}
			return j.outcome;
		}
	}
	async reconcile(id) {
		const j = this.job(id);
		if (j.outcome.disposition !== "unknown") return j.outcome;
		try {
			this.profile.assertHeld();
			if (await this.identity(j.destination.parent) !== j.destination.parentIdentity) return j.outcome;
			const current = await (0, node_fs_promises.open)(j.destination.name, node_fs.constants.O_RDONLY | (node_fs.constants.O_NOFOLLOW ?? 0));
			try {
				const original = await j.fd.stat(), actual = await current.stat();
				if (original.dev !== actual.dev || original.ino !== actual.ino || actual.size !== j.size) return j.outcome;
				const digest = (0, node_crypto.createHash)("sha256"), buffer = Buffer.allocUnsafe(262144);
				let offset = 0;
				while (offset < j.size) {
					const r = await current.read(buffer, 0, Math.min(buffer.length, j.size - offset), offset);
					if (!r.bytesRead) return j.outcome;
					digest.update(buffer.subarray(0, r.bytesRead));
					offset += r.bytesRead;
				}
				if (digest.digest("hex") !== j.sha256) return j.outcome;
				await j.fd.sync();
				if (process.platform !== "win32") {
					const dir = await (0, node_fs_promises.open)(j.destination.parent, node_fs.constants.O_RDONLY);
					try {
						await dir.sync();
					} finally {
						await dir.close();
					}
				}
				j.outcome = {
					disposition: "committed",
					commitId: (0, node_crypto.randomUUID)(),
					durability: process.platform === "win32" ? "file-sync-only" : "file-and-directory-sync"
				};
				await j.fd.close();
				this.quota.releaseTemporary(j.owner.sourceKey, j.temp);
				this.quota.release(id);
				return j.outcome;
			} finally {
				await current.close();
			}
		} catch {
			return j.outcome;
		}
	}
	async abort(id) {
		const j = this.job(id);
		if (j.dispatched) return (await this.reconcile(id)).disposition === "committed" ? "committed" : "unknown";
		this.profile.assertHeld();
		await j.fd.close();
		await (0, node_fs_promises.unlink)(j.temp);
		this.quota.releaseTemporary(j.owner.sourceKey, j.temp);
		this.quota.release(id);
		this.jobs.delete(id);
		return "aborted";
	}
};
//#endregion
//#region packages/plugin-protocol/src/persistence-validation.ts
function validateSettingsResource(input, rawBytes) {
	if (!Number.isSafeInteger(rawBytes) || rawBytes < 0 || rawBytes > 65536) throw new PersistenceValidationError("size-limit");
	const parsed = settingsResourceV1Schema$1.safeParse(input);
	if (!parsed.success) throw new PersistenceValidationError("invalid-resource");
	const resource = parsed.data;
	if (new Set(resource.fields.map((f) => f.key)).size !== resource.fields.length) throw new PersistenceValidationError("duplicate-key");
	const fields = new Map(resource.fields.map((f) => [f.key, f]));
	for (const f of resource.fields) {
		if (f.resetWhen) {
			const controller = fields.get(f.resetWhen.key);
			if (f.resetWhen.key === f.key || !controller || controller.type !== "boolean" || controller.resetWhen) throw new PersistenceValidationError("invalid-resource");
		}
		if ((f.type === "number" || f.type === "integer") && f.minimum > f.maximum) throw new PersistenceValidationError("invalid-resource");
		if (f.type === "string" && f.minLength > f.maxLength) throw new PersistenceValidationError("invalid-resource");
		if (f.type === "enum" && new Set(f.options.map((o) => JSON.stringify([typeof o.value, o.value]))).size !== f.options.length) throw new PersistenceValidationError("duplicate-key");
	}
	validateSettingsValues(resource, resource.fields.map((f) => ({
		key: f.key,
		value: f.default
	})), true);
	return resource;
}
//#endregion
//#region apps/desktop/src/main/plugins/persistence/namespace.ts
var scopedPaths = /* @__PURE__ */ new WeakMap();
function createStorePath(fs, parts) {
	if (parts.some((p) => !p || p === "." || p === ".." || /[\\/:\0]/.test(p))) throw new Error("unsafe-path");
	let paths = scopedPaths.get(fs);
	if (!paths) {
		paths = /* @__PURE__ */ new WeakMap();
		scopedPaths.set(fs, paths);
	}
	const token = Object.freeze({});
	paths.set(token, node_path.default.join(fs.root, ...parts));
	return token;
}
function storePathName(fs, p) {
	const name = scopedPaths.get(fs)?.get(p);
	if (!name) throw new Error("unsafe-path");
	return name;
}
var h = string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
var r = string().regex(/^r_[0-9a-f]{32}$/);
var hash = string().regex(/^[0-9a-f]{64}$/);
var n = number().int().min(0).max(Number.MAX_SAFE_INTEGER);
var v = n.min(1).max(2147483647);
var key = string().min(1).refine((s) => Buffer.byteLength(s) <= 128 && !s.includes("\0"));
var record = strictObject({
	id: h,
	revision: r,
	kind: string().regex(/^[a-z][a-z0-9.-]{0,63}$/),
	schemaVersion: v,
	label: string().refine((s) => [...s].length <= 160 && Buffer.byteLength(s) <= 640 && !/[\u0000-\u001f\u007f]/.test(s)),
	mediaType: _enum([
		"application/json",
		"text/plain",
		"text/csv",
		"application/octet-stream"
	]),
	byteLength: n.max(8388608),
	sha256: hash,
	createdAt: n,
	updatedAt: n,
	checkpoint: _enum([
		"none",
		"open",
		"final"
	]),
	interrupted: boolean()
});
var metadata$3 = union([
	strictObject({
		kind: literal("settings"),
		schemaVersion: v,
		validationDigest: hash
	}),
	strictObject({
		kind: literal("record"),
		record,
		deleted: boolean()
	}),
	strictObject({
		kind: _enum(["import", "recovery"]),
		key
	})
]);
var target = union([
	strictObject({
		kind: literal("settings"),
		expectedRevision: r.nullable()
	}),
	strictObject({
		kind: literal("record"),
		id: h,
		expectedRevision: r.nullable()
	}),
	strictObject({
		kind: _enum(["import", "recovery"]),
		key
	})
]);
var importTagSchema = strictObject({
	importId: key,
	itemKey: key,
	sourceSha256: hash
}).refine((t) => Buffer.byteLength(JSON.stringify(t)) <= 256);
var persistenceOwnerSchema = strictObject({
	sourceKey: string().min(1).max(160),
	pluginId: string().min(1),
	generation: n,
	hostEpoch: h,
	processEpoch: h
});
var publicationTicketSchema = strictObject({
	id: h,
	owner: persistenceOwnerSchema,
	deadlineMonotonicMs: number().min(0).max(Number.MAX_SAFE_INTEGER),
	metadata: metadata$3,
	target
});
var legacyPreferencesEvidenceRefSchema = strictObject({
	nonce: h,
	digest: hash
});
function sameImportValue(a, b) {
	if (a === b) return true;
	if (a === null || b === null || typeof a !== "object" || typeof b !== "object") return false;
	if (Array.isArray(a) || Array.isArray(b)) return Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((value, index) => sameImportValue(value, b[index]));
	const left = Object.entries(a), right = Object.entries(b);
	return left.length === right.length && left.every(([key, value]) => Object.prototype.hasOwnProperty.call(b, key) && sameImportValue(value, Reflect.get(b, key)));
}
function sameImportAttempt(original, attempt) {
	return sameImportValue(original.metadata, attempt.metadata) && sameImportValue(original.target, attempt.target) && original.owner.sourceKey === attempt.owner.sourceKey && original.owner.pluginId === attempt.owner.pluginId;
}
var originalBase64 = string().max(87384).refine((value) => {
	const bytes = Buffer.from(value, "base64");
	return bytes.length <= 65536 && bytes.toString("base64") === value;
});
var devicePreferencesEvidenceSchema = strictObject({
	formatVersion: literal(1),
	defaultedKeys: array(string().regex(/^[a-zA-Z][a-zA-Z0-9]*$/).max(64)).max(9).refine((keys) => keys.every((key, i) => i === 0 || keys[i - 1] < key)),
	device: union([strictObject({ state: literal("absent") }), strictObject({
		state: literal("present"),
		base64: originalBase64,
		sha256: hash
	})]),
	renderer: strictObject({
		nonce: h,
		digest: hash,
		base64: originalBase64
	})
}).refine((e) => {
	if (e.device.state === "present" && (0, node_crypto.createHash)("sha256").update(Buffer.from(e.device.base64, "base64")).digest("hex") !== e.device.sha256) return false;
	if ((0, node_crypto.createHash)("sha256").update(Buffer.from(e.renderer.base64, "base64")).digest("hex") !== e.renderer.digest) return false;
	try {
		return JSON.parse(Buffer.from(e.renderer.base64, "base64").toString("utf8")).nonce === e.renderer.nonce;
	} catch {
		return false;
	}
});
/** Canonical property order is shared by the worker and durable plan verifier. */
function devicePreferencesEvidenceBytes(value) {
	return Buffer.from(JSON.stringify(devicePreferencesEvidenceSchema.parse(value)));
}
var importPlanSchema = strictObject({
	formatVersion: literal(1),
	id: key,
	descriptorId: key,
	mappingVersion: v,
	targetSourceKey: string().min(1).max(160),
	preferencesEvidence: legacyPreferencesEvidenceRefSchema.nullable(),
	devicePreferencesEvidence: devicePreferencesEvidenceSchema.exactOptional(),
	items: array(strictObject({
		key,
		sourceFormat: v,
		sourceSha256: hash,
		mappedSha256: hash,
		byteLength: n.max(8388608),
		ticket: publicationTicketSchema,
		tag: importTagSchema
	})).max(512)
}).superRefine((plan, ctx) => {
	const combined = plan.devicePreferencesEvidence;
	if (combined && (plan.descriptorId !== "kobrixa.device-preferences" || plan.targetSourceKey !== "builtin:kobrixa.device-ev3" || plan.mappingVersion !== 1 || plan.items.length !== 1 || plan.items[0]?.key !== "preferences" || plan.items[0]?.sourceFormat !== 1 || plan.items[0]?.ticket.target.kind !== "settings" || plan.items[0]?.ticket.target.expectedRevision !== null || !sameImportValue(plan.preferencesEvidence, {
		nonce: combined.renderer.nonce,
		digest: combined.renderer.digest
	}) || plan.items[0]?.sourceSha256 !== (0, node_crypto.createHash)("sha256").update(devicePreferencesEvidenceBytes(combined)).digest("hex"))) ctx.addIssue({
		code: "custom",
		message: "combined-evidence-binding"
	});
	if (plan.descriptorId === "kobrixa.device-preferences" && !combined) ctx.addIssue({
		code: "custom",
		message: "missing-combined-evidence"
	});
	const expectedId = "import/" + (0, node_crypto.createHash)("sha256").update(JSON.stringify([plan.descriptorId, plan.targetSourceKey]), "utf8").digest("hex");
	const ids = plan.items.flatMap((item) => item.ticket.target.kind === "record" ? [item.ticket.target.id] : ["settings"]);
	if (plan.id !== expectedId || new Set(ids).size !== ids.length || new Set(plan.items.map((i) => i.key)).size !== plan.items.length || new Set(plan.items.map((i) => i.ticket.id)).size !== plan.items.length || Buffer.byteLength(JSON.stringify(plan)) > 2097152 || plan.items.some((i) => i.tag.importId !== plan.id || i.tag.itemKey !== i.key || i.sourceSha256 !== i.tag.sourceSha256 || i.ticket.owner.sourceKey !== plan.targetSourceKey || i.ticket.metadata.kind !== i.ticket.target.kind || i.ticket.metadata.kind !== "settings" && i.ticket.metadata.kind !== "record" || i.ticket.metadata.kind === "record" && (i.ticket.metadata.deleted || i.ticket.target.kind !== "record" || i.ticket.metadata.record.id !== i.ticket.target.id || i.ticket.metadata.record.byteLength !== i.byteLength || i.ticket.metadata.record.sha256 !== i.mappedSha256))) ctx.addIssue({
		code: "custom",
		message: "input-changed"
	});
});
var receipt = strictObject({
	revision: r,
	commitId: h,
	durability: _enum(["file-and-directory-sync", "file-sync-only"])
});
var importItemEvidenceSchema = strictObject({
	key,
	state: _enum([
		"pending",
		"committed",
		"skipped",
		"unknown"
	]),
	receipt: receipt.nullable(),
	skipReason: string().refine((s) => Buffer.byteLength(s) <= 256).nullable(),
	publicationTicket: publicationTicketSchema.nullable()
}).refine((e) => {
	if (e.state === "committed") return e.receipt !== null && e.publicationTicket !== null && e.skipReason === null && e.receipt.commitId === e.publicationTicket.id && (e.publicationTicket.metadata.kind !== "record" || e.receipt.revision === e.publicationTicket.metadata.record.revision);
	if (e.state === "skipped") return !!e.skipReason && e.receipt === null;
	return e.receipt === null && e.skipReason === null && (e.state !== "unknown" || e.publicationTicket !== null);
});
var importDocumentSchema = strictObject({
	formatVersion: literal(1),
	plan: importPlanSchema,
	items: array(importItemEvidenceSchema).max(512),
	complete: boolean()
}).refine((d) => Buffer.byteLength(JSON.stringify(d)) <= 2097152 && d.items.length === d.plan.items.length && new Set(d.items.map((e) => e.key)).size === d.items.length && d.items.every((e, i) => e.key === d.plan.items[i]?.key && (e.publicationTicket === null || sameImportAttempt(d.plan.items[i].ticket, e.publicationTicket))) && (!d.plan.devicePreferencesEvidence || d.items.every((e) => e.state !== "skipped")) && (!d.complete || d.items.every((e) => e.state === "committed" || e.state === "skipped")));
var storedRecoverySchema = strictObject({
	id: h,
	owner: persistenceOwnerSchema,
	report: strictObject({
		state: _enum([
			"saved",
			"retryable",
			"checkpoint-only",
			"uncertain"
		]),
		blocker: boolean(),
		recovery: h.exactOptional(),
		retryAction: h.exactOptional(),
		pendingSettings: boolean(),
		records: array(strictObject({
			id: h,
			committedRevision: r.nullable(),
			final: boolean(),
			payload: _enum([
				"complete-staging",
				"checkpoint-only",
				"none"
			]),
			expiresAt: n.exactOptional()
		})).max(2),
		errors: array(persistenceErrorSchema$1).max(16)
	}),
	ticket: publicationTicketSchema.nullable(),
	sealedPin: h.nullable(),
	expiresAt: n.nullable()
});
var persistenceBarrierSchema = strictObject({
	id: h,
	scope: union([strictObject({
		kind: literal("namespace"),
		owner: persistenceOwnerSchema
	}), strictObject({
		kind: literal("target"),
		owner: persistenceOwnerSchema,
		recordId: h
	})]),
	through: n,
	deadlineMonotonicMs: number().min(0).max(Number.MAX_SAFE_INTEGER)
});
var diskHeadSchema = strictObject({
	formatVersion: literal(1),
	metadata: metadata$3,
	target,
	object: string().regex(/^r_[0-9a-f]{32}\.(?:bin|json)$/).nullable(),
	byteLength: n.max(8388608),
	sha256: hash,
	receipt: strictObject({
		revision: r,
		commitId: h,
		durability: _enum(["file-and-directory-sync", "file-sync-only"])
	}),
	importTag: importTagSchema.optional()
});
function parseHead(bytes) {
	if (bytes.length > 8192) throw new Error("corrupt");
	let raw;
	try {
		raw = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
	} catch {
		throw new Error("corrupt");
	}
	if (typeof raw === "object" && raw !== null && "formatVersion" in raw && raw.formatVersion !== 1) throw new Error("unsupported-format");
	const parsed = diskHeadSchema.safeParse(raw);
	if (!parsed.success) throw new Error("corrupt");
	const head = parsed.data;
	if (head.metadata.kind === "record" && head.metadata.deleted && (head.object !== null || head.byteLength !== 0) || head.metadata.kind !== head.target.kind || head.metadata.kind === "record" && (head.target.kind !== "record" || head.metadata.record.id !== head.target.id || head.metadata.record.revision !== head.receipt.revision || !head.metadata.deleted && (head.metadata.record.sha256 !== head.sha256 || head.metadata.record.byteLength !== head.byteLength)) || head.object !== null && !head.object.startsWith(head.receipt.revision + ".")) throw new Error("corrupt");
	return head;
}
var Namespace = class Namespace {
	fs;
	sourceKey;
	hash;
	constructor(fs, sourceKey) {
		this.fs = fs;
		this.sourceKey = sourceKey;
		this.hash = (0, node_crypto.createHash)("sha256").update(sourceKey).digest("hex");
	}
	path(...parts) {
		return this.fs.path("namespaces", this.hash, ...parts);
	}
	static async open(fs, sourceKey) {
		if (!sourceKey || sourceKey.length > 160 || sourceKey.includes("\0")) throw new Error("identity-mismatch");
		const ns = new Namespace(fs, sourceKey), identity = ns.path("identity.json");
		if (!await fs.exists(ns.path())) {
			await fs.mkdir(ns.path());
			await ns.writeNew(identity, {
				formatVersion: 1,
				sourceKey
			});
			await fs.syncDirectory(ns.path());
		} else if (!await fs.exists(identity)) throw new Error("identity-mismatch");
		const data = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(await fs.bytes(identity, 4096)));
		if (data.formatVersion !== 1) throw new Error("unsupported-format");
		if (data.sourceKey !== sourceKey || Object.keys(data).sort().join(",") !== "formatVersion,sourceKey") throw new Error("identity-mismatch");
		for (const name of [
			"settings",
			"records",
			"staging",
			"imports",
			"recovery",
			"quarantine"
		]) await fs.mkdir(ns.path(name));
		return ns;
	}
	async writeNew(p, value) {
		const bytes = Buffer.from(JSON.stringify(value));
		const fd = await this.fs.open(p, "create-exclusive");
		try {
			await writeAll(this.fs, fd, 0, bytes);
			await this.fs.sync(fd);
		} finally {
			await this.fs.close(fd);
		}
	}
	async location(t, create = false) {
		let parts, name;
		if (t.kind === "settings") {
			parts = ["settings"];
			name = "head.json";
		} else if (t.kind === "record") {
			h.parse(t.id);
			parts = ["records", t.id];
			name = "head.json";
		} else {
			key.parse(t.key);
			parts = [t.kind === "import" ? "imports" : "recovery"];
			name = (0, node_crypto.createHash)("sha256").update(t.key).digest("hex") + ".json";
		}
		if (create) {
			await this.fs.mkdir(this.path(...parts));
			await this.fs.mkdir(this.path(...parts, "objects"));
		}
		return {
			directory: this.path(...parts),
			head: this.path(...parts, name),
			previous: this.path(...parts, name === "head.json" ? "head.previous" : name + ".previous"),
			objects: this.path(...parts, "objects"),
			parts,
			name
		};
	}
	object(location, head) {
		if (!head.object) throw new Error("not-found");
		return this.path(...location.parts, "objects", head.object);
	}
	async head(location) {
		return await this.fs.exists(location.head) ? parseHead(await this.fs.bytes(location.head, 8192)) : null;
	}
	async verify(location, head) {
		if (head.object === null) {
			if (head.metadata.kind !== "record" || !head.metadata.deleted) throw new Error("corrupt");
			return;
		}
		const object = this.object(location, head), fd = await this.fs.open(object, "read"), digest = (0, node_crypto.createHash)("sha256");
		let offset = 0;
		try {
			if (await this.fs.size(object) !== head.byteLength) throw new Error("corrupt");
			while (offset < head.byteLength) {
				const bytes = await this.fs.read(fd, offset, Math.min(262144, head.byteLength - offset));
				if (!bytes.length) throw new Error("corrupt");
				digest.update(bytes);
				offset += bytes.length;
			}
			if (digest.digest("hex") !== head.sha256) throw new Error("corrupt");
		} finally {
			await this.fs.close(fd);
		}
	}
	async locations() {
		const result = [await this.location({
			kind: "settings",
			expectedRevision: null
		})];
		for (const entry of await this.fs.entries(this.path("records"), 4096)) {
			if (!entry.directory || !h.safeParse(entry.name).success) throw new Error("corrupt");
			result.push(await this.location({
				kind: "record",
				id: entry.name,
				expectedRevision: null
			}));
		}
		for (const kind of ["import", "recovery"]) for (const entry of await this.fs.entries(this.path(kind === "import" ? "imports" : "recovery"), 4096)) if (!entry.directory && entry.name.endsWith(".json")) {
			const head = parseHead(await this.fs.bytes(this.path(kind === "import" ? "imports" : "recovery", entry.name), 8192));
			if (head.target.kind !== kind || !("key" in head.target)) throw new Error("corrupt");
			const loc = await this.location(head.target);
			if (loc.name !== entry.name) throw new Error("identity-mismatch");
			result.push(loc);
		}
		return result;
	}
	async inventory() {
		const result = [];
		let count = 0;
		const walk = async (parts, depth) => {
			if (depth > 6) throw new Error("scan-limit");
			for (const entry of await this.fs.entries(this.path(...parts), 4096 - count)) {
				if (++count > 4096) throw new Error("scan-limit");
				const next = [...parts, entry.name];
				if (entry.directory) await walk(next, depth + 1);
				else result.push({
					path: this.path(...next),
					relative: next.join("/"),
					bytes: entry.bytes
				});
			}
		};
		await walk([], 0);
		return result;
	}
	async quarantine(p) {
		await this.fs.atomicReplace(p, this.path("quarantine", (0, node_crypto.randomUUID)() + ".evidence"));
		await this.fs.syncDirectory(this.path("quarantine"));
	}
};
var liveRecord = (head) => head?.metadata.kind === "record" && !head.metadata.deleted ? head.metadata.record : null;
//#endregion
//#region apps/desktop/src/main/plugins/persistence/import-sources.ts
var IMPORT_LIMITS = Object.freeze({
	candidateNames: 4096,
	items: 512,
	journalBytes: 2097152,
	batch: 64,
	recordBytes: 8388608,
	preferenceBytes: 65536,
	preferenceKeys: 128
});
var canonicalHandle = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
function snapshotBytes(snapshot, allowlist) {
	const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
	if (!object(snapshot) || Object.keys(snapshot).sort().join(",") !== "entries,nonce,scope" || typeof snapshot.nonce !== "string" || !canonicalHandle.test(snapshot.nonce) || !object(snapshot.scope) || Object.keys(snapshot.scope).sort().join(",") !== "hostEpoch,workbenchInstance" || typeof snapshot.scope.hostEpoch !== "string" || !canonicalHandle.test(snapshot.scope.hostEpoch) || typeof snapshot.scope.workbenchInstance !== "string" || !canonicalHandle.test(snapshot.scope.workbenchInstance) || !Array.isArray(snapshot.entries) || !Array.isArray(allowlist) || allowlist.some((key) => typeof key !== "string" || !key || Buffer.byteLength(key) > 128)) throw new Error("snapshot-shape");
	if (allowlist.length > IMPORT_LIMITS.preferenceKeys || snapshot.entries.length > IMPORT_LIMITS.preferenceKeys) throw new Error("snapshot-limit");
	const allowed = new Set(allowlist), seen = /* @__PURE__ */ new Set();
	if (allowed.size !== allowlist.length || snapshot.entries.length !== allowed.size) throw new Error("snapshot-keys");
	for (const entry of snapshot.entries) {
		if (!object(entry) || Object.keys(entry).sort().join(",") !== "key,raw" || typeof entry.key !== "string" || !allowed.has(entry.key) || seen.has(entry.key) || entry.raw !== null && typeof entry.raw !== "string") throw new Error("snapshot-keys");
		seen.add(entry.key);
	}
	const copy = {
		nonce: snapshot.nonce,
		scope: {
			hostEpoch: snapshot.scope.hostEpoch,
			workbenchInstance: snapshot.scope.workbenchInstance
		},
		entries: snapshot.entries.map((entry) => ({
			key: entry.key,
			raw: entry.raw
		}))
	};
	const bytes = new TextEncoder().encode(JSON.stringify(copy));
	if (bytes.byteLength > IMPORT_LIMITS.preferenceBytes) throw new Error("snapshot-limit");
	return bytes;
}
var sameScope = (a, b) => a.hostEpoch === b.hostEpoch && a.workbenchInstance === b.workbenchInstance;
var sha256$2 = (bytes) => (0, node_crypto.createHash)("sha256").update(bytes).digest("hex");
function importIdFor(descriptorId, sourceKey) {
	return "import/" + sha256$2(new TextEncoder().encode(JSON.stringify([descriptorId, sourceKey])));
}
function barrierKeyFor(descriptorId) {
	return "barrier/" + sha256$2(new TextEncoder().encode(descriptorId));
}
function snapshotDigest(snapshot, allowlist) {
	return sha256$2(snapshotBytes(snapshot, allowlist));
}
var boundedId = string().min(1).refine((value) => Buffer.byteLength(value) <= 128 && !value.includes("\0"));
var descriptorIdSchema = boundedId.refine((value) => /^[a-z][a-z0-9-]*(?:[.:][a-z0-9-]+)+$/.test(value));
var handleSchema$2 = string().regex(canonicalHandle);
var scopeSchema = strictObject({
	hostEpoch: handleSchema$2,
	workbenchInstance: handleSchema$2
});
var rawSchema = strictObject({
	nonce: handleSchema$2,
	scope: scopeSchema,
	entries: array(strictObject({
		key: boundedId,
		raw: string().nullable()
	})).max(128)
});
var commonAuxiliary = {
	formatVersion: literal(1),
	descriptorId: descriptorIdSchema,
	sourceKey: string().min(1).max(160),
	originalTicket: publicationTicketSchema,
	ticket: publicationTicketSchema
};
var nonceSchema = strictObject({
	...commonAuxiliary,
	kind: literal("nonce"),
	nonce: handleSchema$2,
	scope: scopeSchema,
	allowlist: array(boundedId).max(128),
	state: _enum(["issued", "consumed"]),
	raw: rawSchema.nullable(),
	digest: string().regex(/^[0-9a-f]{64}$/).nullable()
});
var barrierSchema = strictObject({
	...commonAuxiliary,
	kind: literal("barrier"),
	barrier: handleSchema$2,
	state: _enum(["active", "complete"])
});
function decodeAuxiliary(bytes) {
	if (bytes.byteLength > IMPORT_LIMITS.journalBytes) throw new Error("size-limit");
	return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
}
function checkAuxiliaryTickets(document, key) {
	if (document.originalTicket.id === document.ticket.id && !sameImportValue(document.originalTicket, document.ticket)) throw new Error("evidence-binding");
	for (const ticket of [document.originalTicket, document.ticket]) if (ticket.owner.sourceKey !== document.sourceKey || ticket.owner.pluginId !== document.originalTicket.owner.pluginId || ticket.metadata.kind !== "import" || ticket.metadata.key !== key || ticket.target.kind !== "import" || ticket.target.key !== key) throw new Error("evidence-binding");
}
function parseNonceDocument(bytes) {
	const document = nonceSchema.parse(decodeAuxiliary(bytes));
	checkAuxiliaryTickets(document, "nonce/" + document.nonce);
	if (new Set(document.allowlist).size !== document.allowlist.length || document.raw === null !== (document.digest === null) || document.state === "consumed" && document.raw === null || document.originalTicket.owner.hostEpoch !== document.scope.hostEpoch) throw new Error("evidence-binding");
	if (document.raw && (document.raw.nonce !== document.nonce || !sameScope(document.raw.scope, document.scope) || snapshotDigest(document.raw, document.allowlist) !== document.digest)) throw new Error("evidence-binding");
	if (document.raw === null && !sameImportValue(document.originalTicket, document.ticket)) throw new Error("evidence-binding");
	return structuredClone(document);
}
function parseBarrierDocument(bytes) {
	const document = barrierSchema.parse(decodeAuxiliary(bytes));
	checkAuxiliaryTickets(document, barrierKeyFor(document.descriptorId));
	if (document.state === "active" && document.originalTicket.id === document.ticket.id && !sameImportValue(document.originalTicket, document.ticket)) throw new Error("evidence-binding");
	return structuredClone(document);
}
//#endregion
//#region apps/desktop/src/shared/device-preferences.ts
var USB_RETRY_INTERVALS = [
	"backoff",
	1e3,
	2e3,
	5e3,
	1e4
];
var USB_RETRY_LIMITS = [
	"unlimited",
	3,
	5,
	10
];
var WIFI_CONNECT_TIMEOUTS = [
	3e3,
	5e3,
	1e4,
	3e4
];
var WIFI_HANDSHAKE_TIMEOUTS = [
	1e3,
	3e3,
	5e3,
	1e4
];
var DEFAULT_DEVICE_PREFERENCES = {
	skipUnchangedAssets: true,
	usbAutoReconnect: true,
	usbRetryInterval: "backoff",
	usbRetryLimit: "unlimited",
	wifiConnectTimeout: 5e3,
	wifiHandshakeTimeout: 3e3
};
//#endregion
//#region apps/desktop/src/main/plugins/persistence/device-preferences-port.ts
var DEVICE_PREFERENCES_SOURCE = "builtin:kobrixa.device-ev3";
function choice(key, value, options) {
	return {
		key,
		label: { en: key },
		type: "enum",
		default: value,
		options: options.map((value) => ({
			value,
			label: { en: String(value) }
		}))
	};
}
var expected = {
	schemaVersion: 1,
	title: { en: "Device preferences" },
	fields: [
		{
			key: "skipUnchangedAssets",
			label: { en: "Skip unchanged assets" },
			type: "boolean",
			default: DEFAULT_DEVICE_PREFERENCES.skipUnchangedAssets
		},
		{
			key: "usbAutoReconnect",
			label: { en: "USB auto reconnect" },
			type: "boolean",
			default: DEFAULT_DEVICE_PREFERENCES.usbAutoReconnect
		},
		choice("usbRetryInterval", DEFAULT_DEVICE_PREFERENCES.usbRetryInterval, USB_RETRY_INTERVALS),
		choice("usbRetryLimit", DEFAULT_DEVICE_PREFERENCES.usbRetryLimit, USB_RETRY_LIMITS),
		choice("wifiConnectTimeout", DEFAULT_DEVICE_PREFERENCES.wifiConnectTimeout, WIFI_CONNECT_TIMEOUTS),
		choice("wifiHandshakeTimeout", DEFAULT_DEVICE_PREFERENCES.wifiHandshakeTimeout, WIFI_HANDSHAKE_TIMEOUTS),
		choice("connectionMode", "usb", ["usb", "wifi"]),
		{
			key: "rememberWifiAddress",
			label: { en: "Remember Wi-Fi address" },
			type: "boolean",
			default: false
		},
		{
			key: "lastWifiAddress",
			resetWhen: {
				key: "rememberWifiAddress",
				equals: false
			},
			label: { en: "Last Wi-Fi address" },
			type: "string",
			default: "",
			minLength: 0,
			maxLength: 45,
			maxBytes: 180
		}
	]
};
var devicePreferencesResource = validateSettingsResource(expected, Buffer.byteLength(JSON.stringify(expected)));
function devicePreferenceValues(snapshot) {
	if (snapshot.schemaVersion !== 1) throw new Error("Unsupported device preferences schema.");
	const values = validateSettingsValues(devicePreferencesResource, snapshot.values, true);
	return Object.fromEntries(values.map(({ key, value }) => [key, value]));
}
//#endregion
//#region apps/desktop/src/main/plugins/persistence/device-settings-import.ts
var DEVICE_RENDERER_KEYS = Object.freeze([
	"kobrixa.connectionMode",
	"kobrixa.rememberWifiAddress",
	"kobrixa.lastWifiAddress"
]);
var providerKeys = new Set(devicePreferencesResource.fields.slice(0, 6).map((field) => field.key));
var sha256$1 = (bytes) => (0, node_crypto.createHash)("sha256").update(bytes).digest("hex");
function decode$1(input, kind) {
	if (input.sourceKind !== kind || input.bytes.length > IMPORT_LIMITS.preferenceBytes || sha256$1(input.bytes) !== input.sha256) throw new Error("invalid-source-evidence");
	return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(input.bytes));
}
/** Pure full-candidate mapping; authority and original evidence are worker-owned. */
function mapDeviceSettingsSnapshot(input) {
	const values = new Map(devicePreferencesResource.fields.map((field) => [field.key, field.default]));
	const defaulted = new Set(values.keys());
	if (input.device.state === "present") {
		if (input.device.original.file?.basename !== "device-settings.json") throw new Error("invalid-source-file");
		const raw = decode$1(input.device.original, "device-settings");
		if (!raw || typeof raw !== "object" || Array.isArray(raw) || Object.keys(raw).some((key) => !providerKeys.has(key))) throw new Error("invalid-device-settings");
		for (const { key, value } of validateSettingsValues(devicePreferencesResource, Object.entries(raw).map(([key, value]) => ({
			key,
			value
		})), false)) {
			values.set(key, value);
			defaulted.delete(key);
		}
	}
	const snapshot = decode$1(input.renderer, "renderer-preferences");
	if (!Buffer.from(snapshotBytes(snapshot, DEVICE_RENDERER_KEYS)).equals(input.renderer.bytes)) throw new Error("noncanonical-renderer-evidence");
	for (const { key, raw } of snapshot.entries) {
		if (raw === null) continue;
		const target = key.slice(8);
		let value = raw;
		if (target === "rememberWifiAddress") {
			if (raw !== "true" && raw !== "false") throw new Error("invalid-renderer-preference");
			value = raw === "true";
		}
		values.set(target, value);
		defaulted.delete(target);
	}
	const merged = normalizeSettingsValues(devicePreferencesResource, [...values].map(([key, value]) => ({
		key,
		value
	}))).sort((a, b) => a.key < b.key ? -1 : 1);
	devicePreferenceValues({
		schemaVersion: 1,
		revision: null,
		values: merged
	});
	return {
		item: {
			kind: "settings",
			schemaVersion: 1,
			values: merged
		},
		defaultedKeys: [...defaulted].sort(),
		originals: {
			deviceSha256: input.device.state === "present" ? input.device.original.sha256 : null,
			rendererSha256: input.renderer.sha256,
			rendererNonce: snapshot.nonce
		}
	};
}
var DEVICE_IMPORT_ID = "kobrixa.device-preferences";
var deviceImportSettingsAuthority = Object.freeze({
	schemaVersion: 1,
	validationDigest: sha256$1(Buffer.from(settingsValidationText(devicePreferencesResource)))
});
function mapCombined(input) {
	if (input.sourceKind !== "renderer-preferences" || input.bytes.length > 196608 || sha256$1(input.bytes) !== input.sha256) throw new Error("invalid-source-evidence");
	const raw = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(input.bytes));
	const evidence = devicePreferencesEvidenceSchema.parse(raw);
	if (!devicePreferencesEvidenceBytes(evidence).equals(input.bytes)) throw new Error("noncanonical-combined-evidence");
	const mapped = mapDeviceSettingsSnapshot({
		device: evidence.device.state === "absent" ? { state: "absent" } : {
			state: "present",
			original: {
				sourceKind: "device-settings",
				bytes: Buffer.from(evidence.device.base64, "base64"),
				sha256: evidence.device.sha256,
				file: { basename: "device-settings.json" }
			}
		},
		renderer: {
			sourceKind: "renderer-preferences",
			bytes: Buffer.from(evidence.renderer.base64, "base64"),
			sha256: evidence.renderer.digest
		}
	});
	if (JSON.stringify(mapped.defaultedKeys) !== JSON.stringify(evidence.defaultedKeys)) throw new Error("default-evidence-binding");
	return mapped.item;
}
Object.freeze({
	id: DEVICE_IMPORT_ID,
	mappingVersion: 1,
	targetSourceKey: DEVICE_PREFERENCES_SOURCE,
	sourceKind: "renderer-preferences",
	combinedSource: "device-preferences-v1",
	sourceFormatVersions: [1],
	targetSettingsSchemaVersion: 1,
	targetRecordSchemaVersions: [],
	rendererKeyAllowlist: DEVICE_RENDERER_KEYS,
	validate(input) {
		try {
			mapCombined(input);
			return true;
		} catch {
			return false;
		}
	},
	map: mapCombined
});
//#endregion
//#region plugins/sensor-lab/src/model/calibration.ts
var f = Math.fround;
function scale(c) {
	return f(f(f(c.targetB) - f(c.targetA)) / f(f(c.sourceB) - f(c.sourceA)));
}
/** Stable error keys, translated by the UI. Matches the EV3's float32 arithmetic. */
function validateCalibration(c) {
	if (typeof c.unit !== "string" || c.unit.length > 32 || [...c.unit].some((char) => char.charCodeAt(0) < 32 || char.charCodeAt(0) === 127)) return "invalidUnit";
	const values = [
		c.sourceA,
		c.sourceB,
		c.targetA,
		c.targetB,
		c.zeroOffset
	];
	if (values.some((value) => !Number.isFinite(value))) return "nonFinite";
	if (values.some((value) => !Number.isFinite(f(value)) || value !== 0 && f(value) === 0)) return "float32Range";
	if (c.twoPoint) {
		if (f(c.sourceA) === f(c.sourceB)) return "sameSource";
		const sourceSpan = f(f(c.sourceB) - f(c.sourceA));
		const targetSpan = f(f(c.targetB) - f(c.targetA));
		const slope = scale(c);
		if (![
			sourceSpan,
			targetSpan,
			slope,
			f(sourceSpan * targetSpan)
		].every(Number.isFinite) || c.targetA !== c.targetB && (targetSpan === 0 || slope === 0) || !Number.isFinite(f(f(c.targetA) - f(c.zeroOffset))) || !Number.isFinite(f(f(c.targetB) - f(c.zeroOffset)))) return "float32Range";
	}
}
//#endregion
//#region plugins/sensor-lab/src/model/data.ts
var LIMITS = {
	channels: 4,
	durationMs: 18e5,
	frames: 3600,
	recordings: 50,
	checkpointMs: 5e3,
	previewMs: 6e4,
	previewFrames: 240,
	seriesPerChart: 2,
	pointsPerSeries: 800,
	charts: 4,
	totalPoints: 6400,
	tableRows: 50,
	dialogs: 1
};
var ModelError = class extends Error {
	path;
	code;
	constructor(path, code) {
		super(`${path}: ${code}`);
		this.path = path;
		this.code = code;
	}
};
function requireModel(condition, path, code = "invalid") {
	if (!condition) throw new ModelError(path, code);
}
function object(value, required, optional = [], path = "value") {
	requireModel(value !== null && typeof value === "object" && !Array.isArray(value), path);
	const obj = value;
	requireModel(required.every((k) => Object.hasOwn(obj, k)) && Object.keys(obj).every((k) => required.includes(k) || optional.includes(k)), path, "shape");
	return obj;
}
function text$4(value, max, path, nonempty = false) {
	requireModel(typeof value === "string" && value.length <= max && !value.includes("\0") && (!nonempty || value.trim().length > 0), path);
}
function finite(value, min, max, path) {
	requireModel(typeof value === "number" && Number.isFinite(value) && value >= min && value <= max, path);
}
function integer(value, min, max, path) {
	finite(value, min, max, path);
	requireModel(Number.isInteger(value), path);
}
function channelKey(source) {
	return JSON.stringify([
		source.kind,
		source.port,
		source.type,
		source.mode,
		source.channel,
		source.unit
	]);
}
function validateLegacyChannel(value) {
	const x = object(value, [
		"id",
		"kind",
		"port",
		"type",
		"mode",
		"channel",
		"name",
		"modeName",
		"unit",
		"decimals"
	], [], "source");
	requireModel(x.kind === "input" || x.kind === "output", "source.kind");
	integer(x.port, 0, 3, "source.port");
	integer(x.type, 1, 124, "source.type");
	integer(x.mode, 0, 7, "source.mode");
	integer(x.channel, 0, 7, "source.channel");
	integer(x.decimals, 0, 6, "source.decimals");
	text$4(x.id, 300, "source.id");
	for (const k of [
		"name",
		"modeName",
		"unit"
	]) text$4(x[k], 160, `source.${k}`);
	const source = x;
	requireModel(source.id === channelKey(source), "source.id", "identity");
	requireModel(source.kind === "input" || [7, 8].includes(source.type) && source.mode === 0 && source.channel === 0 && source.unit === "deg", "source", "motor");
	return source;
}
function calibrationSnapshot(value) {
	const x = object(value, [
		"twoPoint",
		"sourceA",
		"sourceB",
		"targetA",
		"targetB",
		"zeroOffset",
		"unit"
	], [], "calibration");
	requireModel(typeof x.twoPoint === "boolean", "calibration.twoPoint");
	const c = x;
	requireModel(!validateCalibration(c), "calibration", validateCalibration(c) ?? "invalid");
	return immutableSnapshot(c);
}
function immutableSnapshot(value) {
	const copy = structuredClone(value);
	const freeze = (x) => {
		if (x !== null && typeof x === "object") {
			Object.values(x).forEach(freeze);
			Object.freeze(x);
		}
	};
	freeze(copy);
	return copy;
}
/** Callers supply validated public DTOs; preserve opaque IDs and all display metadata. */
function snapshotPublicSource(channel, provenance) {
	integer(provenance.sourceRevision, 0, Number.MAX_SAFE_INTEGER, "sourceRevision");
	text$4(provenance.providerId, 160, "providerId", true);
	text$4(provenance.sessionId, 160, "sessionId", true);
	text$4(channel.channelId, 160, "channelId", true);
	return immutableSnapshot({
		origin: "public",
		channel,
		provenance
	});
}
function validateRecordingOrigin(origin, provenance) {
	requireModel(origin !== void 0, "recordingOrigin", "required");
	finite(origin.sessionElapsedMs, 0, Number.MAX_VALUE, "recordingOrigin.sessionElapsedMs");
	requireModel(origin.providerId === provenance.providerId && origin.sessionId === provenance.sessionId, "recordingOrigin", "session");
}
function validateFrames(frames, count, duration, legacy) {
	requireModel(frames.length <= LIMITS.frames, "frames", "limit");
	frames.forEach((f, i) => {
		object(f, [
			"sampledAt",
			"elapsedMs",
			"values",
			"status",
			"segment"
		], legacy ? [] : [
			"sessionElapsedMs",
			"sequence",
			"sourceRevision",
			"gap",
			"program"
		], `frames.${i}`);
		finite(f.sampledAt, 0, Number.MAX_VALUE, "sampledAt");
		finite(f.elapsedMs, 0, duration, "elapsedMs");
		if (f.sessionElapsedMs !== void 0) finite(f.sessionElapsedMs, 0, Number.MAX_VALUE, "sessionElapsedMs");
		integer(f.segment, 0, Number.MAX_SAFE_INTEGER, "segment");
		requireModel((legacy ? [
			"ok",
			"busy",
			"error"
		] : [
			"ok",
			"busy",
			"error",
			"gap"
		]).includes(f.status), "status");
		requireModel(Array.isArray(f.values) && f.values.length === count, "values", "cardinality");
		for (const value of f.values) if (value !== null) finite(value, -Number.MAX_VALUE, Number.MAX_VALUE, "value");
		requireModel(i === 0 || f.elapsedMs >= frames[i - 1].elapsedMs, "elapsedMs", "order");
		if (f.sequence !== void 0) integer(f.sequence, 0, Number.MAX_SAFE_INTEGER, "sequence");
		if (f.sourceRevision !== void 0) integer(f.sourceRevision, 0, Number.MAX_SAFE_INTEGER, "sourceRevision");
		if (f.program !== void 0) requireModel([
			"stopped",
			"running",
			"unknown"
		].includes(f.program), "program");
		if (f.gap !== void 0) {
			const g = object(f.gap, [
				"fromSequence",
				"toSequence",
				"reason"
			], [], "gap");
			integer(g.fromSequence, 0, Number.MAX_SAFE_INTEGER, "gap.fromSequence");
			integer(g.toSequence, g.fromSequence, Number.MAX_SAFE_INTEGER, "gap.toSequence");
			requireModel([
				"busy",
				"overflow",
				"read-error"
			].includes(g.reason), "gap.reason");
		}
	});
}
function validateTerminal(record) {
	requireModel(record.endedAt === void 0 === (record.reason === void 0), "terminal", "paired");
	if (record.endedAt !== void 0) finite(record.endedAt, 0, Number.MAX_VALUE, "endedAt");
	if (record.reason !== void 0) requireModel([
		"manual",
		"limit",
		"source-changed",
		"disconnected",
		"suspend",
		"close",
		"update",
		"interrupted"
	].includes(record.reason), "reason");
}
function snapshotRecording(record) {
	requireModel(record.schemaVersion === 2, "schemaVersion");
	text$4(record.id, 160, "id", true);
	text$4(record.name, 160, "name", true);
	finite(record.startedAt, 0, Number.MAX_VALUE, "startedAt");
	finite(record.durationMs, 0, LIMITS.durationMs, "durationMs");
	requireModel(record.channels.length >= 1 && record.channels.length <= LIMITS.channels, "channels", "limit");
	const ids = record.channels.map(({ source, calibration }) => {
		calibrationSnapshot(calibration);
		if (source.origin === "legacy-ev3") return `legacy:${validateLegacyChannel(source.channel).id}`;
		requireModel(source.origin === "public", "source.origin");
		snapshotPublicSource(source.channel, source.provenance);
		return `public:${source.channel.channelId}`;
	});
	requireModel(new Set(ids).size === ids.length, "channels", "duplicate");
	validateFrames(record.frames, record.channels.length, record.durationMs, false);
	const publicSources = record.channels.map((c) => c.source).filter((s) => s.origin === "public");
	requireModel(publicSources.length === 0 || publicSources.length === record.channels.length, "channels", "mixed-origin");
	if (publicSources.length) {
		const first = publicSources[0];
		const origin = record.recordingOrigin;
		validateRecordingOrigin(origin, first.provenance);
		requireModel(publicSources.every((s) => s.provenance.sessionId === first.provenance.sessionId && s.provenance.providerId === first.provenance.providerId && s.provenance.sourceRevision === first.provenance.sourceRevision), "channels", "provenance");
		for (const frame of record.frames) {
			finite(frame.sessionElapsedMs, 0, Number.MAX_VALUE, "sessionElapsedMs");
			requireModel(frame.elapsedMs === frame.sessionElapsedMs - origin.sessionElapsedMs, "elapsedMs", "recording-origin");
			requireModel(frame.sourceRevision === first.provenance.sourceRevision && frame.sequence !== void 0 && frame.program !== void 0, "frame", "revision");
		}
	}
	requireModel(record.frameCount === record.frames.length, "frameCount");
	validateTerminal(record);
	return immutableSnapshot(record);
}
function uuid$1(value, path) {
	requireModel(typeof value === "string" && /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/.test(value), path, "uuid");
}
function decode(bytes, expectedId, map) {
	if (bytes.byteLength > 8388608) return {
		ok: false,
		errors: [{
			path: "bytes",
			code: "size"
		}]
	};
	let value;
	try {
		value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
	} catch {
		return {
			ok: false,
			errors: [{
				path: "bytes",
				code: "encoding-or-json"
			}]
		};
	}
	try {
		const candidate = map(value);
		requireModel(candidate.id === expectedId, "id", "identity-mismatch");
		return {
			ok: true,
			value: immutableSnapshot(candidate)
		};
	} catch (error) {
		if (error instanceof ModelError) return {
			ok: false,
			errors: [{
				path: error.path,
				code: error.code
			}]
		};
		return {
			ok: false,
			errors: [{
				path: "value",
				code: "invalid"
			}]
		};
	}
}
function profile(value) {
	const x = object(value, [
		"id",
		"name",
		"source",
		"calibration"
	], [], "profile");
	uuid$1(x.id, "id");
	text$4(x.name, 160, "name", true);
	return {
		id: x.id,
		name: x.name,
		source: {
			origin: "legacy-ev3",
			channel: validateLegacyChannel(x.source)
		},
		calibration: calibrationSnapshot(x.calibration)
	};
}
function importLegacyCalibration(bytes, expectedId) {
	return decode(bytes, expectedId, (value) => {
		const envelope = object(value, ["schemaVersion", "profile"]);
		requireModel(envelope.schemaVersion === 1, "schemaVersion", "unsupported-version");
		return {
			schemaVersion: 2,
			...profile(envelope.profile)
		};
	});
}
function device(value) {
	const x = object(value, [
		"id",
		"name",
		"transport"
	], [
		"address",
		"serialNumber",
		"metadata"
	], "device");
	requireModel(typeof x.id === "string" && x.id.length >= 1 && x.id.length <= 1024, "device.id");
	text$4(x.name, 160, "device.name");
	requireModel([
		"usb",
		"wifi",
		"mock"
	].includes(x.transport), "device.transport");
	for (const k of ["address", "serialNumber"]) if (x[k] !== void 0) requireModel(typeof x[k] === "string" && x[k].length <= 1024, `device.${k}`);
	if (x.metadata !== void 0) {
		requireModel(x.metadata !== null && typeof x.metadata === "object" && !Array.isArray(x.metadata), "metadata");
		for (const [key, v] of Object.entries(x.metadata)) {
			requireModel(key.length <= 1024, "metadata.key");
			requireModel(typeof v === "string" && v.length <= 4096, "metadata.value");
		}
	}
	return x;
}
function importLegacyRecording(bytes, expectedId) {
	return decode(bytes, expectedId, (value) => {
		const x = object(value, [
			"schemaVersion",
			"id",
			"name",
			"startedAt",
			"durationMs",
			"frameCount",
			"device",
			"channels",
			"frames"
		], ["endedAt", "reason"]);
		requireModel(x.schemaVersion === 1, "schemaVersion", "unsupported-version");
		uuid$1(x.id, "id");
		text$4(x.name, 160, "name", true);
		finite(x.startedAt, 0, Number.MAX_VALUE, "startedAt");
		finite(x.durationMs, 0, LIMITS.durationMs, "durationMs");
		integer(x.frameCount, 0, LIMITS.frames, "frameCount");
		const legacyDevice = device(x.device);
		requireModel(Array.isArray(x.channels) && x.channels.length >= 1 && x.channels.length <= LIMITS.channels, "channels", "limit");
		const channels = x.channels.map((value) => {
			const c = object(value, ["source", "calibration"], [], "channel");
			return {
				source: {
					origin: "legacy-ev3",
					channel: validateLegacyChannel(c.source)
				},
				calibration: calibrationSnapshot(c.calibration)
			};
		});
		requireModel(Array.isArray(x.frames), "frames");
		const frames = x.frames;
		validateFrames(frames, channels.length, x.durationMs, true);
		requireModel(x.frameCount === frames.length, "frameCount");
		const terminal = {
			...x.endedAt !== void 0 ? { endedAt: x.endedAt } : {},
			...x.reason !== void 0 ? { reason: x.reason } : {}
		};
		validateTerminal(terminal);
		return snapshotRecording({
			schemaVersion: 2,
			id: x.id,
			name: x.name,
			startedAt: x.startedAt,
			durationMs: x.durationMs,
			frameCount: x.frameCount,
			channels,
			frames,
			provenance: {
				origin: "legacy-ev3",
				schemaVersion: 1,
				device: legacyDevice
			},
			...terminal.endedAt === void 0 ? {
				endedAt: frames.at(-1)?.sampledAt ?? x.startedAt,
				reason: "interrupted"
			} : terminal
		});
	});
}
//#endregion
//#region apps/desktop/src/main/plugins/persistence/sensor-lab-import.ts
var filename = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)\.json$/;
function descriptor(profile) {
	function map(input) {
		const match = filename.exec(input.file?.basename ?? "");
		if (input.sourceKind !== "sensor-lab" || !match || input.bytes.byteLength > 8388608 || (0, node_crypto.createHash)("sha256").update(input.bytes).digest("hex") !== input.sha256) throw new Error("invalid-resource");
		const result = profile ? importLegacyCalibration(input.bytes, match[1]) : importLegacyRecording(input.bytes, match[1]);
		if (!result.ok) throw new Error("invalid-resource");
		const bytes = new TextEncoder().encode(JSON.stringify(result.value));
		if (bytes.length > 8388608) throw new Error("size-limit");
		return {
			kind: "record",
			bytes,
			metadata: {
				kind: profile ? "sensor-lab.calibration" : "sensor-lab.recording",
				schemaVersion: 2,
				label: result.value.name,
				mediaType: "application/json",
				byteLength: bytes.length,
				sha256: (0, node_crypto.createHash)("sha256").update(bytes).digest("hex")
			}
		};
	}
	return Object.freeze({
		id: profile ? "kobrixa.sensor-lab.calibrations-import" : "kobrixa.sensor-lab.recordings-import",
		mappingVersion: 1,
		targetSourceKey: "builtin:kobrixa.sensor-lab",
		sourceKind: "sensor-lab",
		fileFormat: profile ? "sensor-lab-profile-v1" : "sensor-lab-recording-v1",
		sourceFormatVersions: Object.freeze([1]),
		targetRecordSchemaVersions: Object.freeze([2]),
		validate(input) {
			try {
				map(input);
				return true;
			} catch {
				return false;
			}
		},
		map
	});
}
Object.freeze([descriptor(false), descriptor(true)]);
//#endregion
//#region packages/plugin-protocol/src/storage.ts
var mediaTypeSchema$1 = _enum([
	"application/json",
	"text/plain",
	"text/csv",
	"application/octet-stream"
]);
var kindSchema$1 = string().regex(/^[a-z][a-z0-9.-]{0,63}$/);
var metadata$2 = {
	kind: kindSchema$1,
	schemaVersion: versionSchema$1,
	label: boundedText$1(0, 160, 640, true),
	mediaType: mediaTypeSchema$1,
	byteLength: safeIntegerSchema$1.max(8388608),
	sha256: sha256Schema$1
};
var recordMetaSchema$1 = strictObject({
	id: handleSchema$3,
	revision: revisionSchema$1,
	...metadata$2,
	createdAt: safeIntegerSchema$1,
	updatedAt: safeIntegerSchema$1,
	checkpoint: _enum([
		"none",
		"open",
		"final"
	]),
	interrupted: boolean()
}).refine((m) => jsonBytes$1(m) <= 2048);
var recordWriteSchema$1 = strictObject({
	target: discriminatedUnion("mode", [strictObject({ mode: literal("create") }), strictObject({
		mode: literal("replace"),
		id: handleSchema$3,
		expectedRevision: revisionSchema$1
	})]),
	...metadata$2,
	checkpoint: strictObject({
		handle: handleSchema$3,
		phase: _enum(["checkpoint", "final"])
	}).optional(),
	drainToken: handleSchema$3.optional()
});
var writeProgressSchema$1 = strictObject({
	write: handleSchema$3,
	id: handleSchema$3,
	state: _enum([
		"receiving",
		"sealed",
		"publishing",
		"committed",
		"aborted",
		"expired",
		"failed"
	]),
	receivedBytes: safeIntegerSchema$1.max(8388608),
	expiresAt: safeIntegerSchema$1,
	receipt: receiptSchema$1.optional(),
	error: persistenceErrorSchema$1.optional()
});
var drainRequestSchema$1 = strictObject({
	token: handleSchema$3,
	reason: _enum([
		"disable",
		"reload",
		"remove",
		"renderer-crash",
		"window-destroyed",
		"shutdown",
		"update",
		"safe-mode",
		"reservation-ended"
	]),
	remainingMs: safeIntegerSchema$1.max(1e4),
	checkpoints: array(strictObject({
		checkpoint: handleSchema$3,
		record: recordMetaSchema$1,
		reservationEnd: strictObject({
			reservationId: handleSchema$3,
			reason: _enum([
				"released",
				"source-changed",
				"disconnected",
				"suspended",
				"core-disconnect",
				"retired",
				"renderer-lost",
				"limit",
				"overflow"
			]),
			lastSequence: safeIntegerSchema$1
		}).exactOptional()
	})).max(2),
	writes: array(strictObject({
		write: handleSchema$3,
		id: handleSchema$3,
		state: _enum(["receiving", "sealed"])
	})).max(2)
});
var request$3 = (params, value) => ({
	params,
	result: persistenceResultSchema$1(value)
});
var empty$4 = strictObject({});
request$3(recordWriteSchema$1, strictObject({
	write: handleSchema$3,
	id: handleSchema$3,
	expiresAt: safeIntegerSchema$1
})), request$3(strictObject({
	write: handleSchema$3,
	offset: safeIntegerSchema$1,
	data: chunkSchema$1()
}), strictObject({
	receivedBytes: safeIntegerSchema$1.max(8388608),
	expiresAt: safeIntegerSchema$1
})), request$3(strictObject({ write: handleSchema$3 }), writeProgressSchema$1), request$3(strictObject({
	write: handleSchema$3,
	drainToken: handleSchema$3.optional()
}), strictObject({
	record: recordMetaSchema$1,
	receipt: receiptSchema$1
})), request$3(strictObject({ write: handleSchema$3 }), writeProgressSchema$1), request$3(strictObject({ write: handleSchema$3 }), strictObject({
	disposition: _enum([
		"aborted",
		"committed",
		"unknown"
	]),
	receipt: receiptSchema$1.optional()
})), request$3(strictObject({ id: handleSchema$3 }), strictObject({ record: recordMetaSchema$1 })), request$3(strictObject({
	kind: kindSchema$1.optional(),
	limit: safeIntegerSchema$1.min(1).max(64),
	cursor: handleSchema$3.optional()
}), strictObject({
	entries: array(recordMetaSchema$1).max(64),
	nextCursor: handleSchema$3.optional()
}).refine((value) => jsonBytes$1({
	ok: true,
	value
}) <= 262144)), request$3(strictObject({
	id: handleSchema$3,
	expectedRevision: revisionSchema$1,
	schemaVersion: versionSchema$1
}), strictObject({
	read: handleSchema$3,
	record: recordMetaSchema$1,
	expiresAt: safeIntegerSchema$1
})), request$3(strictObject({
	read: handleSchema$3,
	offset: safeIntegerSchema$1,
	maxBytes: safeIntegerSchema$1.min(1).max(262144)
}), strictObject({
	offset: safeIntegerSchema$1,
	data: chunkSchema$1(true),
	nextOffset: safeIntegerSchema$1,
	eof: boolean()
})), request$3(strictObject({ read: handleSchema$3 }), empty$4), request$3(strictObject({
	id: handleSchema$3,
	expectedRevision: revisionSchema$1
}), strictObject({
	deleted: literal(true),
	receipt: receiptSchema$1
})), request$3(empty$4, strictObject({
	barrier: handleSchema$3,
	durability: durabilitySchema$1
})), request$3(empty$4, strictObject({
	recordCount: safeIntegerSchema$1,
	reservedCreates: safeIntegerSchema$1,
	committedBytes: safeIntegerSchema$1,
	reservedBytes: safeIntegerSchema$1,
	pinnedBytes: safeIntegerSchema$1,
	temporaryBytes: safeIntegerSchema$1,
	sourceLimitBytes: literal(536870912),
	sourceLimitRecords: literal(256),
	hostAvailableBytes: safeIntegerSchema$1,
	writeSlotsAvailable: safeIntegerSchema$1,
	exportSlotsAvailable: safeIntegerSchema$1
})), request$3(strictObject({
	id: handleSchema$3,
	expectedRevision: revisionSchema$1,
	reservation: handleSchema$3.optional()
}), strictObject({ checkpoint: handleSchema$3 })), request$3(strictObject({ checkpoint: handleSchema$3 }), strictObject({ record: recordMetaSchema$1 })), request$3(drainRequestSchema$1, strictObject({
	status: _enum(["submitted", "checkpoint-only"]),
	writes: array(handleSchema$3).max(2)
}));
//#endregion
//#region apps/desktop/src/main/plugins/persistence/quota.ts
var MiB = 1048576;
var QuotaLedger = class {
	committed = /* @__PURE__ */ new Map();
	reservations = /* @__PURE__ */ new Map();
	temporary = /* @__PURE__ */ new Map();
	restore(source, totals) {
		this.committed.set(source, { ...totals });
	}
	total(source) {
		return this.committed.get(source) ?? {
			committed: 0,
			records: 0,
			metadata: 0,
			temporary: 0
		};
	}
	sum(select) {
		return [...this.committed.values()].reduce((a, v) => a + select(v), 0);
	}
	snapshot(source) {
		const c = this.total(source), all = [...this.reservations.values()], own = all.filter((r) => r.source === source);
		const pending = (rs) => rs.reduce((n, r) => n + r.bytes, 0);
		const tmp = [...this.temporary.values()].filter((r) => r.source === source).reduce((n, r) => n + r.bytes, 0);
		return {
			recordCount: c.records,
			reservedCreates: own.filter((r) => r.create).length,
			committedBytes: c.committed,
			reservedBytes: pending(own),
			pinnedBytes: tmp,
			temporaryBytes: c.temporary + tmp,
			sourceLimitBytes: 536870912,
			sourceLimitRecords: 256,
			hostAvailableBytes: Math.max(0, 1073741824 - this.sum((c) => c.committed) - pending(all)),
			writeSlotsAvailable: Math.max(0, Math.min(2 - own.filter((r) => r.lane === "write").length, 16 - all.filter((r) => r.lane === "write").length)),
			exportSlotsAvailable: Math.max(0, Math.min(1 - own.filter((r) => r.lane === "export").length, 4 - all.filter((r) => r.lane === "export").length))
		};
	}
	reserve(id, source, input, availableBytes) {
		if (this.reservations.has(id)) throw new Error("write-in-progress");
		for (const n of [
			input.bytes,
			input.metadata,
			availableBytes
		]) if (!Number.isSafeInteger(n) || n < 0) throw new Error("invalid-range");
		const s = this.snapshot(source), all = [...this.reservations.values()], own = all.filter((r) => r.source === source);
		if (s.recordCount + s.reservedCreates + Number(input.create) > 256) throw new Error("record-count");
		if (s.committedBytes + s.reservedBytes + input.bytes > 512 * MiB) throw new Error("source-bytes");
		if (s.hostAvailableBytes < input.bytes) throw new Error("host-bytes");
		if (input.lane === "write" && !s.writeSlotsAvailable || input.lane === "export" && !s.exportSlotsAvailable) throw new Error("queue");
		if (this.total(source).metadata + own.reduce((n, r) => n + r.metadata, 0) + input.metadata > 4 * MiB || this.sum((t) => t.metadata) + all.reduce((n, r) => n + r.metadata, 0) + input.metadata > 64 * MiB) throw new Error("metadata-limit");
		if (availableBytes - all.reduce((n, r) => n + r.bytes + r.metadata, 0) - input.bytes - input.metadata < 16 * MiB) throw new Error("disk-full");
		this.reservations.set(id, {
			source,
			...input
		});
	}
	commit(id, delta) {
		const r = this.reservations.get(id);
		if (!r) throw new Error("stale");
		const t = this.total(r.source);
		this.committed.set(r.source, {
			committed: t.committed + delta.committed,
			records: t.records + delta.records,
			metadata: t.metadata + delta.metadata,
			temporary: t.temporary + delta.temporary
		});
		this.reservations.delete(id);
	}
	release(id) {
		this.reservations.delete(id);
	}
	adjustMetadata(source, delta) {
		const current = this.total(source);
		this.committed.set(source, {
			...current,
			metadata: current.metadata + delta
		});
	}
	holdTemporary(source, key, bytes) {
		const id = JSON.stringify([source, key]), existing = this.temporary.get(id);
		if (existing) {
			if (existing.bytes !== bytes) throw new Error("corrupt");
			existing.refs++;
			return;
		}
		if (this.snapshot(source).temporaryBytes + bytes > 32 * MiB || this.sum((t) => t.temporary) + [...this.temporary.values()].reduce((n, r) => n + r.bytes, 0) + bytes > 128 * MiB) throw new Error("temporary-bytes");
		this.temporary.set(id, {
			source,
			bytes,
			refs: 1
		});
	}
	releaseTemporary(source, key) {
		const id = JSON.stringify([source, key]), value = this.temporary.get(id);
		if (value && --value.refs === 0) this.temporary.delete(id);
	}
	hasTemporary(source, key) {
		return this.temporary.has(JSON.stringify([source, key]));
	}
};
var WorkQueue = class {
	now;
	queue = [];
	sourceBytes = /* @__PURE__ */ new Map();
	sourceCount = /* @__PURE__ */ new Map();
	active = 0;
	bytes = 0;
	pending = 0;
	constructor(now) {
		this.now = now;
	}
	run(source, bytes, deadline, run) {
		if (!Number.isSafeInteger(bytes) || bytes < 0 || this.pending >= 32 || this.bytes + bytes > 8388608 || (this.sourceBytes.get(source) ?? 0) + bytes > 1048576 || (this.sourceCount.get(source) ?? 0) >= 16) return Promise.reject(/* @__PURE__ */ new Error("queue"));
		this.pending++;
		this.bytes += bytes;
		this.sourceBytes.set(source, (this.sourceBytes.get(source) ?? 0) + bytes);
		this.sourceCount.set(source, (this.sourceCount.get(source) ?? 0) + 1);
		const result = new Promise((resolve, reject) => this.queue.push({
			source,
			bytes,
			deadline,
			run,
			resolve,
			reject
		}));
		this.pump();
		return result;
	}
	pump() {
		while (this.active < 4 && this.queue.length) {
			const job = this.queue.shift();
			this.active++;
			(this.now() >= job.deadline ? Promise.reject(/* @__PURE__ */ new Error("timeout")) : job.run()).then(job.resolve, job.reject).finally(() => {
				this.active--;
				this.pending--;
				this.bytes -= job.bytes;
				this.sourceBytes.set(job.source, (this.sourceBytes.get(job.source) ?? 0) - job.bytes);
				this.sourceCount.set(job.source, (this.sourceCount.get(job.source) ?? 0) - 1);
				this.pump();
			});
		}
	}
};
//#endregion
//#region apps/desktop/src/main/plugins/persistence/recovery-scan.ts
var contentError = (e) => e instanceof Error && (e.message === "corrupt" || e instanceof SyntaxError || e instanceof TypeError);
var resolvedSchema = discriminatedUnion("disposition", [strictObject({
	formatVersion: literal(1),
	disposition: literal("committed"),
	receipt: receiptSchema$1
}), strictObject({
	formatVersion: literal(1),
	disposition: literal("not-committed"),
	receipt: _null()
})]);
async function resolvedImport(ns, id) {
	const path = ns.path("staging", id, "resolved.json");
	if (!await ns.fs.exists(path)) return null;
	return resolvedSchema.parse(JSON.parse(Buffer.from(await ns.fs.bytes(path, 8192)).toString("utf8")));
}
async function persistResolution(ns, id, value) {
	const temp = ns.path("staging", id, "resolved.tmp");
	if (await ns.fs.exists(temp)) await ns.fs.unlink(temp);
	await ns.writeNew(temp, resolvedSchema.parse(value));
	await ns.fs.atomicReplace(temp, ns.path("staging", id, "resolved.json"));
	await ns.fs.syncDirectory(ns.path("staging", id));
}
async function quarantinePendingImportCandidate(ns, loc) {
	const fs = ns.fs;
	if (loc.parts[0] !== "records" || await fs.exists(loc.head) || await fs.exists(loc.previous)) return false;
	const candidates = (await fs.entries(loc.directory, 4096)).filter((e) => !e.directory && /^head\.[0-9a-f-]{36}\.tmp$/.test(e.name));
	if (candidates.length !== 1) return false;
	const candidate = parseHead(await fs.bytes(ns.path(...loc.parts, candidates[0].name), 8192));
	if (candidate.target.kind !== "record" || candidate.target.expectedRevision !== null || candidate.target.id !== loc.parts[1] || candidate.metadata.kind !== "record" || candidate.metadata.deleted || !candidate.importTag || candidates[0].name !== `head.${candidate.receipt.commitId}.tmp`) return false;
	const objects = await fs.entries(loc.objects, 4096);
	if (objects.length > 1 || objects.length === 1 && (objects[0].directory || objects[0].name !== candidate.object)) return false;
	const journalLoc = await ns.location({
		kind: "import",
		key: candidate.importTag.importId
	});
	const journalHead = await ns.head(journalLoc);
	if (!journalHead || journalHead.target.kind !== "import" || journalHead.target.key !== candidate.importTag.importId) return false;
	await ns.verify(journalLoc, journalHead);
	const journal = importDocumentSchema.parse(JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(await fs.bytes(ns.object(journalLoc, journalHead), 2097152))));
	if (journal.complete || journal.plan.id !== candidate.importTag.importId || journal.plan.targetSourceKey !== ns.sourceKey) return false;
	const index = journal.plan.items.findIndex((i) => i.key === candidate.importTag.itemKey);
	if (index < 0) return false;
	const item = journal.plan.items[index], evidence = journal.items[index], attempt = evidence.publicationTicket;
	if (evidence.state !== "pending" || evidence.receipt !== null || !attempt || attempt.owner.sourceKey !== ns.sourceKey || attempt.id !== candidate.receipt.commitId || !sameImportValue(attempt.target, candidate.target) || !sameImportValue(attempt.metadata, candidate.metadata) || !sameImportValue(item.tag, candidate.importTag) || item.byteLength !== candidate.byteLength || item.mappedSha256 !== candidate.sha256) return false;
	const objectEvidence = ns.path("quarantine", `${candidate.receipt.commitId}.prepublish.bin`);
	const headEvidence = ns.path("quarantine", `${candidate.receipt.commitId}.prepublish-head`);
	if (await fs.exists(headEvidence)) throw new Error("corrupt");
	if (objects.length === 0) {
		if (!await fs.exists(objectEvidence)) return false;
		if (await fs.size(objectEvidence) !== candidate.byteLength) throw new Error("corrupt");
		const fd = await fs.open(objectEvidence, "read"), hash = (0, node_crypto.createHash)("sha256");
		let offset = 0;
		try {
			while (offset < candidate.byteLength) {
				const bytes = await fs.read(fd, offset, Math.min(262144, candidate.byteLength - offset));
				if (!bytes.length) throw new Error("corrupt");
				hash.update(bytes);
				offset += bytes.length;
			}
			if (hash.digest("hex") !== candidate.sha256) throw new Error("corrupt");
		} finally {
			await fs.close(fd);
		}
	} else {
		if (await fs.exists(objectEvidence)) throw new Error("corrupt");
		await ns.verify(loc, candidate);
		await fs.atomicReplace(ns.object(loc, candidate), objectEvidence);
	}
	await fs.syncDirectory(ns.path("quarantine"));
	await fs.syncDirectory(loc.objects);
	await fs.atomicReplace(ns.path(...loc.parts, candidates[0].name), headEvidence);
	await fs.syncDirectory(ns.path("quarantine"));
	await fs.syncDirectory(loc.directory);
	return true;
}
async function scanNamespace(ns, hostEpoch) {
	const fs = ns.fs;
	fs.profile.assertHeld();
	const result = {
		heads: [],
		problems: [],
		totals: {
			committed: 0,
			records: 0,
			metadata: 0,
			temporary: 0
		}
	};
	await ns.inventory();
	const payloads = /* @__PURE__ */ new Set(), retained = /* @__PURE__ */ new Set();
	const unresolved = /* @__PURE__ */ new Set();
	for (const loc of await ns.locations()) {
		let head = null;
		try {
			head = await ns.head(loc);
			if (head) await ns.verify(loc, head);
		} catch (e) {
			if (!contentError(e)) throw e;
			head = null;
			result.problems.push("corrupt");
			unresolved.add(fs.name(loc.directory));
		}
		if (!head && await fs.exists(loc.previous)) {
			const previous = parseHead(await fs.bytes(loc.previous, 8192));
			await ns.verify(loc, previous);
			if (await fs.exists(loc.head)) await ns.quarantine(loc.head);
			const restore = ns.path(...loc.parts, `${loc.name}.${(0, node_crypto.randomUUID)()}.restore`);
			await ns.writeNew(restore, previous);
			await fs.atomicReplace(restore, loc.head);
			await fs.syncDirectory(loc.directory);
			head = previous;
			result.problems.push("rollback-interrupted");
		}
		if (!head) {
			const objectsRemain = await fs.exists(loc.objects) && (await fs.entries(loc.objects, 4096)).length > 0;
			const candidateRemains = loc.parts[0] === "records" && (await fs.entries(loc.directory, 4096)).some((e) => !e.directory && /^head\.[0-9a-f-]{36}\.tmp$/.test(e.name));
			if ((objectsRemain || candidateRemains) && !await quarantinePendingImportCandidate(ns, loc)) {
				result.problems.push("corrupt");
				unresolved.add(fs.name(loc.directory));
			}
			continue;
		}
		if (head.metadata.kind !== "record") {
			const raw = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(await fs.bytes(ns.object(loc, head), 2097152)));
			if (raw === null || typeof raw !== "object" || !("formatVersion" in raw)) throw new Error("corrupt");
			if (raw.formatVersion !== 1) throw new Error("unsupported-format");
		}
		result.heads.push(head);
		const record = liveRecord(head);
		if (record) {
			result.totals.committed += record.byteLength;
			result.totals.records++;
			if (head.object) payloads.add(fs.name(ns.object(loc, head)));
		}
		if (await fs.exists(loc.previous)) {
			const previous = parseHead(await fs.bytes(loc.previous, 8192));
			await ns.verify(loc, previous);
			if (previous.object && previous.object !== head.object && previous.metadata.kind === "record") retained.add(fs.name(ns.object(loc, previous)));
		}
	}
	for (const entry of await fs.entries(ns.path("staging"), 4096)) {
		if (!entry.directory || !/^[0-9a-f-]{36}$/.test(entry.name)) throw new Error("corrupt");
		const intent = ns.path("staging", entry.name, "intent.json");
		if (!await fs.exists(intent)) {
			if ((await fs.entries(ns.path("staging", entry.name), 4096)).length === 0) await fs.removeEmpty(ns.path("staging", entry.name));
			else result.problems.push("corrupt");
			continue;
		}
		const value = JSON.parse(Buffer.from(await fs.bytes(intent, 8192)).toString("utf8"));
		if (value.formatVersion !== 1) throw new Error("unsupported-format");
		if (value.ticket?.owner?.sourceKey !== ns.sourceKey) throw new Error("identity-mismatch");
		const checkedTicket = publicationTicketSchema.parse(value.ticket);
		if (checkedTicket.target.kind === "import") {
			const payload = ns.path("staging", entry.name, "payload.tmp");
			if (await resolvedImport(ns, entry.name)) {
				if (await fs.exists(payload)) await fs.unlink(payload);
				continue;
			}
			const loc = await ns.location(checkedTicket.target), head = await ns.head(loc);
			if (head) await ns.verify(loc, head);
			const raw = JSON.parse(Buffer.from(await fs.bytes(intent, 32768)).toString("utf8"));
			if (Object.keys(raw).sort().join(",") !== "byteLength,formatVersion,predecessor,ticket") throw new Error("corrupt");
			const predecessor = raw.predecessor === null ? null : parseHead(Buffer.from(JSON.stringify(raw.predecessor)));
			if (predecessor) await ns.verify(loc, predecessor);
			let matching = false;
			const candidatePath = ns.path("staging", entry.name, "publication.json");
			if (head && await fs.exists(candidatePath)) {
				const candidate = parseHead(await fs.bytes(candidatePath, 8192));
				if (!sameImportValue(candidate.target, checkedTicket.target) || !sameImportValue(candidate.metadata, checkedTicket.metadata)) throw new Error("identity-mismatch");
				matching = sameImportValue(candidate, head);
			}
			if (head && (checkedTicket.target.key.startsWith("nonce/") || checkedTicket.target.key.startsWith("barrier/"))) {
				const bytes = await fs.bytes(ns.object(loc, head), 2097152);
				matching = sameImportValue((checkedTicket.target.key.startsWith("nonce/") ? parseNonceDocument(bytes) : parseBarrierDocument(bytes)).ticket, checkedTicket);
			}
			if (await fs.exists(payload)) await fs.unlink(payload);
			if (matching) {
				await fs.syncDirectory(loc.directory);
				await persistResolution(ns, entry.name, {
					formatVersion: 1,
					disposition: "committed",
					receipt: head.receipt
				});
			} else if (sameImportValue(head, predecessor)) await persistResolution(ns, entry.name, {
				formatVersion: 1,
				disposition: "not-committed",
				receipt: null
			});
			else result.problems.push("import-uncertain");
			continue;
		}
		if (checkedTicket.target.kind === "record" && unresolved.has(fs.name((await ns.location(checkedTicket.target)).directory))) continue;
		if (value.ticket.owner.hostEpoch !== hostEpoch) {
			for (const name of [
				"payload.tmp",
				"sealed.json",
				"import-tag.json",
				"publication.json",
				"intent.json"
			]) {
				const p = ns.path("staging", entry.name, name);
				try {
					if (await fs.exists(p)) await fs.unlink(p);
				} catch (e) {
					result.problems.push(e.code === "EACCES" ? "permission" : "cleanup-failed");
				}
			}
			if ((await fs.entries(ns.path("staging", entry.name), 4096)).length === 0) await fs.removeEmpty(ns.path("staging", entry.name));
		}
	}
	for (const file of await ns.inventory()) {
		const name = fs.name(file.path);
		if (payloads.has(name)) continue;
		if (/^quarantine\/[0-9a-f-]{36}\.prepublish\.bin$/.test(file.relative) || retained.has(name) || /(?:^|\/)objects\/r_[0-9a-f]{32}\.bin$/.test(file.relative) || file.relative.endsWith("/payload.tmp")) result.totals.temporary += file.bytes;
		else result.totals.metadata += file.bytes;
	}
	if (result.totals.committed > 536870912 || result.totals.records > 256 || result.totals.temporary > 33554432 || result.totals.metadata > 4194304) result.problems.push("quota");
	return result;
}
async function garbageCandidates(ns, protectedPaths) {
	const refs = new Set(protectedPaths), fs = ns.fs;
	for (const loc of await ns.locations()) for (const p of [loc.head, loc.previous]) if (await fs.exists(p)) {
		const head = parseHead(await fs.bytes(p, 8192));
		await ns.verify(loc, head);
		if (head.object) refs.add(fs.name(ns.object(loc, head)));
	}
	return (await ns.inventory()).filter((file) => /(?:^|\/)objects\/r_[0-9a-f]{32}\.(?:bin|json)$/.test(file.relative) && !refs.has(fs.name(file.path))).map((file) => file.path);
}
//#endregion
//#region apps/desktop/src/main/plugins/persistence/atomic-store.ts
var uuid = string().uuid();
var checkpointDocumentSchema = strictObject({
	formatVersion: literal(1),
	checkpoint: uuid,
	record: recordMetaSchema$1,
	binding: strictObject({
		owner: persistenceOwnerSchema,
		reservationId: uuid,
		sessionId: uuid,
		providerGeneration: number().int().nonnegative()
	}).nullable(),
	state: _enum([
		"open",
		"final",
		"interrupted"
	])
});
var AtomicStore = class {
	fs;
	quota = new QuotaLedger();
	namespaces = /* @__PURE__ */ new Map();
	blockedSources = /* @__PURE__ */ new Map();
	importCommitted = /* @__PURE__ */ new WeakMap();
	importReservations = /* @__PURE__ */ new Map();
	failedReserves = /* @__PURE__ */ new Map();
	tombstones = /* @__PURE__ */ new Map();
	entries = /* @__PURE__ */ new Map();
	targets = /* @__PURE__ */ new Map();
	finalAdmissions = /* @__PURE__ */ new Map();
	finalConsumed = /* @__PURE__ */ new Set();
	recoveryDocuments = /* @__PURE__ */ new Set();
	frozen = /* @__PURE__ */ new Map();
	frozenTargets = /* @__PURE__ */ new Map();
	uncertain = /* @__PURE__ */ new Map();
	publication = /* @__PURE__ */ new Map();
	pins = /* @__PURE__ */ new Map();
	closed = /* @__PURE__ */ new Map();
	pages = /* @__PURE__ */ new Set();
	cursors = /* @__PURE__ */ new Map();
	gcHeld = /* @__PURE__ */ new Map();
	constructor(fs) {
		this.fs = fs;
	}
	async initialize() {
		this.fs.profile.assertHeld();
		for (const dir of await this.fs.entries(this.fs.path("namespaces"), 4096)) {
			if (!dir.directory || !/^[0-9a-f]{64}$/.test(dir.name)) throw new Error("corrupt");
			const identity = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(await this.fs.bytes(this.fs.path("namespaces", dir.name, "identity.json"), 4096)));
			if (identity.formatVersion !== 1) throw new Error("unsupported-format");
			if (typeof identity.sourceKey !== "string") throw new Error("identity-mismatch");
			if ((await this.ns(identity.sourceKey)).hash !== dir.name) throw new Error("identity-mismatch");
		}
		if (this.blockedSources.size) throw new Error("recovery-blocked");
	}
	ns(source) {
		let pending = this.namespaces.get(source);
		if (!pending) {
			pending = Namespace.open(this.fs, source).then(async (ns) => {
				try {
					const scanned = await scanNamespace(ns, this.fs.profile.hostEpoch);
					this.quota.restore(source, scanned.totals);
					const imports = /* @__PURE__ */ new Map();
					let bytes = 0;
					for (const head of scanned.heads) if (head.target.kind === "import") {
						bytes += head.byteLength;
						if (imports.size >= 512 || bytes > 2097152) throw new Error("size-limit");
						imports.set(head.target.key, head.byteLength);
					}
					this.importCommitted.set(ns, imports);
					if (scanned.problems.length) this.blockedSources.set(source, scanned.problems[0]);
				} catch (e) {
					this.blockedSources.set(source, e instanceof Error ? e.message : "corrupt");
				}
				return ns;
			});
			this.namespaces.set(source, pending);
		}
		return pending;
	}
	reserveImportBudget(ns, ticket, bytes) {
		if (ticket.target.kind !== "import") return;
		const committed = this.importCommitted.get(ns);
		if (!committed) throw new Error("recovery-blocked");
		let own = 0;
		const projected = new Map(committed);
		for (const held of this.importReservations.values()) if (held.ns === ns) {
			own++;
			projected.set(held.key, Math.max(projected.get(held.key) ?? 0, held.bytes));
		}
		if (this.importReservations.has(ticket.id) || this.importReservations.size >= 1024 || own >= 64) throw new Error("quota");
		projected.set(ticket.target.key, Math.max(projected.get(ticket.target.key) ?? 0, bytes));
		if (projected.size > 512 || [...projected.values()].reduce((sum, n) => sum + n, 0) > 2097152) throw new Error("size-limit");
		this.importReservations.set(ticket.id, {
			ns,
			key: ticket.target.key,
			bytes
		});
	}
	targetKey(t) {
		return JSON.stringify([
			t.owner.sourceKey,
			t.target.kind,
			t.target.kind === "record" ? t.target.id : t.target.kind === "settings" ? "settings" : t.target.key
		]);
	}
	releaseTarget(t) {
		const key = this.targetKey(t);
		if (this.targets.get(key) === t.id) this.targets.delete(key);
	}
	terminalDeletes = /* @__PURE__ */ new Map();
	async admitTerminalDelete(t, byteLength) {
		if (this.finalAdmissions.has(t.id) || t.target.kind !== "record" || !this.frozenTargets.has(JSON.stringify([ownerKey(t.owner), t.target.id]))) return;
		if (this.frozen.has(ownerKey(t.owner)) || byteLength !== 0 || t.metadata.kind !== "record" || !t.metadata.deleted || t.target.expectedRevision === null || t.metadata.record.checkpoint !== "final") throw new Error("stale");
		const record = await this.stat(t.owner, t.target.id);
		if (record.revision !== t.target.expectedRevision) throw new Error("revision-mismatch");
		if (record.checkpoint !== "final") throw new Error("stale");
		if ([...this.entries.values()].some((e) => e.ticket.target.kind === "record" && e.ticket.owner.sourceKey === t.owner.sourceKey && e.ticket.target.id === record.id && e.state !== "committed" && e.state !== "aborted")) throw new Error("write-in-progress");
		let cursor, terminal = false;
		do {
			const page = await this.auxiliaryKeys(t.owner, "recovery", cursor);
			for (const key of page.keys) {
				const bytes = await this.auxiliary(t.owner, "recovery", key);
				if (!bytes) continue;
				const parsed = checkpointDocumentSchema.safeParse(JSON.parse(Buffer.from(bytes).toString("utf8")));
				if (!parsed.success || parsed.data.record.id !== record.id) continue;
				if (parsed.data.state === "open") throw new Error("stale");
				if (parsed.data.state === "final" && parsed.data.record.revision === record.revision) terminal = true;
			}
			cursor = page.nextCursor ?? void 0;
		} while (cursor);
		if (!terminal) throw new Error("stale");
		this.terminalDeletes.set(t.id, JSON.stringify(t));
	}
	admitted(t) {
		this.fs.profile.assertHeld();
		if (t.owner.hostEpoch !== this.fs.profile.hostEpoch || !this.finalAdmissions.has(t.id) && !this.recoveryDocuments.has(t.id) && (this.frozen.has(ownerKey(t.owner)) || t.target.kind === "record" && this.frozenTargets.has(JSON.stringify([ownerKey(t.owner), t.target.id])) && this.terminalDeletes.get(t.id) !== JSON.stringify(t))) throw new Error("stale");
		if (this.blockedSources.has(t.owner.sourceKey)) throw new Error(this.blockedSources.get(t.owner.sourceKey));
		if (this.uncertain.has(t.owner.sourceKey)) throw new Error("publish-uncertain");
	}
	entry(t) {
		this.fs.profile.assertHeld();
		const e = this.entries.get(t.id);
		if (!e || e.signature !== JSON.stringify(t)) throw new Error("stale");
		if (e.finished !== null && e.finished + 12e4 <= this.fs.now() && (e.cleaned || e.state === "aborted")) {
			this.forgetEntry(t.id, e);
			throw new Error("stale");
		}
		return e;
	}
	live(e, gate = e.gate) {
		if (e.state === "aborted" || this.fs.now() >= Math.min(e.created + 12e4, e.progress + 3e4, gate.deadline)) throw new Error("expired");
	}
	cas(t, head) {
		if (t.target.kind === "record" || t.target.kind === "settings") {
			if ((head?.receipt.revision ?? null) !== t.target.expectedRevision) throw new Error("revision-mismatch");
		}
	}
	forgetEntry(id, e) {
		if (e.state !== "committed" && e.state !== "aborted") return;
		this.tombstones.set(id, {
			signature: e.signature,
			disposition: e.state,
			until: this.fs.now() + 12e4
		});
		while (this.tombstones.size > 1024) this.tombstones.delete(this.tombstones.keys().next().value);
		this.entries.delete(id);
	}
	async prune() {
		const now = this.fs.now();
		for (const [id, t] of this.tombstones) if (t.until <= now) this.tombstones.delete(id);
		for (const failed of this.failedReserves.values()) await this.abort(failed.ticket).catch(() => {});
		for (const [id, e] of this.entries) if (e.finished !== null && e.finished + 12e4 <= now && !e.busy && (e.cleaned || e.state === "aborted")) this.forgetEntry(id, e);
		for (const [id, pin] of this.pins) if (now >= Math.min(pin.created + 12e4, pin.used + 3e4, pin.expires ?? Infinity)) await this.closePin(id, pin);
		for (const [id, c] of this.closed) if (c.until <= now) this.closed.delete(id);
		for (const page of this.pages) if (now >= Math.min(page.created + 12e4, page.used + 3e4)) {
			this.pages.delete(page);
			for (const token of page.tokens.values()) this.cursors.delete(token);
		}
		for (const e of this.entries.values()) if ((e.state === "receiving" || e.state === "sealed") && !e.busy && now >= Math.min(e.created + 12e4, e.progress + 3e4, e.retained ? Infinity : e.gate.deadline)) await this.abort(e.ticket);
	}
	async checkImportAdmission(ticket) {
		if (ticket.target.kind !== "record" && ticket.target.kind !== "settings") return;
		const ns = await this.ns(ticket.owner.sourceKey);
		let blocked = false, associated = false;
		for (const loc of await ns.locations()) {
			const head = await ns.head(loc);
			if (head?.target.kind !== "import") continue;
			if (!head.target.key.startsWith("import/") && !head.target.key.startsWith("barrier/")) continue;
			await ns.verify(loc, head);
			const bytes = await this.fs.bytes(ns.object(loc, head), 2097152);
			if (head.target.key.startsWith("barrier/")) {
				const barrier = parseBarrierDocument(bytes);
				if (barrier.sourceKey !== ns.sourceKey) throw new Error("evidence-binding");
				if (barrier.state === "active") blocked = true;
			} else {
				const saved = importDocumentSchema.parse(JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes)));
				if (saved.plan.targetSourceKey !== ns.sourceKey || saved.plan.id !== head.target.key) throw new Error("evidence-binding");
				if (!saved.complete) {
					blocked = true;
					if (saved.items.some((e) => e.state === "pending" && sameImportValue(e.publicationTicket, ticket))) associated = true;
				}
			}
		}
		if (blocked && !associated) throw new Error("import-pending");
	}
	recordUnadmittedReserve(ticket) {
		if (!this.entries.has(ticket.id) && !this.failedReserves.has(ticket.id) && !this.tombstones.has(ticket.id)) {
			this.tombstones.set(ticket.id, {
				signature: JSON.stringify(ticket),
				disposition: "aborted",
				until: this.fs.now() + 12e4
			});
			while (this.tombstones.size > 1024) this.tombstones.delete(this.tombstones.keys().next().value);
		}
	}
	async ownsCheckpoint(owner, checkpoint, recordId) {
		if ([...this.entries.values()].some((e) => e.state === "committed" && e.ticket.target.kind === "recovery" && e.ticket.target.key === checkpoint && ownerKey(e.ticket.owner) === ownerKey(owner))) return true;
		const retained = await this.loadRecovery(checkpointRecoveryId(checkpoint));
		return !!retained && ownerKey(retained.owner) === ownerKey(owner) && retained.report.records.some((r) => r.id === recordId);
	}
	async reserveFinal(ticket, byteLength, grant, memory, byteOffset = 0) {
		const identity = JSON.stringify([ownerKey(ticket.owner), grant.checkpoint]);
		const deadline = Math.min(grant.deadlineMonotonicMs, this.frozen.get(ownerKey(ticket.owner)) ?? Infinity, this.frozenTargets.get(JSON.stringify([ownerKey(ticket.owner), grant.recordId])) ?? Infinity, grant.deviceDrain?.expiresMonotonicMs ?? Infinity);
		if (ownerKey(grant.owner) !== ownerKey(ticket.owner) || ticket.target.kind !== "record" || ticket.target.id !== grant.recordId || ticket.target.expectedRevision === null || ticket.metadata.kind !== "record" || ticket.metadata.deleted || ticket.metadata.record.checkpoint !== "final" || this.finalConsumed.has(identity) || this.fs.now() >= deadline || !uuid.safeParse(grant.token).success || !this.frozen.has(ownerKey(ticket.owner)) && !this.frozenTargets.has(JSON.stringify([ownerKey(ticket.owner), grant.recordId]))) throw new Error("stale");
		const bytes = await this.auxiliary(ticket.owner, "recovery", grant.checkpoint);
		if (!bytes) throw new Error("stale");
		const document = checkpointDocumentSchema.parse(JSON.parse(Buffer.from(bytes).toString("utf8")));
		const ns = await this.ns(ticket.owner.sourceKey), loc = await ns.location({
			kind: "recovery",
			key: grant.checkpoint
		});
		if (document.checkpoint !== grant.checkpoint || document.record.id !== grant.recordId || document.state !== "open" || document.binding && (ownerKey(document.binding.owner) !== ownerKey(ticket.owner) || !grant.deviceDrain || ownerKey(grant.deviceDrain.owner) !== ownerKey(ticket.owner) || grant.deviceDrain.reservationId !== document.binding.reservationId)) throw new Error("stale");
		if (!await ns.head(loc) || !await this.ownsCheckpoint(ticket.owner, grant.checkpoint, grant.recordId)) throw new Error("stale");
		if (this.finalConsumed.has(identity) || this.fs.now() >= deadline) throw new Error("stale");
		this.finalConsumed.add(identity);
		this.finalAdmissions.set(ticket.id, {
			...structuredClone(grant),
			deadlineMonotonicMs: deadline
		});
		try {
			await this.reserve(ticket, byteLength, memory, byteOffset);
			this.entry(ticket).gate.shorten(deadline, this.fs.now());
		} finally {
			this.finalAdmissions.delete(ticket.id);
		}
	}
	async retainSealed(ticket) {
		const e = this.entry(ticket), expiresMonotonicMs = Math.min(e.created + 12e4, e.progress + 3e4);
		if (e.state !== "sealed" || e.busy || e.gate.dispatched || e.received !== e.size || this.fs.now() >= expiresMonotonicMs) throw new Error("incomplete");
		if (e.retained && this.pins.has(e.retained.pin)) return { ...e.retained };
		if ([...this.pins.values()].filter((p) => p.source === ticket.owner.sourceKey).length >= 4) throw new Error("quota");
		e.busy = true;
		try {
			const path = e.object ?? e.temp, fd = await this.fs.open(path, "read"), pin = (0, node_crypto.randomUUID)();
			this.quota.holdTemporary(ticket.owner.sourceKey, this.fs.name(path), e.size);
			this.pins.set(pin, {
				owner: ownerKey(ticket.owner),
				source: ticket.owner.sourceKey,
				ns: e.ns,
				path,
				fd,
				length: e.size,
				created: e.created,
				used: e.progress,
				busy: Promise.resolve(),
				ticket: ticket.id,
				expires: expiresMonotonicMs
			});
			e.retained = {
				pin,
				expiresMonotonicMs
			};
			return { ...e.retained };
		} finally {
			e.busy = false;
		}
	}
	retainedSealed(ticket) {
		const e = this.entries.get(ticket.id);
		return !!e && e.signature === JSON.stringify(ticket) && !!e.retained && this.pins.has(e.retained.pin) && this.fs.now() < e.retained.expiresMonotonicMs && e.state === "sealed" && !e.gate.dispatched && !e.recoveryGate?.dispatched;
	}
	async publishRecovery(ticket, pin, deadline) {
		const e = this.entry(ticket), p = this.pins.get(pin);
		if (!p || p.ticket !== ticket.id || p.owner !== ownerKey(ticket.owner) || e.retained?.pin !== pin || !this.retainedSealed(ticket) || e.busy) throw new Error("stale");
		const gate = new PublicationGate(Math.min(deadline, this.fs.now() + 1e4, e.retained.expiresMonotonicMs));
		const run = (this.publication.get(ticket.owner.sourceKey) ?? Promise.resolve()).catch(() => {}).then(() => {
			if (!this.retainedSealed(ticket) || e.busy) throw new Error("stale");
			e.recoveryGate = gate;
			return this.publishOne(e, gate);
		});
		this.publication.set(ticket.owner.sourceKey, run);
		return run;
	}
	async reserve(ticket, byteLength, memory, byteOffset = 0) {
		try {
			await this.admitTerminalDelete(ticket, byteLength);
			await this.reserveOne(ticket, byteLength, memory, byteOffset);
		} catch (error) {
			this.recordUnadmittedReserve(ticket);
			throw error;
		} finally {
			this.terminalDeletes.delete(ticket.id);
		}
	}
	async reserveOne(ticket, byteLength, memory, byteOffset = 0) {
		await this.prune();
		this.admitted(ticket);
		await this.checkImportAdmission(ticket);
		if (!Number.isSafeInteger(byteLength) || byteLength < 0 || byteLength > (ticket.metadata.kind === "record" ? 8388608 : ticket.metadata.kind === "settings" ? 69632 : 2097152)) throw new Error("size-limit");
		if (this.entries.has(ticket.id) || this.failedReserves.has(ticket.id) || this.entries.size + this.failedReserves.size >= 1024 || [...this.entries.values()].filter((e) => e.ticket.owner.sourceKey === ticket.owner.sourceKey).length >= 64) throw new Error("quota");
		if (ticket.metadata.kind !== ticket.target.kind) throw new Error("invalid-target");
		const targetKey = this.targetKey(ticket);
		if (ticket.target.kind !== "settings" && this.targets.has(targetKey)) throw new Error("write-in-progress");
		if (ticket.target.kind !== "settings") this.targets.set(targetKey, ticket.id);
		let held = null;
		let opened = null;
		let allocated = null;
		let importBudgetHeld = false;
		try {
			const ns = await this.ns(ticket.owner.sourceKey), location = await ns.location(ticket.target, true), old = await ns.head(location);
			this.admitted(ticket);
			this.cas(ticket, old);
			if (old) {
				await ns.verify(location, old);
				if (old.object) {
					const key = this.fs.name(ns.object(location, old));
					this.quota.holdTemporary(ticket.owner.sourceKey, key, old.byteLength);
					held = {
						source: ticket.owner.sourceKey,
						key
					};
				}
			}
			this.reserveImportBudget(ns, ticket, byteLength);
			importBudgetHeld = ticket.target.kind === "import";
			await this.fs.at("reserve", async () => {
				this.quota.reserve(ticket.id, ticket.owner.sourceKey, {
					bytes: ticket.metadata.kind === "record" ? byteLength : 0,
					create: ticket.target.kind === "record" && old === null,
					metadata: 32768 + (ticket.metadata.kind === "record" ? 0 : byteLength),
					lane: ticket.metadata.kind === "record" ? "write" : "metadata"
				}, (await this.fs.statfs(ns.path())).availableBytes);
			});
			allocated = ns;
			await this.fs.mkdir(ns.path("staging", ticket.id));
			await ns.writeNew(ns.path("staging", ticket.id, "intent.json"), {
				formatVersion: 1,
				ticket,
				byteLength,
				predecessor: old
			});
			const temp = ns.path("staging", ticket.id, "payload.tmp");
			await this.fs.at("open-temp", async () => {
				opened = await this.fs.open(temp, "create-exclusive");
			});
			const fd = opened;
			const frozen = JSON.parse(JSON.stringify(ticket));
			this.admitted(ticket);
			this.entries.set(ticket.id, {
				ticket: frozen,
				signature: JSON.stringify(ticket),
				ns,
				location,
				old,
				size: byteLength,
				fd,
				temp,
				object: null,
				gate: new PublicationGate(ticket.deadlineMonotonicMs, memory, byteOffset),
				hash: (0, node_crypto.createHash)("sha256"),
				received: 0,
				last: null,
				created: this.fs.now(),
				progress: this.fs.now(),
				state: "receiving",
				busy: false,
				head: null,
				accounted: false,
				finished: null,
				oldHeld: held !== null,
				cleaned: false
			});
		} catch (e) {
			if (opened) await this.fs.close(opened).catch(() => {});
			let clean = true;
			if (allocated) for (const name of [
				"payload.tmp",
				"sealed.json",
				"import-tag.json",
				"publication.json",
				"intent.json"
			]) {
				const p = allocated.path("staging", ticket.id, name);
				try {
					if (await this.fs.exists(p)) await this.fs.unlink(p);
				} catch {
					clean = false;
				}
			}
			if (clean && allocated) try {
				await this.fs.removeEmpty(allocated.path("staging", ticket.id));
			} catch {
				clean = false;
			}
			if (clean) {
				this.releaseTarget(ticket);
				this.quota.release(ticket.id);
				if (importBudgetHeld) this.importReservations.delete(ticket.id);
			} else this.failedReserves.set(ticket.id, {
				ticket: structuredClone(ticket),
				ns: allocated
			});
			if (held) this.quota.releaseTemporary(held.source, held.key);
			throw e;
		}
	}
	async append(ticket, offset, bytes) {
		const e = this.entry(ticket);
		this.live(e);
		if (e.state !== "receiving" || e.busy) throw new Error("sealed");
		if (bytes.length < 1 || bytes.length > 262144) throw new Error("size-limit");
		if (e.last && offset === e.last.offset && Buffer.from(bytes).equals(Buffer.from(e.last.bytes))) return e.received;
		if (offset !== e.received || offset + bytes.length > e.size) throw new Error("offset-mismatch");
		e.busy = true;
		try {
			this.live(e);
			await this.fs.at("chunk-write", () => writeAll(this.fs, e.fd, offset, bytes));
			e.hash.update(bytes);
			e.received += bytes.length;
			e.last = {
				offset,
				bytes: Uint8Array.from(bytes)
			};
			e.progress = this.fs.now();
			return e.received;
		} finally {
			e.busy = false;
		}
	}
	async seal(ticket, byteLength, sha256) {
		const e = this.entry(ticket);
		this.live(e);
		if (e.state === "sealed") {
			if (byteLength !== e.size || e.hash.copy().digest("hex") !== sha256) throw new Error("checksum-mismatch");
			return;
		}
		if (e.state !== "receiving" || e.busy) throw new Error("sealed");
		if (byteLength !== e.size || e.received !== e.size) throw new Error("incomplete");
		if (e.hash.copy().digest("hex") !== sha256) throw new Error("checksum-mismatch");
		e.busy = true;
		try {
			await this.fs.at("seal-sync", () => this.fs.sync(e.fd));
			await this.fs.close(e.fd);
			e.fd = null;
			e.state = "sealed";
			await e.ns.writeNew(e.ns.path("staging", ticket.id, "sealed.json"), {
				formatVersion: 1,
				byteLength,
				sha256
			});
			await this.fs.syncDirectory(e.ns.path("staging", ticket.id));
			e.state = "sealed";
			e.progress = this.fs.now();
			e.last = null;
		} finally {
			e.busy = false;
		}
	}
	fence(owner, deadlineMonotonicMs) {
		const key = ownerKey(owner), deadline = Math.min(this.frozen.get(key) ?? Infinity, deadlineMonotonicMs);
		this.frozen.set(key, deadline);
		const accepted = [];
		for (const e of this.entries.values()) if (ownerKey(e.ticket.owner) === key && e.finished === null) {
			e.gate.shorten(deadline, this.fs.now());
			accepted.push(e.ticket.id);
		}
		return Object.freeze(accepted);
	}
	fenceTarget(owner, id, deadlineMonotonicMs) {
		const key = JSON.stringify([ownerKey(owner), id]), deadline = Math.min(this.frozenTargets.get(key) ?? Infinity, deadlineMonotonicMs);
		this.frozenTargets.set(key, deadline);
		const accepted = [];
		for (const e of this.entries.values()) if (ownerKey(e.ticket.owner) === ownerKey(owner) && e.ticket.target.kind === "record" && e.ticket.target.id === id && e.finished === null) {
			e.gate.shorten(deadline, this.fs.now());
			accepted.push(e.ticket.id);
		}
		return Object.freeze(accepted);
	}
	async publish(ticket) {
		const e = this.entry(ticket);
		if (e.state === "committed") return {
			disposition: "committed",
			receipt: e.head.receipt
		};
		if (e.state === "unknown" || e.state === "publishing") return this.reconcile(ticket);
		const run = (this.publication.get(ticket.owner.sourceKey) ?? Promise.resolve()).catch(() => {}).then(() => this.publishOne(e));
		this.publication.set(ticket.owner.sourceKey, run);
		return run;
	}
	async publishOne(e, gate = e.gate) {
		if (e.state !== "sealed") return { disposition: "not-committed" };
		try {
			this.live(e, gate);
		} catch {
			return { disposition: "not-committed" };
		}
		if (this.uncertain.has(e.ticket.owner.sourceKey)) return { disposition: "unknown" };
		e.busy = true;
		try {
			const { ticket: t, ns, location: loc } = e;
			const revision = t.metadata.kind === "record" ? t.metadata.record.revision : "r_" + (0, node_crypto.randomUUID)().replaceAll("-", "");
			const deleted = t.metadata.kind === "record" && t.metadata.deleted;
			if (!e.head) e.head = {
				formatVersion: 1,
				metadata: t.metadata,
				target: t.target,
				object: deleted ? null : `${revision}.${t.metadata.kind === "record" ? "bin" : "json"}`,
				byteLength: e.size,
				sha256: e.hash.copy().digest("hex"),
				receipt: {
					revision,
					commitId: e.tag ? t.id : (0, node_crypto.randomUUID)(),
					durability: this.fs.durability
				},
				...e.tag ? { importTag: e.tag } : {}
			};
			parseHead(Buffer.from(JSON.stringify(e.head)));
			if (!deleted && !e.object) {
				this.live(e, gate);
				const destination = ns.object(loc, e.head);
				if (await this.fs.exists(destination)) throw new Error("revision-mismatch");
				await this.fs.at("object-rename", async () => {
					await this.fs.atomicReplace(e.temp, destination);
					e.object = destination;
					for (const pin of this.pins.values()) if (pin.ticket === t.id) {
						const oldKey = this.fs.name(pin.path);
						pin.path = destination;
						this.quota.releaseTemporary(pin.source, oldKey);
						this.quota.holdTemporary(pin.source, this.fs.name(destination), pin.length);
					}
				});
				await this.fs.at("object-dir-sync", async () => {
					await this.fs.syncDirectory(loc.objects);
					await this.fs.syncDirectory(ns.path("staging", t.id));
				});
			}
			this.live(e, gate);
			const current = await ns.head(loc);
			this.cas(t, current);
			if (current) await this.fs.at("backup-head", async () => {
				const backup = ns.path(...loc.parts, `${loc.name}.${t.id}.backup`);
				if (await this.fs.exists(backup)) await this.fs.unlink(backup);
				await ns.writeNew(backup, current);
				await this.fs.atomicReplace(backup, loc.previous);
				await this.fs.syncDirectory(loc.directory);
			});
			const headTemp = ns.path(...loc.parts, `${loc.name === "head.json" ? "head" : loc.name}.${t.id}.tmp`);
			if (await this.fs.exists(headTemp)) await this.fs.unlink(headTemp);
			await this.fs.at("head-write", () => ns.writeNew(headTemp, e.head));
			if (t.target.kind === "import") {
				const candidate = ns.path("staging", t.id, "publication.json");
				if (!await this.fs.exists(candidate)) await ns.writeNew(candidate, e.head);
				else if (!sameImportValue(parseHead(await this.fs.bytes(candidate, 8192)), e.head)) throw new Error("input-changed");
				await this.fs.syncDirectory(ns.path("staging", t.id));
			}
			await this.fs.fault("before-publish");
			this.live(e, gate);
			this.cas(t, await ns.head(loc));
			this.fs.profile.assertHeld();
			if (!gate.dispatch(this.fs.now())) return { disposition: "not-committed" };
			e.state = "publishing";
			this.uncertain.set(t.owner.sourceKey, t.id);
			if (t.metadata.kind === "import") await this.fs.at("import-marker", () => this.fs.atomicReplace(headTemp, loc.head));
			else await this.fs.atomicReplace(headTemp, loc.head);
			await this.fs.fault("after-publish");
			await this.fs.at("head-dir-sync", () => this.fs.syncDirectory(loc.directory));
			await this.fs.at("cache-publish", async () => {
				this.confirm(e);
			});
			await this.cleanup(e, true).catch(() => {});
			await this.fs.fault("receipt-send");
			return {
				disposition: "committed",
				receipt: e.head.receipt
			};
		} catch (error) {
			if (gate.dispatched) {
				e.state = "unknown";
				this.uncertain.set(e.ticket.owner.sourceKey, e.ticket.id);
				return { disposition: "unknown" };
			}
			throw error;
		} finally {
			e.busy = false;
		}
	}
	confirm(e) {
		if (!e.accounted) {
			const oldRecord = liveRecord(e.old), nextRecord = liveRecord(e.head);
			const size = (h) => h ? Buffer.byteLength(JSON.stringify(h)) + (h.metadata.kind === "record" ? 0 : h.byteLength) : 0;
			this.quota.commit(e.ticket.id, {
				committed: (nextRecord?.byteLength ?? 0) - (oldRecord?.byteLength ?? 0),
				records: Number(nextRecord !== null) - Number(oldRecord !== null),
				metadata: size(e.head) - size(e.old) + 32768,
				temporary: 0
			});
			if (e.ticket.target.kind === "import") {
				this.importCommitted.get(e.ns).set(e.ticket.target.key, e.size);
				this.importReservations.delete(e.ticket.id);
			}
			e.accounted = true;
		}
		e.state = "committed";
		e.finished ??= this.fs.now();
		this.uncertain.delete(e.ticket.owner.sourceKey);
		this.releaseTarget(e.ticket);
	}
	async reconcile(ticket) {
		const e = this.entry(ticket);
		if (!e.busy && e.state === "committed") return {
			disposition: "committed",
			receipt: e.head.receipt
		};
		if (e.state === "aborted") return { disposition: "not-committed" };
		if (e.busy && (e.gate.dispatched || e.recoveryGate?.dispatched)) return { disposition: "unknown" };
		if (!(e.gate.dispatched || e.recoveryGate?.dispatched)) return { disposition: "not-committed" };
		try {
			const current = await e.ns.head(e.location);
			if (current && e.head && current.receipt.commitId === e.head.receipt.commitId) {
				await e.ns.verify(e.location, current);
				await this.fs.syncDirectory(e.location.directory);
				this.confirm(e);
				return {
					disposition: "committed",
					receipt: current.receipt
				};
			}
			if ((current?.receipt.commitId ?? null) === (e.old?.receipt.commitId ?? null)) {
				if (current) await e.ns.verify(e.location, current);
				this.uncertain.delete(e.ticket.owner.sourceKey);
				e.state = "sealed";
				await this.abortKnownUnpublished(e);
				return { disposition: "not-committed" };
			}
		} catch {}
		this.uncertain.set(ticket.owner.sourceKey, ticket.id);
		return { disposition: "unknown" };
	}
	async abort(ticket) {
		this.fs.profile.assertHeld();
		const tombstone = this.tombstones.get(ticket.id);
		if (!this.entries.has(ticket.id) && !this.failedReserves.has(ticket.id) && ticket.owner.hostEpoch === this.fs.profile.hostEpoch && tombstone?.disposition === "aborted" && tombstone.until > this.fs.now() && tombstone.signature === JSON.stringify(ticket)) return "aborted";
		const failed = this.failedReserves.get(ticket.id);
		if (failed) {
			if (JSON.stringify(ticket) !== JSON.stringify(failed.ticket)) throw new Error("stale");
			for (const name of [
				"payload.tmp",
				"sealed.json",
				"import-tag.json",
				"publication.json",
				"intent.json"
			]) {
				const p = failed.ns.path("staging", ticket.id, name);
				if (await this.fs.exists(p)) await this.fs.unlink(p);
			}
			await this.fs.removeEmpty(failed.ns.path("staging", ticket.id));
			this.quota.release(ticket.id);
			this.releaseTarget(ticket);
			this.failedReserves.delete(ticket.id);
			this.importReservations.delete(ticket.id);
			for (const [identity, write] of this.documentWrites) if (write.ticket.id === ticket.id) this.documentWrites.delete(identity);
			this.tombstones.set(ticket.id, {
				signature: JSON.stringify(ticket),
				disposition: "aborted",
				until: this.fs.now() + 12e4
			});
			while (this.tombstones.size > 1024) this.tombstones.delete(this.tombstones.keys().next().value);
			return "aborted";
		}
		const e = this.entry(ticket);
		if (e.state === "committed" && !e.busy) return "committed";
		if (e.state === "aborted") return "aborted";
		e.gate.shorten(this.fs.now(), this.fs.now());
		e.recoveryGate?.shorten(this.fs.now(), this.fs.now());
		if (e.busy) return "unknown";
		if (e.gate.dispatched || e.recoveryGate?.dispatched) {
			const result = await this.reconcile(ticket);
			if (result.disposition === "committed") return "committed";
			if (result.disposition === "unknown") return "unknown";
		}
		await this.abortKnownUnpublished(e);
		return "aborted";
	}
	async abortKnownUnpublished(e) {
		const cleanup = (this.publication.get(e.ticket.owner.sourceKey) ?? Promise.resolve()).catch(() => {}).then(() => this.removeUnpublished(e));
		this.publication.set(e.ticket.owner.sourceKey, cleanup);
		await cleanup;
	}
	async removeUnpublished(e) {
		if (e.fd) {
			await this.fs.close(e.fd);
			e.fd = null;
		}
		for (const p of [
			e.temp,
			e.object,
			e.ns.path(...e.location.parts, `${e.location.name === "head.json" ? "head" : e.location.name}.${e.ticket.id}.tmp`),
			e.ns.path(...e.location.parts, `${e.location.name}.${e.ticket.id}.backup`),
			e.ns.path("staging", e.ticket.id, "sealed.json"),
			e.ns.path("staging", e.ticket.id, "import-tag.json"),
			e.ns.path("staging", e.ticket.id, "publication.json"),
			e.ns.path("staging", e.ticket.id, "intent.json")
		]) if (p && await this.fs.exists(p)) await this.fs.unlink(p);
		const current = await e.ns.head(e.location);
		if (current?.receipt.commitId === e.old?.receipt.commitId && await this.fs.exists(e.location.previous)) {
			if (parseHead(await this.fs.bytes(e.location.previous, 8192)).receipt.commitId === current?.receipt.commitId) await this.fs.unlink(e.location.previous);
		}
		await this.fs.removeEmpty(e.ns.path("staging", e.ticket.id));
		this.quota.release(e.ticket.id);
		this.releaseOld(e);
		e.state = "aborted";
		e.finished ??= this.fs.now();
		this.releaseTarget(e.ticket);
		this.importReservations.delete(e.ticket.id);
	}
	releaseOld(e) {
		if (e.oldHeld && e.old?.object) {
			this.quota.releaseTemporary(e.ticket.owner.sourceKey, this.fs.name(e.ns.object(e.location, e.old)));
			e.oldHeld = false;
		}
	}
	async cleanup(e, serialized = false) {
		if (!serialized) {
			const cleanup = (this.publication.get(e.ticket.owner.sourceKey) ?? Promise.resolve()).catch(() => {}).then(() => this.cleanup(e, true));
			this.publication.set(e.ticket.owner.sourceKey, cleanup);
			await cleanup;
			return;
		}
		if (e.cleaned) return;
		await this.fs.at("cleanup", async () => {
			if ((await e.ns.head(e.location))?.receipt.commitId === e.head?.receipt.commitId && await this.fs.exists(e.location.previous)) await this.fs.unlink(e.location.previous);
			for (const name of [
				"payload.tmp",
				"sealed.json",
				"import-tag.json",
				"publication.json",
				"intent.json"
			]) {
				const p = e.ns.path("staging", e.ticket.id, name);
				if (await this.fs.exists(p)) await this.fs.unlink(p);
			}
			if (e.old?.object) {
				const p = e.ns.object(e.location, e.old), key = this.fs.name(p);
				if ([...this.pins.values()].some((pin) => this.fs.name(pin.path) === key)) {
					this.gcHeld.set(key, {
						source: e.ticket.owner.sourceKey,
						key
					});
					e.oldHeld = false;
				} else {
					if (await this.fs.exists(p)) await this.fs.unlink(p);
					this.releaseOld(e);
				}
			}
			await this.fs.removeEmpty(e.ns.path("staging", e.ticket.id));
			await this.fs.syncDirectory(e.location.directory);
		});
		this.quota.adjustMetadata(e.ticket.owner.sourceKey, -32768);
		e.cleaned = true;
	}
	async settled(owner) {
		if (owner.hostEpoch !== this.fs.profile.hostEpoch) throw new Error("stale");
		await this.prune();
		const id = this.uncertain.get(owner.sourceKey);
		if (id) {
			const e = this.entries.get(id);
			if ((await this.reconcile(e.ticket)).disposition === "unknown") throw new Error("publish-uncertain");
		}
		return this.ns(owner.sourceKey);
	}
	async settings(owner) {
		const ns = await this.settled(owner), loc = await ns.location({
			kind: "settings",
			expectedRevision: null
		}), head = await ns.head(loc);
		if (!head) return null;
		await ns.verify(loc, head);
		const body = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(await this.fs.bytes(ns.object(loc, head), 69632)));
		if (body.formatVersion !== 1) throw new Error("unsupported-format");
		if (head.metadata.kind !== "settings" || body.schemaVersion !== head.metadata.schemaVersion || body.validationDigest !== head.metadata.validationDigest || Buffer.byteLength(JSON.stringify(body.values)) > 65536) throw new Error("corrupt");
		return {
			schemaVersion: body.schemaVersion,
			revision: head.receipt.revision,
			values: body.values
		};
	}
	async stat(owner, id) {
		const ns = await this.settled(owner), loc = await ns.location({
			kind: "record",
			id,
			expectedRevision: null
		}), head = await ns.head(loc), record = liveRecord(head);
		if (!head || !record) throw new Error("not-found");
		await ns.verify(loc, head);
		return structuredClone(record);
	}
	async open(owner, id, revision) {
		const ns = await this.settled(owner);
		if ([...this.pins.values()].filter((p) => p.source === owner.sourceKey).length >= 4) throw new Error("quota");
		const loc = await ns.location({
			kind: "record",
			id,
			expectedRevision: revision
		}), head = await ns.head(loc);
		if (!liveRecord(head) || !head) throw new Error("not-found");
		if (head.receipt.revision !== revision) throw new Error("revision-mismatch");
		await ns.verify(loc, head);
		const p = ns.object(loc, head), key = this.fs.name(p);
		this.quota.holdTemporary(owner.sourceKey, key, head.byteLength);
		try {
			const fd = await this.fs.open(p, "read"), pin = (0, node_crypto.randomUUID)();
			this.pins.set(pin, {
				owner: ownerKey(owner),
				source: owner.sourceKey,
				ns,
				path: p,
				fd,
				length: head.byteLength,
				created: this.fs.now(),
				used: this.fs.now(),
				busy: Promise.resolve()
			});
			return pin;
		} catch (e) {
			this.quota.releaseTemporary(owner.sourceKey, key);
			throw e;
		}
	}
	async read(owner, pin, offset, maxBytes) {
		await this.prune();
		const p = this.pins.get(pin);
		if (!p || p.owner !== ownerKey(owner)) throw new Error("stale");
		if (!Number.isSafeInteger(offset) || offset < 0 || offset > p.length || !Number.isSafeInteger(maxBytes) || maxBytes < 1 || maxBytes > 262144) throw new Error("invalid-range");
		const work = p.busy.catch(() => {}).then(async () => {
			p.used = this.fs.now();
			return offset === p.length ? /* @__PURE__ */ new Uint8Array() : this.fs.read(p.fd, offset, Math.min(maxBytes, p.length - offset));
		});
		p.busy = work;
		return work;
	}
	async closePin(id, p) {
		this.pins.delete(id);
		await p.busy.catch(() => {});
		await this.fs.close(p.fd);
		const key = this.fs.name(p.path);
		this.quota.releaseTemporary(p.source, key);
		if (![...this.pins.values()].some((pin) => this.fs.name(pin.path) === key) && this.gcHeld.has(key)) try {
			await this.fs.unlink(p.path);
			this.quota.releaseTemporary(p.source, key);
			this.gcHeld.delete(key);
		} catch {}
		if (this.closed.size < 1024 && [...this.closed.values()].filter((c) => c.owner === p.owner).length < 64) this.closed.set(id, {
			owner: p.owner,
			until: this.fs.now() + 12e4
		});
	}
	async close(owner, pin) {
		const p = this.pins.get(pin);
		if (!p) {
			const old = this.closed.get(pin);
			if (old?.owner === ownerKey(owner) && old.until > this.fs.now()) return;
			throw new Error("stale");
		}
		if (p.owner !== ownerKey(owner)) throw new Error("stale");
		await this.closePin(pin, p);
	}
	async list(owner, input) {
		const ns = await this.settled(owner);
		if (!Number.isSafeInteger(input.limit) || input.limit < 1 || input.limit > 64) throw new Error("invalid-range");
		let page, offset = 0;
		if (input.cursor) {
			const cursor = this.cursors.get(input.cursor);
			if (!cursor || cursor.page.owner !== ownerKey(owner) || cursor.page.kind !== input.kind || cursor.page.limit !== input.limit) throw new Error("stale");
			page = cursor.page;
			offset = cursor.offset;
		} else {
			if ([...this.pages].filter((p) => p.source === owner.sourceKey).length >= 4) throw new Error("quota");
			const entries = [];
			for (const loc of await ns.locations()) {
				const r = liveRecord(await ns.head(loc));
				if (r && (input.kind === void 0 || input.kind === r.kind)) entries.push(structuredClone(r));
			}
			entries.sort((a, b) => b.createdAt - a.createdAt || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
			const bytes = Buffer.byteLength(JSON.stringify(entries));
			if ([...this.pages].filter((p) => p.source === owner.sourceKey).reduce((n, p) => n + p.bytes, bytes) > 524288 || [...this.pages].reduce((n, p) => n + p.bytes, bytes) > 8388608) throw new Error("quota");
			page = {
				owner: ownerKey(owner),
				source: owner.sourceKey,
				kind: input.kind,
				limit: input.limit,
				entries,
				created: this.fs.now(),
				used: this.fs.now(),
				bytes,
				tokens: /* @__PURE__ */ new Map()
			};
			this.pages.add(page);
		}
		page.used = this.fs.now();
		const entries = page.entries.slice(offset, offset + page.limit), next = offset + entries.length;
		if (next === page.entries.length) {
			if (page.tokens.size === 0) this.pages.delete(page);
			return { entries: structuredClone(entries) };
		}
		let token = page.tokens.get(next);
		if (!token) {
			token = (0, node_crypto.randomUUID)();
			page.tokens.set(next, token);
			this.cursors.set(token, {
				page,
				offset: next
			});
		}
		const result = {
			entries: structuredClone(entries),
			nextCursor: token
		};
		if (Buffer.byteLength(JSON.stringify({
			ok: true,
			value: result
		})) > 262144) throw new Error("size-limit");
		return result;
	}
	async tagImport(ticket, tag) {
		const e = this.entry(ticket);
		this.live(e);
		if (e.state !== "receiving" || e.received !== 0 || e.busy || e.tag) throw new Error("sealed");
		e.busy = true;
		try {
			const parsed = importTagSchema.parse(tag);
			const saved = await this.loadImport(ticket.owner, parsed.importId);
			const item = saved?.plan.items.find((i) => i.key === parsed.itemKey);
			const attempt = saved?.items.find((i) => i.key === parsed.itemKey)?.publicationTicket;
			if (!item || !attempt || !sameImportValue(attempt, ticket) || !sameImportAttempt(item.ticket, ticket) || !sameImportValue(item.tag, parsed)) throw new Error("input-changed");
			await e.ns.writeNew(e.ns.path("staging", ticket.id, "import-tag.json"), {
				formatVersion: 1,
				tag: parsed
			});
			await this.fs.syncDirectory(e.ns.path("staging", ticket.id));
			e.tag = parsed;
		} finally {
			e.busy = false;
		}
	}
	async importReceipts(owner, id) {
		const saved = await this.loadImport(owner, id);
		if (!saved) return [];
		const ns = await this.ns(owner.sourceKey), receipts = [];
		for (const item of saved.plan.items) {
			const evidence = saved.items.find((e) => e.key === item.key), attempt = evidence.publicationTicket;
			if (!attempt) continue;
			if (evidence.state === "committed" && evidence.receipt) {
				receipts.push({
					tag: item.tag,
					ticket: attempt,
					receipt: evidence.receipt
				});
				continue;
			}
			const loc = await ns.location(attempt.target), head = await ns.head(loc);
			if (!head?.importTag || !sameImportValue(head.importTag, item.tag)) continue;
			await ns.verify(loc, head);
			if (head.receipt.commitId !== attempt.id || head.sha256 !== item.mappedSha256 || head.byteLength !== item.byteLength || !sameImportValue(head.metadata, attempt.metadata) || !sameImportValue(head.target, attempt.target)) throw new Error("input-changed");
			await this.fs.syncDirectory(loc.directory);
			receipts.push({
				tag: item.tag,
				ticket: attempt,
				receipt: head.receipt
			});
		}
		if (Buffer.byteLength(JSON.stringify(receipts)) > 2097152) throw new Error("size-limit");
		return receipts;
	}
	async auxiliary(owner, kind, key) {
		this.fs.profile.assertHeld();
		if (owner.hostEpoch !== this.fs.profile.hostEpoch) throw new Error("stale");
		const ns = await this.ns(owner.sourceKey), loc = await ns.location({
			kind,
			key
		}), head = await ns.head(loc);
		if (!head) return null;
		await ns.verify(loc, head);
		return this.fs.bytes(ns.object(loc, head), 2097152);
	}
	importMutations = /* @__PURE__ */ new Map();
	mutateImport(owner, id, run) {
		const key = JSON.stringify([owner.sourceKey, id]);
		const result = (this.importMutations.get(key) ?? Promise.resolve()).catch(() => {}).then(run);
		this.importMutations.set(key, result);
		result.finally(() => {
			if (this.importMutations.get(key) === result) this.importMutations.delete(key);
		}).catch(() => {});
		return result;
	}
	planImport(owner, plan) {
		return this.mutateImport(owner, plan.id, () => this.planImportOne(owner, plan));
	}
	recordImport(owner, id, evidence) {
		return this.mutateImport(owner, id, () => this.recordImportOne(owner, id, evidence));
	}
	completeImport(owner, id) {
		return this.mutateImport(owner, id, () => this.completeImportOne(owner, id));
	}
	documentWrites = /* @__PURE__ */ new Map();
	async reconcileDocument(ticket) {
		if (this.failedReserves.has(ticket.id) && await this.abort(ticket) === "aborted") return { disposition: "not-committed" };
		const tombstone = this.tombstones.get(ticket.id);
		if (tombstone?.signature === JSON.stringify(ticket) && tombstone.disposition === "aborted") return { disposition: "not-committed" };
		return this.reconcile(ticket);
	}
	async writeDocument(owner, kind, key, value) {
		const bytes = Buffer.from(JSON.stringify(value)), identity = JSON.stringify([
			owner.sourceKey,
			kind,
			key
		]);
		if (bytes.length > 2097152 || Buffer.byteLength(key) > 128) throw new Error("size-limit");
		if (kind === "import" && key.startsWith("import/")) importDocumentSchema.parse(value);
		const previous = this.documentWrites.get(identity);
		if (previous) {
			let result = await previous.result;
			if (result.disposition === "unknown") result = await this.reconcileDocument(previous.ticket);
			if (result.disposition === "unknown") throw new Error("publish-uncertain");
			this.documentWrites.delete(identity);
			if (result.disposition === "committed") this.forgetCompletedDocument(previous.ticket);
			if (result.disposition === "committed" && Buffer.from(previous.bytes).equals(bytes)) return;
			if (result.disposition === "committed") throw new Error("reload-import");
		}
		const ticket = {
			id: (0, node_crypto.randomUUID)(),
			owner: structuredClone(owner),
			deadlineMonotonicMs: this.fs.now() + 1e4,
			metadata: {
				kind,
				key
			},
			target: {
				kind,
				key
			}
		};
		if (kind === "recovery") this.recoveryDocuments.add(ticket.id);
		this.admitted(ticket);
		const result = Promise.resolve().then(async () => {
			try {
				await this.reserve(ticket, bytes.length);
				for (let offset = 0; offset < bytes.length; offset += 262144) await this.append(ticket, offset, bytes.subarray(offset, offset + 262144));
				await this.seal(ticket, bytes.length, (0, node_crypto.createHash)("sha256").update(bytes).digest("hex"));
				const outcome = await this.publish(ticket);
				return outcome.disposition === "unknown" ? await this.reconcile(ticket) : outcome;
			} catch {
				if (this.entries.has(ticket.id)) {
					if (await this.abort(ticket) !== "aborted") return this.reconcile(ticket);
				}
				if (this.failedReserves.has(ticket.id)) return { disposition: "unknown" };
				return { disposition: "not-committed" };
			}
		});
		result.finally(() => this.recoveryDocuments.delete(ticket.id)).catch(() => {});
		this.documentWrites.set(identity, {
			ticket,
			bytes,
			result
		});
		const outcome = await result;
		if (outcome.disposition === "unknown") throw new Error("publish-uncertain");
		this.documentWrites.delete(identity);
		if (outcome.disposition !== "committed") throw new Error("not-committed");
		this.forgetCompletedDocument(ticket);
	}
	forgetCompletedDocument(ticket) {
		const entry = this.entries.get(ticket.id);
		if (entry && entry.state === "committed" && entry.cleaned && !entry.busy && (ticket.target.kind === "import" || ticket.target.kind === "recovery")) this.forgetEntry(ticket.id, entry);
	}
	admitImport(owner, id, key) {
		return this.mutateImport(owner, id, async () => {
			this.fs.profile.assertHeld();
			if (owner.hostEpoch !== this.fs.profile.hostEpoch) throw new Error("stale");
			const identity = JSON.stringify([
				owner.sourceKey,
				"import",
				id
			]), pending = this.documentWrites.get(identity);
			if (pending) {
				let outcome = await pending.result;
				if (outcome.disposition === "unknown") outcome = await this.reconcileDocument(pending.ticket);
				if (outcome.disposition === "unknown") throw new Error("publish-uncertain");
				this.documentWrites.delete(identity);
			}
			const saved = await this.loadImport(owner, id);
			if (!saved || saved.complete) throw new Error("stale");
			const index = saved.plan.items.findIndex((item) => item.key === key), item = saved.plan.items[index], prior = saved.items[index];
			if (!item || !prior || prior.state === "committed" || prior.state === "skipped" || owner.pluginId !== item.ticket.owner.pluginId || owner.sourceKey !== item.ticket.owner.sourceKey) throw new Error("stale");
			const old = prior.publicationTicket;
			const competing = this.targets.get(this.targetKey(item.ticket));
			if (competing && competing !== old?.id) throw new Error("write-in-progress");
			if (old && !sameImportAttempt(item.ticket, old)) throw new Error("input-changed");
			if (old && this.entries.has(old.id)) {
				const live = this.entry(old);
				if (live.state !== "committed" && live.state !== "aborted") live.gate.shorten(this.fs.now(), this.fs.now());
				if (await this.abort(old) === "unknown") throw new Error("publish-uncertain");
			}
			const outcome = await this.reconcileImport(item.ticket);
			if (outcome.disposition === "committed") {
				if (!old || !outcome.receipt) throw new Error("unverified-receipt");
				await this.recordImportOne(owner, id, {
					...prior,
					state: "committed",
					receipt: outcome.receipt,
					skipReason: null
				});
				throw new Error("already-committed");
			}
			if (outcome.disposition !== "not-committed") throw new Error("publish-uncertain");
			if (old && sameImportValue(old.owner, owner) && !this.entries.has(old.id) && old.deadlineMonotonicMs > this.fs.now()) {
				this.admitted(old);
				return structuredClone(old);
			}
			const deadline = old?.owner.hostEpoch === owner.hostEpoch ? old.deadlineMonotonicMs : this.fs.now() + 1e4;
			if (deadline <= this.fs.now()) throw new Error("stale");
			const attempt = {
				...structuredClone(item.ticket),
				id: (0, node_crypto.randomUUID)(),
				owner: structuredClone(owner),
				deadlineMonotonicMs: deadline
			};
			this.admitted(attempt);
			const items = saved.items.map((e, i) => i === index ? {
				...e,
				state: "pending",
				receipt: null,
				skipReason: null,
				publicationTicket: attempt
			} : e);
			await this.writeDocument(owner, "import", id, {
				formatVersion: 1,
				...saved,
				items
			});
			return structuredClone(attempt);
		});
	}
	async loadImport(owner, id) {
		if (Buffer.byteLength(id) > 128 || !id.startsWith("import/")) throw new Error("size-limit");
		const bytes = await this.auxiliary(owner, "import", id);
		if (!bytes) return null;
		const raw = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
		if (raw.formatVersion !== 1) throw new Error("unsupported-format");
		const saved = importDocumentSchema.parse(raw);
		if (saved.plan.id !== id || saved.plan.targetSourceKey !== owner.sourceKey) throw new Error("input-changed");
		return {
			plan: saved.plan,
			items: saved.items,
			complete: saved.complete
		};
	}
	async planImportOne(owner, plan) {
		importPlanSchema.parse(plan);
		if (plan.targetSourceKey !== owner.sourceKey || plan.items.some((i) => ownerKey(i.ticket.owner) !== ownerKey(owner))) throw new Error("stale");
		const old = await this.loadImport(owner, plan.id);
		if (old) {
			if (!sameImportValue(old.plan, plan)) throw new Error("input-changed");
			return;
		}
		await this.writeDocument(owner, "import", plan.id, {
			formatVersion: 1,
			plan,
			items: plan.items.map((i) => ({
				key: i.key,
				state: "pending",
				receipt: null,
				skipReason: null,
				publicationTicket: null
			})),
			complete: false
		});
	}
	async recordImportOne(owner, id, evidence) {
		importItemEvidenceSchema.parse(evidence);
		const saved = await this.loadImport(owner, id);
		if (!saved) throw new Error("not-found");
		if (saved.plan.devicePreferencesEvidence && evidence.state === "skipped") throw new Error("unverified-receipt");
		const index = saved.plan.items.findIndex((i) => i.key === evidence.key);
		if (index < 0 || saved.complete) throw new Error("stale");
		if (evidence.state === "committed") {
			const receipt = (await this.importReceipts(owner, id)).find((r) => r.tag.itemKey === evidence.key);
			if (!receipt || JSON.stringify(receipt.receipt) !== JSON.stringify(evidence.receipt)) throw new Error("input-changed");
		}
		const prior = saved.items[index];
		if (!sameImportValue(prior.publicationTicket, evidence.publicationTicket)) throw new Error("input-changed");
		if (evidence.state === "skipped") {
			const attempt = prior.publicationTicket;
			if (attempt && this.entries.has(attempt.id)) {
				this.fenceTargetOrTicket(attempt);
				if (await this.abort(attempt) !== "aborted") throw new Error("publish-uncertain");
			}
			if ((await this.reconcileImport(saved.plan.items[index].ticket)).disposition !== "not-committed") throw new Error("publish-uncertain");
		}
		if ((prior.state === "committed" || prior.state === "skipped") && JSON.stringify(prior) !== JSON.stringify(evidence)) throw new Error("input-changed");
		const items = [...saved.items];
		items[index] = evidence;
		await this.writeDocument(owner, "import", id, {
			formatVersion: 1,
			...saved,
			items
		});
	}
	async reconcileImport(ticket) {
		publicationTicketSchema.parse(ticket);
		this.fs.profile.assertHeld();
		try {
			return await this.reconcileImportEvidence(ticket);
		} catch (error) {
			if (error instanceof Error && ["stale", "not-primary"].includes(error.message)) throw error;
			return { disposition: "unknown" };
		}
	}
	async reconcileImportEvidence(ticket) {
		const ns = await this.ns(ticket.owner.sourceKey);
		if (ticket.target.kind === "import") {
			const resolved = await resolvedImport(ns, ticket.id);
			if (resolved) {
				const raw = JSON.parse(Buffer.from(await this.fs.bytes(ns.path("staging", ticket.id, "intent.json"), 32768)).toString("utf8"));
				if (!sameImportValue(publicationTicketSchema.parse(raw.ticket), ticket)) throw new Error("stale");
				return resolved.disposition === "committed" ? {
					disposition: "committed",
					receipt: resolved.receipt
				} : { disposition: "not-committed" };
			}
			const loc = await ns.location(ticket.target), head = await ns.head(loc);
			if (head) {
				await ns.verify(loc, head);
				const bytes = await this.fs.bytes(ns.object(loc, head), 2097152);
				if (ticket.target.key.startsWith("nonce/") || ticket.target.key.startsWith("barrier/")) {
					if (sameImportValue((ticket.target.key.startsWith("nonce/") ? parseNonceDocument(bytes) : parseBarrierDocument(bytes)).ticket, ticket)) {
						await this.fs.syncDirectory(loc.directory);
						return {
							disposition: "committed",
							receipt: head.receipt
						};
					}
				}
			}
			if (this.entries.has(ticket.id)) return this.reconcile(ticket);
			const intentPath = ns.path("staging", ticket.id, "intent.json");
			if (!await this.fs.exists(intentPath)) return { disposition: "unknown" };
			const raw = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(await this.fs.bytes(intentPath, 32768)));
			if (raw.formatVersion !== 1 || Object.keys(raw).sort().join(",") !== "byteLength,formatVersion,predecessor,ticket" || !sameImportValue(publicationTicketSchema.parse(raw.ticket), ticket)) throw new Error("stale");
			const candidatePath = ns.path("staging", ticket.id, "publication.json");
			if (head && await this.fs.exists(candidatePath)) {
				const candidate = parseHead(await this.fs.bytes(candidatePath, 8192));
				if (sameImportValue(candidate.target, ticket.target) && sameImportValue(candidate.metadata, ticket.metadata) && sameImportValue(candidate, head)) {
					await this.fs.syncDirectory(loc.directory);
					return {
						disposition: "committed",
						receipt: head.receipt
					};
				}
			}
			const predecessor = raw.predecessor === null ? null : parseHead(Buffer.from(JSON.stringify(raw.predecessor)));
			if (predecessor) await ns.verify(loc, predecessor);
			if (this.blockedSources.has(ticket.owner.sourceKey) || this.uncertain.has(ticket.owner.sourceKey)) return { disposition: "unknown" };
			return sameImportValue(head, predecessor) ? { disposition: "not-committed" } : { disposition: "unknown" };
		}
		for (const loc of await ns.locations()) {
			const head = await ns.head(loc);
			if (head?.target.kind !== "import" || !head.target.key.startsWith("import/")) continue;
			await ns.verify(loc, head);
			const saved = importDocumentSchema.parse(JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(await this.fs.bytes(ns.object(loc, head), 2097152))));
			if (saved.plan.targetSourceKey !== ns.sourceKey || saved.plan.id !== head.target.key) throw new Error("input-changed");
			const index = saved.plan.items.findIndex((item, i) => sameImportValue(item.ticket, ticket) || sameImportValue(saved.items[i].publicationTicket, ticket));
			if (index < 0) continue;
			const item = saved.plan.items[index], evidence = saved.items[index], attempt = evidence.publicationTicket;
			if (evidence.state === "committed" && evidence.receipt) return {
				disposition: "committed",
				receipt: evidence.receipt
			};
			if (attempt && this.entries.has(attempt.id)) {
				const live = await this.reconcile(attempt);
				if (live.disposition !== "not-committed") return live;
				if (this.unresolvedTicket(attempt.id)) return { disposition: "unknown" };
			}
			const target = await ns.location(item.ticket.target), current = await ns.head(target);
			if (current) await ns.verify(target, current);
			if (attempt && current?.importTag && sameImportValue(current.importTag, item.tag) && current.receipt.commitId === attempt.id && sameImportValue(current.metadata, attempt.metadata) && sameImportValue(current.target, attempt.target) && current.sha256 === item.mappedSha256 && current.byteLength === item.byteLength) {
				await this.fs.syncDirectory(target.directory);
				return {
					disposition: "committed",
					receipt: current.receipt
				};
			}
			if (this.blockedSources.has(ns.sourceKey) || this.uncertain.has(ns.sourceKey) || [...this.entries.values()].some((e) => e.ticket.owner.sourceKey === ns.sourceKey && (e.busy || e.state === "publishing" || e.state === "unknown"))) return { disposition: "unknown" };
			if ((item.ticket.target.kind === "record" || item.ticket.target.kind === "settings") && (current?.receipt.revision ?? null) === item.ticket.target.expectedRevision) return { disposition: "not-committed" };
			return { disposition: "unknown" };
		}
		throw new Error("stale");
	}
	async completeImportOne(owner, id) {
		const saved = await this.loadImport(owner, id);
		if (!saved) throw new Error("not-found");
		if (saved.complete) return;
		const receipts = await this.importReceipts(owner, id);
		const items = saved.items.map((e) => {
			const r = receipts.find((r) => r.tag.itemKey === e.key);
			return e.state === "committed" || e.state === "skipped" ? e : r ? {
				key: e.key,
				state: "committed",
				receipt: r.receipt,
				skipReason: null,
				publicationTicket: r.ticket
			} : e;
		});
		if (items.length !== saved.plan.items.length || items.some((e) => e.state !== "committed" && e.state !== "skipped")) throw new Error("incomplete");
		await this.writeDocument(owner, "import", id, {
			formatVersion: 1,
			...saved,
			items,
			complete: true
		});
	}
	async settingsDigest(owner) {
		const ns = await this.settled(owner), loc = await ns.location({
			kind: "settings",
			expectedRevision: null
		}), head = await ns.head(loc);
		if (!head) return null;
		await ns.verify(loc, head);
		if (head.metadata.kind !== "settings") throw new Error("corrupt");
		return {
			schemaVersion: head.metadata.schemaVersion,
			validationDigest: head.metadata.validationDigest,
			revision: head.receipt.revision
		};
	}
	evidencePages = /* @__PURE__ */ new Map();
	async auxiliaryKeys(owner, kind, cursor) {
		const signature = JSON.stringify([ownerKey(owner), kind]);
		let page;
		if (cursor) {
			page = this.evidencePages.get(cursor);
			if (!page || page.signature !== signature || page.expires <= this.fs.now()) throw new Error("stale");
		} else {
			const ns = await this.ns(owner.sourceKey), items = [];
			for (const loc of await ns.locations()) {
				const h = await ns.head(loc);
				if (h?.target.kind === kind && "key" in h.target) items.push(h.target.key);
			}
			if (items.length > 512 || this.evidencePages.size >= 32) throw new Error("quota");
			page = {
				signature,
				items: items.sort(),
				offset: 0,
				expires: this.fs.now() + 3e4
			};
		}
		const keys = page.items.slice(page.offset, page.offset + 64), next = page.offset + keys.length;
		if (next === page.items.length) return {
			keys,
			nextCursor: null
		};
		const nextCursor = (0, node_crypto.randomUUID)();
		this.evidencePages.set(nextCursor, {
			...page,
			offset: next
		});
		return {
			keys,
			nextCursor
		};
	}
	async saveCheckpoint(owner, value) {
		const document = checkpointDocumentSchema.parse({
			formatVersion: 1,
			...value
		});
		const bytes = await this.auxiliary(owner, "recovery", value.checkpoint);
		if (!bytes) throw new Error("stale");
		if (checkpointDocumentSchema.parse(JSON.parse(Buffer.from(bytes).toString("utf8"))).record.id !== document.record.id || !await this.ownsCheckpoint(owner, value.checkpoint, value.record.id)) throw new Error("stale");
		await this.writeDocument(owner, "recovery", value.checkpoint, document);
	}
	async saveRecovery(value) {
		storedRecoverySchema.parse(value);
		if (value.ticket && ownerKey(value.ticket.owner) !== ownerKey(value.owner)) throw new Error("stale");
		if (value.sealedPin) {
			const e = value.ticket ? this.entries.get(value.ticket.id) : void 0;
			const pin = this.pins.get(value.sealedPin);
			if (!e || e.signature !== JSON.stringify(value.ticket) || !pin || pin.ticket !== e.ticket.id || pin.owner !== ownerKey(value.owner) || e.retained?.pin !== value.sealedPin || this.fs.now() >= e.retained.expiresMonotonicMs || ![
				"sealed",
				"publishing",
				"unknown",
				"committed"
			].includes(e.state) || e.received !== e.size) throw new Error("incomplete");
			const expiresAt = Math.min(value.expiresAt ?? Infinity, Date.now() + e.retained.expiresMonotonicMs - this.fs.now());
			value = {
				...value,
				expiresAt,
				report: {
					...value.report,
					records: value.report.records.map((r) => r.payload === "complete-staging" ? {
						...r,
						expiresAt: Math.min(r.expiresAt ?? Infinity, expiresAt)
					} : r)
				}
			};
		}
		await this.writeDocument(value.owner, "recovery", value.id, {
			formatVersion: 1,
			value
		});
	}
	async recoveryPage(cursor) {
		const all = [];
		for (const pending of this.namespaces.values()) {
			const ns = await pending;
			for (const loc of await ns.locations()) {
				const head = await ns.head(loc);
				if (head?.target.kind !== "recovery") continue;
				await ns.verify(loc, head);
				const raw = JSON.parse(Buffer.from(await this.fs.bytes(ns.object(loc, head), 2097152)).toString("utf8"));
				if (raw.formatVersion !== 1) throw new Error("unsupported-format");
				if ("checkpoint" in raw) {
					if (checkpointDocumentSchema.parse(raw).checkpoint !== head.target.key) throw new Error("corrupt");
					continue;
				}
				if (raw.removed === true) {
					strictObject({
						formatVersion: literal(1),
						removed: literal(true),
						id: uuid
					}).parse(raw);
					if (raw.id !== head.target.key) throw new Error("corrupt");
					continue;
				}
				strictObject({
					formatVersion: literal(1),
					value: storedRecoverySchema
				}).parse(raw);
				const value = storedRecoverySchema.parse(raw.value);
				if (value.id !== head.target.key || value.owner.sourceKey !== ns.sourceKey) throw new Error("corrupt");
				const retained = value.sealedPin ? this.pins.get(value.sealedPin) : void 0;
				const entry = value.ticket ? this.entries.get(value.ticket.id) : void 0;
				if (value.ticket && entry && !sameImportValue(entry.ticket, value.ticket)) throw new Error("stale");
				if (entry) value.ticket = structuredClone(entry.ticket);
				if (value.ticket && entry && (entry.state === "unknown" || entry.state === "publishing")) {
					if ((await this.reconcile(value.ticket)).disposition === "unknown") value.report = {
						...value.report,
						state: "uncertain",
						blocker: true
					};
				}
				if (value.sealedPin && (!retained || !entry || retained.ticket !== value.ticket?.id || retained.owner !== ownerKey(value.owner) || !retained.expires || this.fs.now() >= retained.expires || value.ticket?.owner.hostEpoch !== this.fs.profile.hostEpoch)) {
					value.sealedPin = null;
					value.report = {
						...value.report,
						state: value.report.state === "uncertain" ? "uncertain" : "checkpoint-only",
						blocker: true,
						records: value.report.records.map((r) => ({
							id: r.id,
							committedRevision: r.committedRevision,
							final: r.final,
							payload: r.committedRevision ? "checkpoint-only" : "none"
						}))
					};
				}
				if (value.ticket && value.ticket.owner.hostEpoch !== this.fs.profile.hostEpoch && value.ticket.target.kind === "record") {
					const original = value.ticket, target = original.target;
					const location = await ns.location(target), current = await ns.head(location);
					if (current) await ns.verify(location, current);
					if (original.metadata.kind === "record" && current && sameImportValue(current.metadata, original.metadata) && sameImportValue(current.target, target) && current.receipt.revision === original.metadata.record.revision) {
						const record = original.metadata.record, final = record.checkpoint === "final";
						value.ticket = null;
						value.sealedPin = null;
						value.report = {
							...value.report,
							state: record.checkpoint === "open" ? "checkpoint-only" : "saved",
							blocker: record.checkpoint === "open",
							records: [{
								id: record.id,
								committedRevision: record.revision,
								final,
								payload: "checkpoint-only"
							}]
						};
					} else if (target.kind === "record" && (current?.receipt.revision ?? null) === target.expectedRevision) {
						value.ticket = null;
						value.sealedPin = null;
						value.report = {
							...value.report,
							state: "checkpoint-only",
							blocker: true
						};
					} else value.report = {
						...value.report,
						state: "uncertain",
						blocker: true
					};
				}
				all.push(value);
			}
		}
		all.sort((a, b) => a.id.localeCompare(b.id));
		const signature = "recovery", page = cursor ? this.evidencePages.get(cursor) : void 0;
		if (cursor && (!page || page.signature !== signature || page.expires <= this.fs.now())) throw new Error("stale");
		const offset = page?.offset ?? 0, items = [];
		for (const value of all.slice(offset, offset + 64)) {
			if (Buffer.byteLength(JSON.stringify([...items, value])) > 262144) break;
			items.push(value);
		}
		const next = offset + items.length;
		if (next === all.length) return {
			items,
			nextCursor: null
		};
		if (!items.length || this.evidencePages.size >= 32) throw new Error("quota");
		const nextCursor = (0, node_crypto.randomUUID)();
		this.evidencePages.set(nextCursor, {
			signature,
			items: all.map((v) => v.id),
			offset: next,
			expires: this.fs.now() + 3e4
		});
		return {
			items,
			nextCursor
		};
	}
	async loadRecovery(id) {
		let cursor;
		do {
			const p = await this.recoveryPage(cursor);
			const found = p.items.find((v) => v.id === id);
			if (found) return found;
			cursor = p.nextCursor ?? void 0;
		} while (cursor);
		return null;
	}
	async removeRecovery(id) {
		const old = await this.loadRecovery(id);
		if (!old) return;
		await this.writeDocument({
			...old.owner,
			hostEpoch: this.fs.profile.hostEpoch
		}, "recovery", id, {
			formatVersion: 1,
			removed: true,
			id
		});
	}
	async flushEvidence(barrier, tickets) {
		const accepted = tickets.map((t) => t.id), incomplete = [], unknown = [];
		for (const t of tickets) {
			const e = this.entries.get(t.id);
			if (!e) {
				const tombstone = this.tombstones.get(t.id);
				if (!tombstone || tombstone.until <= this.fs.now() || tombstone.signature !== JSON.stringify(t)) unknown.push(t.id);
				else if (tombstone.disposition === "aborted") incomplete.push(t.id);
				continue;
			}
			if (e.retained && e.state === "sealed" && !e.gate.dispatched && !e.recoveryGate?.dispatched) {
				incomplete.push(t.id);
				continue;
			}
			if (this.fs.now() >= barrier.deadlineMonotonicMs || e.state === "unknown" || e.state === "publishing") {
				if ((await this.reconcile(t)).disposition !== "committed") unknown.push(t.id);
			} else if (e.state !== "committed") incomplete.push(t.id);
		}
		const ns = await this.ns(barrier.scope.owner.sourceKey);
		for (const loc of await ns.locations()) {
			const record = liveRecord(await ns.head(loc));
			if (record?.checkpoint === "open" && (barrier.scope.kind === "namespace" || record.id === barrier.scope.recordId)) incomplete.push(record.id);
		}
		return {
			state: unknown.length ? "unknown" : incomplete.length ? "failed" : "saved",
			accepted,
			incomplete,
			unknown
		};
	}
	fenceTargetOrTicket(ticket) {
		const e = this.entries.get(ticket.id);
		if (e && e.state !== "committed" && e.state !== "aborted" && e.signature === JSON.stringify(ticket)) {
			e.gate.shorten(this.fs.now(), this.fs.now());
			e.recoveryGate?.shorten(this.fs.now(), this.fs.now());
		}
	}
	settledDisposition(id) {
		const e = this.entries.get(id);
		if (e) return !e.busy && (e.state === "committed" || e.state === "aborted") ? e.state : null;
		const tombstone = this.tombstones.get(id);
		return tombstone && tombstone.until > this.fs.now() ? tombstone.disposition : null;
	}
	taggedImport(ticket, tag) {
		const e = this.entries.get(ticket.id);
		return !!e && e.signature === JSON.stringify(ticket) && sameImportValue(e.tag, tag);
	}
	unresolvedTicket(id) {
		const e = this.entries.get(id);
		return !!e && (e.state === "unknown" || e.state === "publishing" || e.busy);
	}
	async collect(owner) {
		const ns = await this.settled(owner), protectedPaths = /* @__PURE__ */ new Set();
		for (const e of this.entries.values()) if (e.ticket.owner.sourceKey === owner.sourceKey && e.state === "committed" && !e.cleaned) await this.cleanup(e);
		for (const pin of this.pins.values()) protectedPaths.add(this.fs.name(pin.path));
		for (const e of this.entries.values()) if (e.ticket.owner.sourceKey === owner.sourceKey && e.finished === null) {
			protectedPaths.add(this.fs.name(e.temp));
			if (e.object) protectedPaths.add(this.fs.name(e.object));
			if (e.old?.object) protectedPaths.add(this.fs.name(ns.object(e.location, e.old)));
		}
		for (const p of await garbageCandidates(ns, protectedPaths)) await this.fs.unlink(p);
	}
	async dispose() {
		for (const e of this.entries.values()) if (e.state !== "committed" && e.state !== "aborted") e.gate.shorten(this.fs.now(), this.fs.now());
		for (const [id, pin] of this.pins) await this.closePin(id, pin);
		for (const e of this.entries.values()) if (e.fd && !e.busy) {
			await this.fs.close(e.fd);
			e.fd = null;
		}
		if (this.failedReserves.size || [...this.entries.values()].some((e) => e.busy || e.state === "unknown")) throw new Error("publish-uncertain");
	}
};
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/limits.js
var PLUGIN_LIMITS = {
	messageBytes: 1048576,
	headerBytes: 1024,
	idLength: 128,
	textLength: 200,
	messageLength: 2e3,
	errorMessageLength: 2e3,
	commandsPerPlugin: 64,
	activationEvents: 64,
	manifestBytes: 65536
};
var DIAGNOSTIC_HELP_LIMITS = {
	fileBytes: 1048576,
	entriesPerPlugin: 512,
	entryBytes: 16384,
	stepsPerLocale: 16,
	linksPerEntry: 4,
	urlLength: 2048,
	lineLength: 500,
	blockLength: 4e3,
	totalBytes: 8388608
};
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/common.js
var SINGLE_LINE = /^[^\u0000-\u001F\u007F]*$/;
var MULTI_LINE = /^[^\u0000-\u0008\u000B-\u001F\u007F]*$/;
var namespacedIdSchema = string().min(3).max(PLUGIN_LIMITS.idLength).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*(?:\.[a-z0-9]+(?:-[a-z0-9]+)*)+$/);
var semverSchema = string().max(64).regex(/^(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/);
var pluginLocaleSchema = _enum(["en", "zh-TW"]);
var permissionSchema = _enum([
	"ui.notifications",
	"ui.panels",
	"ui.status",
	"settings.read",
	"settings.write",
	"storage.read",
	"storage.write",
	"storage.export",
	"ui.clipboard",
	"devices.read",
	"devices.connect",
	"devices.control"
]);
var text$3 = string().min(1).max(PLUGIN_LIMITS.textLength).regex(SINGLE_LINE);
var localizedTextSchema = union([text$3, looseObject({
	en: text$3,
	"zh-TW": text$3.optional()
})]);
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/ui-limits.js
var UI_LIMITS_V1 = Object.freeze({
	resourceBytes: 262144,
	sourceBytes: 1048576,
	hostBytes: 8388608,
	nodes: 256,
	depth: 8,
	dataSlots: 64,
	fields: 32,
	stringCodePoints: 4e3,
	labelCodePoints: 200,
	enumValues: 32,
	enumCodePoints: 128,
	conditionDepth: 4,
	conditionNodes: 32,
	resourceConditionNodes: 256,
	sourcePanels: 4,
	sourceStatus: 2,
	hostPanels: 16,
	hostStatus: 16,
	dataBytes: 65536,
	formBytes: 16384,
	statusDataBytes: 16384,
	patchBytes: 65536,
	patchEntries: 64,
	patchesPerSecond: 10,
	pendingPatches: 4,
	argumentBytes: 16384,
	invokeBytes: 65536,
	resultBytes: 16384,
	sourcePending: 16,
	hostPending: 256,
	sourceSubscriptions: 32,
	eventBytes: 65536,
	queueBytes: 262144,
	controlSlots: 8,
	controlBytes: 16384,
	activeHolds: 1,
	challengeMs: 100,
	expiryMs: 350,
	pendingChallenges: 4,
	sourceReadMs: 5e3,
	initializeMs: 1e4,
	commandMs: 3e4,
	queryMs: 5e3,
	shutdownRequestMs: 2e3,
	cursorMs: 3e4,
	catalogEntries: 16,
	catalogBytes: 262144,
	resourceReplyBytes: 524288,
	detailBytes: 4096,
	completedInvocations: 64,
	invocationRetentionMs: 3e4,
	hostCompletedInvocations: 256,
	hostCompletedBytes: 4194304
});
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/device-types.js
var handleSchema$1 = string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
var counterSchema = number().int().min(0).max(Number.MAX_SAFE_INTEGER);
var boundedIdSchema = string().min(1).max(64).regex(/^[A-Za-z0-9][A-Za-z0-9:._-]*$/);
var wireText = (min, max) => string().min(min).max(2 * max).regex(SINGLE_LINE);
var capabilitySchema = _enum([
	"connection.v1",
	"telemetry.v1",
	"inputModes.v1",
	"finiteMotion.v1",
	"recordingReservation.v1"
]);
var requirementCapabilitySchema = string().max(64).regex(/^[A-Za-z][A-Za-z0-9]*\.v[1-9][0-9]*$/);
var resourceOwnerSchema = strictObject({
	sourceKey: string().max(160).regex(/^(?:builtin:[a-z0-9.-]+|dev:[0-9a-f]{16})$/),
	pluginId: namespacedIdSchema,
	generation: counterSchema,
	hostEpoch: handleSchema$1,
	processEpoch: handleSchema$1
});
var addressSchema = string().min(2).max(45).regex(/^[0-9a-f:.]+$/);
var deviceCandidateSchema = strictObject({
	candidateId: handleSchema$1,
	providerId: namespacedIdSchema,
	name: wireText(1, 200),
	transport: _enum([
		"usb",
		"wifi",
		"mock"
	]),
	address: addressSchema.exactOptional(),
	identity: _enum([
		"stable",
		"session-only",
		"ambiguous"
	]),
	expiresInMs: number().int().min(0).max(3e4)
});
var deviceSessionSnapshotSchema = strictObject({
	sessionId: handleSchema$1,
	providerId: namespacedIdSchema,
	providerGeneration: counterSchema,
	revision: counterSchema,
	name: wireText(1, 200),
	transport: _enum([
		"usb",
		"wifi",
		"mock"
	]),
	capabilities: array(capabilitySchema).max(5),
	state: _enum([
		"connected",
		"quarantined",
		"disconnecting",
		"disconnected"
	]),
	foreground: _enum([
		"none",
		"motion",
		"program",
		"file",
		"mode",
		"recovery"
	]),
	recording: boolean(),
	sourceRevision: counterSchema
});
var sourceState = _enum([
	"ready",
	"empty",
	"initializing",
	"unknown",
	"error"
]);
var channelDefinitionSchema = strictObject({
	channelId: handleSchema$1,
	kind: _enum([
		"input",
		"output-angle",
		"battery-percent",
		"battery-voltage"
	]),
	portId: boundedIdSchema.nullable(),
	typeId: boundedIdSchema,
	modeId: boundedIdSchema.nullable(),
	component: number().int().min(0).max(7),
	name: wireText(1, 80),
	modeName: wireText(0, 80),
	unit: wireText(0, 32),
	decimals: number().int().min(0).max(9),
	state: sourceState
});
var actuatorDefinitionSchema = strictObject({
	actuatorId: handleSchema$1,
	portId: boundedIdSchema,
	name: wireText(1, 80),
	typeId: boundedIdSchema,
	state: sourceState
});
var sourceCatalogSchema = strictObject({
	sessionId: handleSchema$1,
	sourceRevision: counterSchema,
	channels: array(channelDefinitionSchema).max(38),
	actuators: array(actuatorDefinitionSchema).max(4)
});
var overflowGapSchema = strictObject({
	fromSequence: counterSchema,
	toSequence: counterSchema,
	reason: literal("overflow")
});
var telemetryFrameSchema = strictObject({
	sequence: counterSchema,
	sampledAt: counterSchema,
	elapsedMs: number().min(0),
	sourceRevision: counterSchema,
	status: _enum([
		"ok",
		"busy",
		"error",
		"gap"
	]),
	values: array(strictObject({
		channelId: handleSchema$1,
		value: number().nullable()
	})).max(38),
	program: _enum([
		"stopped",
		"running",
		"unknown"
	]),
	gap: strictObject({
		fromSequence: counterSchema,
		toSequence: counterSchema,
		reason: _enum([
			"busy",
			"overflow",
			"read-error"
		])
	}).exactOptional()
});
var readSnapshotSchema = strictObject({
	sessionId: handleSchema$1,
	revision: counterSchema,
	status: _enum([
		"fresh",
		"stale",
		"busy",
		"unavailable"
	]),
	ageMs: number().min(0).nullable(),
	frame: telemetryFrameSchema.nullable()
});
var inputModesValueSchema = strictObject({
	sourceRevision: counterSchema,
	portId: boundedIdSchema,
	typeId: boundedIdSchema,
	currentModeId: boundedIdSchema.nullable(),
	modes: array(strictObject({
		modeId: boundedIdSchema,
		name: wireText(1, 80)
	})).max(8)
});
var motionBase = {
	actuatorId: handleSchema$1,
	power: number().int().min(1).max(100),
	direction: union([literal(1), literal(-1)]),
	brake: boolean()
};
var motionSpecSchema = discriminatedUnion("mode", [
	strictObject({
		...motionBase,
		mode: literal("jog")
	}),
	strictObject({
		...motionBase,
		mode: literal("timed"),
		durationMs: number().int().min(100).max(5e3)
	}),
	strictObject({
		...motionBase,
		mode: literal("relative-angle"),
		degrees: number().int().min(1).max(3600)
	})
]);
var reservationSnapshotSchema = strictObject({
	reservationId: handleSchema$1,
	sessionId: handleSchema$1,
	revision: counterSchema,
	state: _enum([
		"active",
		"ending",
		"ended"
	]),
	channels: array(channelDefinitionSchema).min(1).max(4),
	firstSequence: counterSchema,
	lastSequence: counterSchema,
	reason: _enum([
		"active",
		"released",
		"source-changed",
		"disconnected",
		"suspended",
		"core-disconnect",
		"retired",
		"renderer-lost",
		"limit",
		"overflow"
	])
});
var pluginErrorCodeSchema = _enum([
	"PLUGIN_E_MANIFEST",
	"PLUGIN_E_API_VERSION",
	"PLUGIN_E_RESERVED_ID",
	"PLUGIN_E_DIAGNOSTIC_HELP",
	"PLUGIN_E_STATIC_LANGUAGE",
	"PLUGIN_E_STATIC_LANGUAGE_CONFLICT",
	"PLUGIN_E_STATIC_LANGUAGE_REGISTRATION",
	"PLUGIN_E_DUPLICATE_ID",
	"PLUGIN_E_COMMAND_NAMESPACE",
	"PLUGIN_E_DUPLICATE_COMMAND",
	"PLUGIN_E_ACTIVATION",
	"PLUGIN_E_RUNTIME_NOT_ALLOWED",
	"PLUGIN_E_FRONTEND_REQUIRES_BUILTIN",
	"PLUGIN_E_BACKEND_REQUIRES_BUILTIN",
	"PLUGIN_E_LANGUAGE_SERVICE_REQUIRES_BUILTIN",
	"PLUGIN_E_PROVIDER_CONFLICT",
	"PLUGIN_E_ENTRY",
	"PLUGIN_E_LAUNCH",
	"PLUGIN_E_HANDSHAKE",
	"PLUGIN_E_PROTOCOL",
	"PLUGIN_E_UNRESPONSIVE",
	"PLUGIN_E_CRASHED",
	"PLUGIN_E_CRASH_LOOP",
	"PLUGIN_E_TIMEOUT",
	"PLUGIN_E_CANCELLED",
	"PLUGIN_E_COMMAND_FAILED",
	"PLUGIN_E_UNKNOWN_COMMAND",
	"PLUGIN_E_UNKNOWN_PLUGIN",
	"PLUGIN_E_DISABLED",
	"PLUGIN_E_BUILTIN_REQUIRED",
	"PLUGIN_E_SAFE_MODE",
	"PLUGIN_E_STATE_SAVE",
	"PLUGIN_E_STATE_CORRUPT",
	"PLUGIN_E_SHUTTING_DOWN",
	"PLUGIN_E_SOURCE_TIMEOUT",
	"PLUGIN_E_SOURCE_EXISTS",
	"PLUGIN_E_DEVELOPER_MODE",
	"PLUGIN_E_SESSION_SOURCE",
	"PLUGIN_E_PYTHON_UNUSABLE",
	"PLUGIN_E_PERMISSION_DENIED",
	"PLUGIN_E_STALE_RESOURCE",
	"PLUGIN_E_RESOURCE_LIMIT",
	"PLUGIN_E_DEVICE_PROVIDER_REQUIRES_BUILTIN",
	"PLUGIN_E_DEVICE_UNAVAILABLE",
	"PLUGIN_E_DEVICE_CAPABILITY",
	"PLUGIN_E_DEVICE_BUSY",
	"PLUGIN_E_DEVICE_AUTHORITY",
	"PLUGIN_E_DEVICE_OPERATION",
	"PLUGIN_E_DEVICE_STOP_UNCONFIRMED",
	"PLUGIN_E_UI_RESOURCE",
	"PLUGIN_E_UI_VERSION",
	"PLUGIN_E_SETTINGS_SCHEMA",
	"PLUGIN_E_SETTINGS_CONFLICT",
	"PLUGIN_E_SETTINGS_SAVE",
	"PLUGIN_E_STORAGE_QUOTA",
	"PLUGIN_E_STORAGE_CONFLICT",
	"PLUGIN_E_STORAGE_IO",
	"PLUGIN_E_STORAGE_VERSION"
]);
var reasons$1 = Object.values({
	PLUGIN_E_DEVICE_UNAVAILABLE: [
		"provider-disabled",
		"disconnected",
		"quarantined",
		"ui-scope-unavailable"
	],
	PLUGIN_E_DEVICE_CAPABILITY: ["unsupported-capability"],
	PLUGIN_E_DEVICE_BUSY: [
		"foreground",
		"recording",
		"connecting",
		"source-changing"
	],
	PLUGIN_E_DEVICE_AUTHORITY: [
		"unbound",
		"joining",
		"unsynced",
		"not-holder",
		"viewer",
		"authority-changed",
		"scope-expired"
	],
	PLUGIN_E_DEVICE_OPERATION: [
		"preflight-program-running",
		"preflight-output-unknown",
		"preflight-output-moving",
		"motor-unavailable",
		"source-changed",
		"mode-unavailable",
		"provider-failure",
		"provider-contract",
		"journal-unwritable",
		"journal-corrupt",
		"identity-ambiguous"
	],
	PLUGIN_E_DEVICE_STOP_UNCONFIRMED: [
		"readback-failed",
		"stop-deadline",
		"connection-lost",
		"provider-stalled"
	],
	PLUGIN_E_TIMEOUT: ["deadline"],
	PLUGIN_E_CANCELLED: ["cancelled"],
	PLUGIN_E_DISABLED: ["disabled"],
	PLUGIN_E_SAFE_MODE: ["safe-mode"],
	PLUGIN_E_SHUTTING_DOWN: ["shutting-down"],
	PLUGIN_E_CRASHED: ["process-lost"],
	PLUGIN_E_PROTOCOL: ["protocol"],
	PLUGIN_E_PROVIDER_CONFLICT: ["provider-conflict"]
}).flat();
var deviceErrorDetailSchema = strictObject({
	kind: literal("device"),
	reason: _enum(reasons$1),
	operationId: handleSchema$1.exactOptional(),
	dispatch: _enum([
		"not-sent",
		"sent",
		"unknown"
	]),
	stopConfirmation: _enum([
		"not-required",
		"pending",
		"confirmed",
		"unconfirmed"
	])
});
var permissionErrorDetailSchema = strictObject({
	kind: literal("permission"),
	reason: _enum(["permission", "user-action-required"])
});
var deviceFailureDetailSchema = union([
	deviceErrorDetailSchema,
	permissionErrorDetailSchema,
	strictObject({
		kind: literal("resource"),
		reason: _enum([
			"stale",
			"quota",
			"rate",
			"queue"
		]),
		resource: _enum([
			"operation",
			"subscription",
			"candidate",
			"reservation",
			"journal",
			"rpc",
			"ui-binding",
			"storage-write",
			"storage-read",
			"storage-list",
			"storage-export",
			"storage-watch"
		]),
		limit: counterSchema.exactOptional()
	})
]);
var deviceErrorSchema = strictObject({
	code: pluginErrorCodeSchema,
	message: wireText(1, 2e3),
	detail: deviceErrorDetailSchema
});
var businessResultSchema = (value, detail) => union([strictObject({
	ok: literal(true),
	value
}), strictObject({
	ok: literal(false),
	error: strictObject({
		code: pluginErrorCodeSchema,
		message: wireText(1, 2e3),
		detail: detail.exactOptional()
	})
})]);
var resources150 = [
	"operation",
	"subscription",
	"candidate",
	"reservation",
	"journal",
	"rpc"
];
var resources160 = [...resources150, "ui-binding"];
var resources170 = [
	...resources160,
	"storage-write",
	"storage-read",
	"storage-list",
	"storage-export",
	"storage-watch"
];
function commonFailureSchemaFor(batch) {
	const resources = batch === "1.5.0" ? resources150 : batch === "1.6.0" ? resources160 : resources170;
	return union([
		strictObject({
			ok: literal(false),
			error: strictObject({
				code: literal("PLUGIN_E_PERMISSION_DENIED"),
				message: wireText(1, 2e3),
				detail: permissionErrorDetailSchema
			})
		}),
		strictObject({
			ok: literal(false),
			error: strictObject({
				code: literal("PLUGIN_E_STALE_RESOURCE"),
				message: wireText(1, 2e3),
				detail: strictObject({
					kind: literal("resource"),
					reason: literal("stale"),
					resource: _enum(resources),
					limit: counterSchema.exactOptional()
				})
			})
		}),
		strictObject({
			ok: literal(false),
			error: strictObject({
				code: literal("PLUGIN_E_RESOURCE_LIMIT"),
				message: wireText(1, 2e3),
				detail: strictObject({
					kind: literal("resource"),
					reason: _enum([
						"quota",
						"rate",
						"queue"
					]),
					resource: _enum(resources),
					limit: counterSchema.exactOptional()
				})
			})
		})
	]);
}
var commonFailureSchema = commonFailureSchemaFor("1.6.0");
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/ui-resource.js
var localIdSchema = string().min(1).max(32).regex(/^[a-z][a-z0-9-]{0,31}$/);
var stringBody = string().min(1).max(8e3);
var stringLabel = string().min(1).max(400);
var uiTextSchema = strictObject({
	en: stringBody,
	"zh-TW": stringBody.exactOptional()
});
var uiLabelSchema = strictObject({
	en: stringLabel,
	"zh-TW": stringLabel.exactOptional()
});
var uiScalarSchema = union([
	string().max(8e3),
	number(),
	boolean(),
	_null()
]);
var valueSpecSchema = union([
	strictObject({
		type: literal("string"),
		maxLength: number().int().min(1).max(4e3),
		nullable: boolean()
	}),
	strictObject({
		type: literal("number"),
		min: number(),
		max: number(),
		integer: boolean(),
		nullable: boolean()
	}),
	strictObject({
		type: literal("boolean"),
		nullable: boolean()
	}),
	strictObject({
		type: literal("enum"),
		values: array(string().min(1).max(256)).min(1).max(32),
		nullable: boolean()
	})
]);
var valueRefSchema = strictObject({
	scope: _enum(["data", "form"]),
	key: localIdSchema
});
var dataRefSchema = strictObject({
	scope: literal("data"),
	key: localIdSchema
});
var displayValueSchema = union([strictObject({ literal: uiScalarSchema }), strictObject({ ref: valueRefSchema })]);
var displayTextSchema = union([strictObject({ text: uiTextSchema }), strictObject({ ref: dataRefSchema })]);
function conditionAt(depth) {
	const leaf = union([strictObject({
		op: _enum(["eq", "ne"]),
		left: valueRefSchema,
		right: uiScalarSchema
	}), strictObject({
		op: _enum([
			"lt",
			"lte",
			"gt",
			"gte"
		]),
		left: valueRefSchema,
		right: number()
	})]);
	if (depth === 1) return leaf;
	const child = conditionAt(depth - 1);
	return union([
		leaf,
		strictObject({
			op: _enum(["all", "any"]),
			items: array(child).min(1).max(8)
		}),
		strictObject({
			op: literal("not"),
			item: child
		})
	]);
}
var conditionSchema = conditionAt(4);
var argumentBindingsSchema = record$1(localIdSchema, displayValueSchema);
var uiActionSchema = union([
	strictObject({
		kind: literal("command"),
		command: namespacedIdSchema,
		arguments: argumentBindingsSchema
	}),
	strictObject({
		kind: literal("core"),
		action: literal("openPanel"),
		panelId: namespacedIdSchema
	}),
	strictObject({
		kind: literal("core"),
		action: literal("stop"),
		operation: dataRefSchema
	}),
	strictObject({
		kind: literal("core"),
		action: literal("disconnect"),
		session: dataRefSchema
	}),
	strictObject({
		kind: literal("core"),
		action: literal("openRecovery")
	})
]);
var base$2 = {
	id: localIdSchema,
	visibleWhen: conditionSchema.exactOptional(),
	enabledWhen: conditionSchema.exactOptional()
};
var input = {
	field: localIdSchema,
	label: uiLabelSchema,
	help: uiTextSchema.exactOptional()
};
var numberInput = {
	...input,
	step: number().min(Number.MIN_VALUE),
	unit: uiLabelSchema.exactOptional()
};
var tone = _enum([
	"neutral",
	"info",
	"success",
	"warning",
	"error"
]);
var uiNodeV1Schema = union([
	strictObject({
		...base$2,
		type: literal("group"),
		label: uiLabelSchema.exactOptional(),
		help: uiTextSchema.exactOptional(),
		layout: _enum(["stack", "row"]),
		children: array(localIdSchema).min(1).max(32)
	}),
	strictObject({
		...base$2,
		type: literal("text"),
		value: displayTextSchema,
		emphasis: _enum(["normal", "strong"])
	}),
	strictObject({
		...base$2,
		type: literal("help"),
		value: displayTextSchema
	}),
	strictObject({
		...base$2,
		...input,
		type: literal("textInput"),
		placeholder: uiLabelSchema.exactOptional()
	}),
	strictObject({
		...base$2,
		...numberInput,
		type: literal("number")
	}),
	strictObject({
		...base$2,
		...numberInput,
		type: literal("range")
	}),
	strictObject({
		...base$2,
		...input,
		type: literal("choice"),
		presentation: _enum(["select", "segmented"]),
		options: array(strictObject({
			value: string().min(1).max(256),
			label: uiLabelSchema
		})).min(1).max(32)
	}),
	strictObject({
		...base$2,
		...input,
		type: literal("boolean")
	}),
	strictObject({
		...base$2,
		type: literal("action"),
		label: uiLabelSchema,
		action: uiActionSchema,
		variant: _enum([
			"normal",
			"primary",
			"danger"
		])
	}),
	strictObject({
		...base$2,
		type: literal("holdAction"),
		label: uiLabelSchema,
		command: namespacedIdSchema,
		arguments: argumentBindingsSchema,
		help: uiTextSchema.exactOptional()
	}),
	strictObject({
		...base$2,
		type: literal("status"),
		text: displayTextSchema,
		tone
	}),
	strictObject({
		...base$2,
		type: literal("alert"),
		text: displayTextSchema,
		severity: _enum([
			"info",
			"warning",
			"error"
		])
	}),
	strictObject({
		...base$2,
		type: literal("progress"),
		value: displayValueSchema,
		max: number().min(Number.MIN_VALUE),
		label: uiLabelSchema
	}),
	strictObject({
		...base$2,
		type: literal("keyValue"),
		rows: array(strictObject({
			id: localIdSchema,
			label: uiLabelSchema,
			value: displayValueSchema,
			unit: uiLabelSchema.exactOptional()
		})).min(1).max(16)
	})
]);
var dataSlotSchema = strictObject({
	schema: valueSpecSchema,
	initial: uiScalarSchema
});
var fieldSchema = strictObject({
	schema: valueSpecSchema,
	initial: uiScalarSchema,
	required: boolean(),
	requiredWhen: conditionSchema.exactOptional()
});
var panelResourceV1Schema = strictObject({
	kind: literal("panel"),
	data: record$1(localIdSchema, dataSlotSchema),
	fields: record$1(localIdSchema, fieldSchema),
	root: localIdSchema,
	nodes: array(uiNodeV1Schema).min(1).max(256)
});
var statusResourceV1Schema = strictObject({
	kind: literal("status"),
	text: displayTextSchema,
	tone,
	data: record$1(localIdSchema, dataSlotSchema),
	visibleWhen: conditionSchema.exactOptional()
});
union([panelResourceV1Schema, statusResourceV1Schema]);
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/ui-types.js
var uiResourceDeclarationSchema = strictObject({
	version: number().int().min(1).max(65535),
	path: string().min(1).max(600)
});
var panelDeclarationSchema = strictObject({
	id: namespacedIdSchema,
	title: uiLabelSchema,
	location: literal("right"),
	resource: uiResourceDeclarationSchema
});
var statusDeclarationSchema = strictObject({
	id: namespacedIdSchema,
	title: uiLabelSchema,
	resource: uiResourceDeclarationSchema
});
var contextCommandDeclarationSchema = strictObject({
	id: namespacedIdSchema,
	title: uiLabelSchema,
	invocation: literal("context-v1"),
	arguments: record$1(localIdSchema, valueSpecSchema)
});
var uiBindingSchema = strictObject({
	contributionId: namespacedIdSchema,
	panelInstance: handleSchema$1,
	kind: _enum(["panel", "status"]),
	uiResourceGeneration: counterSchema,
	generation: counterSchema,
	hostEpoch: handleSchema$1,
	processEpoch: handleSchema$1
});
var scalars = record$1(localIdSchema, uiScalarSchema);
var uiStateSnapshotSchema = strictObject({
	binding: uiBindingSchema,
	revision: counterSchema,
	data: scalars,
	formRevision: counterSchema,
	form: scalars,
	valid: boolean(),
	visible: boolean(),
	locale: pluginLocaleSchema
});
var uiSubscriptionSnapshotSchema = strictObject({
	instances: array(uiBindingSchema).max(6),
	states: array(uiStateSnapshotSchema).max(1),
	locale: pluginLocaleSchema,
	theme: _enum(["light", "dark"])
});
var commandInvocationSchema = strictObject({
	version: literal(1),
	invocationId: handleSchema$1,
	command: namespacedIdSchema,
	arguments: scalars,
	context: strictObject({
		contextRef: handleSchema$1.nullable(),
		origin: _enum(["panel", "management"]),
		locale: pluginLocaleSchema,
		binding: uiBindingSchema.exactOptional(),
		motionScopeRef: handleSchema$1.exactOptional(),
		actionRef: handleSchema$1.exactOptional(),
		form: strictObject({
			revision: counterSchema,
			values: scalars
		}).exactOptional(),
		trigger: union([strictObject({ kind: literal("activate") }), strictObject({
			kind: literal("hold"),
			phase: _enum([
				"begin",
				"end",
				"cancel"
			]),
			gestureRef: handleSchema$1
		})])
	})
});
var commandValueSchema = strictObject({
	output: scalars,
	fieldErrors: array(strictObject({
		field: localIdSchema,
		message: uiTextSchema
	})).max(32)
});
var detailFields = {
	kind: literal("ui"),
	contributionId: namespacedIdSchema.exactOptional(),
	fieldPath: string().max(256).regex(/^[A-Za-z0-9_$.[\]-]*$/).exactOptional(),
	limit: _enum(Object.keys(UI_LIMITS_V1)).exactOptional(),
	allowed: counterSchema.exactOptional(),
	actual: counterSchema.exactOptional()
};
var uiResourceDetailSchema = strictObject({
	...detailFields,
	reason: _enum([
		"read",
		"path",
		"schema",
		"reference",
		"cycle",
		"translation",
		"limit",
		"renderer"
	])
});
var uiVersionDetailSchema = strictObject({
	...detailFields,
	reason: _enum(["version", "negotiation"])
});
var uiFailureSchema = union([strictObject({
	ok: literal(false),
	error: strictObject({
		code: literal("PLUGIN_E_UI_RESOURCE"),
		message: string().max(4e3),
		detail: uiResourceDetailSchema.exactOptional()
	})
}), strictObject({
	ok: literal(false),
	error: strictObject({
		code: literal("PLUGIN_E_UI_VERSION"),
		message: string().max(4e3),
		detail: uiVersionDetailSchema.exactOptional()
	})
})]);
function uiResultSchema(value) {
	return union([
		strictObject({
			ok: literal(true),
			value
		}),
		commonFailureSchema,
		uiFailureSchema
	]);
}
var uiRevokeReasonSchema = _enum([
	"release",
	"pointer-cancel",
	"focus-loss",
	"hidden",
	"closed",
	"form-change",
	"action-disabled",
	"heartbeat-expired",
	"authority-lost",
	"generation-retired",
	"resource-replaced",
	"renderer-gone",
	"process-gone",
	"provider-gone",
	"safe-mode",
	"shutdown",
	"overflow"
]);
var uiEventSchema = union([
	strictObject({
		kind: literal("ui.instances"),
		data: strictObject({ instances: array(uiBindingSchema).max(6) })
	}),
	strictObject({
		kind: literal("ui.visibility"),
		data: strictObject({
			binding: uiBindingSchema,
			visible: boolean()
		})
	}),
	strictObject({
		kind: literal("ui.environment"),
		data: strictObject({
			locale: pluginLocaleSchema,
			theme: _enum(["light", "dark"])
		})
	}),
	strictObject({
		kind: literal("ui.form"),
		data: strictObject({
			binding: uiBindingSchema,
			revision: counterSchema,
			values: scalars
		})
	}),
	strictObject({
		kind: literal("ui.state"),
		data: strictObject({
			binding: uiBindingSchema,
			revision: counterSchema
		})
	}),
	strictObject({
		kind: literal("ui.revoked"),
		data: strictObject({
			binding: uiBindingSchema,
			reason: uiRevokeReasonSchema
		})
	})
]);
var uiEnvelopeFields = {
	version: literal(1),
	subscriptionId: handleSchema$1,
	owner: resourceOwnerSchema,
	sequence: counterSchema,
	delivery: literal("control")
};
var uiEventEnvelopeSchema = union([
	uiEventSchema.options[0].extend(uiEnvelopeFields),
	uiEventSchema.options[1].extend(uiEnvelopeFields),
	uiEventSchema.options[2].extend(uiEnvelopeFields),
	uiEventSchema.options[3].extend(uiEnvelopeFields),
	uiEventSchema.options[4].extend({
		...uiEnvelopeFields,
		delivery: literal("telemetry")
	}),
	uiEventSchema.options[5].extend(uiEnvelopeFields)
]);
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/static-language-limits.js
var STATIC_LANGUAGE_LIMITS_V1 = Object.freeze({
	patternLength: 2048,
	compiledPatternLength: 4096,
	rulesPerLanguage: 1024,
	regexesPerLanguage: 1024,
	statesPerLanguage: 64,
	resourceFileBytes: 524288,
	resourceBytesPerLanguage: 786432,
	resourceBytesPerPlugin: 1048576,
	resourceBytesTotal: 8388608,
	expandedRulesPerLanguage: 8192,
	expandedRulesTotal: 65536,
	includeDepth: 16,
	regexFlags: Object.freeze(["", "i"]),
	listsPerLanguage: 32,
	wordsPerLanguage: 4096,
	casesPerRule: 32,
	onEnterRules: 32,
	languagesPerPlugin: 8,
	languagesTotal: 128,
	sessionLanguageIds: 256,
	maxTokenizationLineLength: 1e4
});
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/static-language-schemas.js
var TEXT = /^[^\u0000-\u001f\u007f-\u009f]*$(?![\r\n\u2028\u2029])/u;
var SINGLE_LINE_TEXT = /^[^\u0000-\u001f\u007f-\u009f\u2028\u2029]*$(?![\r\n\u2028\u2029])/u;
function staticLanguageText(minimum, maximum, singleLine = false) {
	return string().min(minimum).max(maximum).regex(singleLine ? SINGLE_LINE_TEXT : TEXT);
}
var name = string().min(1).max(32).regex(/^[a-z][a-z0-9_]{0,31}$(?![\r\n\u2028\u2029])/);
var reference = string().min(2).max(33).regex(/^@[a-z][a-z0-9_]{0,31}$(?![\r\n\u2028\u2029])/);
var literalToken = string().min(0).max(80).regex(/^(?:[a-z][a-z0-9_.-]*)?$(?![\r\n\u2028\u2029])/);
var regexDataSchema = strictObject({
	pattern: staticLanguageText(1, STATIC_LANGUAGE_LIMITS_V1.patternLength),
	flags: _enum(STATIC_LANGUAGE_LIMITS_V1.regexFlags)
});
var pairSchema = strictObject({
	open: staticLanguageText(1, 16),
	close: staticLanguageText(1, 16)
});
var tokenActionSchema = strictObject({
	token: union([literalToken, literal("@brackets")]),
	next: reference.optional(),
	bracket: _enum(["@open", "@close"]).optional()
});
var ruleSchema = union([strictObject({
	regex: regexDataSchema,
	action: union([tokenActionSchema, strictObject({ cases: array(strictObject({
		when: reference,
		action: tokenActionSchema
	})).min(1).max(STATIC_LANGUAGE_LIMITS_V1.casesPerRule) })])
}), strictObject({ include: reference })]);
strictObject({
	ignoreCase: boolean(),
	defaultToken: literalToken.optional(),
	tokenPostfix: string().min(2).max(80).regex(/^\.[a-z][a-z0-9_.-]*$(?![\r\n\u2028\u2029])/).optional(),
	lists: array(strictObject({
		name,
		words: array(staticLanguageText(1, 64)).max(STATIC_LANGUAGE_LIMITS_V1.wordsPerLanguage)
	})).max(STATIC_LANGUAGE_LIMITS_V1.listsPerLanguage).optional(),
	brackets: array(pairSchema.extend({ token: literalToken })).max(32).optional(),
	states: array(strictObject({
		name,
		rules: array(ruleSchema).max(STATIC_LANGUAGE_LIMITS_V1.rulesPerLanguage)
	})).min(1).max(STATIC_LANGUAGE_LIMITS_V1.statesPerLanguage)
});
strictObject({
	comments: strictObject({
		lineComment: staticLanguageText(1, 16).optional(),
		blockComment: pairSchema.optional()
	}).optional(),
	brackets: array(pairSchema).max(32).optional(),
	autoClosingPairs: array(pairSchema.extend({ notIn: array(_enum([
		"string",
		"comment",
		"regex"
	])).max(3).optional() })).max(32).optional(),
	surroundingPairs: array(pairSchema).max(32).optional(),
	indentationRules: strictObject({
		increaseIndentPattern: regexDataSchema,
		decreaseIndentPattern: regexDataSchema,
		indentNextLinePattern: regexDataSchema.optional(),
		unIndentedLinePattern: regexDataSchema.optional()
	}).optional(),
	onEnterRules: array(strictObject({
		beforeText: regexDataSchema,
		afterText: regexDataSchema.optional(),
		previousLineText: regexDataSchema.optional(),
		action: strictObject({
			indentAction: _enum([
				"none",
				"indent",
				"indentOutdent",
				"outdent"
			]),
			appendText: staticLanguageText(0, 256).optional(),
			removeText: number().int().min(0).max(256).optional()
		})
	})).max(STATIC_LANGUAGE_LIMITS_V1.onEnterRules).optional(),
	wordPattern: regexDataSchema.optional()
});
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/diagnostic-help.js
var diagnosticCodeSchema = string().regex(/^[A-Za-z][A-Za-z0-9_.-]{0,63}$/);
var diagnosticHelpKeySchema = string().regex(/^[a-z0-9-]{1,100}$/);
var diagnosticHelpDeclSchema = strictObject({
	version: literal(1),
	path: string().max(600).regex(/^(?:[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}\/){0,7}[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}\.json$/)
});
var line = string().min(1).max(DIAGNOSTIC_HELP_LIMITS.lineLength).regex(SINGLE_LINE);
var block = string().min(1).max(DIAGNOSTIC_HELP_LIMITS.blockLength).regex(MULTI_LINE);
var text$2 = (value) => strictObject({
	en: value,
	"zh-TW": value.optional()
});
var steps = array(line).min(1).max(DIAGNOSTIC_HELP_LIMITS.stepsPerLocale);
var link = strictObject({
	url: string().max(DIAGNOSTIC_HELP_LIMITS.urlLength).regex(/^https:\/\/[^\u0000- \u007F]+$/),
	label: text$2(line)
});
strictObject({ entries: array(strictObject({
	code: diagnosticCodeSchema,
	helpKey: diagnosticHelpKeySchema.optional(),
	title: text$2(line),
	cause: text$2(block),
	steps: strictObject({
		en: steps,
		"zh-TW": steps.optional()
	}),
	example: strictObject({
		before: block,
		after: block
	}).optional(),
	links: array(link).max(DIAGNOSTIC_HELP_LIMITS.linksPerEntry).optional()
})).max(DIAGNOSTIC_HELP_LIMITS.entriesPerPlugin) });
new TextEncoder();
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/manifest.js
var relativePath = string().min(1).max(512).regex(/^[A-Za-z0-9_-][A-Za-z0-9._-]*(?:\/[A-Za-z0-9_-][A-Za-z0-9._-]*)*$/);
var runtimeSchema = discriminatedUnion("kind", [
	strictObject({ kind: literal("static") }),
	looseObject({ kind: literal("builtin") }),
	looseObject({
		kind: literal("node"),
		entry: relativePath
	}),
	looseObject({
		kind: literal("python"),
		entry: relativePath
	})
]);
var compilerIdSchema = string().regex(/^[a-z][a-z0-9-]{0,31}$/);
var extensionSchema = string().regex(/^[a-z0-9]{1,16}$/);
var irRangeSchema = looseObject({
	min: number().int().min(1),
	max: number().int().min(1)
});
var frontendDeclSchema = looseObject({
	language: compilerIdSchema,
	entryExtensions: array(extensionSchema).min(1),
	sourceExtensions: array(extensionSchema).min(1),
	ir: irRangeSchema
});
var artifactDeclSchema = looseObject({
	slot: compilerIdSchema,
	kind: compilerIdSchema,
	extension: extensionSchema,
	mediaType: string().max(127).regex(/^[A-Za-z0-9!#$&^_.+-]+\/[A-Za-z0-9!#$&^_.+-]+$/),
	role: _enum(["deploy-main", "aux"]),
	required: boolean()
});
var backendDeclSchema = looseObject({
	target: compilerIdSchema,
	ir: irRangeSchema,
	capabilities: looseObject({ deploy: literal("ev3").optional() }),
	artifacts: array(artifactDeclSchema).max(16)
});
var languageCapabilitySchema = _enum([
	"analysis",
	"completion",
	"quickFixes",
	"semanticTokens",
	"hover",
	"signatureHelp",
	"definition",
	"references",
	"rename",
	"documentSymbols",
	"documentFormatting",
	"rangeFormatting"
]);
var languageServiceDeclSchema = strictObject({
	language: compilerIdSchema,
	extensions: array(extensionSchema).min(1),
	capabilities: array(languageCapabilitySchema).min(1)
});
var staticLanguageResourceDeclSchema = strictObject({
	version: literal(1),
	path: diagnosticHelpDeclSchema.shape.path
});
var staticLanguageDeclSchema = strictObject({
	id: compilerIdSchema,
	extensions: array(extensionSchema).min(1).max(16),
	aliases: array(staticLanguageText(1, 80, true)).min(1).max(8).optional(),
	tokenizer: staticLanguageResourceDeclSchema,
	configuration: staticLanguageResourceDeclSchema
});
var settingsResourceDeclarationSchema = strictObject({
	version: literal(1),
	path: diagnosticHelpDeclSchema.shape.path
});
looseObject({
	id: namespacedIdSchema,
	version: semverSchema,
	apiVersion: string().max(64).regex(/^[\^~]?(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)$/),
	displayName: localizedTextSchema.optional(),
	runtime: runtimeSchema,
	requires: strictObject({ devices: array(strictObject({
		capability: requirementCapabilitySchema,
		required: boolean()
	})).min(1).max(5) }).optional(),
	activationEvents: array(string().max(160).regex(/^(?:onCommand|onPanel):[a-z0-9.-]+$/)).max(PLUGIN_LIMITS.activationEvents).optional(),
	permissions: array(permissionSchema).max(16).optional(),
	contributes: looseObject({
		deviceProviders: array(strictObject({
			id: namespacedIdSchema,
			capabilities: array(capabilitySchema).min(1).max(5)
		})).min(1).max(1).optional(),
		panels: array(panelDeclarationSchema).max(4).optional(),
		status: array(statusDeclarationSchema).max(2).optional(),
		commands: array(union([looseObject({
			id: namespacedIdSchema,
			title: localizedTextSchema,
			invocation: never().optional(),
			arguments: never().optional()
		}), contextCommandDeclarationSchema])).max(PLUGIN_LIMITS.commandsPerPlugin).optional(),
		frontends: array(frontendDeclSchema).max(8).optional(),
		backends: array(backendDeclSchema).max(8).optional(),
		diagnosticHelp: diagnosticHelpDeclSchema.optional(),
		settings: settingsResourceDeclarationSchema.optional(),
		languageServices: array(languageServiceDeclSchema).max(8).optional(),
		languages: array(staticLanguageDeclSchema).max(8).optional()
	}).optional()
});
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/rpc.js
var jsonRpcIdSchema = union([int().min(0).max(Number.MAX_SAFE_INTEGER), string().min(1).max(64)]);
var version = literal("2.0");
var method = string().min(1).max(128).regex(/^[$A-Za-z][A-Za-z0-9/_-]*$/);
var params = looseObject({});
union([
	strictObject({
		jsonrpc: version,
		id: jsonRpcIdSchema,
		method,
		params: params.optional()
	}),
	strictObject({
		jsonrpc: version,
		method,
		params: params.optional()
	}),
	strictObject({
		jsonrpc: version,
		id: jsonRpcIdSchema,
		result: union([_null(), looseObject({})])
	}),
	strictObject({
		jsonrpc: version,
		id: union([jsonRpcIdSchema, _null()]),
		error: strictObject({
			code: int().min(-2147483648).max(2147483647),
			message: string().max(PLUGIN_LIMITS.errorMessageLength)
		})
	})
]);
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/persistence-primitives.js
var persistenceCodeReasons = {
	PLUGIN_E_SETTINGS_SCHEMA: [
		"invalid-resource",
		"invalid-value",
		"duplicate-key",
		"unknown-key",
		"size-limit",
		"schema-changed-without-version",
		"migration-required",
		"downgrade",
		"unsupported-format",
		"corrupt"
	],
	PLUGIN_E_SETTINGS_CONFLICT: ["revision-mismatch"],
	PLUGIN_E_SETTINGS_SAVE: [
		"disk-full",
		"permission",
		"read-only",
		"io",
		"sync-failed",
		"publish-uncertain",
		"import-pending"
	],
	PLUGIN_E_STORAGE_QUOTA: [
		"record-count",
		"source-bytes",
		"host-bytes",
		"temporary-bytes"
	],
	PLUGIN_E_STORAGE_CONFLICT: [
		"revision-mismatch",
		"write-in-progress",
		"offset-mismatch",
		"sealed",
		"incomplete",
		"checksum-mismatch",
		"flush-incomplete",
		"export-not-ready"
	],
	PLUGIN_E_STORAGE_IO: [
		"not-found",
		"disk-full",
		"permission",
		"read-only",
		"io",
		"sync-failed",
		"publish-uncertain",
		"corrupt",
		"import-pending",
		"input-changed",
		"clipboard-unavailable",
		"destination-changed",
		"unsupported-filesystem"
	],
	PLUGIN_E_STORAGE_VERSION: ["unsupported-format", "schema-mismatch"]
};
var jsonBytes = (value) => new TextEncoder().encode(JSON.stringify(value)).byteLength;
var utf8Bytes = (value) => new TextEncoder().encode(value).byteLength;
var safeIntegerSchema = number().int().min(0).max(Number.MAX_SAFE_INTEGER);
var versionSchema = number().int().min(1).max(2147483647);
var handleSchema = string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
var revisionSchema = string().regex(/^r_[0-9a-f]{32}$/);
var sha256Schema = string().regex(/^[0-9a-f]{64}$/);
var keySchema = string().max(64).regex(/^[a-z][A-Za-z0-9]*(?:\.[a-z][A-Za-z0-9]*)*$/).refine((value) => !value.split(".").some((k) => [
	"__proto__",
	"prototype",
	"constructor"
].includes(k)));
var durabilitySchema = _enum(["file-and-directory-sync", "file-sync-only"]);
var receiptSchema = strictObject({
	revision: revisionSchema,
	commitId: handleSchema,
	durability: durabilitySchema
});
var wellFormedText = (text) => !text.includes("\0") && [...text].every((c) => {
	const n = c.codePointAt(0);
	return n < 55296 || n > 57343;
});
function boundedText(min, max, bytes, singleLine = false) {
	return string().refine((s) => wellFormedText(s) && [...s].length >= min && [...s].length <= max && utf8Bytes(s) <= bytes && (!singleLine || !/[\u0000-\u001f\u007f\u2028\u2029]/u.test(s)));
}
var reasons = [...new Set(Object.values(persistenceCodeReasons).flat())];
var persistenceDetailSchema = strictObject({
	kind: literal("persistence"),
	reason: _enum(reasons),
	phase: _enum([
		"validate",
		"reserve",
		"write",
		"seal",
		"publish",
		"sync",
		"recover"
	]).optional(),
	disposition: _enum([
		"not-committed",
		"committed",
		"unknown"
	]).optional(),
	actualRevision: revisionSchema.optional(),
	expectedVersion: versionSchema.optional(),
	actualVersion: versionSchema.optional(),
	limit: safeIntegerSchema.optional(),
	requested: safeIntegerSchema.optional(),
	retryable: boolean().optional(),
	payload: _enum([
		"complete-staging",
		"checkpoint-only",
		"none"
	]).optional(),
	expiresAt: safeIntegerSchema.optional(),
	commitId: handleSchema.optional(),
	keys: array(keySchema).max(16).optional()
}).refine((d) => jsonBytes(d) <= 2048).transform((d) => ({
	kind: d.kind,
	reason: d.reason,
	...d.phase === void 0 ? {} : { phase: d.phase },
	...d.disposition === void 0 ? {} : { disposition: d.disposition },
	...d.actualRevision === void 0 ? {} : { actualRevision: d.actualRevision },
	...d.expectedVersion === void 0 ? {} : { expectedVersion: d.expectedVersion },
	...d.actualVersion === void 0 ? {} : { actualVersion: d.actualVersion },
	...d.limit === void 0 ? {} : { limit: d.limit },
	...d.requested === void 0 ? {} : { requested: d.requested },
	...d.retryable === void 0 ? {} : { retryable: d.retryable },
	...d.payload === void 0 ? {} : { payload: d.payload },
	...d.expiresAt === void 0 ? {} : { expiresAt: d.expiresAt },
	...d.commitId === void 0 ? {} : { commitId: d.commitId },
	...d.keys === void 0 ? {} : { keys: d.keys }
}));
var permissionDetail = strictObject({
	kind: literal("permission"),
	reason: _enum(["permission", "user-action-required"])
});
var resourceDetail = strictObject({
	kind: literal("resource"),
	reason: _enum([
		"stale",
		"quota",
		"rate",
		"queue"
	]),
	resource: _enum([
		"operation",
		"subscription",
		"candidate",
		"reservation",
		"journal",
		"rpc",
		"ui-binding",
		"storage-write",
		"storage-read",
		"storage-list",
		"storage-export",
		"storage-watch"
	]),
	limit: safeIntegerSchema.optional()
}).transform(({ limit, ...detail }) => ({
	...detail,
	...limit === void 0 ? {} : { limit }
}));
var message = boundedText(0, 2e3, 8e3);
var lifecycle = [
	"PLUGIN_E_TIMEOUT",
	"PLUGIN_E_CANCELLED",
	"PLUGIN_E_DISABLED",
	"PLUGIN_E_SAFE_MODE",
	"PLUGIN_E_SHUTTING_DOWN"
];
var persistenceErrorSchema = strictObject({
	code: _enum([
		"PLUGIN_E_PERMISSION_DENIED",
		"PLUGIN_E_STALE_RESOURCE",
		"PLUGIN_E_RESOURCE_LIMIT",
		...[
			"PLUGIN_E_SETTINGS_SCHEMA",
			"PLUGIN_E_SETTINGS_SAVE",
			"PLUGIN_E_SETTINGS_CONFLICT",
			"PLUGIN_E_STORAGE_QUOTA",
			"PLUGIN_E_STORAGE_CONFLICT",
			"PLUGIN_E_STORAGE_IO",
			"PLUGIN_E_STORAGE_VERSION"
		],
		...lifecycle
	]),
	message,
	detail: union([
		persistenceDetailSchema,
		permissionDetail,
		resourceDetail
	]).optional()
}).superRefine((e, ctx) => {
	let valid = false;
	const d = e.detail;
	if (e.code in persistenceCodeReasons) valid = d === void 0 || d.kind === "persistence" && persistenceCodeReasons[e.code].includes(d.reason);
	else if (e.code === "PLUGIN_E_PERMISSION_DENIED") valid = d === void 0 || d.kind === "permission";
	else if (e.code === "PLUGIN_E_STALE_RESOURCE") valid = d === void 0 || d.kind === "resource" && d.reason === "stale";
	else if (e.code === "PLUGIN_E_RESOURCE_LIMIT") valid = d === void 0 || d.kind === "resource" && d.reason !== "stale";
	else valid = d === void 0;
	if (!valid || d !== void 0 && jsonBytes(d) > 2048) ctx.addIssue({
		code: "custom",
		message: "Invalid code/detail pair"
	});
}).transform(({ detail, ...error }) => ({
	...error,
	...detail === void 0 ? {} : { detail }
}));
function persistenceResultSchema(value) {
	return union([
		strictObject({
			ok: literal(true),
			value
		}),
		commonFailureSchemaFor("1.7.0"),
		strictObject({
			ok: literal(false),
			error: persistenceErrorSchema
		})
	]);
}
persistenceResultSchema(string());
function canonicalBase64Length(text, allowEmpty = false) {
	if (text === "" && allowEmpty) return 0;
	if (text.length === 0 || text.length > 349528 || text.length % 4 !== 0 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(text)) throw new Error("invalid-base64");
	const padding = text.endsWith("==") ? 2 : text.endsWith("=") ? 1 : 0;
	const last = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".indexOf(text[text.length - padding - 1]);
	if (padding === 2 && (last & 15) !== 0 || padding === 1 && (last & 3) !== 0) throw new Error("invalid-base64-tail-bits");
	const bytes = text.length / 4 * 3 - padding;
	if (bytes > 262144) throw new Error("size-limit");
	return bytes;
}
var chunkSchema = (allowEmpty = false) => string().refine((text) => {
	try {
		canonicalBase64Length(text, allowEmpty);
		return true;
	} catch {
		return false;
	}
});
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/settings.js
var settingsText = (value) => ({
	en: value.en,
	...value["zh-TW"] === void 0 ? {} : { "zh-TW": value["zh-TW"] }
});
var title = strictObject({
	en: boundedText(1, 200, 800, true),
	"zh-TW": boundedText(1, 200, 800, true).optional()
}).transform(settingsText);
var common = {
	key: keySchema,
	label: title,
	help: strictObject({
		en: boundedText(0, 2e3, 8192),
		"zh-TW": boundedText(0, 2e3, 8192).optional()
	}).transform(settingsText).optional()
};
var scalar = union([
	boolean(),
	number(),
	boundedText(0, 4e3, 4096)
]);
var optionValue = union([number().int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER), boundedText(0, 4e3, 4096)]);
var settingsFieldSchema = discriminatedUnion("type", [
	strictObject({
		...common,
		type: literal("boolean"),
		default: boolean()
	}),
	strictObject({
		...common,
		type: literal("number"),
		default: number(),
		minimum: number(),
		maximum: number()
	}),
	strictObject({
		...common,
		type: literal("integer"),
		default: number().int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),
		minimum: number().int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),
		maximum: number().int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER)
	}),
	strictObject({
		...common,
		type: literal("string"),
		default: boundedText(0, 4e3, 4096),
		minLength: number().int().min(0).max(4e3),
		maxLength: number().int().min(0).max(4e3),
		maxBytes: number().int().min(1).max(4096)
	}),
	strictObject({
		...common,
		type: literal("enum"),
		default: optionValue,
		options: array(strictObject({
			value: optionValue,
			label: title
		})).min(1).max(32)
	})
]).transform(({ help, ...field }) => ({
	...field,
	...help === void 0 ? {} : { help }
}));
var valuesSchema = array(strictObject({
	key: keySchema,
	value: scalar
})).max(128).refine((v) => new Set(v.map((x) => x.key)).size === v.length && jsonBytes(v) <= 65536);
strictObject({
	schemaVersion: versionSchema,
	title,
	fields: array(settingsFieldSchema).min(1).max(128)
});
var settingsSnapshotSchema = strictObject({
	schemaVersion: versionSchema,
	revision: revisionSchema.nullable(),
	values: valuesSchema
});
var settingsMutationSchema = strictObject({
	snapshot: settingsSnapshotSchema,
	receipt: receiptSchema
});
var settingsChangedSchema = strictObject({
	revision: revisionSchema,
	schemaVersion: versionSchema,
	changedKeys: array(keySchema).max(128),
	cause: _enum([
		"update",
		"reset",
		"migrate",
		"import"
	])
});
var request$2 = (params, value) => ({
	params,
	result: persistenceResultSchema(value)
});
var settingsRequestSchemas = {
	"settings/read": request$2(strictObject({ schemaVersion: versionSchema }), settingsSnapshotSchema),
	"settings/update": request$2(strictObject({
		schemaVersion: versionSchema,
		expectedRevision: revisionSchema.nullable(),
		changes: valuesSchema.min(1)
	}), settingsMutationSchema),
	"settings/reset": request$2(strictObject({
		schemaVersion: versionSchema,
		expectedRevision: revisionSchema.nullable(),
		keys: array(keySchema).min(1).max(128).refine((v) => new Set(v).size === v.length)
	}), settingsMutationSchema),
	"settings/watch": request$2(strictObject({ schemaVersion: versionSchema }), strictObject({
		subscriptionId: handleSchema,
		sequence: literal(0),
		snapshot: settingsSnapshotSchema
	})),
	"settings/readMigration": request$2(strictObject({}), strictObject({
		stored: settingsSnapshotSchema,
		declaredSchemaVersion: versionSchema
	})),
	"settings/migrate": request$2(strictObject({
		fromSchemaVersion: versionSchema,
		schemaVersion: versionSchema,
		expectedRevision: revisionSchema,
		values: valuesSchema
	}), settingsMutationSchema)
};
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/storage.js
var mediaTypeSchema = _enum([
	"application/json",
	"text/plain",
	"text/csv",
	"application/octet-stream"
]);
var kindSchema = string().regex(/^[a-z][a-z0-9.-]{0,63}$/);
var metadata$1 = {
	kind: kindSchema,
	schemaVersion: versionSchema,
	label: boundedText(0, 160, 640, true),
	mediaType: mediaTypeSchema,
	byteLength: safeIntegerSchema.max(8388608),
	sha256: sha256Schema
};
var recordMetaSchema = strictObject({
	id: handleSchema,
	revision: revisionSchema,
	...metadata$1,
	createdAt: safeIntegerSchema,
	updatedAt: safeIntegerSchema,
	checkpoint: _enum([
		"none",
		"open",
		"final"
	]),
	interrupted: boolean()
}).refine((m) => jsonBytes(m) <= 2048);
var recordWriteSchema = strictObject({
	target: discriminatedUnion("mode", [strictObject({ mode: literal("create") }), strictObject({
		mode: literal("replace"),
		id: handleSchema,
		expectedRevision: revisionSchema
	})]),
	...metadata$1,
	checkpoint: strictObject({
		handle: handleSchema,
		phase: _enum(["checkpoint", "final"])
	}).optional(),
	drainToken: handleSchema.optional()
});
var writeProgressSchema = strictObject({
	write: handleSchema,
	id: handleSchema,
	state: _enum([
		"receiving",
		"sealed",
		"publishing",
		"committed",
		"aborted",
		"expired",
		"failed"
	]),
	receivedBytes: safeIntegerSchema.max(8388608),
	expiresAt: safeIntegerSchema,
	receipt: receiptSchema.optional(),
	error: persistenceErrorSchema.optional()
});
var drainRequestSchema = strictObject({
	token: handleSchema,
	reason: _enum([
		"disable",
		"reload",
		"remove",
		"renderer-crash",
		"window-destroyed",
		"shutdown",
		"update",
		"safe-mode",
		"reservation-ended"
	]),
	remainingMs: safeIntegerSchema.max(1e4),
	checkpoints: array(strictObject({
		checkpoint: handleSchema,
		record: recordMetaSchema,
		reservationEnd: strictObject({
			reservationId: handleSchema,
			reason: _enum([
				"released",
				"source-changed",
				"disconnected",
				"suspended",
				"core-disconnect",
				"retired",
				"renderer-lost",
				"limit",
				"overflow"
			]),
			lastSequence: safeIntegerSchema
		}).exactOptional()
	})).max(2),
	writes: array(strictObject({
		write: handleSchema,
		id: handleSchema,
		state: _enum(["receiving", "sealed"])
	})).max(2)
});
var request$1 = (params, value) => ({
	params,
	result: persistenceResultSchema(value)
});
var empty$3 = strictObject({});
var storageRequestSchemas = {
	"storage/beginWrite": request$1(recordWriteSchema, strictObject({
		write: handleSchema,
		id: handleSchema,
		expiresAt: safeIntegerSchema
	})),
	"storage/writeChunk": request$1(strictObject({
		write: handleSchema,
		offset: safeIntegerSchema,
		data: chunkSchema()
	}), strictObject({
		receivedBytes: safeIntegerSchema.max(8388608),
		expiresAt: safeIntegerSchema
	})),
	"storage/sealWrite": request$1(strictObject({ write: handleSchema }), writeProgressSchema),
	"storage/commitWrite": request$1(strictObject({
		write: handleSchema,
		drainToken: handleSchema.optional()
	}), strictObject({
		record: recordMetaSchema,
		receipt: receiptSchema
	})),
	"storage/writeStatus": request$1(strictObject({ write: handleSchema }), writeProgressSchema),
	"storage/abortWrite": request$1(strictObject({ write: handleSchema }), strictObject({
		disposition: _enum([
			"aborted",
			"committed",
			"unknown"
		]),
		receipt: receiptSchema.optional()
	})),
	"storage/stat": request$1(strictObject({ id: handleSchema }), strictObject({ record: recordMetaSchema })),
	"storage/list": request$1(strictObject({
		kind: kindSchema.optional(),
		limit: safeIntegerSchema.min(1).max(64),
		cursor: handleSchema.optional()
	}), strictObject({
		entries: array(recordMetaSchema).max(64),
		nextCursor: handleSchema.optional()
	}).refine((value) => jsonBytes({
		ok: true,
		value
	}) <= 262144)),
	"storage/openRead": request$1(strictObject({
		id: handleSchema,
		expectedRevision: revisionSchema,
		schemaVersion: versionSchema
	}), strictObject({
		read: handleSchema,
		record: recordMetaSchema,
		expiresAt: safeIntegerSchema
	})),
	"storage/readChunk": request$1(strictObject({
		read: handleSchema,
		offset: safeIntegerSchema,
		maxBytes: safeIntegerSchema.min(1).max(262144)
	}), strictObject({
		offset: safeIntegerSchema,
		data: chunkSchema(true),
		nextOffset: safeIntegerSchema,
		eof: boolean()
	})),
	"storage/closeRead": request$1(strictObject({ read: handleSchema }), empty$3),
	"storage/delete": request$1(strictObject({
		id: handleSchema,
		expectedRevision: revisionSchema
	}), strictObject({
		deleted: literal(true),
		receipt: receiptSchema
	})),
	"storage/flush": request$1(empty$3, strictObject({
		barrier: handleSchema,
		durability: durabilitySchema
	})),
	"storage/quota": request$1(empty$3, strictObject({
		recordCount: safeIntegerSchema,
		reservedCreates: safeIntegerSchema,
		committedBytes: safeIntegerSchema,
		reservedBytes: safeIntegerSchema,
		pinnedBytes: safeIntegerSchema,
		temporaryBytes: safeIntegerSchema,
		sourceLimitBytes: literal(536870912),
		sourceLimitRecords: literal(256),
		hostAvailableBytes: safeIntegerSchema,
		writeSlotsAvailable: safeIntegerSchema,
		exportSlotsAvailable: safeIntegerSchema
	})),
	"storage/registerCheckpoint": request$1(strictObject({
		id: handleSchema,
		expectedRevision: revisionSchema,
		reservation: handleSchema.optional()
	}), strictObject({ checkpoint: handleSchema })),
	"storage/abandonCheckpoint": request$1(strictObject({ checkpoint: handleSchema }), strictObject({ record: recordMetaSchema })),
	"storage/drain": request$1(drainRequestSchema, strictObject({
		status: _enum(["submitted", "checkpoint-only"]),
		writes: array(handleSchema).max(2)
	}))
};
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/persistence-actions.js
var request = (params, value) => ({
	params,
	result: persistenceResultSchema(value)
});
var persistenceActionRequestSchemas = {
	"storage/exportBegin": request(strictObject({
		actionRef: handleSchema,
		suggestedName: boundedText(1, 80, 320, true).refine((s) => !/[\\/:]/.test(s) && s !== "." && s !== ".." && !/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(s)),
		mediaType: mediaTypeSchema,
		byteLength: safeIntegerSchema.max(8388608),
		sha256: sha256Schema
	}), strictObject({
		export: handleSchema,
		state: literal("waiting"),
		expiresAt: safeIntegerSchema
	})),
	"storage/exportChunk": request(strictObject({
		export: handleSchema,
		offset: safeIntegerSchema,
		data: chunkSchema()
	}), strictObject({
		receivedBytes: safeIntegerSchema.max(8388608),
		expiresAt: safeIntegerSchema
	})),
	"storage/exportCommit": request(strictObject({ export: handleSchema }), strictObject({
		exported: literal(true),
		commitId: handleSchema,
		durability: durabilitySchema
	})),
	"storage/exportStatus": request(strictObject({ export: handleSchema }), strictObject({
		state: _enum([
			"waiting",
			"receiving",
			"publishing",
			"completed",
			"cancelled",
			"expired",
			"failed"
		]),
		receivedBytes: safeIntegerSchema.max(8388608),
		expiresAt: safeIntegerSchema,
		commitId: handleSchema.optional(),
		durability: durabilitySchema.optional(),
		error: persistenceErrorSchema.optional()
	})),
	"storage/exportCancel": request(strictObject({ export: handleSchema }), strictObject({
		disposition: _enum([
			"aborted",
			"committed",
			"unknown"
		]),
		commitId: handleSchema.optional()
	})),
	"ui/copyText": request(strictObject({
		actionRef: handleSchema,
		text: boundedText(0, 16384, 65536)
	}), strictObject({ copied: literal(true) }))
};
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/ui-v2-form.js
var fields = (minimum) => record$1(localIdSchema, uiScalarSchema).meta({
	minProperties: minimum,
	maxProperties: 32
});
var uiFormRequestSchemasV2 = { "ui/formPatch": {
	params: strictObject({
		binding: uiBindingSchema.extend({ kind: literal("panel") }),
		baseFormRevision: counterSchema,
		set: fields(1)
	}),
	result: uiResultSchema(strictObject({
		formRevision: counterSchema,
		form: fields(0)
	}))
} };
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/ui-methods.js
var empty$2 = strictObject({});
var versions = union([tuple([]), tuple([literal(1)])]);
var uiRequestSchemas = {
	"ui/negotiate": {
		params: strictObject({
			commandEnvelopeVersions: tuple([literal(1)]),
			uiResourceVersions: array(number().int().min(1).max(65535)).max(16)
		}),
		result: uiResultSchema(strictObject({
			commandEnvelopeVersions: versions,
			uiResourceVersions: versions
		}))
	},
	"ui/ready": {
		params: empty$2,
		result: uiResultSchema(empty$2)
	},
	"command/invoke": {
		params: commandInvocationSchema,
		result: union([uiResultSchema(commandValueSchema), strictObject({
			ok: literal(false),
			error: strictObject({
				code: _enum([
					"PLUGIN_E_COMMAND_FAILED",
					"PLUGIN_E_CANCELLED",
					"PLUGIN_E_TIMEOUT"
				]),
				message: wireText(1, 2e3)
			})
		})])
	},
	"ui/instances": {
		params: empty$2,
		result: uiResultSchema(strictObject({ instances: array(uiBindingSchema).max(6) }))
	},
	"ui/state": {
		params: strictObject({ binding: uiBindingSchema }),
		result: uiResultSchema(uiStateSnapshotSchema)
	},
	"ui/patch": {
		params: strictObject({
			binding: uiBindingSchema,
			baseRevision: counterSchema,
			set: record$1(localIdSchema, uiScalarSchema)
		}),
		result: uiResultSchema(strictObject({ revision: counterSchema }))
	},
	"ui/subscribe": {
		params: strictObject({
			topics: array(_enum([
				"instances",
				"visibility",
				"environment",
				"form",
				"state"
			])).min(1).max(5),
			binding: uiBindingSchema.exactOptional()
		}),
		result: uiResultSchema(strictObject({
			subscriptionId: handleSchema$1,
			sequence: literal(0),
			snapshot: uiSubscriptionSnapshotSchema
		}))
	},
	"ui/snapshot": {
		params: strictObject({ subscriptionId: handleSchema$1 }),
		result: uiResultSchema(strictObject({
			sequence: counterSchema,
			snapshot: uiSubscriptionSnapshotSchema
		}))
	}
};
Object.freeze({
	datasets: 8,
	charts: 4,
	codeDatasets: 1,
	series: 2,
	pointsPerSeries: 800,
	panelPoints: 6400,
	fullPoints: 3600,
	rows: 50,
	chunkEntries: 256,
	datasetBytes: 524288,
	panelBytes: 524288,
	headerBytes: 16384,
	entryBytes: 8192,
	chunkBytes: 49152,
	codePoints: 16384,
	codeBytes: 65536,
	codeEntryPoints: 1024
});
var counter = number().int().min(0).max(Number.MAX_SAFE_INTEGER);
var text$1 = (max) => string().max(max * 2);
var column = strictObject({
	id: localIdSchema,
	label: uiLabelSchema,
	value: _enum([
		"string",
		"number",
		"boolean"
	])
});
var datasetDeclarationV2Schema = discriminatedUnion("kind", [
	strictObject({
		kind: literal("chart"),
		series: array(strictObject({
			id: localIdSchema,
			label: uiLabelSchema
		})).min(1).max(2)
	}),
	strictObject({
		kind: literal("table"),
		columns: array(column).min(1).max(8)
	}),
	strictObject({
		kind: literal("list"),
		columns: array(column).min(1).max(3)
	}),
	strictObject({ kind: literal("code") })
]);
var timeDomainV2Schema = tuple([literal(0), number().min(1e3)]);
var timeViewV2Schema = _enum(["full", "recent60s"]);
var datasetPointV2Schema = tuple([
	counter,
	counter,
	number().min(0),
	number()
]);
var datasetSeriesV2Schema = strictObject({
	id: localIdSchema,
	unit: text$1(32),
	range: tuple([number(), number()]),
	extrema: tuple([tuple([number().min(0), number()]), tuple([number().min(0), number()])]).nullable(),
	fullPointCount: counter.max(3600),
	omittedPoints: counter.max(3600),
	omittedRuns: counter.max(3600)
});
var chartHeaderV2Schema = strictObject({
	kind: literal("chart"),
	timeDomain: timeDomainV2Schema,
	view: timeViewV2Schema,
	series: array(datasetSeriesV2Schema).min(1).max(2)
});
var tableHeader = strictObject({ kind: literal("table") });
var listHeader = strictObject({ kind: literal("list") });
var codeHeader = strictObject({ kind: literal("code") });
var datasetHeaderV2Schema = discriminatedUnion("kind", [
	chartHeaderV2Schema,
	tableHeader,
	listHeader,
	codeHeader
]);
var datasetRowV2Schema = strictObject({
	key: text$1(128).min(1),
	version: text$1(128).min(1).nullable(),
	cells: array(union([
		text$1(200),
		number(),
		boolean(),
		_null()
	])).max(8)
});
var codeEntry = text$1(1024).min(1);
var datasetChunkV2Schema = discriminatedUnion("kind", [
	strictObject({
		kind: literal("chart"),
		entries: array(datasetPointV2Schema).max(256)
	}),
	strictObject({
		kind: literal("table"),
		entries: array(datasetRowV2Schema).max(50)
	}),
	strictObject({
		kind: literal("list"),
		entries: array(datasetRowV2Schema).max(50)
	}),
	strictObject({
		kind: literal("code"),
		entries: array(codeEntry).max(256)
	})
]);
union([
	strictObject({
		header: chartHeaderV2Schema,
		entries: array(datasetPointV2Schema).max(1600)
	}),
	strictObject({
		header: tableHeader,
		entries: array(datasetRowV2Schema).max(50)
	}),
	strictObject({
		header: listHeader,
		entries: array(datasetRowV2Schema).max(50)
	}),
	strictObject({
		header: codeHeader,
		entries: array(codeEntry).max(16384)
	})
]);
new TextEncoder();
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/ui-v2-methods.js
/** Unpublished v2 data-plane wire leaves. These do not register public methods,
* negotiate v2, or authorize an owner. Host admission remains mandatory.
*/
var panelBinding = uiBindingSchema.extend({ kind: literal("panel") });
var positiveCounter = number().int().min(1).max(Number.MAX_SAFE_INTEGER);
var sha256 = string().regex(/^[a-f0-9]{64}$/);
var bytes$1 = positiveCounter.max(524288);
var remainingMs = number().min(0).max(1e4);
var base$1 = {
	binding: panelBinding,
	dataset: localIdSchema
};
var metadata = {
	revision: positiveCounter,
	presentation: positiveCounter,
	byteLength: bytes$1,
	sha256
};
var failure = (code, reasons) => strictObject({
	ok: literal(false),
	error: strictObject({
		code: literal(code),
		message: wireText(1, 2e3),
		detail: strictObject({
			kind: literal("ui-data"),
			reason: _enum(reasons)
		})
	})
});
var uiDataFailureSchemaV2 = union([
	failure("PLUGIN_E_UI_RESOURCE", [
		"schema",
		"reference",
		"offset",
		"checksum"
	]),
	failure("PLUGIN_E_STALE_RESOURCE", [
		"revision",
		"expired",
		"stale"
	]),
	failure("PLUGIN_E_RESOURCE_LIMIT", [
		"quota",
		"rate",
		"queue"
	]),
	failure("PLUGIN_E_UI_VERSION", ["version"]),
	strictObject({
		ok: literal(false),
		error: strictObject({
			code: literal("PLUGIN_E_PERMISSION_DENIED"),
			message: wireText(1, 2e3),
			detail: permissionErrorDetailSchema
		})
	})
]);
function uiDataResultSchemaV2(value) {
	return union([strictObject({
		ok: literal(true),
		value
	}), uiDataFailureSchemaV2]);
}
var uiDataMetadataSchemaV2 = strictObject({
	dataset: localIdSchema,
	...metadata
});
var readFields = {
	...metadata,
	nextOffset: counterSchema,
	done: boolean()
};
var uiDataReadValueSchemaV2 = union(datasetHeaderV2Schema.options.map((header) => {
	const chunk = datasetChunkV2Schema.options.find((c) => c.shape.kind.value === header.shape.kind.value);
	return strictObject({
		...readFields,
		header,
		chunk
	});
}));
var uiDataSnapshotValueSchemaV2 = strictObject({ datasets: array(uiDataMetadataSchemaV2).max(8) });
var uiDataRequestSchemasV2 = {
	"ui/dataBegin": {
		params: strictObject({
			...base$1,
			baseRevision: counterSchema,
			presentation: positiveCounter,
			header: datasetHeaderV2Schema,
			entryCount: number().int().min(0).max(16384),
			byteLength: bytes$1,
			sha256
		}),
		result: uiDataResultSchemaV2(strictObject({
			transfer: handleSchema$1,
			nextOffset: literal(0),
			remainingMs
		}))
	},
	"ui/dataChunk": {
		params: strictObject({
			...base$1,
			transfer: handleSchema$1,
			offset: counterSchema,
			chunk: datasetChunkV2Schema
		}),
		result: uiDataResultSchemaV2(strictObject({
			nextOffset: counterSchema,
			remainingMs
		}))
	},
	"ui/dataCommit": {
		params: strictObject({
			...base$1,
			transfer: handleSchema$1
		}),
		result: uiDataResultSchemaV2(strictObject(metadata))
	},
	"ui/dataAbort": {
		params: strictObject({
			...base$1,
			transfer: handleSchema$1
		}),
		result: uiDataResultSchemaV2(strictObject({ aborted: boolean() }))
	},
	"ui/dataRead": {
		params: strictObject({
			...base$1,
			revision: positiveCounter,
			offset: counterSchema,
			limit: number().int().min(1).max(256)
		}),
		result: uiDataResultSchemaV2(uiDataReadValueSchemaV2)
	},
	"ui/dataSnapshot": {
		params: strictObject({ binding: panelBinding }),
		result: uiDataResultSchemaV2(uiDataSnapshotValueSchemaV2)
	}
};
var uiDataEventSchemaV2 = strictObject({
	kind: literal("ui.data"),
	data: strictObject({
		...base$1,
		revision: positiveCounter,
		presentation: positiveCounter
	})
});
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/ui-v2-session.js
var uiResourceVersionsV2Schema = union([
	tuple([]),
	tuple([literal(1)]),
	tuple([literal(2)]),
	tuple([literal(1), literal(2)])
]);
var uiSubscriptionSnapshotV2Schema = uiSubscriptionSnapshotSchema.extend({ data: array(strictObject({
	binding: uiBindingSchema.extend({ kind: literal("panel") }),
	datasets: array(uiDataMetadataSchemaV2).max(8)
})).max(4).exactOptional() });
var uiRequestSchemasV2 = {
	...uiRequestSchemas,
	...uiDataRequestSchemasV2,
	...uiFormRequestSchemasV2,
	"ui/negotiate": {
		params: strictObject({
			commandEnvelopeVersions: tuple([literal(1)]),
			uiResourceVersions: uiResourceVersionsV2Schema
		}),
		result: uiResultSchema(strictObject({
			commandEnvelopeVersions: union([tuple([]), tuple([literal(1)])]),
			uiResourceVersions: uiResourceVersionsV2Schema
		}))
	},
	"ui/subscribe": {
		params: uiRequestSchemas["ui/subscribe"].params.extend({ topics: array(_enum([
			"instances",
			"visibility",
			"environment",
			"form",
			"state",
			"data"
		])).min(1).max(6) }),
		result: uiResultSchema(strictObject({
			subscriptionId: handleSchema$1,
			sequence: literal(0),
			snapshot: uiSubscriptionSnapshotV2Schema
		}))
	},
	"ui/snapshot": {
		params: uiRequestSchemas["ui/snapshot"].params,
		result: uiResultSchema(strictObject({
			sequence: counterSchema,
			snapshot: uiSubscriptionSnapshotV2Schema
		}))
	}
};
union([uiEventEnvelopeSchema, uiDataEventSchemaV2.extend({
	version: literal(1),
	subscriptionId: handleSchema$1,
	owner: resourceOwnerSchema,
	sequence: counterSchema,
	delivery: literal("telemetry")
})]);
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/device-methods.js
var empty$1 = strictObject({});
var authoritySnapshotSchema = strictObject({
	contextRef: handleSchema$1.nullable(),
	revision: counterSchema,
	state: _enum([
		"local",
		"allowed",
		"restricted",
		"unbound"
	]),
	reason: _enum([
		"local",
		"holder",
		"joining",
		"unsynced",
		"not-holder",
		"viewer",
		"window-lost",
		"unbound"
	])
});
var deviceListValueSchema = strictObject({
	revision: counterSchema,
	providers: array(strictObject({
		providerId: namespacedIdSchema,
		state: _enum([
			"available",
			"disabled",
			"conflict",
			"failed"
		]),
		capabilities: array(capabilitySchema).max(5)
	})).max(8),
	sessions: array(deviceSessionSnapshotSchema).max(1)
});
var motionSnapshotSchema = strictObject({
	operationId: handleSchema$1,
	sessionId: handleSchema$1,
	revision: counterSchema,
	phase: _enum([
		"preparing",
		"running",
		"stopping",
		"completed",
		"stopped",
		"timeout",
		"failed",
		"unconfirmed"
	]),
	stage: _enum([
		"prepared",
		"waiting-read",
		"preflight",
		"uploading-helper",
		"awaiting-helper",
		"arming",
		"moving",
		"readback",
		"terminal"
	]),
	startAccepted: boolean(),
	stopRequested: boolean(),
	dispatch: _enum([
		"not-sent",
		"sent",
		"unknown"
	]),
	movement: _enum([
		"not-started",
		"completed",
		"interrupted",
		"timed-out",
		"unknown"
	]),
	stopConfirmation: _enum([
		"not-required",
		"pending",
		"confirmed",
		"unconfirmed"
	]),
	brakeRequired: boolean(),
	elapsedMs: number().min(0),
	angle: number().nullable(),
	displacement: number().nullable(),
	preparedRemainingMs: number().int().min(0).max(5e3),
	error: deviceErrorSchema.exactOptional()
});
var deviceSubscriptionParamsSchema = discriminatedUnion("topic", [
	strictObject({ topic: literal("catalog") }),
	strictObject({
		topic: literal("session"),
		sessionId: handleSchema$1
	}),
	strictObject({
		topic: literal("telemetry"),
		sessionId: handleSchema$1,
		channelIds: array(handleSchema$1).min(1).max(38),
		intervalMs: union([literal(500), literal(3e4)])
	}),
	strictObject({
		topic: literal("motion"),
		operationId: handleSchema$1
	}),
	strictObject({
		topic: literal("reservation"),
		reservationId: handleSchema$1
	}),
	strictObject({
		topic: literal("authority"),
		contextRef: handleSchema$1
	})
]);
var pair = (params, value) => ({
	params,
	result: businessResultSchema(value, deviceFailureDetailSchema)
});
var operation = strictObject({ operation: motionSnapshotSchema });
var reserved = strictObject({ reservation: reservationSnapshotSchema });
var sessionValue = strictObject({ session: deviceSessionSnapshotSchema });
var sessionSources = strictObject({
	session: deviceSessionSnapshotSchema,
	sources: sourceCatalogSchema
});
var snapshot = union([
	deviceListValueSchema,
	sessionSources,
	readSnapshotSchema,
	motionSnapshotSchema,
	reservationSnapshotSchema,
	authoritySnapshotSchema
]);
var deviceRequestSchemas = {
	"devices/negotiate": pair(empty$1, strictObject({
		devicesContractVersion: literal(1),
		eventVersion: literal(1),
		capabilities: array(strictObject({
			capability: requirementCapabilitySchema,
			state: _enum([
				"available",
				"provider-unavailable",
				"no-session",
				"unsupported"
			]),
			providerId: namespacedIdSchema.nullable()
		})).max(10),
		requirementsSatisfied: boolean()
	})),
	"devices/context": pair(strictObject({ contextRef: handleSchema$1.exactOptional() }), authoritySnapshotSchema),
	"devices/list": pair(empty$1, deviceListValueSchema),
	"devices/discover": pair(strictObject({ providerId: namespacedIdSchema }), strictObject({ candidates: array(deviceCandidateSchema).max(32) })),
	"devices/connect": pair(strictObject({ target: discriminatedUnion("kind", [strictObject({
		kind: literal("candidate"),
		candidateId: handleSchema$1
	}), strictObject({
		kind: literal("wifi-address"),
		providerId: namespacedIdSchema,
		address: addressSchema
	})]) }), sessionValue),
	"devices/disconnect": pair(strictObject({ sessionId: handleSchema$1 }), sessionValue),
	"devices/session": pair(strictObject({ sessionId: handleSchema$1 }), sessionSources),
	"devices/read": pair(strictObject({
		sessionId: handleSchema$1,
		channelIds: array(handleSchema$1).min(1).max(38),
		freshness: _enum(["cached", "fresh"])
	}), readSnapshotSchema),
	"devices/inputModes/query": pair(strictObject({
		sessionId: handleSchema$1,
		portId: boundedIdSchema,
		expectedSourceRevision: counterSchema
	}), inputModesValueSchema),
	"devices/inputModes/set": pair(strictObject({
		sessionId: handleSchema$1,
		portId: boundedIdSchema,
		expectedSourceRevision: counterSchema,
		modeId: boundedIdSchema,
		contextRef: handleSchema$1
	}), strictObject({
		sources: sourceCatalogSchema,
		snapshot: readSnapshotSchema
	})),
	"devices/motion/prepare": pair(strictObject({
		sessionId: handleSchema$1,
		contextRef: handleSchema$1,
		motionScopeRef: handleSchema$1,
		motion: motionSpecSchema,
		gestureRef: handleSchema$1.exactOptional()
	}), operation),
	"devices/motion/start": pair(strictObject({ operationId: handleSchema$1 }), operation),
	"devices/motion/query": pair(strictObject({ operationId: handleSchema$1 }), operation),
	"devices/motion/stop": pair(strictObject({
		operationId: handleSchema$1,
		stopMode: _enum(["configured", "brake"])
	}), operation),
	"devices/recording/reserve": pair(strictObject({
		sessionId: handleSchema$1,
		channelIds: array(handleSchema$1).min(1).max(4),
		expectedSourceRevision: counterSchema
	}), strictObject({
		reservation: reservationSnapshotSchema,
		firstFrame: telemetryFrameSchema
	})),
	"devices/recording/query": pair(strictObject({ reservationId: handleSchema$1 }), reserved),
	"devices/recording/read": pair(strictObject({
		reservationId: handleSchema$1,
		afterSequence: counterSchema,
		limit: number().int().min(1).max(64)
	}), strictObject({
		reservation: reservationSnapshotSchema,
		frames: array(telemetryFrameSchema).max(64),
		gap: overflowGapSchema.nullable(),
		nextSequence: counterSchema,
		hasMore: boolean()
	})),
	"devices/recording/release": pair(strictObject({ reservationId: handleSchema$1 }), reserved),
	"devices/subscribe": pair(deviceSubscriptionParamsSchema, strictObject({
		subscriptionId: handleSchema$1,
		sequence: literal(0),
		snapshot
	})),
	"events/ack": pair(strictObject({
		subscriptionId: handleSchema$1,
		sequence: counterSchema
	}), strictObject({ acknowledged: counterSchema })),
	"events/unsubscribe": pair(strictObject({ subscriptionId: handleSchema$1 }), strictObject({ removed: boolean() }))
};
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/events.js
var base = {
	version: literal(1),
	subscriptionId: handleSchema$1,
	owner: resourceOwnerSchema,
	sequence: number().int().min(1).max(Number.MAX_SAFE_INTEGER)
};
var event = (kind, delivery, data) => strictObject({
	...base,
	kind: literal(kind),
	delivery: literal(delivery),
	data
});
var deviceEventDataSchemas = {
	"devices.catalog": deviceListValueSchema,
	"devices.session": strictObject({
		session: deviceSessionSnapshotSchema,
		sourcesChanged: boolean()
	}),
	"devices.telemetry": strictObject({
		sessionId: handleSchema$1,
		frames: array(telemetryFrameSchema).max(64),
		snapshot: readSnapshotSchema
	}),
	"devices.motion": motionSnapshotSchema,
	"devices.reservation": reservationSnapshotSchema,
	"devices.recordingFrames": strictObject({
		reservationId: handleSchema$1,
		frames: array(telemetryFrameSchema).max(64),
		gap: overflowGapSchema.nullable()
	}),
	"devices.authority": authoritySnapshotSchema,
	"events.resyncRequired": strictObject({
		reason: _enum(["overflow", "ack-timeout"]),
		affected: array(handleSchema$1).max(32)
	})
};
var uiEventDataSchemas = {
	"ui.data": uiDataEventSchemaV2.shape.data,
	"ui.instances": uiEventSchema.options[0].shape.data,
	"ui.visibility": uiEventSchema.options[1].shape.data,
	"ui.environment": uiEventSchema.options[2].shape.data,
	"ui.form": uiEventSchema.options[3].shape.data,
	"ui.state": uiEventSchema.options[4].shape.data,
	"ui.revoked": uiEventSchema.options[5].shape.data
};
var eventEnvelopeSchema = discriminatedUnion("kind", [
	event("settings.changed", "telemetry", settingsChangedSchema),
	event("devices.catalog", "control", deviceEventDataSchemas["devices.catalog"]),
	event("devices.session", "control", deviceEventDataSchemas["devices.session"]),
	event("devices.telemetry", "telemetry", deviceEventDataSchemas["devices.telemetry"]),
	event("devices.motion", "control", deviceEventDataSchemas["devices.motion"]),
	event("devices.reservation", "control", deviceEventDataSchemas["devices.reservation"]),
	event("devices.recordingFrames", "telemetry", deviceEventDataSchemas["devices.recordingFrames"]),
	event("devices.authority", "control", deviceEventDataSchemas["devices.authority"]),
	event("events.resyncRequired", "control", deviceEventDataSchemas["events.resyncRequired"]),
	event("ui.data", "telemetry", uiEventDataSchemas["ui.data"]),
	event("ui.instances", "control", uiEventDataSchemas["ui.instances"]),
	event("ui.visibility", "control", uiEventDataSchemas["ui.visibility"]),
	event("ui.environment", "control", uiEventDataSchemas["ui.environment"]),
	event("ui.form", "control", uiEventDataSchemas["ui.form"]),
	event("ui.state", "telemetry", uiEventDataSchemas["ui.state"]),
	event("ui.revoked", "control", uiEventDataSchemas["ui.revoked"])
]);
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/methods.js
var severitySchema = _enum([
	"info",
	"warning",
	"error"
]);
var empty = strictObject({});
var requestMethods = {
	...settingsRequestSchemas,
	...storageRequestSchemas,
	...persistenceActionRequestSchemas,
	...uiRequestSchemasV2,
	...deviceRequestSchemas,
	initialize: {
		params: strictObject({
			apiVersion: semverSchema,
			pluginId: namespacedIdSchema,
			locale: pluginLocaleSchema,
			grantedPermissions: array(permissionSchema).max(16)
		}),
		result: strictObject({
			apiVersion: semverSchema,
			sdk: strictObject({
				name: string().min(1).max(64),
				version: string().min(1).max(64)
			})
		})
	},
	"command/execute": {
		params: strictObject({ command: namespacedIdSchema }),
		result: _null()
	},
	shutdown: {
		params: empty,
		result: _null()
	},
	"ui/showMessage": {
		params: strictObject({
			severity: severitySchema,
			message: string().min(1).max(PLUGIN_LIMITS.messageLength).regex(MULTI_LINE)
		}),
		result: _null()
	}
};
var notificationMethods = {
	"events/deliver": eventEnvelopeSchema,
	"$/cancelRequest": strictObject({ id: jsonRpcIdSchema }),
	exit: empty
};
new TextEncoder();
//#endregion
//#region ../../plugin-3d/Kobrixa/packages/plugin-protocol/dist/ui-v2-resource.js
var dataRef = strictObject({
	scope: literal("data"),
	key: localIdSchema
});
var uiCommandV2Schema = strictObject({
	command: namespacedIdSchema,
	arguments: argumentBindingsSchema
});
var rowCommandV2Schema = uiCommandV2Schema.extend({
	rowKeyArg: localIdSchema,
	rowVersionArg: localIdSchema,
	datasetRevisionArg: localIdSchema
});
var cursorCommandV2Schema = uiCommandV2Schema.extend({
	timeArg: localIdSchema,
	presentationArg: localIdSchema,
	readings: array(strictObject({
		dataset: localIdSchema,
		series: localIdSchema,
		rawKey: localIdSchema,
		valueKey: localIdSchema
	})).min(1).max(8)
});
var recordingStop = strictObject({
	kind: literal("core"),
	action: literal("stopRecording"),
	reservation: dataRef
});
var uiActionV2Schema = union([
	uiActionSchema,
	recordingStop,
	strictObject({
		kind: literal("view"),
		action: _enum(["openDialog", "closeDialog"]),
		dialogId: localIdSchema
	})
]);
var labeled = {
	id: localIdSchema,
	visibleWhen: conditionSchema.exactOptional(),
	enabledWhen: conditionSchema.exactOptional(),
	label: uiLabelSchema
};
var rowAction = union([strictObject({
	kind: literal("command"),
	command: rowCommandV2Schema
}), strictObject({
	kind: literal("view"),
	action: literal("openDialog"),
	dialogId: localIdSchema
})]);
var uiNodeV2Schema = union([
	...uiNodeV1Schema.options.filter((s) => s.shape.type.value !== "action"),
	strictObject({
		...labeled,
		type: literal("action"),
		action: uiActionV2Schema,
		variant: _enum([
			"normal",
			"primary",
			"danger"
		])
	}),
	strictObject({
		...labeled,
		type: literal("lineChart"),
		dataset: localIdSchema,
		cursorGroup: localIdSchema,
		timeView: _enum(["default", "inspect"]),
		onCursor: cursorCommandV2Schema
	}),
	strictObject({
		...labeled,
		type: literal("table"),
		dataset: localIdSchema,
		onSelect: rowCommandV2Schema.exactOptional()
	}),
	strictObject({
		...labeled,
		type: literal("list"),
		dataset: localIdSchema,
		actions: array(strictObject({
			id: localIdSchema,
			label: uiLabelSchema,
			action: rowAction
		})).max(3)
	}),
	strictObject({
		...labeled,
		type: literal("code"),
		dataset: localIdSchema,
		copy: uiCommandV2Schema
	}),
	strictObject({
		...labeled,
		type: literal("dialog"),
		children: array(localIdSchema).min(1).max(32),
		confirm: strictObject({
			label: uiLabelSchema,
			command: rowCommandV2Schema,
			dataset: localIdSchema
		}).exactOptional()
	})
]);
union([panelResourceV1Schema.extend({
	formSync: literal(true).exactOptional(),
	derivedFormRevisionKey: localIdSchema.exactOptional(),
	nodes: array(uiNodeV2Schema).min(1).max(256),
	datasets: record$1(localIdSchema, datasetDeclarationV2Schema),
	presentationKey: localIdSchema
}), statusResourceV1Schema.extend({ actions: array(strictObject({
	id: localIdSchema,
	label: uiLabelSchema,
	action: union([strictObject({
		kind: literal("core"),
		action: literal("openPanel"),
		panelId: namespacedIdSchema
	}), recordingStop])
})).max(2) })]);
//#endregion
//#region ../../../../Documents/Kobrixa/.claude/worktrees/plugin-3b2/node_modules/@eslint-community/regexpp/index.mjs
var latestEcmaVersion = 2025;
var largeIdStartRanges = void 0;
var largeIdContinueRanges = void 0;
function isIdStart(cp) {
	if (cp < 65) return false;
	if (cp < 91) return true;
	if (cp < 97) return false;
	if (cp < 123) return true;
	return isLargeIdStart(cp);
}
function isIdContinue(cp) {
	if (cp < 48) return false;
	if (cp < 58) return true;
	if (cp < 65) return false;
	if (cp < 91) return true;
	if (cp === 95) return true;
	if (cp < 97) return false;
	if (cp < 123) return true;
	return isLargeIdStart(cp) || isLargeIdContinue(cp);
}
function isLargeIdStart(cp) {
	return isInRange(cp, largeIdStartRanges !== null && largeIdStartRanges !== void 0 ? largeIdStartRanges : largeIdStartRanges = initLargeIdStartRanges());
}
function isLargeIdContinue(cp) {
	return isInRange(cp, largeIdContinueRanges !== null && largeIdContinueRanges !== void 0 ? largeIdContinueRanges : largeIdContinueRanges = initLargeIdContinueRanges());
}
function initLargeIdStartRanges() {
	return restoreRanges("4q 0 b 0 5 0 6 m 2 u 2 cp 5 b f 4 8 0 2 0 3m 4 2 1 3 3 2 0 7 0 2 2 2 0 2 j 2 2a 2 3u 9 4l 2 11 3 0 7 14 20 q 5 3 1a 16 10 1 2 2q 2 0 g 1 8 1 b 2 3 0 h 0 2 t u 2g c 0 p w a 1 5 0 6 l 5 0 a 0 4 0 o o 8 a 6 n 2 6 h 15 1n 1h 4 0 j 0 8 9 g f 5 7 3 1 3 l 2 6 2 0 4 3 4 0 h 0 e 1 2 2 f 1 b 0 9 5 5 1 3 l 2 6 2 1 2 1 2 1 w 3 2 0 k 2 h 8 2 2 2 l 2 6 2 1 2 4 4 0 j 0 g 1 o 0 c 7 3 1 3 l 2 6 2 1 2 4 4 0 v 1 2 2 g 0 i 0 2 5 4 2 2 3 4 1 2 0 2 1 4 1 4 2 4 b n 0 1h 7 2 2 2 m 2 f 4 0 r 2 2 1 3 1 v 0 5 7 2 2 2 m 2 9 2 4 4 0 v 2 2 1 g 1 i 8 2 2 2 14 3 0 h 0 6 2 9 2 p 5 6 h 4 n 2 8 2 0 3 6 1n 1b 2 1 d 6 1n 1 2 0 2 4 2 n 2 0 2 9 2 1 a 0 3 4 2 0 m 3 x 0 1s 7 2 z s 4 38 16 l 0 h 5 5 3 4 0 4 1 8 2 5 c d 0 i 11 2 0 6 0 3 16 2 98 2 3 3 6 2 0 2 3 3 14 2 3 3 w 2 3 3 6 2 0 2 3 3 e 2 1k 2 3 3 1u 12 f h 2d 3 5 4 h7 3 g 2 p 6 22 4 a 8 h e i f h f c 2 2 g 1f 10 0 5 0 1w 2g 8 14 2 0 6 1x b u 1e t 3 4 c 17 5 p 1j m a 1g 2b 0 2m 1a i 7 1j t e 1 b 17 r z 16 2 b z 3 a 6 16 3 2 16 3 2 5 2 1 4 0 6 5b 1t 7p 3 5 3 11 3 5 3 7 2 0 2 0 2 0 2 u 3 1g 2 6 2 0 4 2 2 6 4 3 3 5 5 c 6 2 2 6 39 0 e 0 h c 2u 0 5 0 3 9 2 0 3 5 7 0 2 0 2 0 2 f 3 3 6 4 5 0 i 14 22g 6c 7 3 4 1 d 11 2 0 6 0 3 1j 8 0 h m a 6 2 6 2 6 2 6 2 6 2 6 2 6 2 6 fb 2 q 8 8 4 3 4 5 2d 5 4 2 2h 2 3 6 16 2 2l i v 1d f e9 533 1t h3g 1w 19 3 7g 4 f b 1 l 1a h u 3 27 14 8 3 2u 3 29 l g 2 2 2 3 2 m u 1f f 1d 1r 5 4 0 2 1 c r b m q s 8 1a t 0 h 4 2 9 b 4 2 14 o 2 2 7 l m 4 0 4 1d 2 0 4 1 3 4 3 0 2 0 p 2 3 a 8 2 d 5 3 5 3 5 a 6 2 6 2 16 2 d 7 36 u 8mb d m 5 1c 6it a5 3 2x 13 6 d 4 6 0 2 9 2 c 2 4 2 0 2 1 2 1 2 2z y a2 j 1r 3 1h 15 b 39 4 2 3q 11 p 7 p c 2g 4 5 3 5 3 5 3 2 10 b 2 p 2 i 2 1 2 e 3 d z 3e 1y 1g 7g s 4 1c 1c v e t 6 11 b t 3 z 5 7 2 4 17 4d j z 5 z 5 13 9 1f d a 2 e 2 6 2 1 2 a 2 e 2 6 2 1 4 1f d 8m a l b 7 p 5 2 15 2 8 1y 5 3 0 2 17 2 1 4 0 3 m b m a u 1u i 2 1 b l b p 7 p 13 1j 7 1 1t 0 g 3 2 2 2 s 17 s 4 s 10 7 2 r s 1h b l b i e h 33 20 1k 1e e 1e e z 13 r a m 6z 15 7 1 h 5 1l s b 0 9 l 17 h 1b k s m d 1g 1m 1 3 0 e 18 x o r z u 0 3 0 9 y 4 0 d 1b f 3 m 0 2 0 10 h 2 o k 1 1s 6 2 0 2 3 2 e 2 9 8 1a 13 7 3 1 3 l 2 6 2 1 2 4 4 0 j 0 d 4 v 9 2 0 3 0 2 11 2 0 q 0 2 0 19 1g j 3 l 2 v 1b l 1 2 0 55 1a 16 3 11 1b l 0 1o 16 e 0 20 q 12 6 56 17 39 1r w 7 3 0 3 7 2 1 2 n g 0 2 0 2n 7 3 12 h 0 2 0 t 0 b 13 8 0 m 0 c 19 k 0 j 20 5k w w 8 2 10 i 0 1e t 35 6 2 1 2 11 m 0 q 5 2 1 2 v f 0 o 17 79 i g 0 2 c 2 x 3h 0 28 pl 2v 32 i 5f 219 2o g tr i 5 q 32y 6 g6 5a2 t 1cz fs 8 u i 26 i t j 1b h 3 w k 6 i c1 18 5w 1r x o 3 o 19 22 6 0 1v c 1t 1 2 0 f 4 a 5p1 16 v 2q 36 6pq 3 2 6 2 1 2 82 g 0 u 2 3 0 f 3 9 az 1s5 2y 6 c 4 8 8 9 4mf 2c 2 1y 2 1 3 0 3 1 3 3 2 b 2 0 2 6 2 1s 2 3 3 7 2 6 2 r 2 3 2 4 2 0 4 6 2 9f 3 o 2 o 2 u 2 o 2 u 2 o 2 u 2 o 2 u 2 o 2 7 1f9 u 7 5 7a 1p 43 18 b 6 h 0 8y t j 17 dh r 6d t 3 0 5s u 2 2 2 1 2 6 3 4 a 1 69 6 2 3 2 1 2 e 2 5g 1o 1v 8 0 xh 3 2 q 2 1 2 0 3 0 2 9 2 3 2 0 2 0 7 0 5 0 2 0 2 0 2 2 2 1 2 0 3 0 2 0 2 0 2 0 2 0 2 1 2 0 3 3 2 6 2 3 2 3 2 0 2 9 2 g 6 2 2 4 2 g 3et wyn x 3dp 3 4gd 3 5rk g h9 1wj f1 15v 3t6 6 6jt");
}
function initLargeIdContinueRanges() {
	return restoreRanges("53 0 g9 33 o 0 70 4 7e 18 2 0 2 1 2 1 2 0 21 a 1d u 7 0 2u 6 3 5 3 1 2 3 3 9 o 0 v q 2k a g 9 y 8 a 0 p 3 2 8 2 2 2 4 18 2 1o 8 17 n 2 w 1j 2 2 h 2 6 b 1 3 9 i 2 1l 0 2 6 3 1 3 2 a 0 b 1 3 9 f 0 3 2 1l 0 2 4 5 1 3 2 4 0 l b 4 0 c 2 1l 0 2 7 2 2 2 2 l 1 3 9 b 5 2 2 1l 0 2 6 3 1 3 2 8 2 b 1 3 9 j 0 1o 4 4 2 2 3 a 0 f 9 h 4 1k 0 2 6 2 2 2 3 8 1 c 1 3 9 i 2 1l 0 2 6 2 2 2 3 8 1 c 1 3 9 4 0 d 3 1k 1 2 6 2 2 2 3 a 0 b 1 3 9 i 2 1z 0 5 5 2 0 2 7 7 9 3 1 1q 0 3 6 d 7 2 9 2g 0 3 8 c 6 2 9 1r 1 7 9 c 0 2 0 2 0 5 1 1e j 2 1 6 a 2 z a 0 2t j 2 9 d 3 5 2 2 2 3 6 4 3 e b 2 e jk 2 a 8 pt 3 t 2 u 1 v 1 1t v a 0 3 9 y 2 2 a 40 0 3b b 5 b b 9 3l a 1p 4 1m 9 2 s 3 a 7 9 n d 2 u 3 b l 4 1c g c 9 i 8 d 2 v c 3 9 19 d 1d j 9 9 7 9 3b 2 2 k 5 0 7 0 3 2 5j 1r el 1 1e 1 k 0 3g c 5 0 4 b 2db 2 3y 0 2p v ff 5 2y 1 2p 0 n51 9 1y 0 5 9 x 1 29 1 7l 0 4 0 5 0 o 4 5 0 2c 1 1f h b 9 7 h e a t 7 q c 19 3 1c d g 9 c 0 b 9 1c d d 0 9 1 3 9 y 2 1f 0 2 2 3 1 6 1 2 0 16 4 6 1 6l 7 2 1 3 9 fmt 0 ki f h f 4 1 p 2 5d 9 12 0 12 0 ig 0 6b 0 46 4 86 9 120 2 2 1 6 3 15 2 5 0 4m 1 fy 3 9 9 7 9 w 4 8u 1 26 5 1z a 1e 3 3f 2 1i e w a 3 1 b 3 1a a 8 0 1a 9 7 2 11 d 2 9 6 1 19 0 d 2 1d d 9 3 2 b 2b b 7 0 3 0 4e b 6 9 7 3 1k 1 2 6 3 1 3 2 a 0 b 1 3 6 4 4 1w 8 2 0 3 0 2 3 2 4 2 0 f 1 2b h a 9 5 0 2a j d 9 5y 6 3 8 s 1 2b g g 9 2a c 9 9 7 j 1m e 5 9 6r e 4m 9 1z 5 2 1 3 3 2 0 2 1 d 9 3c 6 3 6 4 0 t 9 15 6 2 3 9 0 a a 1b f 5j 7 3t 9 1i 7 2 7 h 9 1l l 2 d 3f 5 4 0 2 1 2 6 2 0 9 9 1d 4 2 1 2 4 9 9 1j 9 7e 3 a 1 2 0 1d 6 4 4 e a 44m 0 7 e 8uh r 1t3 9 2f 9 13 4 1o 6 q 9 ev 9 d2 0 2 1i 8 3 2a 0 c 1 f58 1 382 9 ef 19 3 m f3 4 4 5 9 7 3 6 v 3 45 2 13e 1d e9 1i 5 1d 9 0 f 0 n 4 2 e 11t 6 2 g 3 6 2 1 2 4 2t 0 4h 6 a 9 9x 0 1q d dv d 6t 1 2 9 6h 0 3 0 8 1 6 0 d7 6 32 6 6 9 3o7 9 gvt3 6n");
}
function isInRange(cp, ranges) {
	let l = 0, r = ranges.length / 2 | 0, i = 0, min = 0, max = 0;
	while (l < r) {
		i = (l + r) / 2 | 0;
		min = ranges[2 * i];
		max = ranges[2 * i + 1];
		if (cp < min) r = i;
		else if (cp > max) l = i + 1;
		else return true;
	}
	return false;
}
function restoreRanges(data) {
	let last = 0;
	return data.split(" ").map((s) => last += parseInt(s, 36) | 0);
}
var DataSet = class {
	constructor(raw2018, raw2019, raw2020, raw2021, raw2022, raw2023, raw2024, raw2025, raw2026) {
		this._raw2018 = raw2018;
		this._raw2019 = raw2019;
		this._raw2020 = raw2020;
		this._raw2021 = raw2021;
		this._raw2022 = raw2022;
		this._raw2023 = raw2023;
		this._raw2024 = raw2024;
		this._raw2025 = raw2025;
		this._raw2026 = raw2026;
	}
	get es2018() {
		var _a;
		return (_a = this._set2018) !== null && _a !== void 0 ? _a : this._set2018 = new Set(this._raw2018.split(" "));
	}
	get es2019() {
		var _a;
		return (_a = this._set2019) !== null && _a !== void 0 ? _a : this._set2019 = new Set(this._raw2019.split(" "));
	}
	get es2020() {
		var _a;
		return (_a = this._set2020) !== null && _a !== void 0 ? _a : this._set2020 = new Set(this._raw2020.split(" "));
	}
	get es2021() {
		var _a;
		return (_a = this._set2021) !== null && _a !== void 0 ? _a : this._set2021 = new Set(this._raw2021.split(" "));
	}
	get es2022() {
		var _a;
		return (_a = this._set2022) !== null && _a !== void 0 ? _a : this._set2022 = new Set(this._raw2022.split(" "));
	}
	get es2023() {
		var _a;
		return (_a = this._set2023) !== null && _a !== void 0 ? _a : this._set2023 = new Set(this._raw2023.split(" "));
	}
	get es2024() {
		var _a;
		return (_a = this._set2024) !== null && _a !== void 0 ? _a : this._set2024 = new Set(this._raw2024.split(" "));
	}
	get es2025() {
		var _a;
		return (_a = this._set2025) !== null && _a !== void 0 ? _a : this._set2025 = new Set(this._raw2025.split(" "));
	}
	get es2026() {
		var _a;
		return (_a = this._set2026) !== null && _a !== void 0 ? _a : this._set2026 = new Set(this._raw2026.split(" "));
	}
};
var gcNameSet = /* @__PURE__ */ new Set(["General_Category", "gc"]);
var scNameSet = /* @__PURE__ */ new Set([
	"Script",
	"Script_Extensions",
	"sc",
	"scx"
]);
var gcValueSets = new DataSet("C Cased_Letter Cc Cf Close_Punctuation Cn Co Combining_Mark Connector_Punctuation Control Cs Currency_Symbol Dash_Punctuation Decimal_Number Enclosing_Mark Final_Punctuation Format Initial_Punctuation L LC Letter Letter_Number Line_Separator Ll Lm Lo Lowercase_Letter Lt Lu M Mark Math_Symbol Mc Me Mn Modifier_Letter Modifier_Symbol N Nd Nl No Nonspacing_Mark Number Open_Punctuation Other Other_Letter Other_Number Other_Punctuation Other_Symbol P Paragraph_Separator Pc Pd Pe Pf Pi Po Private_Use Ps Punctuation S Sc Separator Sk Sm So Space_Separator Spacing_Mark Surrogate Symbol Titlecase_Letter Unassigned Uppercase_Letter Z Zl Zp Zs cntrl digit punct", "", "", "", "", "", "", "", "");
var scValueSets = new DataSet("Adlam Adlm Aghb Ahom Anatolian_Hieroglyphs Arab Arabic Armenian Armi Armn Avestan Avst Bali Balinese Bamu Bamum Bass Bassa_Vah Batak Batk Beng Bengali Bhaiksuki Bhks Bopo Bopomofo Brah Brahmi Brai Braille Bugi Buginese Buhd Buhid Cakm Canadian_Aboriginal Cans Cari Carian Caucasian_Albanian Chakma Cham Cher Cherokee Common Copt Coptic Cprt Cuneiform Cypriot Cyrillic Cyrl Deseret Deva Devanagari Dsrt Dupl Duployan Egyp Egyptian_Hieroglyphs Elba Elbasan Ethi Ethiopic Geor Georgian Glag Glagolitic Gonm Goth Gothic Gran Grantha Greek Grek Gujarati Gujr Gurmukhi Guru Han Hang Hangul Hani Hano Hanunoo Hatr Hatran Hebr Hebrew Hira Hiragana Hluw Hmng Hung Imperial_Aramaic Inherited Inscriptional_Pahlavi Inscriptional_Parthian Ital Java Javanese Kaithi Kali Kana Kannada Katakana Kayah_Li Khar Kharoshthi Khmer Khmr Khoj Khojki Khudawadi Knda Kthi Lana Lao Laoo Latin Latn Lepc Lepcha Limb Limbu Lina Linb Linear_A Linear_B Lisu Lyci Lycian Lydi Lydian Mahajani Mahj Malayalam Mand Mandaic Mani Manichaean Marc Marchen Masaram_Gondi Meetei_Mayek Mend Mende_Kikakui Merc Mero Meroitic_Cursive Meroitic_Hieroglyphs Miao Mlym Modi Mong Mongolian Mro Mroo Mtei Mult Multani Myanmar Mymr Nabataean Narb Nbat New_Tai_Lue Newa Nko Nkoo Nshu Nushu Ogam Ogham Ol_Chiki Olck Old_Hungarian Old_Italic Old_North_Arabian Old_Permic Old_Persian Old_South_Arabian Old_Turkic Oriya Orkh Orya Osage Osge Osma Osmanya Pahawh_Hmong Palm Palmyrene Pau_Cin_Hau Pauc Perm Phag Phags_Pa Phli Phlp Phnx Phoenician Plrd Prti Psalter_Pahlavi Qaac Qaai Rejang Rjng Runic Runr Samaritan Samr Sarb Saur Saurashtra Sgnw Sharada Shavian Shaw Shrd Sidd Siddham SignWriting Sind Sinh Sinhala Sora Sora_Sompeng Soyo Soyombo Sund Sundanese Sylo Syloti_Nagri Syrc Syriac Tagalog Tagb Tagbanwa Tai_Le Tai_Tham Tai_Viet Takr Takri Tale Talu Tamil Taml Tang Tangut Tavt Telu Telugu Tfng Tglg Thaa Thaana Thai Tibetan Tibt Tifinagh Tirh Tirhuta Ugar Ugaritic Vai Vaii Wara Warang_Citi Xpeo Xsux Yi Yiii Zanabazar_Square Zanb Zinh Zyyy", "Dogr Dogra Gong Gunjala_Gondi Hanifi_Rohingya Maka Makasar Medefaidrin Medf Old_Sogdian Rohg Sogd Sogdian Sogo", "Elym Elymaic Hmnp Nand Nandinagari Nyiakeng_Puachue_Hmong Wancho Wcho", "Chorasmian Chrs Diak Dives_Akuru Khitan_Small_Script Kits Yezi Yezidi", "Cpmn Cypro_Minoan Old_Uyghur Ougr Tangsa Tnsa Toto Vith Vithkuqi", "Berf Beria_Erfe Gara Garay Gukh Gurung_Khema Hrkt Katakana_Or_Hiragana Kawi Kirat_Rai Krai Nag_Mundari Nagm Ol_Onal Onao Sidetic Sidt Sunu Sunuwar Tai_Yo Tayo Todhri Todr Tolong_Siki Tols Tulu_Tigalari Tutg Unknown Zzzz", "", "", "");
var binPropertySets = new DataSet("AHex ASCII ASCII_Hex_Digit Alpha Alphabetic Any Assigned Bidi_C Bidi_Control Bidi_M Bidi_Mirrored CI CWCF CWCM CWKCF CWL CWT CWU Case_Ignorable Cased Changes_When_Casefolded Changes_When_Casemapped Changes_When_Lowercased Changes_When_NFKC_Casefolded Changes_When_Titlecased Changes_When_Uppercased DI Dash Default_Ignorable_Code_Point Dep Deprecated Dia Diacritic Emoji Emoji_Component Emoji_Modifier Emoji_Modifier_Base Emoji_Presentation Ext Extender Gr_Base Gr_Ext Grapheme_Base Grapheme_Extend Hex Hex_Digit IDC IDS IDSB IDST IDS_Binary_Operator IDS_Trinary_Operator ID_Continue ID_Start Ideo Ideographic Join_C Join_Control LOE Logical_Order_Exception Lower Lowercase Math NChar Noncharacter_Code_Point Pat_Syn Pat_WS Pattern_Syntax Pattern_White_Space QMark Quotation_Mark RI Radical Regional_Indicator SD STerm Sentence_Terminal Soft_Dotted Term Terminal_Punctuation UIdeo Unified_Ideograph Upper Uppercase VS Variation_Selector White_Space XIDC XIDS XID_Continue XID_Start space", "Extended_Pictographic", "", "EBase EComp EMod EPres ExtPict", "", "", "", "", "");
var binPropertyOfStringsSets = new DataSet("", "", "", "", "", "", "Basic_Emoji Emoji_Keycap_Sequence RGI_Emoji RGI_Emoji_Flag_Sequence RGI_Emoji_Modifier_Sequence RGI_Emoji_Tag_Sequence RGI_Emoji_ZWJ_Sequence", "", "");
function isValidUnicodeProperty(version, name, value) {
	if (gcNameSet.has(name)) return version >= 2018 && gcValueSets.es2018.has(value);
	if (scNameSet.has(name)) return version >= 2018 && scValueSets.es2018.has(value) || version >= 2019 && scValueSets.es2019.has(value) || version >= 2020 && scValueSets.es2020.has(value) || version >= 2021 && scValueSets.es2021.has(value) || version >= 2022 && scValueSets.es2022.has(value) || version >= 2023 && scValueSets.es2023.has(value);
	return false;
}
function isValidLoneUnicodeProperty(version, value) {
	return version >= 2018 && binPropertySets.es2018.has(value) || version >= 2019 && binPropertySets.es2019.has(value) || version >= 2021 && binPropertySets.es2021.has(value);
}
function isValidLoneUnicodePropertyOfString(version, value) {
	return version >= 2024 && binPropertyOfStringsSets.es2024.has(value);
}
var BACKSPACE = 8;
var CHARACTER_TABULATION = 9;
var LINE_FEED = 10;
var LINE_TABULATION = 11;
var FORM_FEED = 12;
var CARRIAGE_RETURN = 13;
var EXCLAMATION_MARK = 33;
var NUMBER_SIGN = 35;
var DOLLAR_SIGN = 36;
var PERCENT_SIGN = 37;
var AMPERSAND = 38;
var LEFT_PARENTHESIS = 40;
var RIGHT_PARENTHESIS = 41;
var ASTERISK = 42;
var PLUS_SIGN = 43;
var COMMA = 44;
var HYPHEN_MINUS = 45;
var FULL_STOP = 46;
var SOLIDUS = 47;
var DIGIT_ZERO = 48;
var DIGIT_ONE = 49;
var DIGIT_SEVEN = 55;
var DIGIT_NINE = 57;
var COLON = 58;
var SEMICOLON = 59;
var LESS_THAN_SIGN = 60;
var EQUALS_SIGN = 61;
var GREATER_THAN_SIGN = 62;
var QUESTION_MARK = 63;
var COMMERCIAL_AT = 64;
var LATIN_CAPITAL_LETTER_A = 65;
var LATIN_CAPITAL_LETTER_B = 66;
var LATIN_CAPITAL_LETTER_D = 68;
var LATIN_CAPITAL_LETTER_F = 70;
var LATIN_CAPITAL_LETTER_P = 80;
var LATIN_CAPITAL_LETTER_S = 83;
var LATIN_CAPITAL_LETTER_W = 87;
var LATIN_CAPITAL_LETTER_Z = 90;
var LOW_LINE = 95;
var LATIN_SMALL_LETTER_A = 97;
var LATIN_SMALL_LETTER_B = 98;
var LATIN_SMALL_LETTER_C = 99;
var LATIN_SMALL_LETTER_D = 100;
var LATIN_SMALL_LETTER_F = 102;
var LATIN_SMALL_LETTER_G = 103;
var LATIN_SMALL_LETTER_I = 105;
var LATIN_SMALL_LETTER_K = 107;
var LATIN_SMALL_LETTER_M = 109;
var LATIN_SMALL_LETTER_N = 110;
var LATIN_SMALL_LETTER_P = 112;
var LATIN_SMALL_LETTER_Q = 113;
var LATIN_SMALL_LETTER_R = 114;
var LATIN_SMALL_LETTER_S = 115;
var LATIN_SMALL_LETTER_T = 116;
var LATIN_SMALL_LETTER_U = 117;
var LATIN_SMALL_LETTER_V = 118;
var LATIN_SMALL_LETTER_W = 119;
var LATIN_SMALL_LETTER_X = 120;
var LATIN_SMALL_LETTER_Y = 121;
var LATIN_SMALL_LETTER_Z = 122;
var LEFT_SQUARE_BRACKET = 91;
var REVERSE_SOLIDUS = 92;
var RIGHT_SQUARE_BRACKET = 93;
var CIRCUMFLEX_ACCENT = 94;
var GRAVE_ACCENT = 96;
var LEFT_CURLY_BRACKET = 123;
var VERTICAL_LINE = 124;
var RIGHT_CURLY_BRACKET = 125;
var TILDE = 126;
var ZERO_WIDTH_NON_JOINER = 8204;
var ZERO_WIDTH_JOINER = 8205;
var LINE_SEPARATOR = 8232;
var PARAGRAPH_SEPARATOR = 8233;
var MIN_CODE_POINT = 0;
var MAX_CODE_POINT = 1114111;
function isLatinLetter(code) {
	return code >= LATIN_CAPITAL_LETTER_A && code <= LATIN_CAPITAL_LETTER_Z || code >= LATIN_SMALL_LETTER_A && code <= LATIN_SMALL_LETTER_Z;
}
function isDecimalDigit(code) {
	return code >= DIGIT_ZERO && code <= DIGIT_NINE;
}
function isOctalDigit(code) {
	return code >= DIGIT_ZERO && code <= DIGIT_SEVEN;
}
function isHexDigit(code) {
	return code >= DIGIT_ZERO && code <= DIGIT_NINE || code >= LATIN_CAPITAL_LETTER_A && code <= LATIN_CAPITAL_LETTER_F || code >= LATIN_SMALL_LETTER_A && code <= LATIN_SMALL_LETTER_F;
}
function isLineTerminator(code) {
	return code === LINE_FEED || code === CARRIAGE_RETURN || code === LINE_SEPARATOR || code === PARAGRAPH_SEPARATOR;
}
function isValidUnicode(code) {
	return code >= MIN_CODE_POINT && code <= MAX_CODE_POINT;
}
function digitToInt(code) {
	if (code >= LATIN_SMALL_LETTER_A && code <= LATIN_SMALL_LETTER_F) return code - LATIN_SMALL_LETTER_A + 10;
	if (code >= LATIN_CAPITAL_LETTER_A && code <= LATIN_CAPITAL_LETTER_F) return code - LATIN_CAPITAL_LETTER_A + 10;
	return code - DIGIT_ZERO;
}
function isLeadSurrogate(code) {
	return code >= 55296 && code <= 56319;
}
function isTrailSurrogate(code) {
	return code >= 56320 && code <= 57343;
}
function combineSurrogatePair(lead, trail) {
	return (lead - 55296) * 1024 + (trail - 56320) + 65536;
}
var GroupSpecifiersAsES2018 = class {
	constructor() {
		this.groupName = /* @__PURE__ */ new Set();
	}
	clear() {
		this.groupName.clear();
	}
	isEmpty() {
		return !this.groupName.size;
	}
	hasInPattern(name) {
		return this.groupName.has(name);
	}
	hasInScope(name) {
		return this.hasInPattern(name);
	}
	addToScope(name) {
		this.groupName.add(name);
	}
	enterDisjunction() {}
	enterAlternative() {}
	leaveDisjunction() {}
};
var BranchID = class BranchID {
	constructor(parent, base) {
		this.parent = parent;
		this.base = base !== null && base !== void 0 ? base : this;
	}
	separatedFrom(other) {
		var _a, _b;
		if (this.base === other.base && this !== other) return true;
		if (other.parent && this.separatedFrom(other.parent)) return true;
		return (_b = (_a = this.parent) === null || _a === void 0 ? void 0 : _a.separatedFrom(other)) !== null && _b !== void 0 ? _b : false;
	}
	child() {
		return new BranchID(this, null);
	}
	sibling() {
		return new BranchID(this.parent, this.base);
	}
};
var GroupSpecifiersAsES2025 = class {
	constructor() {
		this.branchID = new BranchID(null, null);
		this.groupNames = /* @__PURE__ */ new Map();
	}
	clear() {
		this.branchID = new BranchID(null, null);
		this.groupNames.clear();
	}
	isEmpty() {
		return !this.groupNames.size;
	}
	enterDisjunction() {
		this.branchID = this.branchID.child();
	}
	enterAlternative(index) {
		if (index === 0) return;
		this.branchID = this.branchID.sibling();
	}
	leaveDisjunction() {
		this.branchID = this.branchID.parent;
	}
	hasInPattern(name) {
		return this.groupNames.has(name);
	}
	hasInScope(name) {
		const branches = this.groupNames.get(name);
		if (!branches) return false;
		for (const branch of branches) if (!branch.separatedFrom(this.branchID)) return true;
		return false;
	}
	addToScope(name) {
		const branches = this.groupNames.get(name);
		if (branches) {
			branches.push(this.branchID);
			return;
		}
		this.groupNames.set(name, [this.branchID]);
	}
};
var legacyImpl = {
	at(s, end, i) {
		return i < end ? s.charCodeAt(i) : -1;
	},
	width(c) {
		return 1;
	}
};
var unicodeImpl = {
	at(s, end, i) {
		return i < end ? s.codePointAt(i) : -1;
	},
	width(c) {
		return c > 65535 ? 2 : 1;
	}
};
var Reader = class {
	constructor() {
		this._impl = legacyImpl;
		this._s = "";
		this._i = 0;
		this._end = 0;
		this._cp1 = -1;
		this._w1 = 1;
		this._cp2 = -1;
		this._w2 = 1;
		this._cp3 = -1;
		this._w3 = 1;
		this._cp4 = -1;
	}
	get source() {
		return this._s;
	}
	get index() {
		return this._i;
	}
	get currentCodePoint() {
		return this._cp1;
	}
	get nextCodePoint() {
		return this._cp2;
	}
	get nextCodePoint2() {
		return this._cp3;
	}
	get nextCodePoint3() {
		return this._cp4;
	}
	reset(source, start, end, uFlag) {
		this._impl = uFlag ? unicodeImpl : legacyImpl;
		this._s = source;
		this._end = end;
		this.rewind(start);
	}
	rewind(index) {
		const impl = this._impl;
		this._i = index;
		this._cp1 = impl.at(this._s, this._end, index);
		this._w1 = impl.width(this._cp1);
		this._cp2 = impl.at(this._s, this._end, index + this._w1);
		this._w2 = impl.width(this._cp2);
		this._cp3 = impl.at(this._s, this._end, index + this._w1 + this._w2);
		this._w3 = impl.width(this._cp3);
		this._cp4 = impl.at(this._s, this._end, index + this._w1 + this._w2 + this._w3);
	}
	advance() {
		if (this._cp1 !== -1) {
			const impl = this._impl;
			this._i += this._w1;
			this._cp1 = this._cp2;
			this._w1 = this._w2;
			this._cp2 = this._cp3;
			this._w2 = impl.width(this._cp2);
			this._cp3 = this._cp4;
			this._w3 = impl.width(this._cp3);
			this._cp4 = impl.at(this._s, this._end, this._i + this._w1 + this._w2 + this._w3);
		}
	}
	eat(cp) {
		if (this._cp1 === cp) {
			this.advance();
			return true;
		}
		return false;
	}
	eat2(cp1, cp2) {
		if (this._cp1 === cp1 && this._cp2 === cp2) {
			this.advance();
			this.advance();
			return true;
		}
		return false;
	}
	eat3(cp1, cp2, cp3) {
		if (this._cp1 === cp1 && this._cp2 === cp2 && this._cp3 === cp3) {
			this.advance();
			this.advance();
			this.advance();
			return true;
		}
		return false;
	}
};
var RegExpSyntaxError = class extends SyntaxError {
	constructor(message, index) {
		super(message);
		this.index = index;
	}
};
function newRegExpSyntaxError(srcCtx, flags, index, message) {
	let source = "";
	if (srcCtx.kind === "literal") {
		const literal = srcCtx.source.slice(srcCtx.start, srcCtx.end);
		if (literal) source = `: ${literal}`;
	} else if (srcCtx.kind === "pattern") source = `: /${srcCtx.source.slice(srcCtx.start, srcCtx.end)}/${`${flags.unicode ? "u" : ""}${flags.unicodeSets ? "v" : ""}`}`;
	return new RegExpSyntaxError(`Invalid regular expression${source}: ${message}`, index);
}
var SYNTAX_CHARACTER = /* @__PURE__ */ new Set([
	CIRCUMFLEX_ACCENT,
	DOLLAR_SIGN,
	REVERSE_SOLIDUS,
	FULL_STOP,
	ASTERISK,
	PLUS_SIGN,
	QUESTION_MARK,
	LEFT_PARENTHESIS,
	RIGHT_PARENTHESIS,
	LEFT_SQUARE_BRACKET,
	RIGHT_SQUARE_BRACKET,
	LEFT_CURLY_BRACKET,
	RIGHT_CURLY_BRACKET,
	VERTICAL_LINE
]);
var CLASS_SET_RESERVED_DOUBLE_PUNCTUATOR_CHARACTER = /* @__PURE__ */ new Set([
	AMPERSAND,
	EXCLAMATION_MARK,
	NUMBER_SIGN,
	DOLLAR_SIGN,
	PERCENT_SIGN,
	ASTERISK,
	PLUS_SIGN,
	COMMA,
	FULL_STOP,
	COLON,
	SEMICOLON,
	LESS_THAN_SIGN,
	EQUALS_SIGN,
	GREATER_THAN_SIGN,
	QUESTION_MARK,
	COMMERCIAL_AT,
	CIRCUMFLEX_ACCENT,
	GRAVE_ACCENT,
	TILDE
]);
var CLASS_SET_SYNTAX_CHARACTER = /* @__PURE__ */ new Set([
	LEFT_PARENTHESIS,
	RIGHT_PARENTHESIS,
	LEFT_SQUARE_BRACKET,
	RIGHT_SQUARE_BRACKET,
	LEFT_CURLY_BRACKET,
	RIGHT_CURLY_BRACKET,
	SOLIDUS,
	HYPHEN_MINUS,
	REVERSE_SOLIDUS,
	VERTICAL_LINE
]);
var CLASS_SET_RESERVED_PUNCTUATOR = /* @__PURE__ */ new Set([
	AMPERSAND,
	HYPHEN_MINUS,
	EXCLAMATION_MARK,
	NUMBER_SIGN,
	PERCENT_SIGN,
	COMMA,
	COLON,
	SEMICOLON,
	LESS_THAN_SIGN,
	EQUALS_SIGN,
	GREATER_THAN_SIGN,
	COMMERCIAL_AT,
	GRAVE_ACCENT,
	TILDE
]);
var FLAG_PROP_TO_CODEPOINT = {
	global: LATIN_SMALL_LETTER_G,
	ignoreCase: LATIN_SMALL_LETTER_I,
	multiline: LATIN_SMALL_LETTER_M,
	unicode: LATIN_SMALL_LETTER_U,
	sticky: LATIN_SMALL_LETTER_Y,
	dotAll: LATIN_SMALL_LETTER_S,
	hasIndices: LATIN_SMALL_LETTER_D,
	unicodeSets: LATIN_SMALL_LETTER_V
};
var FLAG_CODEPOINT_TO_PROP = Object.fromEntries(Object.entries(FLAG_PROP_TO_CODEPOINT).map(([k, v]) => [v, k]));
function isSyntaxCharacter(cp) {
	return SYNTAX_CHARACTER.has(cp);
}
function isClassSetReservedDoublePunctuatorCharacter(cp) {
	return CLASS_SET_RESERVED_DOUBLE_PUNCTUATOR_CHARACTER.has(cp);
}
function isClassSetSyntaxCharacter(cp) {
	return CLASS_SET_SYNTAX_CHARACTER.has(cp);
}
function isClassSetReservedPunctuator(cp) {
	return CLASS_SET_RESERVED_PUNCTUATOR.has(cp);
}
function isIdentifierStartChar(cp) {
	return isIdStart(cp) || cp === DOLLAR_SIGN || cp === LOW_LINE;
}
function isIdentifierPartChar(cp) {
	return isIdContinue(cp) || cp === DOLLAR_SIGN || cp === ZERO_WIDTH_NON_JOINER || cp === ZERO_WIDTH_JOINER;
}
function isUnicodePropertyNameCharacter(cp) {
	return isLatinLetter(cp) || cp === LOW_LINE;
}
function isUnicodePropertyValueCharacter(cp) {
	return isUnicodePropertyNameCharacter(cp) || isDecimalDigit(cp);
}
function isRegularExpressionModifier(ch) {
	return ch === LATIN_SMALL_LETTER_I || ch === LATIN_SMALL_LETTER_M || ch === LATIN_SMALL_LETTER_S;
}
var RegExpValidator = class {
	constructor(options) {
		this._reader = new Reader();
		this._unicodeMode = false;
		this._unicodeSetsMode = false;
		this._nFlag = false;
		this._lastIntValue = 0;
		this._lastRange = {
			min: 0,
			max: Number.POSITIVE_INFINITY
		};
		this._lastStrValue = "";
		this._lastAssertionIsQuantifiable = false;
		this._numCapturingParens = 0;
		this._backreferenceNames = /* @__PURE__ */ new Set();
		this._srcCtx = null;
		this._options = options !== null && options !== void 0 ? options : {};
		this._groupSpecifiers = this.ecmaVersion >= 2025 ? new GroupSpecifiersAsES2025() : new GroupSpecifiersAsES2018();
	}
	validateLiteral(source, start = 0, end = source.length) {
		this._srcCtx = {
			source,
			start,
			end,
			kind: "literal"
		};
		this._unicodeSetsMode = this._unicodeMode = this._nFlag = false;
		this.reset(source, start, end);
		this.onLiteralEnter(start);
		if (this.eat(SOLIDUS) && this.eatRegExpBody() && this.eat(SOLIDUS)) {
			const flagStart = this.index;
			const unicode = source.includes("u", flagStart);
			const unicodeSets = source.includes("v", flagStart);
			this.validateFlagsInternal(source, flagStart, end);
			this.validatePatternInternal(source, start + 1, flagStart - 1, {
				unicode,
				unicodeSets
			});
		} else if (start >= end) this.raise("Empty");
		else {
			const c = String.fromCodePoint(this.currentCodePoint);
			this.raise(`Unexpected character '${c}'`);
		}
		this.onLiteralLeave(start, end);
	}
	validateFlags(source, start = 0, end = source.length) {
		this._srcCtx = {
			source,
			start,
			end,
			kind: "flags"
		};
		this.validateFlagsInternal(source, start, end);
	}
	validatePattern(source, start = 0, end = source.length, uFlagOrFlags = void 0) {
		this._srcCtx = {
			source,
			start,
			end,
			kind: "pattern"
		};
		this.validatePatternInternal(source, start, end, uFlagOrFlags);
	}
	validatePatternInternal(source, start = 0, end = source.length, uFlagOrFlags = void 0) {
		const mode = this._parseFlagsOptionToMode(uFlagOrFlags, end);
		this._unicodeMode = mode.unicodeMode;
		this._nFlag = mode.nFlag;
		this._unicodeSetsMode = mode.unicodeSetsMode;
		this.reset(source, start, end);
		this.consumePattern();
		if (!this._nFlag && this.ecmaVersion >= 2018 && !this._groupSpecifiers.isEmpty()) {
			this._nFlag = true;
			this.rewind(start);
			this.consumePattern();
		}
	}
	validateFlagsInternal(source, start, end) {
		const flags = this.parseFlags(source, start, end);
		this.onRegExpFlags(start, end, flags);
	}
	_parseFlagsOptionToMode(uFlagOrFlags, sourceEnd) {
		let unicode = false;
		let unicodeSets = false;
		if (uFlagOrFlags && this.ecmaVersion >= 2015) {
			if (typeof uFlagOrFlags === "object") {
				unicode = Boolean(uFlagOrFlags.unicode);
				if (this.ecmaVersion >= 2024) unicodeSets = Boolean(uFlagOrFlags.unicodeSets);
			} else unicode = uFlagOrFlags;
		}
		if (unicode && unicodeSets) this.raise("Invalid regular expression flags", {
			index: sourceEnd + 1,
			unicode,
			unicodeSets
		});
		return {
			unicodeMode: unicode || unicodeSets,
			nFlag: unicode && this.ecmaVersion >= 2018 || unicodeSets || Boolean(this._options.strict && this.ecmaVersion >= 2023),
			unicodeSetsMode: unicodeSets
		};
	}
	get strict() {
		return Boolean(this._options.strict) || this._unicodeMode;
	}
	get ecmaVersion() {
		var _a;
		return (_a = this._options.ecmaVersion) !== null && _a !== void 0 ? _a : latestEcmaVersion;
	}
	onLiteralEnter(start) {
		if (this._options.onLiteralEnter) this._options.onLiteralEnter(start);
	}
	onLiteralLeave(start, end) {
		if (this._options.onLiteralLeave) this._options.onLiteralLeave(start, end);
	}
	onRegExpFlags(start, end, flags) {
		if (this._options.onRegExpFlags) this._options.onRegExpFlags(start, end, flags);
		if (this._options.onFlags) this._options.onFlags(start, end, flags.global, flags.ignoreCase, flags.multiline, flags.unicode, flags.sticky, flags.dotAll, flags.hasIndices);
	}
	onPatternEnter(start) {
		if (this._options.onPatternEnter) this._options.onPatternEnter(start);
	}
	onPatternLeave(start, end) {
		if (this._options.onPatternLeave) this._options.onPatternLeave(start, end);
	}
	onDisjunctionEnter(start) {
		if (this._options.onDisjunctionEnter) this._options.onDisjunctionEnter(start);
	}
	onDisjunctionLeave(start, end) {
		if (this._options.onDisjunctionLeave) this._options.onDisjunctionLeave(start, end);
	}
	onAlternativeEnter(start, index) {
		if (this._options.onAlternativeEnter) this._options.onAlternativeEnter(start, index);
	}
	onAlternativeLeave(start, end, index) {
		if (this._options.onAlternativeLeave) this._options.onAlternativeLeave(start, end, index);
	}
	onGroupEnter(start) {
		if (this._options.onGroupEnter) this._options.onGroupEnter(start);
	}
	onGroupLeave(start, end) {
		if (this._options.onGroupLeave) this._options.onGroupLeave(start, end);
	}
	onModifiersEnter(start) {
		if (this._options.onModifiersEnter) this._options.onModifiersEnter(start);
	}
	onModifiersLeave(start, end) {
		if (this._options.onModifiersLeave) this._options.onModifiersLeave(start, end);
	}
	onAddModifiers(start, end, flags) {
		if (this._options.onAddModifiers) this._options.onAddModifiers(start, end, flags);
	}
	onRemoveModifiers(start, end, flags) {
		if (this._options.onRemoveModifiers) this._options.onRemoveModifiers(start, end, flags);
	}
	onCapturingGroupEnter(start, name) {
		if (this._options.onCapturingGroupEnter) this._options.onCapturingGroupEnter(start, name);
	}
	onCapturingGroupLeave(start, end, name) {
		if (this._options.onCapturingGroupLeave) this._options.onCapturingGroupLeave(start, end, name);
	}
	onQuantifier(start, end, min, max, greedy) {
		if (this._options.onQuantifier) this._options.onQuantifier(start, end, min, max, greedy);
	}
	onLookaroundAssertionEnter(start, kind, negate) {
		if (this._options.onLookaroundAssertionEnter) this._options.onLookaroundAssertionEnter(start, kind, negate);
	}
	onLookaroundAssertionLeave(start, end, kind, negate) {
		if (this._options.onLookaroundAssertionLeave) this._options.onLookaroundAssertionLeave(start, end, kind, negate);
	}
	onEdgeAssertion(start, end, kind) {
		if (this._options.onEdgeAssertion) this._options.onEdgeAssertion(start, end, kind);
	}
	onWordBoundaryAssertion(start, end, kind, negate) {
		if (this._options.onWordBoundaryAssertion) this._options.onWordBoundaryAssertion(start, end, kind, negate);
	}
	onAnyCharacterSet(start, end, kind) {
		if (this._options.onAnyCharacterSet) this._options.onAnyCharacterSet(start, end, kind);
	}
	onEscapeCharacterSet(start, end, kind, negate) {
		if (this._options.onEscapeCharacterSet) this._options.onEscapeCharacterSet(start, end, kind, negate);
	}
	onUnicodePropertyCharacterSet(start, end, kind, key, value, negate, strings) {
		if (this._options.onUnicodePropertyCharacterSet) this._options.onUnicodePropertyCharacterSet(start, end, kind, key, value, negate, strings);
	}
	onCharacter(start, end, value) {
		if (this._options.onCharacter) this._options.onCharacter(start, end, value);
	}
	onBackreference(start, end, ref) {
		if (this._options.onBackreference) this._options.onBackreference(start, end, ref);
	}
	onCharacterClassEnter(start, negate, unicodeSets) {
		if (this._options.onCharacterClassEnter) this._options.onCharacterClassEnter(start, negate, unicodeSets);
	}
	onCharacterClassLeave(start, end, negate) {
		if (this._options.onCharacterClassLeave) this._options.onCharacterClassLeave(start, end, negate);
	}
	onCharacterClassRange(start, end, min, max) {
		if (this._options.onCharacterClassRange) this._options.onCharacterClassRange(start, end, min, max);
	}
	onClassIntersection(start, end) {
		if (this._options.onClassIntersection) this._options.onClassIntersection(start, end);
	}
	onClassSubtraction(start, end) {
		if (this._options.onClassSubtraction) this._options.onClassSubtraction(start, end);
	}
	onClassStringDisjunctionEnter(start) {
		if (this._options.onClassStringDisjunctionEnter) this._options.onClassStringDisjunctionEnter(start);
	}
	onClassStringDisjunctionLeave(start, end) {
		if (this._options.onClassStringDisjunctionLeave) this._options.onClassStringDisjunctionLeave(start, end);
	}
	onStringAlternativeEnter(start, index) {
		if (this._options.onStringAlternativeEnter) this._options.onStringAlternativeEnter(start, index);
	}
	onStringAlternativeLeave(start, end, index) {
		if (this._options.onStringAlternativeLeave) this._options.onStringAlternativeLeave(start, end, index);
	}
	get index() {
		return this._reader.index;
	}
	get currentCodePoint() {
		return this._reader.currentCodePoint;
	}
	get nextCodePoint() {
		return this._reader.nextCodePoint;
	}
	get nextCodePoint2() {
		return this._reader.nextCodePoint2;
	}
	get nextCodePoint3() {
		return this._reader.nextCodePoint3;
	}
	reset(source, start, end) {
		this._reader.reset(source, start, end, this._unicodeMode);
	}
	rewind(index) {
		this._reader.rewind(index);
	}
	advance() {
		this._reader.advance();
	}
	eat(cp) {
		return this._reader.eat(cp);
	}
	eat2(cp1, cp2) {
		return this._reader.eat2(cp1, cp2);
	}
	eat3(cp1, cp2, cp3) {
		return this._reader.eat3(cp1, cp2, cp3);
	}
	raise(message, context) {
		var _a, _b, _c;
		throw newRegExpSyntaxError(this._srcCtx, {
			unicode: (_a = context === null || context === void 0 ? void 0 : context.unicode) !== null && _a !== void 0 ? _a : this._unicodeMode && !this._unicodeSetsMode,
			unicodeSets: (_b = context === null || context === void 0 ? void 0 : context.unicodeSets) !== null && _b !== void 0 ? _b : this._unicodeSetsMode
		}, (_c = context === null || context === void 0 ? void 0 : context.index) !== null && _c !== void 0 ? _c : this.index, message);
	}
	eatRegExpBody() {
		const start = this.index;
		let inClass = false;
		let escaped = false;
		for (;;) {
			const cp = this.currentCodePoint;
			if (cp === -1 || isLineTerminator(cp)) {
				const kind = inClass ? "character class" : "regular expression";
				this.raise(`Unterminated ${kind}`);
			}
			if (escaped) escaped = false;
			else if (cp === REVERSE_SOLIDUS) escaped = true;
			else if (cp === LEFT_SQUARE_BRACKET) inClass = true;
			else if (cp === RIGHT_SQUARE_BRACKET) inClass = false;
			else if (cp === SOLIDUS && !inClass || cp === ASTERISK && this.index === start) break;
			this.advance();
		}
		return this.index !== start;
	}
	consumePattern() {
		const start = this.index;
		this._numCapturingParens = this.countCapturingParens();
		this._groupSpecifiers.clear();
		this._backreferenceNames.clear();
		this.onPatternEnter(start);
		this.consumeDisjunction();
		const cp = this.currentCodePoint;
		if (this.currentCodePoint !== -1) {
			if (cp === RIGHT_PARENTHESIS) this.raise("Unmatched ')'");
			if (cp === REVERSE_SOLIDUS) this.raise("\\ at end of pattern");
			if (cp === RIGHT_SQUARE_BRACKET || cp === RIGHT_CURLY_BRACKET) this.raise("Lone quantifier brackets");
			const c = String.fromCodePoint(cp);
			this.raise(`Unexpected character '${c}'`);
		}
		for (const name of this._backreferenceNames) if (!this._groupSpecifiers.hasInPattern(name)) this.raise("Invalid named capture referenced");
		this.onPatternLeave(start, this.index);
	}
	countCapturingParens() {
		const start = this.index;
		let inClass = false;
		let escaped = false;
		let count = 0;
		let cp = 0;
		while ((cp = this.currentCodePoint) !== -1) {
			if (escaped) escaped = false;
			else if (cp === REVERSE_SOLIDUS) escaped = true;
			else if (cp === LEFT_SQUARE_BRACKET) inClass = true;
			else if (cp === RIGHT_SQUARE_BRACKET) inClass = false;
			else if (cp === LEFT_PARENTHESIS && !inClass && (this.nextCodePoint !== QUESTION_MARK || this.nextCodePoint2 === LESS_THAN_SIGN && this.nextCodePoint3 !== EQUALS_SIGN && this.nextCodePoint3 !== EXCLAMATION_MARK)) count += 1;
			this.advance();
		}
		this.rewind(start);
		return count;
	}
	consumeDisjunction() {
		const start = this.index;
		let i = 0;
		this._groupSpecifiers.enterDisjunction();
		this.onDisjunctionEnter(start);
		do
			this.consumeAlternative(i++);
		while (this.eat(VERTICAL_LINE));
		if (this.consumeQuantifier(true)) this.raise("Nothing to repeat");
		if (this.eat(LEFT_CURLY_BRACKET)) this.raise("Lone quantifier brackets");
		this.onDisjunctionLeave(start, this.index);
		this._groupSpecifiers.leaveDisjunction();
	}
	consumeAlternative(i) {
		const start = this.index;
		this._groupSpecifiers.enterAlternative(i);
		this.onAlternativeEnter(start, i);
		while (this.currentCodePoint !== -1 && this.consumeTerm());
		this.onAlternativeLeave(start, this.index, i);
	}
	consumeTerm() {
		if (this._unicodeMode || this.strict) return this.consumeAssertion() || this.consumeAtom() && this.consumeOptionalQuantifier();
		return this.consumeAssertion() && (!this._lastAssertionIsQuantifiable || this.consumeOptionalQuantifier()) || this.consumeExtendedAtom() && this.consumeOptionalQuantifier();
	}
	consumeOptionalQuantifier() {
		this.consumeQuantifier();
		return true;
	}
	consumeAssertion() {
		const start = this.index;
		this._lastAssertionIsQuantifiable = false;
		if (this.eat(CIRCUMFLEX_ACCENT)) {
			this.onEdgeAssertion(start, this.index, "start");
			return true;
		}
		if (this.eat(DOLLAR_SIGN)) {
			this.onEdgeAssertion(start, this.index, "end");
			return true;
		}
		if (this.eat2(REVERSE_SOLIDUS, LATIN_CAPITAL_LETTER_B)) {
			this.onWordBoundaryAssertion(start, this.index, "word", true);
			return true;
		}
		if (this.eat2(REVERSE_SOLIDUS, LATIN_SMALL_LETTER_B)) {
			this.onWordBoundaryAssertion(start, this.index, "word", false);
			return true;
		}
		if (this.eat2(LEFT_PARENTHESIS, QUESTION_MARK)) {
			const lookbehind = this.ecmaVersion >= 2018 && this.eat(LESS_THAN_SIGN);
			let negate = false;
			if (this.eat(EQUALS_SIGN) || (negate = this.eat(EXCLAMATION_MARK))) {
				const kind = lookbehind ? "lookbehind" : "lookahead";
				this.onLookaroundAssertionEnter(start, kind, negate);
				this.consumeDisjunction();
				if (!this.eat(RIGHT_PARENTHESIS)) this.raise("Unterminated group");
				this._lastAssertionIsQuantifiable = !lookbehind && !this.strict;
				this.onLookaroundAssertionLeave(start, this.index, kind, negate);
				return true;
			}
			this.rewind(start);
		}
		return false;
	}
	consumeQuantifier(noConsume = false) {
		const start = this.index;
		let min = 0;
		let max = 0;
		let greedy = false;
		if (this.eat(ASTERISK)) {
			min = 0;
			max = Number.POSITIVE_INFINITY;
		} else if (this.eat(PLUS_SIGN)) {
			min = 1;
			max = Number.POSITIVE_INFINITY;
		} else if (this.eat(QUESTION_MARK)) {
			min = 0;
			max = 1;
		} else if (this.eatBracedQuantifier(noConsume)) ({min, max} = this._lastRange);
		else return false;
		greedy = !this.eat(QUESTION_MARK);
		if (!noConsume) this.onQuantifier(start, this.index, min, max, greedy);
		return true;
	}
	eatBracedQuantifier(noError) {
		const start = this.index;
		if (this.eat(LEFT_CURLY_BRACKET)) {
			if (this.eatDecimalDigits()) {
				const min = this._lastIntValue;
				let max = min;
				if (this.eat(COMMA)) max = this.eatDecimalDigits() ? this._lastIntValue : Number.POSITIVE_INFINITY;
				if (this.eat(RIGHT_CURLY_BRACKET)) {
					if (!noError && max < min) this.raise("numbers out of order in {} quantifier");
					this._lastRange = {
						min,
						max
					};
					return true;
				}
			}
			if (!noError && (this._unicodeMode || this.strict)) this.raise("Incomplete quantifier");
			this.rewind(start);
		}
		return false;
	}
	consumeAtom() {
		return this.consumePatternCharacter() || this.consumeDot() || this.consumeReverseSolidusAtomEscape() || Boolean(this.consumeCharacterClass()) || this.consumeCapturingGroup() || this.consumeUncapturingGroup();
	}
	consumeDot() {
		if (this.eat(FULL_STOP)) {
			this.onAnyCharacterSet(this.index - 1, this.index, "any");
			return true;
		}
		return false;
	}
	consumeReverseSolidusAtomEscape() {
		const start = this.index;
		if (this.eat(REVERSE_SOLIDUS)) {
			if (this.consumeAtomEscape()) return true;
			this.rewind(start);
		}
		return false;
	}
	consumeUncapturingGroup() {
		const start = this.index;
		if (this.eat2(LEFT_PARENTHESIS, QUESTION_MARK)) {
			this.onGroupEnter(start);
			if (this.ecmaVersion >= 2025) this.consumeModifiers();
			if (!this.eat(COLON)) {
				this.rewind(start + 1);
				this.raise("Invalid group");
			}
			this.consumeDisjunction();
			if (!this.eat(RIGHT_PARENTHESIS)) this.raise("Unterminated group");
			this.onGroupLeave(start, this.index);
			return true;
		}
		return false;
	}
	consumeModifiers() {
		const start = this.index;
		const hasAddModifiers = this.eatModifiers();
		const addModifiersEnd = this.index;
		const hasHyphen = this.eat(HYPHEN_MINUS);
		if (!hasAddModifiers && !hasHyphen) return false;
		this.onModifiersEnter(start);
		const addModifiers = this.parseModifiers(start, addModifiersEnd);
		this.onAddModifiers(start, addModifiersEnd, addModifiers);
		if (hasHyphen) {
			const modifiersStart = this.index;
			if (!this.eatModifiers() && !hasAddModifiers && this.currentCodePoint === COLON) this.raise("Invalid empty flags");
			const modifiers = this.parseModifiers(modifiersStart, this.index);
			for (const [flagName] of Object.entries(modifiers).filter(([, enable]) => enable)) if (addModifiers[flagName]) this.raise(`Duplicated flag '${String.fromCodePoint(FLAG_PROP_TO_CODEPOINT[flagName])}'`);
			this.onRemoveModifiers(modifiersStart, this.index, modifiers);
		}
		this.onModifiersLeave(start, this.index);
		return true;
	}
	consumeCapturingGroup() {
		const start = this.index;
		if (this.eat(LEFT_PARENTHESIS)) {
			let name = null;
			if (this.ecmaVersion >= 2018) {
				if (this.consumeGroupSpecifier()) name = this._lastStrValue;
				else if (this.currentCodePoint === QUESTION_MARK) {
					this.rewind(start);
					return false;
				}
			} else if (this.currentCodePoint === QUESTION_MARK) {
				this.rewind(start);
				return false;
			}
			this.onCapturingGroupEnter(start, name);
			this.consumeDisjunction();
			if (!this.eat(RIGHT_PARENTHESIS)) this.raise("Unterminated group");
			this.onCapturingGroupLeave(start, this.index, name);
			return true;
		}
		return false;
	}
	consumeExtendedAtom() {
		return this.consumeDot() || this.consumeReverseSolidusAtomEscape() || this.consumeReverseSolidusFollowedByC() || Boolean(this.consumeCharacterClass()) || this.consumeCapturingGroup() || this.consumeUncapturingGroup() || this.consumeInvalidBracedQuantifier() || this.consumeExtendedPatternCharacter();
	}
	consumeReverseSolidusFollowedByC() {
		const start = this.index;
		if (this.currentCodePoint === REVERSE_SOLIDUS && this.nextCodePoint === LATIN_SMALL_LETTER_C) {
			this._lastIntValue = this.currentCodePoint;
			this.advance();
			this.onCharacter(start, this.index, REVERSE_SOLIDUS);
			return true;
		}
		return false;
	}
	consumeInvalidBracedQuantifier() {
		if (this.eatBracedQuantifier(true)) this.raise("Nothing to repeat");
		return false;
	}
	consumePatternCharacter() {
		const start = this.index;
		const cp = this.currentCodePoint;
		if (cp !== -1 && !isSyntaxCharacter(cp)) {
			this.advance();
			this.onCharacter(start, this.index, cp);
			return true;
		}
		return false;
	}
	consumeExtendedPatternCharacter() {
		const start = this.index;
		const cp = this.currentCodePoint;
		if (cp !== -1 && cp !== CIRCUMFLEX_ACCENT && cp !== DOLLAR_SIGN && cp !== REVERSE_SOLIDUS && cp !== FULL_STOP && cp !== ASTERISK && cp !== PLUS_SIGN && cp !== QUESTION_MARK && cp !== LEFT_PARENTHESIS && cp !== RIGHT_PARENTHESIS && cp !== LEFT_SQUARE_BRACKET && cp !== VERTICAL_LINE) {
			this.advance();
			this.onCharacter(start, this.index, cp);
			return true;
		}
		return false;
	}
	consumeGroupSpecifier() {
		const start = this.index;
		if (this.eat(QUESTION_MARK)) {
			if (this.eatGroupName()) {
				if (!this._groupSpecifiers.hasInScope(this._lastStrValue)) {
					this._groupSpecifiers.addToScope(this._lastStrValue);
					return true;
				}
				this.raise("Duplicate capture group name");
			}
			this.rewind(start);
		}
		return false;
	}
	consumeAtomEscape() {
		if (this.consumeBackreference() || this.consumeCharacterClassEscape() || this.consumeCharacterEscape() || this._nFlag && this.consumeKGroupName()) return true;
		if (this.strict || this._unicodeMode) this.raise("Invalid escape");
		return false;
	}
	consumeBackreference() {
		const start = this.index;
		if (this.eatDecimalEscape()) {
			const n = this._lastIntValue;
			if (n <= this._numCapturingParens) {
				this.onBackreference(start - 1, this.index, n);
				return true;
			}
			if (this.strict || this._unicodeMode) this.raise("Invalid escape");
			this.rewind(start);
		}
		return false;
	}
	consumeCharacterClassEscape() {
		var _a;
		const start = this.index;
		if (this.eat(LATIN_SMALL_LETTER_D)) {
			this._lastIntValue = -1;
			this.onEscapeCharacterSet(start - 1, this.index, "digit", false);
			return {};
		}
		if (this.eat(LATIN_CAPITAL_LETTER_D)) {
			this._lastIntValue = -1;
			this.onEscapeCharacterSet(start - 1, this.index, "digit", true);
			return {};
		}
		if (this.eat(LATIN_SMALL_LETTER_S)) {
			this._lastIntValue = -1;
			this.onEscapeCharacterSet(start - 1, this.index, "space", false);
			return {};
		}
		if (this.eat(LATIN_CAPITAL_LETTER_S)) {
			this._lastIntValue = -1;
			this.onEscapeCharacterSet(start - 1, this.index, "space", true);
			return {};
		}
		if (this.eat(LATIN_SMALL_LETTER_W)) {
			this._lastIntValue = -1;
			this.onEscapeCharacterSet(start - 1, this.index, "word", false);
			return {};
		}
		if (this.eat(LATIN_CAPITAL_LETTER_W)) {
			this._lastIntValue = -1;
			this.onEscapeCharacterSet(start - 1, this.index, "word", true);
			return {};
		}
		let negate = false;
		if (this._unicodeMode && this.ecmaVersion >= 2018 && (this.eat(LATIN_SMALL_LETTER_P) || (negate = this.eat(LATIN_CAPITAL_LETTER_P)))) {
			this._lastIntValue = -1;
			let result = null;
			if (this.eat(LEFT_CURLY_BRACKET) && (result = this.eatUnicodePropertyValueExpression()) && this.eat(RIGHT_CURLY_BRACKET)) {
				if (negate && result.strings) this.raise("Invalid property name");
				this.onUnicodePropertyCharacterSet(start - 1, this.index, "property", result.key, result.value, negate, (_a = result.strings) !== null && _a !== void 0 ? _a : false);
				return { mayContainStrings: result.strings };
			}
			this.raise("Invalid property name");
		}
		return null;
	}
	consumeCharacterEscape() {
		const start = this.index;
		if (this.eatControlEscape() || this.eatCControlLetter() || this.eatZero() || this.eatHexEscapeSequence() || this.eatRegExpUnicodeEscapeSequence() || !this.strict && !this._unicodeMode && this.eatLegacyOctalEscapeSequence() || this.eatIdentityEscape()) {
			this.onCharacter(start - 1, this.index, this._lastIntValue);
			return true;
		}
		return false;
	}
	consumeKGroupName() {
		const start = this.index;
		if (this.eat(LATIN_SMALL_LETTER_K)) {
			if (this.eatGroupName()) {
				const groupName = this._lastStrValue;
				this._backreferenceNames.add(groupName);
				this.onBackreference(start - 1, this.index, groupName);
				return true;
			}
			this.raise("Invalid named reference");
		}
		return false;
	}
	consumeCharacterClass() {
		const start = this.index;
		if (this.eat(LEFT_SQUARE_BRACKET)) {
			const negate = this.eat(CIRCUMFLEX_ACCENT);
			this.onCharacterClassEnter(start, negate, this._unicodeSetsMode);
			const result = this.consumeClassContents();
			if (!this.eat(RIGHT_SQUARE_BRACKET)) {
				if (this.currentCodePoint === -1) this.raise("Unterminated character class");
				this.raise("Invalid character in character class");
			}
			if (negate && result.mayContainStrings) this.raise("Negated character class may contain strings");
			this.onCharacterClassLeave(start, this.index, negate);
			return result;
		}
		return null;
	}
	consumeClassContents() {
		if (this._unicodeSetsMode) {
			if (this.currentCodePoint === RIGHT_SQUARE_BRACKET) return {};
			return this.consumeClassSetExpression();
		}
		const strict = this.strict || this._unicodeMode;
		for (;;) {
			const rangeStart = this.index;
			if (!this.consumeClassAtom()) break;
			const min = this._lastIntValue;
			if (!this.eat(HYPHEN_MINUS)) continue;
			this.onCharacter(this.index - 1, this.index, HYPHEN_MINUS);
			if (!this.consumeClassAtom()) break;
			const max = this._lastIntValue;
			if (min === -1 || max === -1) {
				if (strict) this.raise("Invalid character class");
				continue;
			}
			if (min > max) this.raise("Range out of order in character class");
			this.onCharacterClassRange(rangeStart, this.index, min, max);
		}
		return {};
	}
	consumeClassAtom() {
		const start = this.index;
		const cp = this.currentCodePoint;
		if (cp !== -1 && cp !== REVERSE_SOLIDUS && cp !== RIGHT_SQUARE_BRACKET) {
			this.advance();
			this._lastIntValue = cp;
			this.onCharacter(start, this.index, this._lastIntValue);
			return true;
		}
		if (this.eat(REVERSE_SOLIDUS)) {
			if (this.consumeClassEscape()) return true;
			if (!this.strict && this.currentCodePoint === LATIN_SMALL_LETTER_C) {
				this._lastIntValue = REVERSE_SOLIDUS;
				this.onCharacter(start, this.index, this._lastIntValue);
				return true;
			}
			if (this.strict || this._unicodeMode) this.raise("Invalid escape");
			this.rewind(start);
		}
		return false;
	}
	consumeClassEscape() {
		const start = this.index;
		if (this.eat(LATIN_SMALL_LETTER_B)) {
			this._lastIntValue = BACKSPACE;
			this.onCharacter(start - 1, this.index, this._lastIntValue);
			return true;
		}
		if (this._unicodeMode && this.eat(HYPHEN_MINUS)) {
			this._lastIntValue = HYPHEN_MINUS;
			this.onCharacter(start - 1, this.index, this._lastIntValue);
			return true;
		}
		let cp = 0;
		if (!this.strict && !this._unicodeMode && this.currentCodePoint === LATIN_SMALL_LETTER_C && (isDecimalDigit(cp = this.nextCodePoint) || cp === LOW_LINE)) {
			this.advance();
			this.advance();
			this._lastIntValue = cp % 32;
			this.onCharacter(start - 1, this.index, this._lastIntValue);
			return true;
		}
		return Boolean(this.consumeCharacterClassEscape()) || this.consumeCharacterEscape();
	}
	consumeClassSetExpression() {
		const start = this.index;
		let mayContainStrings = false;
		let result = null;
		if (this.consumeClassSetCharacter()) {
			if (this.consumeClassSetRangeFromOperator(start)) {
				this.consumeClassUnionRight({});
				return {};
			}
			mayContainStrings = false;
		} else if (result = this.consumeClassSetOperand()) mayContainStrings = result.mayContainStrings;
		else {
			const cp = this.currentCodePoint;
			if (cp === REVERSE_SOLIDUS) {
				this.advance();
				this.raise("Invalid escape");
			}
			if (cp === this.nextCodePoint && isClassSetReservedDoublePunctuatorCharacter(cp)) this.raise("Invalid set operation in character class");
			this.raise("Invalid character in character class");
		}
		if (this.eat2(AMPERSAND, AMPERSAND)) {
			while (this.currentCodePoint !== AMPERSAND && (result = this.consumeClassSetOperand())) {
				this.onClassIntersection(start, this.index);
				if (!result.mayContainStrings) mayContainStrings = false;
				if (this.eat2(AMPERSAND, AMPERSAND)) continue;
				return { mayContainStrings };
			}
			this.raise("Invalid character in character class");
		}
		if (this.eat2(HYPHEN_MINUS, HYPHEN_MINUS)) {
			while (this.consumeClassSetOperand()) {
				this.onClassSubtraction(start, this.index);
				if (this.eat2(HYPHEN_MINUS, HYPHEN_MINUS)) continue;
				return { mayContainStrings };
			}
			this.raise("Invalid character in character class");
		}
		return this.consumeClassUnionRight({ mayContainStrings });
	}
	consumeClassUnionRight(leftResult) {
		let mayContainStrings = leftResult.mayContainStrings;
		for (;;) {
			const start = this.index;
			if (this.consumeClassSetCharacter()) {
				this.consumeClassSetRangeFromOperator(start);
				continue;
			}
			const result = this.consumeClassSetOperand();
			if (result) {
				if (result.mayContainStrings) mayContainStrings = true;
				continue;
			}
			break;
		}
		return { mayContainStrings };
	}
	consumeClassSetRangeFromOperator(start) {
		const currentStart = this.index;
		const min = this._lastIntValue;
		if (this.eat(HYPHEN_MINUS)) {
			if (this.consumeClassSetCharacter()) {
				const max = this._lastIntValue;
				if (min === -1 || max === -1) this.raise("Invalid character class");
				if (min > max) this.raise("Range out of order in character class");
				this.onCharacterClassRange(start, this.index, min, max);
				return true;
			}
			this.rewind(currentStart);
		}
		return false;
	}
	consumeClassSetOperand() {
		let result = null;
		if (result = this.consumeNestedClass()) return result;
		if (result = this.consumeClassStringDisjunction()) return result;
		if (this.consumeClassSetCharacter()) return {};
		return null;
	}
	consumeNestedClass() {
		const start = this.index;
		if (this.eat(LEFT_SQUARE_BRACKET)) {
			const negate = this.eat(CIRCUMFLEX_ACCENT);
			this.onCharacterClassEnter(start, negate, true);
			const result = this.consumeClassContents();
			if (!this.eat(RIGHT_SQUARE_BRACKET)) this.raise("Unterminated character class");
			if (negate && result.mayContainStrings) this.raise("Negated character class may contain strings");
			this.onCharacterClassLeave(start, this.index, negate);
			return result;
		}
		if (this.eat(REVERSE_SOLIDUS)) {
			const result = this.consumeCharacterClassEscape();
			if (result) return result;
			this.rewind(start);
		}
		return null;
	}
	consumeClassStringDisjunction() {
		const start = this.index;
		if (this.eat3(REVERSE_SOLIDUS, LATIN_SMALL_LETTER_Q, LEFT_CURLY_BRACKET)) {
			this.onClassStringDisjunctionEnter(start);
			let i = 0;
			let mayContainStrings = false;
			do
				if (this.consumeClassString(i++).mayContainStrings) mayContainStrings = true;
			while (this.eat(VERTICAL_LINE));
			if (this.eat(RIGHT_CURLY_BRACKET)) {
				this.onClassStringDisjunctionLeave(start, this.index);
				return { mayContainStrings };
			}
			this.raise("Unterminated class string disjunction");
		}
		return null;
	}
	consumeClassString(i) {
		const start = this.index;
		let count = 0;
		this.onStringAlternativeEnter(start, i);
		while (this.currentCodePoint !== -1 && this.consumeClassSetCharacter()) count++;
		this.onStringAlternativeLeave(start, this.index, i);
		return { mayContainStrings: count !== 1 };
	}
	consumeClassSetCharacter() {
		const start = this.index;
		const cp = this.currentCodePoint;
		if (cp !== this.nextCodePoint || !isClassSetReservedDoublePunctuatorCharacter(cp)) {
			if (cp !== -1 && !isClassSetSyntaxCharacter(cp)) {
				this._lastIntValue = cp;
				this.advance();
				this.onCharacter(start, this.index, this._lastIntValue);
				return true;
			}
		}
		if (this.eat(REVERSE_SOLIDUS)) {
			if (this.consumeCharacterEscape()) return true;
			if (isClassSetReservedPunctuator(this.currentCodePoint)) {
				this._lastIntValue = this.currentCodePoint;
				this.advance();
				this.onCharacter(start, this.index, this._lastIntValue);
				return true;
			}
			if (this.eat(LATIN_SMALL_LETTER_B)) {
				this._lastIntValue = BACKSPACE;
				this.onCharacter(start, this.index, this._lastIntValue);
				return true;
			}
			this.rewind(start);
		}
		return false;
	}
	eatGroupName() {
		if (this.eat(LESS_THAN_SIGN)) {
			if (this.eatRegExpIdentifierName() && this.eat(GREATER_THAN_SIGN)) return true;
			this.raise("Invalid capture group name");
		}
		return false;
	}
	eatRegExpIdentifierName() {
		if (this.eatRegExpIdentifierStart()) {
			this._lastStrValue = String.fromCodePoint(this._lastIntValue);
			while (this.eatRegExpIdentifierPart()) this._lastStrValue += String.fromCodePoint(this._lastIntValue);
			return true;
		}
		return false;
	}
	eatRegExpIdentifierStart() {
		const start = this.index;
		const forceUFlag = !this._unicodeMode && this.ecmaVersion >= 2020;
		let cp = this.currentCodePoint;
		this.advance();
		if (cp === REVERSE_SOLIDUS && this.eatRegExpUnicodeEscapeSequence(forceUFlag)) cp = this._lastIntValue;
		else if (forceUFlag && isLeadSurrogate(cp) && isTrailSurrogate(this.currentCodePoint)) {
			cp = combineSurrogatePair(cp, this.currentCodePoint);
			this.advance();
		}
		if (isIdentifierStartChar(cp)) {
			this._lastIntValue = cp;
			return true;
		}
		if (this.index !== start) this.rewind(start);
		return false;
	}
	eatRegExpIdentifierPart() {
		const start = this.index;
		const forceUFlag = !this._unicodeMode && this.ecmaVersion >= 2020;
		let cp = this.currentCodePoint;
		this.advance();
		if (cp === REVERSE_SOLIDUS && this.eatRegExpUnicodeEscapeSequence(forceUFlag)) cp = this._lastIntValue;
		else if (forceUFlag && isLeadSurrogate(cp) && isTrailSurrogate(this.currentCodePoint)) {
			cp = combineSurrogatePair(cp, this.currentCodePoint);
			this.advance();
		}
		if (isIdentifierPartChar(cp)) {
			this._lastIntValue = cp;
			return true;
		}
		if (this.index !== start) this.rewind(start);
		return false;
	}
	eatCControlLetter() {
		const start = this.index;
		if (this.eat(LATIN_SMALL_LETTER_C)) {
			if (this.eatControlLetter()) return true;
			this.rewind(start);
		}
		return false;
	}
	eatZero() {
		if (this.currentCodePoint === DIGIT_ZERO && !isDecimalDigit(this.nextCodePoint)) {
			this._lastIntValue = 0;
			this.advance();
			return true;
		}
		return false;
	}
	eatControlEscape() {
		if (this.eat(LATIN_SMALL_LETTER_F)) {
			this._lastIntValue = FORM_FEED;
			return true;
		}
		if (this.eat(LATIN_SMALL_LETTER_N)) {
			this._lastIntValue = LINE_FEED;
			return true;
		}
		if (this.eat(LATIN_SMALL_LETTER_R)) {
			this._lastIntValue = CARRIAGE_RETURN;
			return true;
		}
		if (this.eat(LATIN_SMALL_LETTER_T)) {
			this._lastIntValue = CHARACTER_TABULATION;
			return true;
		}
		if (this.eat(LATIN_SMALL_LETTER_V)) {
			this._lastIntValue = LINE_TABULATION;
			return true;
		}
		return false;
	}
	eatControlLetter() {
		const cp = this.currentCodePoint;
		if (isLatinLetter(cp)) {
			this.advance();
			this._lastIntValue = cp % 32;
			return true;
		}
		return false;
	}
	eatRegExpUnicodeEscapeSequence(forceUFlag = false) {
		const start = this.index;
		const uFlag = forceUFlag || this._unicodeMode;
		if (this.eat(LATIN_SMALL_LETTER_U)) {
			if (uFlag && this.eatRegExpUnicodeSurrogatePairEscape() || this.eatFixedHexDigits(4) || uFlag && this.eatRegExpUnicodeCodePointEscape()) return true;
			if (this.strict || uFlag) this.raise("Invalid unicode escape");
			this.rewind(start);
		}
		return false;
	}
	eatRegExpUnicodeSurrogatePairEscape() {
		const start = this.index;
		if (this.eatFixedHexDigits(4)) {
			const lead = this._lastIntValue;
			if (isLeadSurrogate(lead) && this.eat(REVERSE_SOLIDUS) && this.eat(LATIN_SMALL_LETTER_U) && this.eatFixedHexDigits(4)) {
				const trail = this._lastIntValue;
				if (isTrailSurrogate(trail)) {
					this._lastIntValue = combineSurrogatePair(lead, trail);
					return true;
				}
			}
			this.rewind(start);
		}
		return false;
	}
	eatRegExpUnicodeCodePointEscape() {
		const start = this.index;
		if (this.eat(LEFT_CURLY_BRACKET) && this.eatHexDigits() && this.eat(RIGHT_CURLY_BRACKET) && isValidUnicode(this._lastIntValue)) return true;
		this.rewind(start);
		return false;
	}
	eatIdentityEscape() {
		const cp = this.currentCodePoint;
		if (this.isValidIdentityEscape(cp)) {
			this._lastIntValue = cp;
			this.advance();
			return true;
		}
		return false;
	}
	isValidIdentityEscape(cp) {
		if (cp === -1) return false;
		if (this._unicodeMode) return isSyntaxCharacter(cp) || cp === SOLIDUS;
		if (this.strict) return !isIdContinue(cp);
		if (this._nFlag) return !(cp === LATIN_SMALL_LETTER_C || cp === LATIN_SMALL_LETTER_K);
		return cp !== LATIN_SMALL_LETTER_C;
	}
	eatDecimalEscape() {
		this._lastIntValue = 0;
		let cp = this.currentCodePoint;
		if (cp >= DIGIT_ONE && cp <= DIGIT_NINE) {
			do {
				this._lastIntValue = 10 * this._lastIntValue + (cp - DIGIT_ZERO);
				this.advance();
			} while ((cp = this.currentCodePoint) >= DIGIT_ZERO && cp <= DIGIT_NINE);
			return true;
		}
		return false;
	}
	eatUnicodePropertyValueExpression() {
		const start = this.index;
		if (this.eatUnicodePropertyName() && this.eat(EQUALS_SIGN)) {
			const key = this._lastStrValue;
			if (this.eatUnicodePropertyValue()) {
				const value = this._lastStrValue;
				if (isValidUnicodeProperty(this.ecmaVersion, key, value)) return {
					key,
					value: value || null
				};
				this.raise("Invalid property name");
			}
		}
		this.rewind(start);
		if (this.eatLoneUnicodePropertyNameOrValue()) {
			const nameOrValue = this._lastStrValue;
			if (isValidUnicodeProperty(this.ecmaVersion, "General_Category", nameOrValue)) return {
				key: "General_Category",
				value: nameOrValue || null
			};
			if (isValidLoneUnicodeProperty(this.ecmaVersion, nameOrValue)) return {
				key: nameOrValue,
				value: null
			};
			if (this._unicodeSetsMode && isValidLoneUnicodePropertyOfString(this.ecmaVersion, nameOrValue)) return {
				key: nameOrValue,
				value: null,
				strings: true
			};
			this.raise("Invalid property name");
		}
		return null;
	}
	eatUnicodePropertyName() {
		this._lastStrValue = "";
		while (isUnicodePropertyNameCharacter(this.currentCodePoint)) {
			this._lastStrValue += String.fromCodePoint(this.currentCodePoint);
			this.advance();
		}
		return this._lastStrValue !== "";
	}
	eatUnicodePropertyValue() {
		this._lastStrValue = "";
		while (isUnicodePropertyValueCharacter(this.currentCodePoint)) {
			this._lastStrValue += String.fromCodePoint(this.currentCodePoint);
			this.advance();
		}
		return this._lastStrValue !== "";
	}
	eatLoneUnicodePropertyNameOrValue() {
		return this.eatUnicodePropertyValue();
	}
	eatHexEscapeSequence() {
		const start = this.index;
		if (this.eat(LATIN_SMALL_LETTER_X)) {
			if (this.eatFixedHexDigits(2)) return true;
			if (this._unicodeMode || this.strict) this.raise("Invalid escape");
			this.rewind(start);
		}
		return false;
	}
	eatDecimalDigits() {
		const start = this.index;
		this._lastIntValue = 0;
		while (isDecimalDigit(this.currentCodePoint)) {
			this._lastIntValue = 10 * this._lastIntValue + digitToInt(this.currentCodePoint);
			this.advance();
		}
		return this.index !== start;
	}
	eatHexDigits() {
		const start = this.index;
		this._lastIntValue = 0;
		while (isHexDigit(this.currentCodePoint)) {
			this._lastIntValue = 16 * this._lastIntValue + digitToInt(this.currentCodePoint);
			this.advance();
		}
		return this.index !== start;
	}
	eatLegacyOctalEscapeSequence() {
		if (this.eatOctalDigit()) {
			const n1 = this._lastIntValue;
			if (this.eatOctalDigit()) {
				const n2 = this._lastIntValue;
				if (n1 <= 3 && this.eatOctalDigit()) this._lastIntValue = n1 * 64 + n2 * 8 + this._lastIntValue;
				else this._lastIntValue = n1 * 8 + n2;
			} else this._lastIntValue = n1;
			return true;
		}
		return false;
	}
	eatOctalDigit() {
		const cp = this.currentCodePoint;
		if (isOctalDigit(cp)) {
			this.advance();
			this._lastIntValue = cp - DIGIT_ZERO;
			return true;
		}
		this._lastIntValue = 0;
		return false;
	}
	eatFixedHexDigits(length) {
		const start = this.index;
		this._lastIntValue = 0;
		for (let i = 0; i < length; ++i) {
			const cp = this.currentCodePoint;
			if (!isHexDigit(cp)) {
				this.rewind(start);
				return false;
			}
			this._lastIntValue = 16 * this._lastIntValue + digitToInt(cp);
			this.advance();
		}
		return true;
	}
	eatModifiers() {
		let ate = false;
		while (isRegularExpressionModifier(this.currentCodePoint)) {
			this.advance();
			ate = true;
		}
		return ate;
	}
	parseModifiers(start, end) {
		const { ignoreCase, multiline, dotAll } = this.parseFlags(this._reader.source, start, end);
		return {
			ignoreCase,
			multiline,
			dotAll
		};
	}
	parseFlags(source, start, end) {
		const flags = {
			global: false,
			ignoreCase: false,
			multiline: false,
			unicode: false,
			sticky: false,
			dotAll: false,
			hasIndices: false,
			unicodeSets: false
		};
		const validFlags = /* @__PURE__ */ new Set();
		validFlags.add(LATIN_SMALL_LETTER_G);
		validFlags.add(LATIN_SMALL_LETTER_I);
		validFlags.add(LATIN_SMALL_LETTER_M);
		if (this.ecmaVersion >= 2015) {
			validFlags.add(LATIN_SMALL_LETTER_U);
			validFlags.add(LATIN_SMALL_LETTER_Y);
			if (this.ecmaVersion >= 2018) {
				validFlags.add(LATIN_SMALL_LETTER_S);
				if (this.ecmaVersion >= 2022) {
					validFlags.add(LATIN_SMALL_LETTER_D);
					if (this.ecmaVersion >= 2024) validFlags.add(LATIN_SMALL_LETTER_V);
				}
			}
		}
		for (let i = start; i < end; ++i) {
			const flag = source.charCodeAt(i);
			if (validFlags.has(flag)) {
				const prop = FLAG_CODEPOINT_TO_PROP[flag];
				if (flags[prop]) this.raise(`Duplicated flag '${source[i]}'`, { index: start });
				flags[prop] = true;
			} else this.raise(`Invalid flag '${source[i]}'`, { index: start });
		}
		return flags;
	}
};
var DUMMY_PATTERN = {};
var DUMMY_FLAGS = {};
var DUMMY_CAPTURING_GROUP = {};
function isClassSetOperand(node) {
	return node.type === "Character" || node.type === "CharacterSet" || node.type === "CharacterClass" || node.type === "ExpressionCharacterClass" || node.type === "ClassStringDisjunction";
}
var RegExpParserState = class {
	constructor(options) {
		var _a;
		this._node = DUMMY_PATTERN;
		this._expressionBufferMap = /* @__PURE__ */ new Map();
		this._flags = DUMMY_FLAGS;
		this._backreferences = [];
		this._capturingGroups = [];
		this.source = "";
		this.strict = Boolean(options === null || options === void 0 ? void 0 : options.strict);
		this.ecmaVersion = (_a = options === null || options === void 0 ? void 0 : options.ecmaVersion) !== null && _a !== void 0 ? _a : latestEcmaVersion;
	}
	get pattern() {
		if (this._node.type !== "Pattern") throw new Error("UnknownError");
		return this._node;
	}
	get flags() {
		if (this._flags.type !== "Flags") throw new Error("UnknownError");
		return this._flags;
	}
	onRegExpFlags(start, end, { global, ignoreCase, multiline, unicode, sticky, dotAll, hasIndices, unicodeSets }) {
		this._flags = {
			type: "Flags",
			parent: null,
			start,
			end,
			raw: this.source.slice(start, end),
			global,
			ignoreCase,
			multiline,
			unicode,
			sticky,
			dotAll,
			hasIndices,
			unicodeSets
		};
	}
	onPatternEnter(start) {
		this._node = {
			type: "Pattern",
			parent: null,
			start,
			end: start,
			raw: "",
			alternatives: []
		};
		this._backreferences.length = 0;
		this._capturingGroups.length = 0;
	}
	onPatternLeave(start, end) {
		this._node.end = end;
		this._node.raw = this.source.slice(start, end);
		for (const reference of this._backreferences) {
			const ref = reference.ref;
			const groups = typeof ref === "number" ? [this._capturingGroups[ref - 1]] : this._capturingGroups.filter((g) => g.name === ref);
			if (groups.length === 1) {
				const group = groups[0];
				reference.ambiguous = false;
				reference.resolved = group;
			} else {
				reference.ambiguous = true;
				reference.resolved = groups;
			}
			for (const group of groups) group.references.push(reference);
		}
	}
	onAlternativeEnter(start) {
		const parent = this._node;
		if (parent.type !== "Assertion" && parent.type !== "CapturingGroup" && parent.type !== "Group" && parent.type !== "Pattern") throw new Error("UnknownError");
		this._node = {
			type: "Alternative",
			parent,
			start,
			end: start,
			raw: "",
			elements: []
		};
		parent.alternatives.push(this._node);
	}
	onAlternativeLeave(start, end) {
		const node = this._node;
		if (node.type !== "Alternative") throw new Error("UnknownError");
		node.end = end;
		node.raw = this.source.slice(start, end);
		this._node = node.parent;
	}
	onGroupEnter(start) {
		const parent = this._node;
		if (parent.type !== "Alternative") throw new Error("UnknownError");
		const group = {
			type: "Group",
			parent,
			start,
			end: start,
			raw: "",
			modifiers: null,
			alternatives: []
		};
		this._node = group;
		parent.elements.push(this._node);
	}
	onGroupLeave(start, end) {
		const node = this._node;
		if (node.type !== "Group" || node.parent.type !== "Alternative") throw new Error("UnknownError");
		node.end = end;
		node.raw = this.source.slice(start, end);
		this._node = node.parent;
	}
	onModifiersEnter(start) {
		const parent = this._node;
		if (parent.type !== "Group") throw new Error("UnknownError");
		this._node = {
			type: "Modifiers",
			parent,
			start,
			end: start,
			raw: "",
			add: null,
			remove: null
		};
		parent.modifiers = this._node;
	}
	onModifiersLeave(start, end) {
		const node = this._node;
		if (node.type !== "Modifiers" || node.parent.type !== "Group") throw new Error("UnknownError");
		node.end = end;
		node.raw = this.source.slice(start, end);
		this._node = node.parent;
	}
	onAddModifiers(start, end, { ignoreCase, multiline, dotAll }) {
		const parent = this._node;
		if (parent.type !== "Modifiers") throw new Error("UnknownError");
		parent.add = {
			type: "ModifierFlags",
			parent,
			start,
			end,
			raw: this.source.slice(start, end),
			ignoreCase,
			multiline,
			dotAll
		};
	}
	onRemoveModifiers(start, end, { ignoreCase, multiline, dotAll }) {
		const parent = this._node;
		if (parent.type !== "Modifiers") throw new Error("UnknownError");
		parent.remove = {
			type: "ModifierFlags",
			parent,
			start,
			end,
			raw: this.source.slice(start, end),
			ignoreCase,
			multiline,
			dotAll
		};
	}
	onCapturingGroupEnter(start, name) {
		const parent = this._node;
		if (parent.type !== "Alternative") throw new Error("UnknownError");
		this._node = {
			type: "CapturingGroup",
			parent,
			start,
			end: start,
			raw: "",
			name,
			alternatives: [],
			references: []
		};
		parent.elements.push(this._node);
		this._capturingGroups.push(this._node);
	}
	onCapturingGroupLeave(start, end) {
		const node = this._node;
		if (node.type !== "CapturingGroup" || node.parent.type !== "Alternative") throw new Error("UnknownError");
		node.end = end;
		node.raw = this.source.slice(start, end);
		this._node = node.parent;
	}
	onQuantifier(start, end, min, max, greedy) {
		const parent = this._node;
		if (parent.type !== "Alternative") throw new Error("UnknownError");
		const element = parent.elements.pop();
		if (element == null || element.type === "Quantifier" || element.type === "Assertion" && element.kind !== "lookahead") throw new Error("UnknownError");
		const node = {
			type: "Quantifier",
			parent,
			start: element.start,
			end,
			raw: this.source.slice(element.start, end),
			min,
			max,
			greedy,
			element
		};
		parent.elements.push(node);
		element.parent = node;
	}
	onLookaroundAssertionEnter(start, kind, negate) {
		const parent = this._node;
		if (parent.type !== "Alternative") throw new Error("UnknownError");
		const node = this._node = {
			type: "Assertion",
			parent,
			start,
			end: start,
			raw: "",
			kind,
			negate,
			alternatives: []
		};
		parent.elements.push(node);
	}
	onLookaroundAssertionLeave(start, end) {
		const node = this._node;
		if (node.type !== "Assertion" || node.parent.type !== "Alternative") throw new Error("UnknownError");
		node.end = end;
		node.raw = this.source.slice(start, end);
		this._node = node.parent;
	}
	onEdgeAssertion(start, end, kind) {
		const parent = this._node;
		if (parent.type !== "Alternative") throw new Error("UnknownError");
		parent.elements.push({
			type: "Assertion",
			parent,
			start,
			end,
			raw: this.source.slice(start, end),
			kind
		});
	}
	onWordBoundaryAssertion(start, end, kind, negate) {
		const parent = this._node;
		if (parent.type !== "Alternative") throw new Error("UnknownError");
		parent.elements.push({
			type: "Assertion",
			parent,
			start,
			end,
			raw: this.source.slice(start, end),
			kind,
			negate
		});
	}
	onAnyCharacterSet(start, end, kind) {
		const parent = this._node;
		if (parent.type !== "Alternative") throw new Error("UnknownError");
		parent.elements.push({
			type: "CharacterSet",
			parent,
			start,
			end,
			raw: this.source.slice(start, end),
			kind
		});
	}
	onEscapeCharacterSet(start, end, kind, negate) {
		const parent = this._node;
		if (parent.type !== "Alternative" && parent.type !== "CharacterClass") throw new Error("UnknownError");
		parent.elements.push({
			type: "CharacterSet",
			parent,
			start,
			end,
			raw: this.source.slice(start, end),
			kind,
			negate
		});
	}
	onUnicodePropertyCharacterSet(start, end, kind, key, value, negate, strings) {
		const parent = this._node;
		if (parent.type !== "Alternative" && parent.type !== "CharacterClass") throw new Error("UnknownError");
		const base = {
			type: "CharacterSet",
			parent: null,
			start,
			end,
			raw: this.source.slice(start, end),
			kind,
			strings: null,
			key
		};
		if (strings) {
			if (parent.type === "CharacterClass" && !parent.unicodeSets || negate || value !== null) throw new Error("UnknownError");
			parent.elements.push(Object.assign(Object.assign({}, base), {
				parent,
				strings,
				value,
				negate
			}));
		} else parent.elements.push(Object.assign(Object.assign({}, base), {
			parent,
			strings,
			value,
			negate
		}));
	}
	onCharacter(start, end, value) {
		const parent = this._node;
		if (parent.type !== "Alternative" && parent.type !== "CharacterClass" && parent.type !== "StringAlternative") throw new Error("UnknownError");
		parent.elements.push({
			type: "Character",
			parent,
			start,
			end,
			raw: this.source.slice(start, end),
			value
		});
	}
	onBackreference(start, end, ref) {
		const parent = this._node;
		if (parent.type !== "Alternative") throw new Error("UnknownError");
		const node = {
			type: "Backreference",
			parent,
			start,
			end,
			raw: this.source.slice(start, end),
			ref,
			ambiguous: false,
			resolved: DUMMY_CAPTURING_GROUP
		};
		parent.elements.push(node);
		this._backreferences.push(node);
	}
	onCharacterClassEnter(start, negate, unicodeSets) {
		const parent = this._node;
		const base = {
			type: "CharacterClass",
			parent,
			start,
			end: start,
			raw: "",
			unicodeSets,
			negate,
			elements: []
		};
		if (parent.type === "Alternative") {
			const node = Object.assign(Object.assign({}, base), { parent });
			this._node = node;
			parent.elements.push(node);
		} else if (parent.type === "CharacterClass" && parent.unicodeSets && unicodeSets) {
			const node = Object.assign(Object.assign({}, base), {
				parent,
				unicodeSets
			});
			this._node = node;
			parent.elements.push(node);
		} else throw new Error("UnknownError");
	}
	onCharacterClassLeave(start, end) {
		const node = this._node;
		if (node.type !== "CharacterClass" || node.parent.type !== "Alternative" && node.parent.type !== "CharacterClass") throw new Error("UnknownError");
		const parent = node.parent;
		node.end = end;
		node.raw = this.source.slice(start, end);
		this._node = parent;
		const expression = this._expressionBufferMap.get(node);
		if (!expression) return;
		if (node.elements.length > 0) throw new Error("UnknownError");
		this._expressionBufferMap.delete(node);
		const newNode = {
			type: "ExpressionCharacterClass",
			parent,
			start: node.start,
			end: node.end,
			raw: node.raw,
			negate: node.negate,
			expression
		};
		expression.parent = newNode;
		if (node !== parent.elements.pop()) throw new Error("UnknownError");
		parent.elements.push(newNode);
	}
	onCharacterClassRange(start, end) {
		const parent = this._node;
		if (parent.type !== "CharacterClass") throw new Error("UnknownError");
		const elements = parent.elements;
		const max = elements.pop();
		if (!max || max.type !== "Character") throw new Error("UnknownError");
		if (!parent.unicodeSets) {
			const hyphen = elements.pop();
			if (!hyphen || hyphen.type !== "Character" || hyphen.value !== HYPHEN_MINUS) throw new Error("UnknownError");
		}
		const min = elements.pop();
		if (!min || min.type !== "Character") throw new Error("UnknownError");
		const node = {
			type: "CharacterClassRange",
			parent,
			start,
			end,
			raw: this.source.slice(start, end),
			min,
			max
		};
		min.parent = node;
		max.parent = node;
		elements.push(node);
	}
	onClassIntersection(start, end) {
		var _a;
		const parent = this._node;
		if (parent.type !== "CharacterClass" || !parent.unicodeSets) throw new Error("UnknownError");
		const right = parent.elements.pop();
		const left = (_a = this._expressionBufferMap.get(parent)) !== null && _a !== void 0 ? _a : parent.elements.pop();
		if (!left || !right || left.type === "ClassSubtraction" || left.type !== "ClassIntersection" && !isClassSetOperand(left) || !isClassSetOperand(right)) throw new Error("UnknownError");
		const node = {
			type: "ClassIntersection",
			parent,
			start,
			end,
			raw: this.source.slice(start, end),
			left,
			right
		};
		left.parent = node;
		right.parent = node;
		this._expressionBufferMap.set(parent, node);
	}
	onClassSubtraction(start, end) {
		var _a;
		const parent = this._node;
		if (parent.type !== "CharacterClass" || !parent.unicodeSets) throw new Error("UnknownError");
		const right = parent.elements.pop();
		const left = (_a = this._expressionBufferMap.get(parent)) !== null && _a !== void 0 ? _a : parent.elements.pop();
		if (!left || !right || left.type === "ClassIntersection" || left.type !== "ClassSubtraction" && !isClassSetOperand(left) || !isClassSetOperand(right)) throw new Error("UnknownError");
		const node = {
			type: "ClassSubtraction",
			parent,
			start,
			end,
			raw: this.source.slice(start, end),
			left,
			right
		};
		left.parent = node;
		right.parent = node;
		this._expressionBufferMap.set(parent, node);
	}
	onClassStringDisjunctionEnter(start) {
		const parent = this._node;
		if (parent.type !== "CharacterClass" || !parent.unicodeSets) throw new Error("UnknownError");
		this._node = {
			type: "ClassStringDisjunction",
			parent,
			start,
			end: start,
			raw: "",
			alternatives: []
		};
		parent.elements.push(this._node);
	}
	onClassStringDisjunctionLeave(start, end) {
		const node = this._node;
		if (node.type !== "ClassStringDisjunction" || node.parent.type !== "CharacterClass") throw new Error("UnknownError");
		node.end = end;
		node.raw = this.source.slice(start, end);
		this._node = node.parent;
	}
	onStringAlternativeEnter(start) {
		const parent = this._node;
		if (parent.type !== "ClassStringDisjunction") throw new Error("UnknownError");
		this._node = {
			type: "StringAlternative",
			parent,
			start,
			end: start,
			raw: "",
			elements: []
		};
		parent.alternatives.push(this._node);
	}
	onStringAlternativeLeave(start, end) {
		const node = this._node;
		if (node.type !== "StringAlternative") throw new Error("UnknownError");
		node.end = end;
		node.raw = this.source.slice(start, end);
		this._node = node.parent;
	}
};
var RegExpParser = class {
	constructor(options) {
		this._state = new RegExpParserState(options);
		this._validator = new RegExpValidator(this._state);
	}
	parseLiteral(source, start = 0, end = source.length) {
		this._state.source = source;
		this._validator.validateLiteral(source, start, end);
		const pattern = this._state.pattern;
		const flags = this._state.flags;
		const literal = {
			type: "RegExpLiteral",
			parent: null,
			start,
			end,
			raw: source,
			pattern,
			flags
		};
		pattern.parent = literal;
		flags.parent = literal;
		return literal;
	}
	parseFlags(source, start = 0, end = source.length) {
		this._state.source = source;
		this._validator.validateFlags(source, start, end);
		return this._state.flags;
	}
	parsePattern(source, start = 0, end = source.length, uFlagOrFlags = void 0) {
		this._state.source = source;
		this._validator.validatePattern(source, start, end, uFlagOrFlags);
		return this._state.pattern;
	}
};
new RegExpParser({ ecmaVersion: 2022 });
({ ...Object.fromEntries(Object.entries(uiRequestSchemas).flatMap(([method, schemas]) => [[`${method}.v1.params`, schemas.params], [`${method}.v1.result`, schemas.result]])) }), {
	...Object.fromEntries(Object.entries(requestMethods).flatMap(([method, { params, result }]) => [[`${method}.params`, params], [`${method}.result`, result]])),
	...Object.fromEntries(Object.entries(notificationMethods).map(([method, params]) => [`${method}.params`, params]))
};
new TextEncoder();
Object.freeze({
	argumentBytes: 16384,
	providers: 8,
	discoveryCandidates: 32,
	hostCandidates: 64,
	candidateMs: 3e4,
	sourcePrepared: 4,
	hostPrepared: 16,
	prepareMs: 5e3,
	sourceOperations: 64,
	hostOperations: 256,
	snapshotBytes: 16384,
	sourceSubscriptions: 32,
	hostSubscriptions: 256,
	sourcePending: 16,
	safetyPending: 4,
	batchFrames: 64,
	batchBytes: 65536,
	telemetryBytes: 262144,
	recordingBytes: 262144,
	controlSlots: 8,
	ordinaryControlSlots: 7,
	controlBytes: 16384,
	ackMs: 1e4,
	progressHz: 10,
	sourceHolds: 1,
	journalEntries: 64,
	journalEntryBytes: 8192,
	journalBytes: 8388608,
	motorExchangeMs: 2e3,
	exchangeMs: 5e3,
	fileExchangeMs: 1e4,
	discoverMs: 1e4,
	connectMs: 6e4,
	motionMs: 3e4,
	pendingJournalMs: 5e3,
	stopMs: 15e3,
	finalJournalMs: 5e3,
	intentMs: 350,
	intentTickMs: 100,
	jogPulseMs: 400,
	movementMs: 1e4,
	helperArmMs: 2e3,
	helperWatchdogMs: 1e4,
	helperGraceMs: 2e3,
	readbackAttempts: 5,
	readbackIntervalMs: 100,
	pollDelayMs: 500,
	batteryDelayMs: 3e4,
	freshnessMs: 2500,
	pollMs: 1e4,
	recordingMs: 18e5,
	recordingFrames: 3600,
	recordingChannels: 4,
	retainedMs: 1e4,
	fileMs: 6e5,
	confirmationMs: 12e4,
	rpcMs: 5e3,
	readRpcMs: 15e3,
	connectionRpcMs: 65e3
});
//#endregion
//#region apps/desktop/src/main/plugins/persistence/record-port.ts
var PersistenceFault = class extends Error {
	result;
	constructor(code, reason, resource = "storage-write") {
		super("Persistence request could not be completed.");
		const detail = code === "PLUGIN_E_STALE_RESOURCE" ? {
			kind: "resource",
			reason: "stale",
			resource
		} : code === "PLUGIN_E_RESOURCE_LIMIT" ? {
			kind: "resource",
			reason: "quota",
			resource
		} : code === "PLUGIN_E_PERMISSION_DENIED" ? {
			kind: "permission",
			reason: "permission"
		} : reason ? {
			kind: "persistence",
			reason
		} : void 0;
		this.result = {
			ok: false,
			error: {
				code,
				message: this.message,
				...detail ? { detail } : {}
			}
		};
	}
};
//#endregion
//#region apps/desktop/src/main/plugins/persistence/worker.ts
var count = number().int().min(0).max(Number.MAX_SAFE_INTEGER);
var handle = string().uuid();
var digest = string().regex(/^[0-9a-f]{64}$/);
var text = string().min(1).refine((s) => Buffer.byteLength(s) <= 128);
var revision = string().regex(/^r_[0-9a-f]{32}$/);
var bytes = _instanceof(Uint8Array).refine((b) => b.byteLength <= 262144);
var ticket = publicationTicketSchema;
var owner = persistenceOwnerSchema;
var monotonic = number().min(0).max(Number.MAX_SAFE_INTEGER);
var scope = strictObject({
	hostEpoch: handle,
	workbenchInstance: handle
});
var finalGrant = strictObject({
	owner,
	recordId: handle,
	checkpoint: handle,
	token: handle,
	deadlineMonotonicMs: monotonic,
	deviceDrain: strictObject({
		owner,
		reservationId: handle,
		lastSequence: count,
		expiresMonotonicMs: monotonic
	}).optional()
});
var args = {
	"engine.reserveFinal": tuple([
		ticket,
		count.max(8388608),
		finalGrant
	]),
	"engine.publishRecovery": tuple([
		ticket,
		handle,
		monotonic
	]),
	"evidence.retainSealed": tuple([ticket]),
	"evidence.saveCheckpoint": tuple([owner, checkpointDocumentSchema.omit({ formatVersion: true })]),
	"engine.reserve": tuple([ticket, count.max(8388608)]),
	"engine.append": tuple([
		ticket,
		count,
		bytes
	]),
	"engine.seal": tuple([
		ticket,
		count.max(8388608),
		digest
	]),
	"engine.publish": tuple([ticket]),
	"engine.reconcile": tuple([ticket]),
	"engine.abort": tuple([ticket]),
	"reads.settings": tuple([owner]),
	"reads.stat": tuple([owner, handle]),
	"reads.list": tuple([owner, strictObject({
		kind: string().optional(),
		limit: count.min(1).max(64),
		cursor: handle.optional()
	})]),
	"reads.open": tuple([
		owner,
		handle,
		revision
	]),
	"reads.read": tuple([
		owner,
		handle,
		count,
		count.min(1).max(262144)
	]),
	"reads.close": tuple([owner, handle]),
	"evidence.flush": tuple([persistenceBarrierSchema, array(ticket).max(1024)]),
	"evidence.quota": tuple([owner]),
	"evidence.settingsDigest": tuple([owner]),
	"evidence.auxiliary": tuple([
		owner,
		_enum(["import", "recovery"]),
		text
	]),
	"evidence.auxiliaryKeys": tuple([
		owner,
		_enum(["import", "recovery"]),
		handle.optional()
	]),
	"evidence.recoveryPage": tuple([handle.optional()]),
	"evidence.loadRecovery": tuple([handle]),
	"evidence.saveRecovery": tuple([storedRecoverySchema]),
	"evidence.removeRecovery": tuple([handle]),
	"imports.admit": tuple([
		owner,
		text,
		text
	]),
	"imports.load": tuple([owner, text]),
	"imports.plan": tuple([owner, importPlanSchema]),
	"imports.tagImport": tuple([ticket, importTagSchema]),
	"imports.importReceipts": tuple([owner, text]),
	"imports.record": tuple([
		owner,
		text,
		importItemEvidenceSchema
	]),
	"imports.reconcile": tuple([ticket]),
	"imports.complete": tuple([owner, text]),
	"output.begin": tuple([
		handle,
		owner,
		handle,
		count.max(8388608),
		digest,
		monotonic
	]),
	"output.append": tuple([
		handle,
		count,
		bytes
	]),
	"output.commit": tuple([handle]),
	"output.reconcile": tuple([handle]),
	"output.abort": tuple([handle]),
	"destinations.register": tuple([strictObject({
		action: handle,
		scope,
		nativePath: string().min(1),
		deadlineMonotonicMs: monotonic
	})]),
	"destinations.release": tuple([handle]),
	"sources.resolvePreferences": tuple([strictObject({
		descriptorId: text,
		owner,
		evidence: strictObject({
			nonce: string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/),
			digest
		}),
		settings: strictObject({
			schemaVersion: number().int().min(1).max(2147483647),
			validationDigest: digest
		}).optional(),
		admissionRevision: count.min(1).optional()
	})]),
	"sources.register": tuple([strictObject({
		descriptorId: text,
		mapperId: text,
		sourceKind: _enum([
			"sensor-lab",
			"device-settings",
			"renderer-preferences"
		])
	})]),
	"sources.map": tuple([text, text]),
	"sources.appendMapped": tuple([strictObject({
		mapped: handle,
		ticket,
		offset: count,
		maxBytes: count.min(1).max(262144)
	})]),
	"sources.releaseMapped": tuple([handle]),
	"sources.inventory": tuple([text]),
	"sources.read": tuple([
		text,
		text,
		count,
		count.min(1).max(262144)
	])
};
var gateBinding = strictObject({
	slot: count.max(1023),
	sequence: count.min(1),
	targetFenceDeadline: number().finite().nonnegative().optional()
});
var PersistenceWorkerRequest = strictObject({
	gate: gateBinding.optional(),
	version: literal(1),
	id: count.min(1),
	operation: _enum(Object.keys(args)),
	args: array(unknown())
}).superRefine((r, ctx) => {
	if (["engine.reserve", "engine.reserveFinal"].includes(r.operation) !== !!r.gate || !args[r.operation].safeParse(r.args).success) ctx.addIssue({
		code: "custom",
		message: "invalid-args"
	});
});
var settledMarkers = array(strictObject({
	id: handle,
	disposition: _enum([
		"committed",
		"not-committed",
		"aborted"
	])
})).max(1024);
union([strictObject({
	version: literal(1),
	id: count.min(1),
	ok: literal(true),
	value: unknown(),
	settled: settledMarkers.optional()
}), strictObject({
	version: literal(1),
	id: count.min(1),
	ok: literal(false),
	settled: settledMarkers.optional(),
	error: strictObject({
		code: _enum([
			"io",
			"invalid",
			"stale",
			"quota",
			"unknown"
		]),
		message: string().max(128)
	})
})]);
var bootSchema = strictObject({
	version: literal(1),
	kind: literal("boot"),
	hostEpoch: handle,
	root: string().min(1),
	held: _instanceof(SharedArrayBuffer)
});
strictObject({
	version: literal(1),
	kind: literal("ready"),
	recovery: _enum(["ready", "blocked"])
});
var matches = (scope, t) => ownerKey(scope.owner) === ownerKey(t.owner) && (scope.kind === "namespace" || t.target.kind === "record" && t.target.id === scope.recordId);
var gateBytes = 16400;
var sharedBytes = 20496;
var gateOffset = (slot) => 16 + 16 * slot;
function reserveGateOffset(memory, binding) {
	const { slot } = gateBinding.parse(binding);
	if (memory.byteLength !== sharedBytes || Atomics.load(new Int32Array(memory, gateBytes, 1024), slot) !== 1) throw new Error("invalid-gate");
	return gateOffset(slot);
}
var storageErrorCodes = [
	"PLUGIN_E_STORAGE_QUOTA",
	"PLUGIN_E_STORAGE_CONFLICT",
	"PLUGIN_E_STORAGE_IO",
	"PLUGIN_E_STORAGE_VERSION"
];
function storageFault(message, operation) {
	if (message === "quota") {
		const fault = new PersistenceFault("PLUGIN_E_RESOURCE_LIMIT", void 0, operation === "reads.list" ? "storage-list" : operation?.startsWith("reads.") ? "storage-read" : operation?.startsWith("output.") ? "storage-export" : "storage-write");
		fault.message = message;
		return fault;
	}
	for (const code of storageErrorCodes) {
		const reason = persistenceCodeReasons$1[code].find((reason) => reason === message);
		if (reason !== void 0) {
			const fault = new PersistenceFault(code, reason);
			fault.message = message;
			return fault;
		}
	}
}
function privateError(error) {
	const errno = error instanceof Error && "code" in error ? error.code : void 0;
	if (errno === "ENOSPC" || errno === "EDQUOT") return {
		code: "io",
		message: "disk-full"
	};
	if (errno === "EACCES" || errno === "EPERM") return {
		code: "io",
		message: "permission"
	};
	if (errno === "EROFS") return {
		code: "io",
		message: "read-only"
	};
	const message = error instanceof Error ? error.message : "";
	if (message.length > 128 || !/^[a-z]+(?:-[a-z]+)*$/.test(message)) return {
		code: "io",
		message: "persistence-io"
	};
	const code = [
		"stale",
		"expired",
		"not-primary"
	].includes(message) ? "stale" : ["quota", "queue"].includes(message) || /-(limit|bytes)$/.test(message) ? "quota" : message === "publish-uncertain" ? "unknown" : [
		"input-changed",
		"revision-mismatch",
		"already-committed"
	].includes(message) || message.startsWith("invalid-") ? "invalid" : "io";
	return {
		code,
		message: code === "io" && !storageFault(message) ? "persistence-io" : message
	};
}
var charge = (value) => value instanceof Uint8Array ? value.byteLength : Array.isArray(value) ? value.reduce((n, v) => n + charge(v), 0) : Buffer.byteLength(JSON.stringify(value) ?? "null");
function runPersistenceWorker(input) {
	if (!node_worker_threads.parentPort) throw new Error("worker-port-missing");
	const port = node_worker_threads.parentPort;
	port.once("message", async (raw) => {
		const boot = bootSchema.parse(raw);
		if (!node_path.default.isAbsolute(boot.root) || boot.held.byteLength !== sharedBytes) throw new Error("invalid-boot");
		const profile = {
			hostEpoch: boot.hostEpoch,
			assertHeld() {
				if (Atomics.load(new Int32Array(boot.held), 0) !== 1) throw new Error("not-primary");
			}
		};
		profile.assertHeld();
		const faultPort = node_worker_threads.workerData.faultPort;
		const armed = /* @__PURE__ */ new Map(), paused = /* @__PURE__ */ new Map();
		faultPort?.on("message", (m) => {
			if (m.kind === "arm") armed.set(m.point, m.action);
			if (m.kind === "release") {
				paused.get(m.point)?.();
				paused.delete(m.point);
			}
		});
		const activeTicket = new node_async_hooks.AsyncLocalStorage();
		const fs = new NodePersistenceFs(boot.root, profile, { fault: async (point, edge) => {
			if (edge !== "before") return;
			faultPort?.postMessage({
				point,
				time: performance.now(),
				ticket: activeTicket.getStore() ?? null
			});
			const action = armed.get(point);
			if (!action) return;
			armed.delete(point);
			if (action === "kill") process.exit(71);
			if (action === "fail") throw Object.assign(/* @__PURE__ */ new Error("injected"), { code: "EIO" });
			await new Promise((resolve) => paused.set(point, resolve));
		} });
		await fs.check(fs.path());
		const store = new AtomicStore(fs), output = new NativeOutput(profile, store.quota, () => performance.now(), fs), sources = new WorkerSources(boot.root, store, input.mappers, input.sourceRootsForStore?.(boot.root) ?? input.sourceRoots ?? /* @__PURE__ */ new Map());
		if (!input.lazySourceRoots) await sources.validateRoots();
		let recovery = "ready";
		try {
			await store.initialize();
		} catch {
			recovery = "blocked";
		}
		const queue = new WorkQueue(() => performance.now()), accepted = /* @__PURE__ */ new Map(), destinations = /* @__PURE__ */ new Map();
		let closed = false;
		const requests = /* @__PURE__ */ new Map();
		function collectSettled() {
			const settled = [];
			for (const e of accepted.values()) {
				const terminal = store.settledDisposition(e.ticket.id);
				if (terminal) {
					e.until ??= performance.now() + 12e4;
					settled.push({
						id: e.ticket.id,
						disposition: terminal
					});
				} else if (store.unresolvedTicket(e.ticket.id)) e.until = null;
			}
			return settled;
		}
		const api = {
			"engine.reserveFinal": (t, n, g) => {
				store.fenceTarget(t.owner, g.recordId, g.deadlineMonotonicMs);
				return store.reserveFinal(t, n, g, boot.held, gateOffset([...accepted].find(([, e]) => e.ticket.id === t.id)[0]));
			},
			"engine.publishRecovery": store.publishRecovery.bind(store),
			"evidence.retainSealed": store.retainSealed.bind(store),
			"evidence.saveCheckpoint": store.saveCheckpoint.bind(store),
			"engine.reserve": (t, n) => {
				const request = [...requests.values()].find((r) => r.operation === "engine.reserve" && r.args[0].id === t.id);
				if (request?.gate?.targetFenceDeadline !== void 0 && t.target.kind === "record") store.fenceTarget(t.owner, t.target.id, request.gate.targetFenceDeadline);
				return store.reserve(t, n, boot.held, gateOffset([...accepted].find(([, e]) => e.ticket.id === t.id)[0]));
			},
			"engine.append": store.append.bind(store),
			"engine.seal": store.seal.bind(store),
			"engine.publish": store.publish.bind(store),
			"engine.reconcile": store.reconcile.bind(store),
			"engine.abort": store.abort.bind(store),
			"reads.settings": store.settings.bind(store),
			"reads.stat": store.stat.bind(store),
			"reads.list": store.list.bind(store),
			"reads.open": store.open.bind(store),
			"reads.read": store.read.bind(store),
			"reads.close": store.close.bind(store),
			"evidence.flush": (b, tickets) => store.flushEvidence(b, tickets.filter((t) => matches(b.scope, t))),
			"evidence.quota": async (o) => ({
				ok: true,
				value: store.quota.snapshot(o.sourceKey)
			}),
			"evidence.settingsDigest": store.settingsDigest.bind(store),
			"evidence.auxiliary": store.auxiliary.bind(store),
			"evidence.auxiliaryKeys": store.auxiliaryKeys.bind(store),
			"evidence.recoveryPage": store.recoveryPage.bind(store),
			"evidence.loadRecovery": store.loadRecovery.bind(store),
			"evidence.saveRecovery": store.saveRecovery.bind(store),
			"evidence.removeRecovery": store.removeRecovery.bind(store),
			"imports.admit": store.admitImport.bind(store),
			"imports.load": store.loadImport.bind(store),
			"imports.plan": store.planImport.bind(store),
			"imports.tagImport": store.tagImport.bind(store),
			"imports.importReceipts": store.importReceipts.bind(store),
			"imports.record": store.recordImport.bind(store),
			"imports.reconcile": store.reconcileImport.bind(store),
			"imports.complete": store.completeImport.bind(store),
			"destinations.register": async (i) => {
				const value = await output.register(i), id = (0, node_crypto.randomUUID)();
				destinations.set(id, value);
				return id;
			},
			"destinations.release": async (id) => {
				const d = destinations.get(id);
				if (!d) throw new Error("stale");
				await output.release(d);
			},
			"output.begin": (id, o, d, n, h, deadline) => {
				const token = destinations.get(d);
				if (!token) throw new Error("stale");
				return output.begin(id, o, token, n, h, deadline);
			},
			"output.append": output.append.bind(output),
			"output.commit": output.commit.bind(output),
			"output.reconcile": output.reconcile.bind(output),
			"output.abort": output.abort.bind(output),
			"sources.resolvePreferences": sources.resolvePreferences.bind(sources),
			"sources.register": sources.register.bind(sources),
			"sources.map": sources.map.bind(sources),
			"sources.appendMapped": sources.appendMapped.bind(sources),
			"sources.releaseMapped": sources.releaseMapped.bind(sources),
			"sources.inventory": sources.inventory.bind(sources),
			"sources.read": sources.read.bind(sources)
		};
		port.on("message", (raw) => {
			const cancel = strictObject({
				version: literal(1),
				kind: literal("cancel"),
				id: count.min(1)
			}).safeParse(raw);
			if (cancel.success) {
				const t = requests.get(cancel.data.id)?.args[0];
				const parsed = publicationTicketSchema.safeParse(t);
				if (parsed.success) store.fenceTargetOrTicket(parsed.data);
				return;
			}
			if (strictObject({
				version: literal(1),
				kind: literal("close")
			}).safeParse(raw).success) {
				closed = true;
				(async () => {
					while (queue.pending) await new Promise((r) => setTimeout(r, 1));
					await store.dispose();
					for (const d of destinations.values()) await output.release(d);
					output.assertSettled();
					faultPort?.close();
					port.close();
				})().catch(() => {
					process.exitCode = 72;
					faultPort?.close();
					port.close();
				});
				return;
			}
			const parsed = PersistenceWorkerRequest.safeParse(raw);
			if (!parsed.success || closed) return;
			const r = parsed.data;
			requests.set(r.id, r);
			if (recovery === "blocked" && ![
				"evidence.recoveryPage",
				"evidence.loadRecovery",
				"evidence.auxiliary",
				"evidence.auxiliaryKeys",
				"imports.load",
				"imports.importReceipts",
				"imports.reconcile"
			].includes(r.operation)) {
				port.postMessage({
					version: 1,
					id: r.id,
					ok: false,
					error: {
						code: "io",
						message: "unsupported-format"
					}
				});
				return;
			}
			if (r.operation === "engine.reserve" || r.operation === "engine.reserveFinal") try {
				reserveGateOffset(boot.held, r.gate);
				for (const [slot, e] of accepted) if (e.until !== null && e.until <= performance.now()) accepted.delete(slot);
				if (accepted.has(r.gate.slot)) throw new Error("invalid-gate");
				accepted.set(r.gate.slot, {
					ticket: publicationTicketSchema.parse(r.args[0]),
					until: null
				});
			} catch (error) {
				requests.delete(r.id);
				port.postMessage({
					version: 1,
					id: r.id,
					ok: false,
					error: privateError(error)
				});
				return;
			}
			const first = r.args[0];
			queue.run(first?.owner?.sourceKey ?? first?.sourceKey ?? "core", charge(r.args) + 256, performance.now() + 1e4, async () => {
				profile.assertHeld();
				const fn = api[r.operation];
				return activeTicket.run(first?.owner ? first.id ?? null : null, () => fn(...r.args));
			}).then(async (value) => {
				const disposition = typeof value === "string" ? value : value?.disposition;
				if (["engine.publish", "engine.reconcile"].includes(r.operation) && disposition === "not-committed") {
					const original = publicationTicketSchema.parse(r.args[0]);
					if (!store.retainedSealed(original)) await store.abort(original);
				}
				const settled = collectSettled();
				port.postMessage({
					version: 1,
					id: r.id,
					ok: true,
					value,
					settled
				});
			}).catch((error) => {
				if (r.operation === "engine.reserve" || r.operation === "engine.reserveFinal") store.recordUnadmittedReserve(r.args[0]);
				port.postMessage({
					version: 1,
					id: r.id,
					ok: false,
					error: privateError(error),
					settled: collectSettled()
				});
			}).finally(() => requests.delete(r.id));
		});
		port.postMessage({
			version: 1,
			kind: "ready",
			recovery
		});
	});
}
var WorkerSources = class {
	root;
	store;
	mappers;
	sourceRoots;
	registered = /* @__PURE__ */ new Map();
	mapped = /* @__PURE__ */ new Map();
	constructor(root, store, mappers, sourceRoots) {
		this.root = root;
		this.store = store;
		this.mappers = mappers;
		this.sourceRoots = sourceRoots;
		this.sourceRoots = new Map(sourceRoots);
		this.mappers = new Map(mappers);
		const used = /* @__PURE__ */ new Set();
		for (const [id, root] of this.sourceRoots) {
			const descriptor = this.mappers.get(id);
			if (!descriptor || descriptor.id !== id || descriptor.sourceKind === "renderer-preferences" && descriptor.combinedSource !== "device-preferences-v1" || !node_path.default.isAbsolute(root) || node_path.default.normalize(root) !== root || root.includes("\0") || used.has(root)) throw new Error("invalid-source-root");
			used.add(root);
		}
	}
	async validateRoots() {
		for (const root of this.sourceRoots.values()) {
			const fs = new NodePersistenceFs(root, this.store.fs.profile);
			await fs.check(fs.path());
		}
	}
	async register(input) {
		const descriptor = this.mappers.get(input.mapperId);
		if (!descriptor || descriptor.id !== input.descriptorId || descriptor.sourceKind !== input.sourceKind) throw new Error("invalid-mapper");
		const existing = this.registered.get(input.descriptorId);
		if (existing) {
			if (existing.descriptor !== descriptor) throw new Error("invalid-mapper");
			return;
		}
		if (descriptor.sourceKind === "renderer-preferences") {
			const root = this.sourceRoots.get(descriptor.id);
			if (descriptor.combinedSource && (descriptor.id !== "kobrixa.device-preferences" || !root)) throw new Error("missing-source-root");
			this.registered.set(input.descriptorId, {
				kind: "renderer",
				descriptor,
				resolved: null,
				...descriptor.combinedSource ? { fs: new NodePersistenceFs(root, this.store.fs.profile) } : {}
			});
			return;
		}
		const sourceRoot = this.sourceRoots.get(descriptor.id);
		if (!sourceRoot) throw new Error("missing-source-root");
		this.registered.set(input.descriptorId, {
			kind: "file",
			descriptor,
			fs: new NodePersistenceFs(sourceRoot, this.store.fs.profile)
		});
	}
	source(id) {
		const s = this.registered.get(id);
		if (!s) throw new Error("stale");
		return s;
	}
	async resolvePreferences(input) {
		const binding = this.source(input.descriptorId);
		if (binding.kind !== "renderer" || input.owner.sourceKey !== binding.descriptor.targetSourceKey || input.owner.hostEpoch !== this.store.fs.profile.hostEpoch) throw new Error("stale");
		const previous = binding.resolved;
		if (binding.descriptor.combinedSource && !sameImportValue(input.settings, deviceImportSettingsAuthority)) throw new Error("schema-mismatch");
		if (!binding.descriptor.combinedSource && (input.settings || input.admissionRevision !== void 0)) throw new Error("invalid-mapper");
		if (previous?.admissionRevision !== void 0 && (input.admissionRevision === void 0 || input.admissionRevision < previous.admissionRevision)) throw new Error("stale");
		const plan = await this.store.loadImport(input.owner, importIdFor(binding.descriptor.id, binding.descriptor.targetSourceKey));
		if (binding.descriptor.combinedSource && plan && !plan.plan.devicePreferencesEvidence) throw new Error("missing-combined-evidence");
		if (plan && !plan.complete && !sameImportValue(plan.plan.preferencesEvidence, input.evidence)) throw new Error("input-changed");
		if (previous) {
			if (!sameImportValue(previous.evidence, input.evidence) || !sameImportValue(previous.settings, input.settings)) throw new Error("input-changed");
			if (!sameImportValue(previous.owner, input.owner)) {
				if (!binding.descriptor.combinedSource) throw new Error("input-changed");
				if (previous.owner.sourceKey !== input.owner.sourceKey || previous.owner.pluginId !== input.owner.pluginId || previous.owner.hostEpoch !== input.owner.hostEpoch || input.owner.generation < previous.owner.generation || input.owner.generation === previous.owner.generation && !(input.admissionRevision !== void 0 && (previous.admissionRevision === void 0 || input.admissionRevision > previous.admissionRevision))) throw new Error("stale");
			}
		}
		const encoded = await this.store.auxiliary(input.owner, "import", "nonce/" + input.evidence.nonce);
		if (!encoded) throw new Error("missing-evidence");
		const document = parseNonceDocument(encoded);
		if (document.state !== "consumed" || !document.raw || document.nonce !== input.evidence.nonce || document.digest !== input.evidence.digest || document.sourceKey !== input.owner.sourceKey || document.originalTicket.owner.pluginId !== input.owner.pluginId || document.descriptorId !== binding.descriptor.id || !sameImportValue(document.allowlist, binding.descriptor.rendererKeyAllowlist) || !binding.descriptor.sourceFormatVersions.includes(1)) throw new Error("evidence-binding");
		if (binding.descriptor.combinedSource) {
			if ([
				document.originalTicket.owner,
				document.ticket.owner,
				...plan?.plan.items.map((item) => item.ticket.owner) ?? [],
				...plan?.items.flatMap((item) => item.publicationTicket ? [item.publicationTicket.owner] : []) ?? []
			].some((original) => original.sourceKey !== input.owner.sourceKey || original.pluginId !== input.owner.pluginId || original.hostEpoch === input.owner.hostEpoch && (input.owner.generation < original.generation || input.owner.generation === original.generation && input.owner.processEpoch !== original.processEpoch && input.admissionRevision === void 0))) throw new Error("stale");
		}
		const bytes = snapshotBytes(document.raw, document.allowlist);
		if ((0, node_crypto.createHash)("sha256").update(bytes).digest("hex") !== input.evidence.digest) throw new Error("evidence-binding");
		if (binding.descriptor.combinedSource && binding.resolved !== previous) throw new Error("stale");
		const retained = binding.resolved;
		if (retained) {
			if (!Buffer.from(retained.bytes).equals(bytes) || plan?.plan.devicePreferencesEvidence && !sameImportValue(binding.combined, plan.plan.devicePreferencesEvidence)) throw new Error("input-changed");
			if (binding.descriptor.combinedSource && (!sameImportValue(retained.owner, input.owner) || retained.admissionRevision !== input.admissionRevision)) binding.resolved = {
				...retained,
				owner: structuredClone(input.owner),
				...input.admissionRevision !== void 0 ? { admissionRevision: input.admissionRevision } : {}
			};
			return;
		}
		const bindings = [...this.registered.values()].flatMap((s) => s.kind === "renderer" && s.resolved ? [s.resolved] : []);
		if (bindings.reduce((total, b) => total + b.bytes.length, bytes.length) > 8388608 || bindings.filter((b) => b.owner.sourceKey === input.owner.sourceKey).reduce((total, b) => total + b.bytes.length, bytes.length) > 524288) throw new Error("quota");
		const charge = (0, node_crypto.randomUUID)();
		this.store.quota.holdTemporary(input.owner.sourceKey, charge, bytes.length);
		binding.resolved = {
			owner: structuredClone(input.owner),
			evidence: structuredClone(input.evidence),
			bytes,
			charge,
			...input.settings ? { settings: structuredClone(input.settings) } : {},
			...input.admissionRevision !== void 0 ? { admissionRevision: input.admissionRevision } : {}
		};
		if (plan?.plan.devicePreferencesEvidence) binding.combined = structuredClone(plan.plan.devicePreferencesEvidence);
	}
	async preferences(binding) {
		if (!binding.resolved) throw new Error("missing-evidence");
		await this.resolvePreferences({
			descriptorId: binding.descriptor.id,
			owner: binding.resolved.owner,
			evidence: binding.resolved.evidence,
			...binding.resolved.settings ? { settings: binding.resolved.settings } : {},
			...binding.resolved.admissionRevision !== void 0 ? { admissionRevision: binding.resolved.admissionRevision } : {}
		});
		if (!binding.descriptor.combinedSource) return binding.resolved.bytes;
		const fs = binding.fs;
		const anchor = node_path.default.parse(fs.root).root, anchored = new NodePersistenceFs(anchor, fs.profile);
		await anchored.check(anchored.path(...node_path.default.relative(anchor, fs.root).split(node_path.default.sep)));
		let device;
		try {
			await fs.check(fs.path("device-settings.json"));
			device = {
				state: "present",
				base64: "",
				sha256: ""
			};
		} catch (error) {
			if (error.code !== "ENOENT") throw error;
			await anchored.check(anchored.path(...node_path.default.relative(anchor, fs.root).split(node_path.default.sep)));
			device = { state: "absent" };
		}
		if (device.state === "present") {
			const bytes = await fs.bytes(fs.path("device-settings.json"), 65536);
			device = {
				state: "present",
				base64: Buffer.from(bytes).toString("base64"),
				sha256: (0, node_crypto.createHash)("sha256").update(bytes).digest("hex")
			};
		}
		const candidate = {
			formatVersion: 1,
			defaultedKeys: mapDeviceSettingsSnapshot({
				device: device.state === "absent" ? { state: "absent" } : {
					state: "present",
					original: {
						sourceKind: "device-settings",
						bytes: Buffer.from(device.base64, "base64"),
						sha256: device.sha256,
						file: { basename: "device-settings.json" }
					}
				},
				renderer: {
					sourceKind: "renderer-preferences",
					bytes: binding.resolved.bytes,
					sha256: binding.resolved.evidence.digest
				}
			}).defaultedKeys,
			device,
			renderer: {
				...binding.resolved.evidence,
				base64: Buffer.from(binding.resolved.bytes).toString("base64")
			}
		};
		if (binding.combined && !sameImportValue(binding.combined, candidate)) throw new Error("input-changed");
		const bytes = devicePreferencesEvidenceBytes(candidate);
		if (!binding.descriptor.validate({
			sourceKind: binding.descriptor.sourceKind,
			bytes,
			sha256: (0, node_crypto.createHash)("sha256").update(bytes).digest("hex")
		})) throw new Error("invalid-resource");
		if (!binding.combinedCharged) {
			this.store.quota.holdTemporary(binding.resolved.owner.sourceKey, binding.resolved.charge + "/combined", bytes.length);
			binding.combinedCharged = true;
			binding.combined = candidate;
		}
		return bytes;
	}
	async inventory(id) {
		const binding = this.source(id), { descriptor } = binding;
		if (binding.kind === "renderer") {
			if (!binding.resolved) return {
				state: "blocked",
				entries: []
			};
			try {
				const bytes = await this.preferences(binding);
				return {
					state: "present",
					entries: [{
						key: "preferences",
						format: 1,
						byteLength: bytes.length,
						sha256: (0, node_crypto.createHash)("sha256").update(bytes).digest("hex")
					}],
					...binding.combined ? { devicePreferencesEvidence: structuredClone(binding.combined) } : {}
				};
			} catch (error) {
				if (!descriptor.combinedSource) throw error;
				return {
					state: "blocked",
					entries: []
				};
			}
		}
		const { fs } = binding;
		try {
			const anchor = node_path.default.parse(fs.root).root, anchored = new NodePersistenceFs(anchor, fs.profile);
			await anchored.check(anchored.path(...node_path.default.relative(anchor, fs.root).split(node_path.default.sep)));
		} catch (e) {
			return {
				state: e.code === "ENOENT" ? "absent" : "blocked",
				entries: []
			};
		}
		try {
			const entries = await fs.entries(fs.path(), 4096), items = [];
			if (entries.length > 512) throw new Error("size-limit");
			for (let start = 0; start < entries.length; start += 64) for (const entry of entries.slice(start, start + 64)) {
				if (entry.directory || Buffer.byteLength(entry.name) > 128 || entry.bytes > 8388608) throw new Error("invalid-resource");
				const bytes = await fs.bytes(fs.path(entry.name), 8388608), sha256 = (0, node_crypto.createHash)("sha256").update(bytes).digest("hex");
				const raw = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
				const format = descriptor.fileFormat === "sensor-lab-recording-v1" || descriptor.fileFormat === "sensor-lab-profile-v1" ? raw.schemaVersion : descriptor.fileFormat === void 0 || descriptor.fileFormat === "format-version" ? raw.formatVersion : void 0;
				if (!descriptor.sourceFormatVersions.includes(format) || !descriptor.validate({
					sourceKind: descriptor.sourceKind,
					bytes,
					sha256,
					file: { basename: entry.name }
				})) throw new Error("unsupported-format");
				items.push({
					key: entry.name,
					format,
					byteLength: bytes.length,
					sha256
				});
			}
			return {
				state: "present",
				entries: items
			};
		} catch {
			return {
				state: "blocked",
				entries: []
			};
		}
	}
	async read(id, key, offset, maxBytes) {
		const binding = this.source(id);
		if (!Number.isSafeInteger(offset) || offset < 0 || !Number.isSafeInteger(maxBytes) || maxBytes < 1 || maxBytes > 262144) throw new Error("size-limit");
		if (binding.kind === "renderer") {
			if (key !== "preferences") throw new Error("stale");
			const bytes = await this.preferences(binding);
			if (offset > bytes.length) throw new Error("offset-mismatch");
			return bytes.slice(offset, offset + maxBytes);
		}
		const { fs } = binding;
		if (Buffer.byteLength(key) > 128) throw new Error("size-limit");
		const fd = await fs.open(fs.path(key), "read");
		try {
			return await fs.read(fd, offset, maxBytes);
		} finally {
			await fs.close(fd);
		}
	}
	async settingsValidationDigest(descriptor) {
		const owner = {
			sourceKey: descriptor.targetSourceKey,
			pluginId: descriptor.id,
			generation: 0,
			hostEpoch: this.store.fs.profile.hostEpoch,
			processEpoch: this.store.fs.profile.hostEpoch
		};
		const committed = await this.store.settingsDigest(owner);
		if (committed && committed.schemaVersion === descriptor.targetSettingsSchemaVersion) return committed.validationDigest;
		throw new Error("schema-mismatch");
	}
	async map(id, key) {
		const binding = this.source(id), { descriptor } = binding;
		if (binding.kind === "renderer" && key !== "preferences") throw new Error("stale");
		const bytes = binding.kind === "renderer" ? await this.preferences(binding) : await binding.fs.bytes(binding.fs.path(key), 8388608);
		const sourceSha256 = (0, node_crypto.createHash)("sha256").update(bytes).digest("hex");
		const input = {
			sourceKind: descriptor.sourceKind,
			bytes,
			sha256: sourceSha256,
			...binding.kind === "file" ? { file: { basename: key } } : {}
		};
		if (!descriptor.validate(input)) throw new Error("invalid-resource");
		const item = descriptor.map(input);
		const mappedBytes = item.kind === "record" ? item.bytes : Buffer.from(JSON.stringify({
			formatVersion: 1,
			schemaVersion: item.schemaVersion,
			values: item.values,
			validationDigest: binding.kind === "renderer" && binding.descriptor.combinedSource ? binding.resolved.settings.validationDigest : await this.settingsValidationDigest(descriptor)
		}));
		if (mappedBytes.length > 8388608 || this.mapped.size >= 4) throw new Error("quota");
		const mapped = (0, node_crypto.randomUUID)(), mappedSha256 = (0, node_crypto.createHash)("sha256").update(mappedBytes).digest("hex");
		this.store.quota.holdTemporary(descriptor.targetSourceKey, mapped, mappedBytes.length);
		const metadata = {
			mapped,
			sourceSha256,
			mappedSha256,
			byteLength: mappedBytes.length,
			...item.kind === "record" ? {
				kind: "record",
				metadata: item.metadata
			} : {
				kind: "settings",
				schemaVersion: item.schemaVersion
			}
		};
		this.mapped.set(mapped, {
			bytes: mappedBytes,
			sourceSha256,
			mappedSha256,
			metadata,
			offset: 0,
			ticket: null
		});
		return metadata;
	}
	async appendMapped(input) {
		const p = this.mapped.get(input.mapped);
		if (!p || input.offset !== p.offset || input.maxBytes < 1 || input.maxBytes > 262144 || p.ticket !== null && p.ticket !== input.ticket.id) throw new Error("stale");
		const planKeys = await this.store.auxiliaryKeys(input.ticket.owner, "import");
		let cursor = planKeys.nextCursor, keys = [...planKeys.keys], matched = false;
		for (;;) {
			for (const key of keys) {
				if (!key.startsWith("import/")) continue;
				const plan = await this.store.loadImport(input.ticket.owner, key);
				if (plan?.plan.items.some((i) => this.store.taggedImport(input.ticket, i.tag) && sameImportValue(plan.items.find((e) => e.key === i.key)?.publicationTicket, input.ticket) && sameImportAttempt(i.ticket, input.ticket) && i.byteLength === p.bytes.length && i.mappedSha256 === p.mappedSha256 && i.sourceSha256 === p.sourceSha256 && (p.metadata.kind === "settings" ? input.ticket.metadata.kind === "settings" && p.metadata.schemaVersion === input.ticket.metadata.schemaVersion : input.ticket.metadata.kind === "record" && p.metadata.metadata.kind === input.ticket.metadata.record.kind && p.metadata.metadata.schemaVersion === input.ticket.metadata.record.schemaVersion))) matched = true;
			}
			if (!cursor) break;
			const next = await this.store.auxiliaryKeys(input.ticket.owner, "import", cursor);
			keys = [...next.keys];
			cursor = next.nextCursor;
		}
		if (!matched) throw new Error("input-changed");
		p.ticket = input.ticket.id;
		const chunk = p.bytes.subarray(p.offset, p.offset + input.maxBytes);
		if (chunk.length) p.offset = await this.store.append(input.ticket, p.offset, chunk);
		return {
			nextOffset: p.offset,
			done: p.offset === p.bytes.length
		};
	}
	async releaseMapped(mapped) {
		const p = this.mapped.get(mapped);
		if (!p) return;
		if (p.ticket && this.store.unresolvedTicket(p.ticket)) throw new Error("publish-uncertain");
		for (const { descriptor } of this.registered.values()) this.store.quota.releaseTemporary(descriptor.targetSourceKey, mapped);
		this.mapped.delete(mapped);
	}
};
//#endregion
//#region apps/desktop/src/main/plugins/persistence/import-fixtures.ts
var syntheticImportDescriptor = {
	id: "test.synthetic-import",
	mappingVersion: 1,
	targetSourceKey: "builtin:test.synthetic",
	sourceKind: "sensor-lab",
	sourceFormatVersions: [1],
	targetRecordSchemaVersions: [1],
	validate(input) {
		return input.sourceKind === "sensor-lab" && input.bytes.byteLength <= 8388608;
	},
	map(input) {
		return {
			kind: "record",
			metadata: {
				kind: "test.synthetic",
				schemaVersion: 1,
				label: "Synthetic import fixture",
				mediaType: "application/octet-stream",
				byteLength: input.bytes.byteLength,
				sha256: input.sha256
			},
			bytes: input.bytes
		};
	}
};
var syntheticPreferencesImportDescriptor = {
	id: "test.synthetic-preferences",
	mappingVersion: 1,
	targetSourceKey: "builtin:test.preferences",
	sourceKind: "renderer-preferences",
	sourceFormatVersions: [1],
	targetRecordSchemaVersions: [1],
	rendererKeyAllowlist: ["test.preference"],
	validate(input) {
		if (input.sourceKind !== "renderer-preferences") return false;
		try {
			const snapshot = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(input.bytes));
			return Buffer.from(snapshotBytes(snapshot, ["test.preference"])).equals(input.bytes) && snapshotDigest(snapshot, ["test.preference"]) === input.sha256;
		} catch {
			return false;
		}
	},
	map(input) {
		if (!syntheticPreferencesImportDescriptor.validate(input)) throw new Error("invalid-resource");
		return {
			kind: "record",
			metadata: {
				kind: "test.preferences",
				schemaVersion: 1,
				label: "Synthetic preferences fixture",
				mediaType: "application/json",
				byteLength: input.bytes.length,
				sha256: input.sha256
			},
			bytes: input.bytes.slice()
		};
	}
};
//#endregion
//#region ../../../../../../private/var/folders/mx/g0rnwxh14t93mtqb06px7x400000gn/T/persistence-worker-test-V7oWWX/worker-entry.ts
var entries = NodePersistenceFs.prototype.entries;
NodePersistenceFs.prototype.entries = async function(...args) {
	const result = await entries.apply(this, args);
	const trigger = "/private/var/folders/mx/g0rnwxh14t93mtqb06px7x400000gn/T/persistence-worker-test-V7oWWX/child-race.trigger";
	if (this.root === "/private/var/folders/mx/g0rnwxh14t93mtqb06px7x400000gn/T/persistence-worker-test-V7oWWX/legacy/sensor-lab" && (0, node_fs.existsSync)(trigger)) {
		(0, node_fs.unlinkSync)(trigger);
		(0, node_fs.unlinkSync)(this.root + "/22222222-2222-4222-8222-222222222222.json");
	}
	return result;
};
var unlink = NodePersistenceFs.prototype.unlink;
NodePersistenceFs.prototype.unlink = async function(p) {
	if ((0, node_fs.existsSync)("/private/var/folders/mx/g0rnwxh14t93mtqb06px7x400000gn/T/persistence-worker-test-V7oWWX/cleanup-failure.trigger") && this.name(p).endsWith("intent.json")) throw new Error("injected-cleanup");
	return unlink.call(this, p);
};
runPersistenceWorker({
	mappers: new Map([syntheticImportDescriptor, syntheticPreferencesImportDescriptor].map((d) => [d.id, d])),
	sourceRoots: /* @__PURE__ */ new Map([[syntheticImportDescriptor.id, "/private/var/folders/mx/g0rnwxh14t93mtqb06px7x400000gn/T/persistence-worker-test-V7oWWX/legacy/sensor-lab"]])
});
//#endregion
