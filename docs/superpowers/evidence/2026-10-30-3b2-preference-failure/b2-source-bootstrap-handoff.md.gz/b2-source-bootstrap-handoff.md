# Supported bootstrap — FINAL GREEN / stopped

Exact package oracle command on final bytes: **596 PASS,0 FAIL,0 SKIP**. Includes semantic24, raw26 and bootstrap4. No /tmp loader, NODE_PATH workaround, native execution, install, shared build or commit. Existing tests' write:false esbuild compilations run only in memory.

```sh
# cwd: /Users/kingsley/.codex/worktrees/plugin-3e/Kobrixa
RF5_DEPS_ROOT=/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa \
node -e 'const fs=require("node:fs"); require("node:child_process").execSync(JSON.parse(fs.readFileSync("package.json","utf8")).scripts["test:persistence:oracles"],{stdio:"inherit"})'
```

This executes the exact package script (equivalent to pnpm test:persistence:oracles) without invoking a package-manager installer. Log: /private/tmp/b2-package-oracles.log. Committed bootstrap lives at tests/desktop/persistence-source-loader.mjs; normal installed checkout defaults its source/dependency roots to the repository. E/D split overrides RF5_DEPS_ROOT only. Native controller entry is `pnpm test:persistence:run`; no native invocation performed here.

## Final bounded test corrections

- plugin-persistence-contention.test.mjs: both existing in-memory build calls use persistenceTestNodePaths(). Production sources and all behavior assertions unchanged.
- plugin-persistence-disconnect.test.mjs: same option on its two existing build calls. No fixture semantics changed.
- plugin-persistence-optional-off.test.mjs: strict preloading assertion now includes existing optional OR compatibility exclusion. Admission ordering assertions remain.
- plugin-persistence-renderer-loss.test.mjs: strict launcher assertion now checks the actual createDesktopLauncher object with forwarded hooks. Actual retirement, crash and destroy wiring assertions remain.

The already supplied bootstrap helper resolves explicit installed dependency directories from RF5_DEPS_ROOT (default sourceRoot), including package-local lookup for non-hoisted installations. No arbitrary module aliasing or product resolver change. Previous report's five blockers and temporary-loader requirement are resolved. Historical frozen acceptance-plan bare-Node commands remain controller-owned; README documents the supported command.

ESLint PASS on loader and affected tests; loader syntax and git diff --check PASS. Earlier actual raw/main typecheck PASS remains applicable (no subsequent TS changes). Declarative interop5PASS/2evidence-absent skips. The596 package run supersedes prior partial/error counts. Native/raw RF5 evidence remains controller-owned and unclaimed.

## Stop/release

All seventeen owned files are stopped, unstaged, and released for controller review/commit; main/run/harness common ownership released. Original seven-file raw independent review reported no actionableP1/P2. Pressure pacing and product retention were NOT touched. Other agents' record-service, consumer.ts/consumer.py, interop and evidence changes remain preserved and excluded from this receipt.

## Exact owned files / SHA-256

```json
{
  "head": "e9d8ba50791950cdb20a4bba4941337d55921368",
  "status": "stopped; common files released",
  "files": {
    "tests/desktop/import-preferences.ts": "fc89a7b81f0b4ae0512e0c10b0ba37c2b14851a1d6f09fcb06ecff0d1961a6d9",
    "tests/desktop/import-preferences.test.mjs": "ce61f2219dfe95cf2731ebfb1af1e51c64b29a811b540886d6c32badea678c9a",
    "tests/desktop/import-preferences-renderer.ts": "cb620efc0f15471284f69040351b3acf2abcffbf55a6a1278dbc13483d8028d6",
    "tests/desktop/fixtures/plugin-persistence/import-consumer.ts": "81bda00c1c2c1f4a15fc8113dc04906cc1da5b959b327e48f1c222b2e48cfab7",
    "tests/desktop/plugin-persistence-main.ts": "71f57b74e88699bd2a2741cc8b573d5f92fa55671ef4bc33e216b40b19a886b2",
    "tests/desktop/plugin-persistence-run.mjs": "13f3c662473cd275f620b8b77925640a17445e90371e8bf14252b40f3aa35aff",
    "tests/desktop/plugin-persistence-harness.mjs": "6bced7719760e59205efd300a2275a927ea77108328603d753af2be87bc1a890",
    "tests/desktop/persistence-source-loader.mjs": "fa7a1c6b742be085caf781c8b461854c566aef7c882c8216302f1b1c84ea4d5e",
    "tests/desktop/persistence-source-loader.test.mjs": "8be94e85b67167bc629634ea811592e7e32134e04836de309a9f1b50e2bff8f3",
    "package.json": "7df009cc9bb3c4ff180de5797a0337305a16515f231770d2ac3adde6f8545486",
    "tests/desktop/README.md": "3c52e08383c6fc09423cd48f17ede4ddae54cdc872058b8d82fb2fc76c18ddd9",
    "tests/desktop/import-boundaries.test.mjs": "9ce5829b768358755130448cfaa41f8a0275f592501e75b7e55f9c8df31fe098",
    "tests/desktop/plugin-persistence-outcomes.test.mjs": "fb16fcd4a3be19b2cf902d27300a910ada6ee808e339f7a2ee74163dfeeacef0",
    "tests/desktop/plugin-persistence-contention.test.mjs": "3a934e4f44cbbd8e68334e60ccc4640292f67d3e814cd57aac1d329a84b8200c",
    "tests/desktop/plugin-persistence-disconnect.test.mjs": "f4979d9f3ba72f19236bb578f9a1d7bffd32699a14bfc6b0ca63bbf9f23fb05f",
    "tests/desktop/plugin-persistence-optional-off.test.mjs": "985480db7613743bff5f86cbbc4aaaa9622803f476f281314431dccd390a9282",
    "tests/desktop/plugin-persistence-renderer-loss.test.mjs": "5c128f7469d8fa9a3ea63f228fc08678655c697dc6ad031d2dc10f95b1a875d7"
  }
}
```
