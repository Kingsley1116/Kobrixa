import {runSyntheticPersistenceWorker} from "/workspace/tests/desktop/fixtures/plugin-persistence/kill-worker.mjs";
runSyntheticPersistenceWorker(new Map([['test.synthetic-import',"/evidence/kobrixa-persistence-ZqfKuA/synthetic"]]));
