# N01/N02/N06 worker tests — validated / STOPPED

Sole changed repository file: `apps/desktop/src/main/plugins/persistence/worker.test.ts`.
SHA256: `0241ec14a77c3d4c7085b2ba23e441600f2d24afd5ed93b25e233b6b17ad2d46`.
No product edits. Raw/common/pressure files untouched. No git mutation/install/native Electron/shared build.

## Demonstrated fixture corrections

1. Actual evidence.quota returns `{ok:true,value:...}`; cleanup assertion now checks that business envelope, retaining it unchanged in diagnostics.
2. An explicitly admitted then aborted write remains a shutdown obligation. On reopen the real host projects exactly one source-bound `checkpoint-only`, payload `none`, null record/revision, discard-only recovery row. Tests require that exact shape for these six cases, and require empty recovery for cases without admitted writes. They still prove no live pins/reservations, no publishable payload, exact committed records/settings, and stale prior handles. No recovery record is hidden or deleted to manufacture an empty snapshot.
3. Replaced explicit-any observer projections and inline type imports to satisfy scoped lint. Product/internal worker not-found classification unchanged; existing public missing-ID expectation remains corrected to typed stale.
4. Every retained receipt now includes the actual built worker entry path and SHA256 read from its bytes.

## Results / exact commands

E working directory: `/Users/kingsley/.codex/worktrees/plugin-3e/Kobrixa`.
D executable prefix: `/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin`.

- Initial focused run: 16 failures exposed quota envelope assumption; next run 10 pass/6 failures exposed aborted-write shutdown projection. Both fixed only in test.
- Entire file: **59 PASS**, `/private/tmp/b2-negative-worker-all.log`.
  `D/vitest run --config /private/tmp/b2-negative-worker-vitest.config.mjs`
- Final retained focused run: **16 PASS, 43 filtered/skipped**, `/private/tmp/b2-negative-worker-retained.log`.
  `B2_NEGATIVE_EVIDENCE_DIR=/private/tmp/b2-negative-worker-validated-evidence D/vitest run --config /private/tmp/b2-negative-worker-vitest.config.mjs -t 'B2-N0[126]'`
- Scoped types: exit0, `/private/tmp/b2-negative-worker-types.log`.
  `D/tsc -p /private/tmp/b2-negative-worker-tsconfig.json`
- Scoped lint: exit0, `/private/tmp/b2-negative-worker-lint.log`.
  `D/eslint --config /private/tmp/e1-final-eslint.config.mjs apps/desktop/src/main/plugins/persistence/worker.test.ts`
- `git diff --check -- apps/desktop/src/main/plugins/persistence/worker.test.ts`: clean.

16 retained receipts independently checked against actual transcript, current test-source and worker-bundle bytes; all success=true. Check record: `/private/tmp/b2-negative-worker-receipt-check.json`.
Bundle SHA256: `0a96ccae4a9012a95b1879ae868164cf2b1112095e2e45165919cb3c10426fc2`.
Bundle path: `/private/var/folders/mx/g0rnwxh14t93mtqb06px7x400000gn/T/persistence-worker-test-Z3Z37C/bundle/persistence-worker.cjs`.
Profiles/artifact retained by evidence mode. Candidate commit field intentionally null for this dirty-source verification. Controller should use a fresh evidence directory and B2_CANDIDATE_COMMIT for the reviewed immutable rerun.

## Bounds

16 named rejection groups; related malformed variants share the named case's before/after/cleanup/reopen snapshots. Real public RpcPeer routes, host, worker thread, filesystem and EventLedger. Worker bundle compilation is the existing temporary test fixture, not a shared/product build.

Not native full-matrix acceptance: test lock stub; no Electron/installed manifest/hardware; observed public handles/backend pins, not exhaustive private registry dump; worker count/epochs, no private thread-ID diagnostic. N01–N29/native full matrix remains open. All writes stopped for controller review/commit.
