# C legacy motor retirement — tested, stopped

Implemented approved T6 subset in E. **322 tests PASS / 14 files**, main and renderer full import typechecks PASS, combined changed-test/import typecheck PASS, lint/diff checks PASS. No native, packaging/shared build, installs or commits. Not C closure: controller final native/package and integration fixture follow-up remain. Installed-agent files and package.json untouched; concurrent dirty changes preserved.

## Change and safety

Removed old motor controls/controller/service/shared DTO and private preload/IPC routes. Removed motor-only app initialization, activity logging, busy/drain hooks; output angle/readings, monitor visibility cleanup, battery, execution, remote-files and frozen Lab original-writer barrier remain. Legacy-only execution activity log tests were removed with their unused private MotorTestState path; public motor state/status remains authoritative.

App Stop shortcut now calls existing ExecutionController.stop→trusted device:stop before ordinary modal/update/workspace guards; build phase still cancels its build. No new API. Regression proves a publicly adopted session can be stopped without an open project. ExecutionController's existing no-session/locked guards remain; core recovery Stop stays independently available for unresolved custody. Main trusted stop still bypasses update admission only through the existing validated action path.

Native blur/hide/minimize handlers explicitly revoke public intent via ui.intent.dispose rather than the removed inert service. attachNativeLifecycle already installs this same revocation; owner/window-loss, authority, suspend, journal, coordinator close/update/readback are unchanged. Legacy Lab flush/save blockers remain. Public motion conflicts continue to be rejected by broker admission, not a renderer flag or feature-process liveness. Provider `motor-test-image.ts`, motion engine and helper image tests are untouched.

Initial automatic edit review rejected removing native stop hooks. No edits ran in that attempt. After verifying shutdown-coordinator.ts native event routing and ui-intent.ts revokeScope/stop dispatch, a safer batch retained those handlers on the existing public revocation path and was approved. No blocked approval remains.

## Assertion preservation

Existing public model/feature tests already cover field boundaries, masked fields, unknown angle, confirmation, lost prepare/start, original ID cleanup, keepalive/coalescing, coast→brake escalation, stale replies, lifecycle retirement, uncertainty and no replay. Added five model cases: four independent port/default/three-mode mappings and elapsed/absolute-angle/clamped/null progress. Kept generic Segmented keyboard test in motor-test-controls.test.ts without any retired runtime import. New monitor-panel.test.ts proves output reading survives, no motor controls mount, and monitor cleanup still executes. Replaced motor-test-ipc test with absence of four private routes plus retention of monitor/Lab/files/core Stop endpoints. Existing actual IPC tests cover authority revocation, journal failures, close/update blockers and physical-stop ordering against fake provider.

## Actual commands/results

From E, installed D executables, E source aliases:
```
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/vitest run --config /private/tmp/c-retirement-vitest.config.mjs
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/tsc -p /private/tmp/e5-main-tsconfig.json
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/tsc -p /private/tmp/e5-renderer-tsconfig.json
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/tsc -p /private/tmp/c-retirement-tsconfig.json
```
Vitest: public model/feature/resources; monitor panel/controller; preserved Segmented; execution; IPC; retired motor IPC; collaboration gate; updates/install IPC/installation; shutdown coordinator. 322 PASS, no skips. Initial run had missing React alias and four wrong test expectations (default is jog, not timed); corrected temporary config/test literals, no product behavior changed to satisfy tests.
ESLint `/private/tmp/e1-final-eslint.config.mjs` and Prettier ran only existing paths in `/private/tmp/c-retirement-tracked-files.txt`; both succeeded. Combined types include changed tests. Logs: `/private/tmp/c-retirement-{tests,main-types,renderer-types,types,lint,format}.log`. No broad desktop suite/native rerun.

## Exact required integration fixture follow-up — not edited

| File | Evidence / minimal follow-up |
| --- | --- |
| tests/desktop/run-smoke.mjs:101 | Removed service is still an esbuild entry. Remove its entry after smoke fixture no longer imports it. Current generic smoke cannot build unchanged. |
| tests/desktop/smoke-main.mjs:41 | Imports old service/ref schema; lines131–163 inject motors, alter sampler busy and publish private events; 271–276 implement private handlers; 284 calls stopAll; 743/811/890 build motorContext/call checkMotorTests. Remove that private fixture wiring while retaining monitor/Lab lifecycle; route motor acceptance to existing actual public harness, not a new fake service. |
| tests/desktop/motor-test-smoke.mjs | createMotorFixture/checkMotorTests target removed controls/private runtime. Retire/replace this old smoke component with existing public acceptance coverage; do not silently skip motor acceptance or claim full smoke PASS. |
| tests/desktop/device-broker-boundaries.test.mjs:47 | Fixed file inventory reads deleted service. Remove this stale inventory entry; retain runtime/transport boundary assertions for all surviving services and public feature. |

These four paths are necessary next fixture scope, not touched under current authorization. Controller-owned package.json may sequence existing public motor test command; no request for a duplicate harness. Optional dead-prop cleanup only: renderer/workbench/toolbar.tsx retains optional motorTesting default=false, now with no caller. It imports no removed runtime and does not block current types; left outside scope. Old CSS selectors similarly remain inert. D Lab routing is deliberately deferred.

## Exact stopped write set / SHA-256

Machine receipt: `/private/tmp/c-legacy-retirement-stopped.json`. Deleted entries record pre-deletion HEAD blob hash. All owned files stopped; these hashes exclude concurrent installed work.

- `apps/desktop/src/main/collab/device-control.test.ts` — SHA-256 `bd7a46ea6781662c7189e15d97aba5ef8b05327582b0e63bdd45181b4a6f1425`
- `apps/desktop/src/main/collab/device-control.ts` — SHA-256 `4bcb3e6f788ba54ef902104c896d0f3d8c8574f0dbde992df1a17331735dbc12`
- `apps/desktop/src/main/device/motor-test-ipc.test.ts` — SHA-256 `1c4b841d8d23b3c28eefed204742b431226eccde5e6b8f88126da6be7d8a1665`
- `apps/desktop/src/main/device/motor-test-service.test.ts` — DELETED; base SHA-256 `e6a7bd1e3e0f00ff9a422339359cdae868a5fc53d9ba5767aa26cf621c3cff0f`
- `apps/desktop/src/main/device/motor-test-service.ts` — DELETED; base SHA-256 `b8e6d672a4186a947b8c8c0342dfec9153d0c9ec75acbbf37b4346e7d9458393`
- `apps/desktop/src/main/index.ts` — SHA-256 `7500e5a8cbaf5a4fd5106c6a741a6fe1038493fa38ce75dbb4a1ee3d80260aff`
- `apps/desktop/src/main/ipc.test.ts` — SHA-256 `5ffc6c461e1b7ea55cd6bcba55214bdc4d2ed01633e09cccdb20e70df755cb7c`
- `apps/desktop/src/main/ipc.ts` — SHA-256 `f3e53f3f80f235736309237229b60176ba43b1ca254db2d06d9c8ed0e0dd7bb0`
- `apps/desktop/src/main/updates/service.ts` — SHA-256 `9f751ddef8534e017be7f68606d08f395456b3536e71854b8f4b98283e27debc`
- `apps/desktop/src/preload/index.ts` — SHA-256 `3ee38f2d1f709147cf8715b4ab8c9c51e5e1ae17effe60fd28d71c891e612b25`
- `apps/desktop/src/renderer/app.tsx` — SHA-256 `7dae380bc6a06c88370551a068fdd602019a97a4f464586c9d22f29ab5a72044`
- `apps/desktop/src/renderer/device/monitor-panel.tsx` — SHA-256 `0a7a0659c202afaf588ab57e523db789ebc8e1d08a0ff8b8fa5ccf3f89235ceb`
- `apps/desktop/src/renderer/device/monitor-workspace.tsx` — SHA-256 `3b0275dc8ed978eef48b1961af72a267c99438d5a33b761347183c3cb4bb0683`
- `apps/desktop/src/renderer/device/motor-test-controller.test.ts` — DELETED; base SHA-256 `ec70601339a2ae8322f01d40d871f6a9254919853451012712d585d0bb18a29e`
- `apps/desktop/src/renderer/device/motor-test-controller.ts` — DELETED; base SHA-256 `fafe15b97fb4fda1ce7671fbcc9b60e83c91e845ded7b927a7859d029cf83afb`
- `apps/desktop/src/renderer/device/motor-test-controls.test.ts` — SHA-256 `b6800be712083d4b8467a37a8138eba3db1f912484f4416e78bc8e0e3421f212`
- `apps/desktop/src/renderer/device/motor-test-controls.tsx` — DELETED; base SHA-256 `ab682b97335f466d67af06496416fc60936204e0bb64ba33effef7cf0049dea8`
- `apps/desktop/src/renderer/execution/execution.test.ts` — SHA-256 `8d4367e9e6d3bd7e4df02ddc1ec7898c326444dd0d9ee2b9ac64dd6a7b7ff8d4`
- `apps/desktop/src/renderer/execution/execution.ts` — SHA-256 `c57f0dc454219ede7a94190528cba9ee816b792dee2063789c1242e43a46cde3`
- `apps/desktop/src/shared/api.ts` — SHA-256 `c50c3a33f0133cb5555b2d1f5c1f62b0adf2dee1dbc9afecab1e389901dce0e9`
- `apps/desktop/src/shared/motor-test.ts` — DELETED; base SHA-256 `76ffac16d8f53f59ca24c59f596bd453a33e21a8c5bdf8e6f9fbd712fae3b459`
- `plugins/motor-test/src/model.test.ts` — SHA-256 `acfb1a614ee5e483a6c5d50e48f5e3c6b8c79df16b4e069a761259a8af0e1ceb`
- `apps/desktop/src/renderer/device/monitor-panel.test.ts` — SHA-256 `14327221e517e0611a68cc4fbecfa2b645fdfb323e6dd6da826a162d0d1c5713`

Remaining acceptance: fix authorized smoke integration inventory, controller review/native final rebuilt artifact, retained core safety regressions at product boundary. Existing C77/Linux receipts justify retirement implementation but do not certify these new bytes; no physical EV3 or final Stage3 claim.
