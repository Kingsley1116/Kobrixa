# C legacy smoke integration — stopped

Exact four authorized files changed; previous 23-file stopped receipt rehashed with zero differences. Package.json and installed-agent files untouched. No native, builds, installs or commits.

- run-smoke.mjs: remove deleted motor service build entry; emit dedicated public motor acceptance handoff before temporary directory/server setup.
- smoke-main.mjs: remove old service/schema import, injected motor fixture, private motor handlers, fake motor busy sampler branch, obsolete stopAll and both old checkMotorTests calls. Preserve monitor sampling/watch/mode handlers, Lab service/reservation/observation, sensorLab.onDisconnect and sampler.disconnect, existing checkMonitor/checkSensorLab and other core/workbench checks.
- motor-test-smoke.mjs: replace retired private-service producer/UI assertions with a small handoff marker. No motor API or substitute acceptance runner. KOBRIXA_SMOKE_MOTORS_ONLY throws actionable error; normal output explicitly says motor acceptance NOT RUN here and requires `node tests/desktop/motor-test-public-run.mjs --all`. Pure feature oracles are explicitly not native acceptance.
- device-broker-boundaries.test.mjs: remove deleted service from surviving-service inventory; retain other boundary checks. New regression verifies the marker and obsolete flag rejection, absence of old wiring, and retained monitor/Lab/disconnect checks.

Validation from E:
```
node --test tests/desktop/device-broker-boundaries.test.mjs
node --check tests/desktop/run-smoke.mjs
node --check tests/desktop/smoke-main.mjs
node --check tests/desktop/motor-test-smoke.mjs
node --check tests/desktop/device-broker-boundaries.test.mjs
/Users/kingsley/.codex/worktrees/plugin-3d/Kobrixa/node_modules/.bin/eslint --config /private/tmp/e1-final-eslint.config.mjs tests/desktop/{run-smoke,smoke-main,motor-test-smoke,device-broker-boundaries.test}.mjs
```
**5 tests PASS, zero skips; all four syntax checks, ESLint, formatting and scoped diff check PASS.** Logs `/private/tmp/c-smoke-integration-{tests,lint,format}.log`. No complete workbench smoke/native PASS claimed. Controller still owns post-retirement native/package acceptance and root script wiring.

## Stopped hashes
- `tests/desktop/run-smoke.mjs` — `117f7d2aad11b50daff9ce0281bee353ebec836a0342d722d59e7e10bbe483e4`
- `tests/desktop/smoke-main.mjs` — `8129ce1c4a0613b6e94d0fae3fa8bf087223ed41e6d62a4a069e1f50bcdfc35b`
- `tests/desktop/motor-test-smoke.mjs` — `4451cef68cc572e566eaf4784be46078788fe257f861aed44273da56f6b4027f`
- `tests/desktop/device-broker-boundaries.test.mjs` — `e9c6183aae8c59d28f0d43e937d22feeaf57a972abf3619221c337cc6a6861d2`

Machine receipt: `/private/tmp/c-legacy-smoke-integration-stopped.json`. All four files stopped. C closure and hardware acceptance remain unclaimed.
