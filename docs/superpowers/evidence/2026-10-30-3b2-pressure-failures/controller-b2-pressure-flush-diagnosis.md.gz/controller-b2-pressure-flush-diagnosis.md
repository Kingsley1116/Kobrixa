# Pressure native2 flush diagnosis

**Fixture ordering misuse, not evidence of a product flush bug.** Immutable `43adff4` correctly returned `PLUGIN_E_STORAGE_CONFLICT / flush-incomplete` because each consumer had just staged and sealed a new replacement. Do not relax product validation or count this result as a successful flush sample.

Read-only investigation; no source edits, tests, builds or native runs. Current E advanced during inspection (last observed `16f2ccc`); diagnosis uses `git show 43adff4` for the executed sequence. Maxwell’s dirty semantic files were left untouched.

## Exact retained failure

Root: [5fOYMF](/private/tmp/kobrixa-b2-pressure-native-43adff4/kobrixa-persistence-5fOYMF), [native log](/private/tmp/b2-pressure-native2.log), [RPC trace](/private/tmp/kobrixa-b2-pressure-native-43adff4/kobrixa-persistence-5fOYMF/pressure-rpc.jsonl).

- Each actual consumer (PID876/877) completed 25 seed commands and 25 verification commands. Each then completed one burst and one replacement. This is observed partial progress, not 30 samples/600-second acceptance.
- Native `step(0)` executes `burst → replace → stage → stagingStatus → inventory → flush` per both owners. The replacement consumes the initial held stage, but `stage` immediately creates another sealed write.
- Immediately before flush, owner A retains write `51f470bb-f573-4c3c-acd6-c49e37fd2371`; owner B retains `ff783938-bba2-4c3e-9609-42cd91889b11`. Both snapshots explicitly say `state:"sealed"`.
- A’s plugin-clock flush interval is 29097.767721–29102.470430ms; B’s is 29097.854430–29102.943763ms. Both SDK results are `{ok:false,error:{code:"PLUGIN_E_STORAGE_CONFLICT",detail:{kind:"persistence",reason:"flush-incomplete"}}}`. These are business failures, not transport timeouts.
- `createPressureWorkload.flush()` calls the strict `value()` unwrap. Its assertion throws on that business result; the command handler consequently returns JSON-RPC error `-32603` (both command IDs59), retaining the business result in the error text. The main workload branch rejects. `Promise.allSettled` then reaches the generic `work[1].status === "fulfilled"` assertion, masking the useful cause with **rejected vs fulfilled**.
- This is the first sampled step’s flush, **not** the successful-path final `finish()` flush. `finish()` is not reached after the step throws.

[Entry failure](/private/tmp/kobrixa-b2-pressure-native-43adff4/kobrixa-persistence-5fOYMF/storage-ui-pressure.candidate.json.entry-failure.json) records the assertion at `Object.step` and `cleanupState:"failed"`, with “Device or persistence disposition is incomplete.” [Controller failure](/private/tmp/kobrixa-b2-pressure-native-43adff4/kobrixa-persistence-5fOYMF/storage-ui-pressure.candidate.json.controller-failure.json) records main PID139 exit1 and `remainingChildren:[]`. OS no-survivors does not turn the failed persistence disposition into clean shutdown. All original evidence remains unchanged.

## Binding contract / implementation

- [Frozen §5.4](/Users/kingsley/.codex/worktrees/plugin-3e/Kobrixa/docs/superpowers/specs/2026-10-17-plugin-system-3b2-settings-storage-design.md:348): flush captures a namespace mutation barrier; receiving **or sealed** writes, unfinished checkpoint registrations or unresolved I/O require `flush-incomplete`. It does not seal/commit arbitrary staged data. Final commit precedes successful flush. §10 N15 explicitly prohibits reporting all saved or auto-committing partial payloads.
- [Product storage/flush](/Users/kingsley/.codex/worktrees/plugin-3e/Kobrixa/apps/desktop/src/main/plugins/persistence/record-service.ts:665) checks nonterminal source writes before taking/flushing the evidence barrier. This exactly explains the observed result.
- [Fixture stage/replace/flush](/Users/kingsley/.codex/worktrees/plugin-3e/Kobrixa/tests/desktop/plugin-persistence-pressure.ts:299): stageOne deliberately retains the sealed replacement; replaceOne commits it and removes the held write; flush correctly keeps strict BusinessResult unwrapping.
- `43adff4:tests/desktop/plugin-persistence-main.ts` step sequence above is the misuse. Its finish hook does cleanup then flush, but only on normal completion; the generic UI runner does not invoke workload finish in its finally block.
- [Unit storage double](/Users/kingsley/.codex/worktrees/plugin-3e/Kobrixa/tests/desktop/plugin-persistence-pressure.test.mjs:151) always returns successful flush even with entries in `writes`. This is why the public contract mismatch escaped pure coverage.

## Smallest correct patch and regressions

Proposed exact files (no product/SDK edits):

1. `tests/desktop/plugin-persistence-main.ts`: use `burst → replace → flush → stage → stagingStatus → inventory`. Successful flush occurs in the real settled interval after committing both held replacements, before staging the next pair. Keep concurrent provider/UI execution, restore the two maximum sealed reservations before returning each step, retain staging proof and all existing limits. Capture truthful timestamps: flush is not a measurement made while its own namespace has an incomplete stage. Do not drop staging or extend its TTL to manufacture success.
2. `tests/desktop/plugin-persistence-pressure.ts`: if needed to test the **executed** sequence without importing Electron, extract only this small ordered step into a helper used by main and the existing pure suite. No generalized runner. Preserve `flush()` failure semantics; do not auto-commit/abort secretly in it.
3. `tests/desktop/plugin-persistence-pressure.test.mjs`: make the SDK-shaped store return the real conflict envelope while writes remain. Regression: stage then flush rejects with `flush-incomplete` and retains the exact write; the actual shared step commits, successfully flushes, then restores one sealed 8MiB stage per owner. Verify counts remain 25 each and the staged payload is not spuriously committed by flush. Inject flush rejection into the ordered step: no restage, no success sample, original business cause retained.

In the same main-only correction, propagate settled rejection reasons (aggregate if both provider and storage failed) rather than replacing them with a status equality assertion. On failure, after settling the already-started owner commands, explicitly attempt each owner’s existing cleanup command before composition retirement; retain the original failure and any cleanup failures. Do not use automatic final publication to “clean” a failed benchmark and do not suppress unknown disposition. Successful-path cleanup/flush stays required. A focused negative test should prove failure cleanup is attempted for both owners and cannot turn the run into PASS.

One focused pure regression run plus scoped typing/lint is sufficient before a fresh controller native run. The saved run cannot be repaired or relabeled passed. It proves initial data/verification and the first rejection only; no completed pressure sample set, ten-minute workload, memory gate, or clean persistence shutdown is established.
