# Pressure fixture fix — stopped, ready for controller native verification

Exact pressure write set:
- tests/desktop/plugin-persistence-main.ts: register only pressure-a/pressure-b for pressure; preserve reference panels in other cases.
- tests/desktop/plugin-persistence-interop.test.mjs: role selection regression.
- tests/desktop/declarative-ui-load-renderer.tsx: use original createPluginUiWindow with actual preload UI/recovery, SettingsStore, and storage, without optional device migration adapter. Preserve initial environment, visibility/focus/blur, pagehide and explicit idempotent disposal/listener removal.

This standalone fixture claims foundation UI load, not actual device migration. Earlier invalid-descriptor errors reflected requesting device migration from a fixture without that host attachment. No descriptor guard changes, error catching/silencing, fake bridges, or zero-panel oracle relaxation. Eight UI sources still load normally; two storage consumers register without unrelated reference panels.

## Isolated handoff

`/private/tmp/b2-pressure-complete-only.patch` includes all three pressure deltas and excludes semantic work. The old roles-only patch remains available. Do not stage the entire main working diff: it contains separate semantic integration. Nothing staged by this agent.

## Verification

- 22 PASS: `node --experimental-transform-types --import /private/tmp/b2-semantic-test-alias.mjs --test --test-name-pattern='pressure builtin roles|T7fix' tests/desktop/plugin-persistence-interop.test.mjs`.
- PASS: D node_modules/.bin/tsc -p /private/tmp/b2-pressure-renderer-tsconfig.json (E source, actual renderer/window.d.ts plus temporary CSS declaration).
- PASS: D node_modules/.bin/eslint --config /private/tmp/e1-final-eslint.config.mjs on the three listed files.
- PASS: git diff --check. Renderer Prettier unchanged after formatting.
- No native/build/install/commit. Native outcome remains unverified until controller rerun.

## Stopped hashes

```json
{
  "head": "284b26442f15b99da9c8dd7a2224087ebbf4d6ee",
  "patch": "/private/tmp/b2-pressure-complete-only.patch",
  "patchSha256": "1cf23ffbea481cd6659cdd17dfb4bef4b845981924a5bb23f6262c14aa40419f",
  "files": {
    "tests/desktop/plugin-persistence-main.ts": "595e6ba0990bc20a80542640f1ac0a0dae05ab15aea17688362be41fb2c48c0b",
    "tests/desktop/plugin-persistence-interop.test.mjs": "5019ce8020f6ffd479e0bd6b0f5ecb67f80ac4c37a6a4bfb32436cf9304c43d9",
    "tests/desktop/declarative-ui-load-renderer.tsx": "ca5e2b4a51470f28c287eff6c879fde038861f9f059f649203bdd0a3f474ed59"
  },
  "note": "main working hash includes semantic changes; isolated patch includes only pressure roles/test and standalone renderer attachment"
}
```

## Semantic module status (separate, preserved and unstaged)

Eight explicit semantic cuts implemented: before/after plan, attempt admission, trusted-host skip, and actual composition barrier publication. Shared storage evidence remains bounded; 50 actual 8 MiB originals, 49 destinations only for skip. Six publication paths preserved. Main/run have pending explicit integration. New import-boundaries.ts/.test.mjs plus import.ts/.test.mjs hold producer/oracles; no pressure core files edited.

Previously completed scoped checks: 23 semantic tests PASS, 45 slice regression tests PASS, semantic TypeScript/lint PASS. These are pure verification, not native boundary coverage. Raw/consumption and the full 18-boundary matrix remain OPEN.

One integration scope still needed before semantic native: plugin-persistence-harness.mjs verifyRunReceipt currently always dispatches import slices to the six-publication oracle. Proposed exact dispatch-only patch: /private/tmp/b2-semantic-harness-proposed.patch. It selects the semantic oracle only for the eight explicit cuts; keeps pressure and full-foundation partial-report rejection unchanged. Harness remains untouched pending authorization. No workaround or fabricated full-foundation PASS.
