# B2 pressure pacing — stopped handoff

Changed only these E files:
- tests/desktop/plugin-persistence-pressure.ts
- tests/desktop/plugin-persistence-pressure.test.mjs
- tests/desktop/plugin-persistence-main.ts (pressure callsite only; other raw additions preserved)

Fixed minimum 5,000ms monotonic pacing is anchored to the previous two source stage-command completion observations. This conservatively spaces actual replacement admissions by at least five seconds. The asynchronous pause precedes step/RPC timing and leaves the event loop available for UI updates. The receipt retains initial stage observations and each step's previous stages, wait start, due time, release time and measurement phases. The outside oracle checks their ordering. Early timer wakes recheck the monotonic deadline; cancellation/errors do not retry mutations or extend expiry.

Unchanged: 600-second driver, 50×8MiB records, two sealed stages between steps, actual four-job burst, 30 samples, 1,000 UI cycles, public deadlines, terminal retention, quotas and expiry. Flush still occurs in the settled 400MiB interval; each successful step restores 416MiB including two sealed stages. No claim of continuous staging during flush. Existing joined-owner cleanup and original-cause preservation remain in place.

Validation:
- `node --experimental-transform-types --test tests/desktop/plugin-persistence-pressure.test.mjs`: 26 PASS, zero skipped/failed. Log: /private/tmp/b2-pressure-pacing-pure.log.
- D node_modules/.bin/tsc -p /private/tmp/b2-pressure-integration-tsconfig.json: PASS. Log: /private/tmp/b2-pressure-pacing-types.log.
- D node_modules/.bin/eslint -c /private/tmp/e1-final-eslint.config.mjs tests/desktop/plugin-persistence-pressure.ts tests/desktop/plugin-persistence-pressure.test.mjs tests/desktop/plugin-persistence-main.ts: PASS.

New regressions model 25 seed terminal reservations per source plus replacement admissions through 600 seconds and 180 seconds of overrun, including late wakeups. Retained terminal plus live reservations remain below 64 (asserted conservative bound <=51), with at least 30 iterations in 600 seconds. Additional checks reject early release/RPC overlap with pacing and cover cancellation, event-loop progress, early timer wakeups, clock regression and wait failure. Existing owner cleanup failure tests also pass.

SHA-256 stopped hashes:
- pressure.ts: da605cbb38aca6ce3f20e67ef8c9a8b21b692dd6266c5cad6a6f929c31f3ef45
- pressure.test.mjs: 1abaedb6a51a18da417ed6a47eecc3e92d23a1200412b75c662ba5c34cb59fa7
- main.ts: 7a7bbb368c620e891165706ffcfdf09e3f09772220d81867c9076d7b93913603

Native failure receipts are untouched. No native execution, build, install, product change or git operation performed. Fresh controller native execution remains required; these checks do not establish runtime pressure acceptance or resolve the separate RSS attribution gate. Writes stopped.
