import {parentPort} from 'node:worker_threads';
import {appendFileSync} from 'node:fs';
import {WorkQueue} from "/workspace/apps/desktop/src/main/plugins/persistence/quota.ts";
import {PersistenceWorkerRequest} from "/workspace/apps/desktop/src/main/plugins/persistence/worker.ts";
import {persistenceOwnerSchema} from "/workspace/apps/desktop/src/main/plugins/persistence/namespace.ts";
import {attachPressureWorkerTrace} from "/workspace/tests/desktop/plugin-persistence-pressure-observer.ts";
import {runSyntheticPersistenceWorker} from "/workspace/tests/desktop/fixtures/plugin-persistence/kill-worker.mjs";
attachPressureWorkerTrace({Queue:WorkQueue,port:parentPort,
parseRequest:raw=>{const p=PersistenceWorkerRequest.safeParse(raw);return p.success?p.data:null},
parseOwner:raw=>{const p=persistenceOwnerSchema.safeParse(raw);return p.success?p.data:null},
write:row=>appendFileSync("/evidence/kobrixa-persistence-5fOYMF/pressure-worker.jsonl",JSON.stringify(row)+'\n')});
runSyntheticPersistenceWorker(new Map([['test.synthetic-import',"/evidence/kobrixa-persistence-5fOYMF/synthetic"]]));
